(function(){
  document.addEventListener('submit', function(e){
    var form = e.target;
    if (form && form.querySelector('input[name="action"][value="aiseogeo_run_audit"]')) {
      var btn = form.querySelector('button[type="submit"],button:not([type])');
      if (btn) { btn.disabled = true; btn.textContent = 'Анализ выполняется...'; }
    }
  });
})();

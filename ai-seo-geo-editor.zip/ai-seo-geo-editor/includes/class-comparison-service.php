<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Comparison_Service {
    private $rewrite_service; private $audit_service;
    public function __construct($rewrite_service, $audit_service) { $this->rewrite_service=$rewrite_service; $this->audit_service=$audit_service; }

    public function get_score_comparison($rewrite_id) {
        $rewrite = $this->rewrite_service->get_rewrite($rewrite_id);
        if (!$rewrite) { return array(); }
        $before = $this->audit_service->get_audit((int)$rewrite->audit_id);
        $after = $rewrite->re_audit_id ? $this->audit_service->get_audit((int)$rewrite->re_audit_id) : null;
        $forecast_after = null;
        $is_forecast = false;
        if (!$after && $before && class_exists('AISEOGEO_Search_Forecast_Service')) {
            $forecast_after = AISEOGEO_Search_Forecast_Service::suggested_after_scores($before, $rewrite->rewrite_mode);
            $is_forecast = true;
        }
        $keys = array(
            'overall_score'=>array('label'=>'Общая','forecast_key'=>'overall'),
            'seo_score'=>array('label'=>'SEO','forecast_key'=>'seo'),
            'geo_score'=>array('label'=>'GEO','forecast_key'=>'geo'),
            'eeat_score'=>array('label'=>'EEAT','forecast_key'=>'eeat'),
            'readability_score'=>array('label'=>'Читаемость','forecast_key'=>'readability'),
            'structure_score'=>array('label'=>'Структура','forecast_key'=>'structure'),
            'meta_score'=>array('label'=>'Meta','forecast_key'=>'meta'),
        );
        $out = array();
        foreach ($keys as $k=>$meta) {
            $b = $before ? intval($before->$k) : null;
            if ($after) { $a = intval($after->$k); }
            elseif ($forecast_after) { $a = intval($forecast_after[$meta['forecast_key']] ?? 0); }
            else { $a = null; }
            $out[] = array('label'=>$meta['label'], 'before'=>$b, 'after'=>$a, 'delta'=>($a !== null && $b !== null) ? ($a-$b) : null, 'is_forecast'=>$is_forecast);
        }
        return $out;
    }

    public function get_search_forecast($rewrite_id) {
        $rewrite = $this->rewrite_service->get_rewrite($rewrite_id);
        if (!$rewrite || !class_exists('AISEOGEO_Search_Forecast_Service')) { return array(); }
        $before = $this->audit_service->get_audit((int)$rewrite->audit_id);
        $after = $rewrite->re_audit_id ? $this->audit_service->get_audit((int)$rewrite->re_audit_id) : null;
        return AISEOGEO_Search_Forecast_Service::forecast_from_rewrite($before, $after, $rewrite);
    }

    public function get_content_change_summary($rewrite_id) {
        $rewrite = $this->rewrite_service->get_rewrite($rewrite_id);
        if (!$rewrite) { return array(); }

        $old_content = (string)$rewrite->original_content_longtext;
        $new_content = (string)$rewrite->new_content_longtext;
        $old_plain = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($old_content)));
        $new_plain = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($new_content)));

        $old_headings = $this->extract_headings($old_content);
        $new_headings = $this->extract_headings($new_content);
        $old_h_text = array_map(function($h){ return $h['text']; }, $old_headings);
        $new_h_text = array_map(function($h){ return $h['text']; }, $new_headings);

        $added_headings = array_values(array_diff($new_h_text, $old_h_text));
        $removed_headings = array_values(array_diff($old_h_text, $new_h_text));

        $old_links = $this->extract_links($old_content);
        $new_links = $this->extract_links($new_content);
        $removed_links = array_values(array_diff($old_links, $new_links));
        $added_links = array_values(array_diff($new_links, $old_links));

        $old_shortcodes = $this->extract_shortcodes($old_content);
        $new_shortcodes = $this->extract_shortcodes($new_content);
        $removed_shortcodes = array_values(array_diff($old_shortcodes, $new_shortcodes));

        $old_blocks = $this->detect_business_blocks($old_content);
        $new_blocks = $this->detect_business_blocks($new_content);
        $block_rows = array();
        foreach (array('faq'=>'FAQ / Частые вопросы', 'cta'=>'CTA / Следующий шаг', 'summary'=>'Итог / вывод') as $key=>$label) {
            $block_rows[] = array(
                'label' => $label,
                'before' => !empty($old_blocks[$key]),
                'after' => !empty($new_blocks[$key]),
                'status' => (!empty($old_blocks[$key]) && empty($new_blocks[$key])) ? 'removed' : ((!empty($old_blocks[$key]) || !empty($new_blocks[$key])) ? 'present' : 'missing'),
            );
        }

        $title_changed = trim((string)$rewrite->original_title) !== trim((string)$rewrite->new_title) && trim((string)$rewrite->new_title) !== '';
        $excerpt_changed = trim((string)$rewrite->original_excerpt) !== trim((string)$rewrite->new_excerpt) && trim((string)$rewrite->new_excerpt) !== '';

        return array(
            'title_changed' => $title_changed,
            'excerpt_changed' => $excerpt_changed,
            'old_title' => (string)$rewrite->original_title,
            'new_title' => (string)$rewrite->new_title,
            'old_excerpt' => (string)$rewrite->original_excerpt,
            'new_excerpt' => (string)$rewrite->new_excerpt,
            'old_words' => $this->word_count($old_plain),
            'new_words' => $this->word_count($new_plain),
            'old_headings_count' => count($old_headings),
            'new_headings_count' => count($new_headings),
            'added_headings' => array_slice($added_headings, 0, 20),
            'removed_headings' => array_slice($removed_headings, 0, 20),
            'old_links_count' => count($old_links),
            'new_links_count' => count($new_links),
            'added_links' => array_slice($added_links, 0, 20),
            'removed_links' => array_slice($removed_links, 0, 20),
            'old_shortcodes_count' => count($old_shortcodes),
            'new_shortcodes_count' => count($new_shortcodes),
            'removed_shortcodes' => array_slice($removed_shortcodes, 0, 20),
            'blocks' => $block_rows,
            'content_similarity' => $this->similarity_percent($old_plain, $new_plain),
        );
    }

    private function extract_headings($content) {
        $out = array();
        if (preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\1>/isu', (string)$content, $m, PREG_SET_ORDER)) {
            foreach ($m as $row) {
                $text = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($row[2])));
                if ($text !== '') { $out[] = array('level'=>(int)$row[1], 'text'=>$text); }
            }
        }
        return $out;
    }

    private function extract_links($content) {
        $out = array();
        if (preg_match_all('/<a\b[^>]*href=["\']([^"\']+)["\']/iu', (string)$content, $m)) {
            foreach ($m[1] as $url) { $out[] = trim(html_entity_decode($url)); }
        }
        return array_values(array_unique(array_filter($out)));
    }

    private function extract_shortcodes($content) {
        $out = array();
        if (preg_match_all('/\[([A-Za-z0-9_\-]+)(?:\s|\]|\/)/u', (string)$content, $m)) {
            foreach ($m[1] as $code) { $out[] = '[' . $code . ']'; }
        }
        return array_values(array_unique(array_filter($out)));
    }

    private function detect_business_blocks($content) {
        $plain = mb_strtolower(trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags((string)$content))));
        return array(
            'faq' => (mb_stripos($plain, 'частые вопросы') !== false || mb_stripos($plain, 'faq') !== false || preg_match('/вопросы\s+и\s+ответы/u', $plain)),
            'cta' => (mb_stripos($plain, 'следующий шаг') !== false || mb_stripos($plain, 'оставить заявку') !== false || mb_stripos($plain, 'получить консультацию') !== false || mb_stripos($plain, 'попробовать') !== false || mb_stripos($plain, 'заказать') !== false),
            'summary' => (mb_stripos($plain, 'итог') !== false || mb_stripos($plain, 'вывод') !== false || mb_stripos($plain, 'что важно запомнить') !== false),
        );
    }

    private function word_count($plain) {
        $plain = trim((string)$plain);
        if ($plain === '') { return 0; }
        preg_match_all('/[\p{L}\p{N}]+/u', $plain, $m);
        return count($m[0]);
    }

    private function similarity_percent($a, $b) {
        $a = mb_substr((string)$a, 0, 6000);
        $b = mb_substr((string)$b, 0, 6000);
        if ($a === '' && $b === '') { return 100; }
        similar_text($a, $b, $pct);
        return (int)round($pct);
    }

}

<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Детерминированные гейты качества — порт Python-инструментов статейника:
 *   ai-cadence-check.py + structure-check.py + AI-detection (этап 15).
 * Все проверки механические, без AI. Возвращают список нарушений с приоритетом.
 */
class AISEOGEO_Quality_Gates {

    // ── Раздел 1: Unicode-маркеры (этап 15, Слой A — HARD) ──────────────────
    public function check_unicode($text) {
        $issues = array();
        $markers = array(
            '/\x{2014}/u' => 'Длинное тире — (U+2014)',
            '/\x{2013}/u' => 'Короткое тире – (U+2013)',
            '/\x{2026}/u' => 'Многоточие … одним символом (U+2026)',
            '/[\x{201C}\x{201D}]/u' => 'Типографские кавычки " " (U+201C/201D)',
            '/[\x{2018}\x{2019}]/u' => 'Типографские апострофы \' \' (U+2018/2019)',
            '/[\x{200B}\x{200C}\x{200D}\x{FEFF}]/u' => 'Скрытые байты zero-width/BOM',
            '/\x{00A0}/u' => 'Non-breaking space (U+00A0)',
        );
        foreach ($markers as $re => $label) {
            $n = preg_match_all($re, $text);
            if ($n > 0) { $issues[] = array('level' => 'hard', 'rule' => 'unicode', 'msg' => $label . ': ' . $n . ' шт', 'count' => $n); }
        }
        return $issues;
    }

    // ── Принудительная авто-замена unicode (детерминирована) ────────────────
    public function fix_unicode($text) {
        $text = preg_replace('/\x{2014}/u', '-', $text);
        $text = preg_replace('/\x{2013}/u', '-', $text);
        $text = preg_replace('/\x{2026}/u', '...', $text);
        $text = preg_replace('/[\x{2018}\x{2019}]/u', "'", $text);
        $text = preg_replace('/[\x{200B}\x{200C}\x{200D}\x{FEFF}]/u', '', $text);
        $text = preg_replace('/\x{00A0}/u', ' ', $text);
        // Типографские кавычки → ёлочки (русская типографика)
        $text = preg_replace('/\x{201C}/u', '«', $text);
        $text = preg_replace('/\x{201D}/u', '»', $text);
        return $text;
    }

    // ── Разделы 2-12: AI-почерк (ai-cadence-check.py) ───────────────────────
    public function check_ai_cadence($text) {
        $plain = $this->strip_markup($text);
        $issues = array();

        // Раздел 2: симметрии «не А, а Б» — допустимо max 1
        $n = preg_match_all('/ не [^.,;:!?]{1,40}, а [^.,;:!?]{1,40}/u', $plain);
        if ($n > 1) { $issues[] = $this->iss('warn', 'symmetry', "Симметрий «не А, а Б»: $n (допустимо max 1)"); }

        // Раздел 2.1: «Это не X. Это Y» через точку — НОЛЬ раз
        $n = preg_match_all('/(это|дело)\s+не\s+[^.,;:!?]{1,45}[.,—\-]\s*(это|дело)\s/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'symmetry_dot', "«Это не X. Это Y» через точку: $n (запрещено)"); }

        // Раздел 3: одиночные слова через точку «Просто. Понятно. Эффективно.»
        $n = preg_match_all('/(?:^|\s)[А-ЯЁA-Z][а-яёa-z]{2,15}\.\s+[А-ЯЁA-Z][а-яёa-z]{2,15}\.\s+[А-ЯЁA-Z][а-яёa-z]{2,15}\./u', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'staccato', "Удар-удар-удар (слова через точку): $n"); }

        // Раздел 4: литературные обороты
        $literary = '(эпох[аиыу]\s+\S+\s+(?:закончи|ушл|прошл)|настала\s+эра|новая\s+эра|настоящая\s+революция|в\s+мире,?\s+где|в\s+эпоху|новая\s+грамотность|фундаментальн|кардинальн|радикальн|по-настоящему|будущее\s+за\s+теми|это\s+меняет\s+вс[её]|меняет\s+вс[её]|изменил\s+мир)';
        $n = preg_match_all('/' . $literary . '/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'literary', "Литературные обороты/пафос: $n"); }

        // Раздел 5: канцелярит
        $clerical = '(однако|таким\s+образом|важно\s+отметить|стоит\s+отметить|стоит\s+сказать|следует\s+понимать|необходимо\s+учитывать|следует\s+учитывать|как\s+было\s+сказано\s+выше|вышеупомянут|кроме\s+того|более\s+того|при\s+этом\s+важно|также\s+стоит|в\s+заключение|подвед[ёе]м\s+итог|в\s+современном\s+мире|играет\s+(?:ключевую|важную)\s+роль|представляет\s+собой|является\s+неотъемлемой)';
        $n = preg_match_all('/' . $clerical . '/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'clerical', "Канцелярит: $n"); }

        // Раздел 6-7: безличные конструкции + крючки-подзаголовки
        $impersonal = '(вам\s+расскаж|вы\s+узнаете|тебе\s+расскаж|ты\s+узнаешь|здесь\s+объясн|здесь\s+покаж|давайте\s+разбер[ёе]м|давайте\s+рассмотрим|обратите\s+внимание|следует\s+помнить|важно\s+понимать,?\s+что|и\s+самое\s+(?:мощное|важное|интересное)|вот\s+в\s+ч[ёе]м\s+суть|а\s+теперь\s+представь|и\s+тут\s+начинается\s+интересное|самое\s+(?:интересное|важное|мощное))';
        $n = preg_match_all('/' . $impersonal . '/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'impersonal', "Безличные/крючки: $n"); }

        // Раздел 8: шаблонные финалы
        $endings = '(и\s+теперь\s+(?:ты\s+понимаешь|вы\s+понимаете)|именно\s+поэтому|будущее\s+за\s+теми|это\s+и\s+есть)';
        $n = preg_match_all('/' . $endings . '/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'template_end', "Шаблонные финалы: $n"); }

        // Раздел 9: мотивационщина/инфоцыганщина
        $info = '(у\s+тебя\s+получится|верю\s+в\s+тебя|осталось\s+[0-9]+\s+мест|цена\s+вырастет|успей\s+пока|секрет\s+миллион|гарантиру[еюя]|дорогие\s+друзья|солнышки|мои\s+дорогие)';
        $n = preg_match_all('/' . $info . '/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('hard', 'infocig', "Мотивационщина/инфоцыганщина: $n (юр-риск)"); }

        // Раздел 10: стартовые/закрывающие шаблоны
        $start = '(привет,?\s+друзья|сегодня\s+поговорим|в\s+этой\s+статье\s+вы\s+узнаете|здравствуйте,?\s+дорогие|сегодня\s+я\s+хочу\s+поделиться)';
        $n = preg_match_all('/' . $start . '/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'template_start', "Стартовые шаблоны: $n"); }
        $end = '(спасибо\s+за\s+внимание|подписывайтесь\s+на\s+канал|жду\s+вас\s+в\s+комментариях|до\s+новых\s+встреч)';
        $n = preg_match_all('/' . $end . '/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'template_close', "Закрывающие шаблоны: $n"); }

        // Раздел 12: кальки с английского
        $calques = '(delve|moreover|furthermore|leverage|robust|comprehensive|tapestry|\blandscape\b|journey|realm|погружаемся\s+в|меняющемся\s+ландшафте|бесшовн|всеобъемлющ|надёжное\s+решение)';
        $n = preg_match_all('/' . $calques . '/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'calque', "Кальки с английского: $n"); }

        // Суммарная плотность маркеров на 1000 слов (порог 8.0)
        $words = $this->count_words($plain);
        $total = 0;
        foreach ($issues as $i) { if (preg_match('/: (\d+)/', $i['msg'], $m)) { $total += (int)$m[1]; } }
        $density = $words > 0 ? round($total / $words * 1000, 1) : 0;
        if ($density > 8.0) { $issues[] = $this->iss('hard', 'density', "Плотность AI-маркеров: $density на 1000 слов (порог 8.0)"); }

        return array('issues' => $issues, 'density' => $density, 'words' => $words);
    }

    // ── Раздел 11: Burstiness CV (этап 15, Слой C) ──────────────────────────
    public function check_burstiness($text) {
        $plain = $this->strip_markup($text);
        // Разбиваем на предложения
        $sentences = preg_split('/(?<=[.!?])\s+/u', $plain, -1, PREG_SPLIT_NO_EMPTY);
        $lengths = array();
        foreach ($sentences as $s) {
            $wc = $this->count_words($s);
            if ($wc > 0) { $lengths[] = $wc; }
        }
        if (count($lengths) < 5) { return array('cv' => null, 'verdict' => 'мало предложений', 'issues' => array()); }
        $mean = array_sum($lengths) / count($lengths);
        $var = 0;
        foreach ($lengths as $l) { $var += pow($l - $mean, 2); }
        $std = sqrt($var / count($lengths));
        $cv = $mean > 0 ? round($std / $mean, 2) : 0;
        $issues = array();
        $verdict = 'живой';
        if ($cv < 0.40) { $verdict = 'слишком ровно (машинный ритм)'; $issues[] = $this->iss('warn', 'burstiness', "Ритм CV=$cv < 0.40 — текст слишком ровный, машинный"); }
        elseif ($cv < 0.55) { $verdict = 'средний'; }
        return array('cv' => $cv, 'verdict' => $verdict, 'issues' => $issues, 'sentences' => count($lengths));
    }

    // ── structure-check.py: структура статьи ────────────────────────────────
    public function check_structure($html, $opts = array()) {
        $issues = array();
        $min_internal = $opts['min_internal_links'] ?? 3;
        $site_host    = $opts['site_host'] ?? '';

        // 1. H1 в теле быть не должно (WP рендерит заголовок отдельно), но H2 нужны
        $h2_count = preg_match_all('/<h2[^>]*>(.*?)<\/h2>/isu', $html, $h2m);
        if ($h2_count === 0) { $issues[] = $this->iss('hard', 'no_h2', 'Нет ни одного H2 — статья без структуры'); }
        elseif ($h2_count < 8)  { $issues[] = $this->iss('warn', 'few_h2', "H2 разделов: $h2_count (норма 8-14)"); }
        elseif ($h2_count > 14) { $issues[] = $this->iss('warn', 'many_h2', "H2 разделов: $h2_count (норма 8-14, объединить)"); }

        // 2. Пустые H2 (нет контента до следующего заголовка)
        if (preg_match_all('/<h2[^>]*>.*?<\/h2>(.*?)(?=<h2|$)/isu', $html, $sections)) {
            $empty = 0;
            foreach ($sections[1] as $sec) { if (trim(wp_strip_all_tags($sec)) === '') { $empty++; } }
            if ($empty > 0) { $issues[] = $this->iss('warn', 'empty_h2', "Пустых H2 без текста: $empty"); }
        }

        // 3. Блок источников
        if (!preg_match('/<h[23][^>]*>\s*источник/iu', $html) && stripos($html, 'Источники') === false) {
            $issues[] = $this->iss('warn', 'no_sources', 'Нет блока «Источники»');
        } else {
            // ≥5 ссылок в источниках
            $src_links = 0;
            if (preg_match('/источник[иов]*[\s\S]*$/iu', $html, $sm)) { $src_links = preg_match_all('/<a\s[^>]*href/i', $sm[0]); }
            if ($src_links < 5) { $issues[] = $this->iss('warn', 'few_sources', "Ссылок в источниках: $src_links (норма ≥5)"); }
        }

        // 4. Внутренние ссылки (на свой домен или относительные)
        $internal = 0;
        if (preg_match_all('/<a\s[^>]*href=["\']([^"\']+)["\']/i', $html, $links)) {
            foreach ($links[1] as $href) {
                if (strpos($href, '/') === 0 && strpos($href, '//') !== 0) { $internal++; }
                elseif ($site_host && stripos($href, $site_host) !== false) { $internal++; }
            }
        }
        if ($internal < $min_internal) { $issues[] = $this->iss('warn', 'few_internal', "Внутренних ссылок: $internal (норма ≥$min_internal)"); }

        // 5. Alt у картинок
        if (preg_match_all('/<img\b[^>]*>/i', $html, $imgs)) {
            $no_alt = 0;
            foreach ($imgs[0] as $img) { if (!preg_match('/\balt=["\'][^"\']+["\']/i', $img)) { $no_alt++; } }
            if ($no_alt > 0) { $issues[] = $this->iss('warn', 'img_no_alt', "Картинок без alt: $no_alt"); }
        }

        return array('issues' => $issues, 'h2_count' => $h2_count);
    }

    // ── SEO/GEO-гейт (checklists/seo-geo.md, раздел 2) ──────────────────────
    public function check_seo_geo($html) {
        $issues = array();

        // 2.2: ≥50% H2 в форме вопроса
        $h2_total = preg_match_all('/<h2[^>]*>(.*?)<\/h2>/isu', $html, $h2m);
        if ($h2_total > 0) {
            $q = 0;
            foreach ($h2m[1] as $h) {
                $ht = wp_strip_all_tags($h);
                if (preg_match('/\?\s*$/u', $ht) || preg_match('/^(как|что|зачем|почему|когда|где|какой|какая|сколько|нужно\s+ли|стоит\s+ли)\b/iu', trim($ht))) { $q++; }
            }
            $pct = round($q / $h2_total * 100);
            if ($pct < 50) { $issues[] = $this->iss('warn', 'few_question_h2', "H2 в форме вопроса: $pct% (норма ≥50%)"); }
        }

        // 2.5: минимум 1 сравнительная таблица
        if (preg_match_all('/<table[^>]*>/i', $html) < 1) {
            $issues[] = $this->iss('soft', 'no_table', 'Нет ни одной таблицы (сравнения = таблицы)');
        }

        // 2.4: абзацы 2-4 предложения (флаг длинных)
        if (preg_match_all('/<p[^>]*>(.*?)<\/p>/isu', $html, $ps)) {
            $long = 0;
            foreach ($ps[1] as $p) {
                $sc = preg_match_all('/[.!?]+/u', wp_strip_all_tags($p));
                if ($sc > 5) { $long++; }
            }
            if ($long > 2) { $issues[] = $this->iss('soft', 'long_paragraphs', "Длинных абзацев (>5 предложений): $long"); }
        }

        // 2.3: standalone — нет отсылок «как мы видели выше»
        $n = preg_match_all('/(как\s+(?:мы\s+)?видели\s+выше|выше\s+упомянут|ниже\s+(?:мы\s+)?рассмотрим|продолжая\s+тему|в\s+продолжение|как\s+(?:было\s+)?сказано\s+(?:выше|ранее))/iu', wp_strip_all_tags($html));
        if ($n > 0) { $issues[] = $this->iss('warn', 'not_standalone', "Отсылок к соседним разделам: $n (нарушает standalone)"); }

        return array('issues' => $issues);
    }

    // ── Compliance-гейт (checklists/compliance.md) ──────────────────────────
    public function check_compliance($html) {
        $issues = array();
        $plain = wp_strip_all_tags($html);

        // 14.2: гарантии результата
        $n = preg_match_all('/(гарантиру[еюя]|100%\s*результат|стопроцентн|обязательно\s+(получите|заработаете)|гарантированно|обещаем\s+(результат|заработок)|гаранти[яю]\s+трудоустройства)/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('hard', 'guarantee', "Обещания гарантированного результата: $n (юр-риск, STOP)"); }

        // 14.3: ложная срочность
        $n = preg_match_all('/(осталось\s+[0-9]+\s+мест|успей|только\s+сегодня|до\s+полуночи|последний\s+шанс|цена\s+вырастет\s+через)/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('hard', 'urgency', "Ложная срочность: $n (юр-риск, STOP)"); }

        // 14.5: PII — email/телефоны (кроме служебных)
        $n = preg_match_all('/[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]{2,}/iu', $plain);
        if ($n > 0) { $issues[] = $this->iss('warn', 'pii_email', "Email-адресов в тексте: $n (проверить — PII)"); }

        return array('issues' => $issues);
    }

    // ── Полный прогон всех гейтов ───────────────────────────────────────────
    public function run_all($html, $opts = array()) {
        $unicode    = $this->check_unicode($html);
        $cadence    = $this->check_ai_cadence($html);
        $burst      = $this->check_burstiness($html);
        $structure  = $this->check_structure($html, $opts);
        $seo_geo    = $this->check_seo_geo($html);
        $compliance = $this->check_compliance($html);

        $all = array_merge(
            $unicode,
            $cadence['issues'],
            $burst['issues'],
            $structure['issues'],
            $seo_geo['issues'],
            $compliance['issues']
        );

        $hard = 0; $warn = 0; $soft = 0;
        foreach ($all as $i) {
            if ($i['level'] === 'hard') { $hard++; }
            elseif ($i['level'] === 'warn') { $warn++; }
            else { $soft++; }
        }

        // AI-score 0-100 (выше = хуже): плотность + burstiness
        $ai_score = min(100, round($cadence['density'] * 6 + ($burst['cv'] !== null && $burst['cv'] < 0.40 ? 30 : 0) + $hard * 10));

        return array(
            'issues'     => $all,
            'hard'       => $hard,
            'warn'       => $warn,
            'soft'       => $soft,
            'density'    => $cadence['density'],
            'cv'         => $burst['cv'],
            'h2_count'   => $structure['h2_count'],
            'ai_score'   => $ai_score,
            'verdict'    => $hard === 0 ? ($warn <= 3 ? 'clean' : 'soft_warn') : 'blocked',
        );
    }

    // ── Helpers ──────────────────────────────────────────────────────────────
    private function strip_markup($text) {
        $text = preg_replace('/```.*?```/su', ' ', $text);
        $text = preg_replace('/`[^`]*`/u', ' ', $text);
        $text = wp_strip_all_tags($text);
        return $text;
    }
    private function count_words($text) { preg_match_all('/[\p{L}\p{N}]+/u', (string)$text, $m); return count($m[0]); }
    private function iss($level, $rule, $msg) { return array('level' => $level, 'rule' => $rule, 'msg' => $msg); }
}

<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Audit_Result_Parser {
    public function parse($content) {
        $json = AISEOGEO_JSON_Helper::parse($content);
        if (is_wp_error($json)) { return $json; }
        $defaults = array(
            'overall_score'=>0,'seo_score'=>0,'geo_score'=>0,'eeat_score'=>0,'readability_score'=>0,'structure_score'=>0,'meta_score'=>0,'internal_links_score'=>0,'anti_ai_score'=>0,
            'geo_violations'=>array(),'anti_ai_violations'=>array(),'structure_violations'=>array(),
            'summary'=>'','main_problems'=>array(),'quick_wins'=>array(),'critical_issues'=>array(),'recommended_actions'=>array(),'suggested_title'=>'','suggested_meta_description'=>'','suggested_h2'=>array(),'suggested_faq'=>array(),'schema_recommendation'=>'','rewrite_needed'=>false,'rewrite_priority'=>'medium','rewrite_strategy'=>''
        );
        $json = wp_parse_args($json, $defaults);

        foreach (array('main_problems','quick_wins','critical_issues','recommended_actions','suggested_h2') as $key) {
            $json[$key] = $this->normalize_list($json[$key]);
        }
        $json['suggested_faq'] = $this->normalize_faq($json['suggested_faq']);
        foreach (array('summary','suggested_title','suggested_meta_description','schema_recommendation','rewrite_priority','rewrite_strategy') as $key) {
            $json[$key] = $this->value_to_text($json[$key]);
        }
        $json['rewrite_needed'] = filter_var($json['rewrite_needed'], FILTER_VALIDATE_BOOLEAN);
        return $json;
    }

    private function normalize_list($value) {
        if (empty($value)) { return array(); }
        if (!is_array($value)) { $value = array($value); }
        $out = array();
        foreach ($value as $item) {
            $text = $this->value_to_text($item);
            if ($text !== '') { $out[] = $text; }
        }
        return array_values(array_unique($out));
    }

    private function normalize_faq($value) {
        if (empty($value)) { return array(); }
        if (!is_array($value)) { return array(array('question'=>'','answer'=>$this->value_to_text($value))); }
        $out = array();
        foreach ($value as $item) {
            if (is_array($item)) {
                $q = $this->value_to_text($item['question'] ?? ($item['q'] ?? ''));
                $a = $this->value_to_text($item['answer'] ?? ($item['a'] ?? ''));
                if ($q === '' && $a === '') { $a = $this->value_to_text($item); }
                if ($q !== '' || $a !== '') { $out[] = array('question'=>$q, 'answer'=>$a); }
            } else {
                $a = $this->value_to_text($item);
                if ($a !== '') { $out[] = array('question'=>'', 'answer'=>$a); }
            }
        }
        return $out;
    }

    private function value_to_text($value) {
        if (is_scalar($value) || $value === null) { return sanitize_textarea_field((string)$value); }
        if (!is_array($value)) { return ''; }
        $preferred = array('problem','issue','title','recommendation','action','text','summary','message','question','answer','description','value');
        $parts = array();
        foreach ($preferred as $key) {
            if (isset($value[$key]) && (is_scalar($value[$key]) || $value[$key] === null)) {
                $txt = sanitize_textarea_field((string)$value[$key]);
                if ($txt !== '') { $parts[] = $txt; }
            }
        }
        if (!empty($parts)) { return implode(' — ', array_unique($parts)); }
        foreach ($value as $k => $v) {
            if (is_scalar($v) || $v === null) {
                $txt = sanitize_textarea_field((string)$v);
                if ($txt !== '') { $parts[] = is_string($k) ? ($k . ': ' . $txt) : $txt; }
            }
        }
        return implode('; ', array_unique($parts));
    }
}

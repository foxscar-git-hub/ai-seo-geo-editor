<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Post_Content_Reader {
    public function read($post_id) {
        $post = get_post($post_id);
        if (!$post) { return new WP_Error('post_not_found', 'Запись не найдена.'); }
        $categories = wp_get_post_terms($post_id, 'category', array('fields'=>'names'));
        $tags = wp_get_post_terms($post_id, 'post_tag', array('fields'=>'names'));
        $content = $post->post_content;
        preg_match_all('/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $content, $links);
        $internal = array(); $external = array(); $home = wp_parse_url(home_url(), PHP_URL_HOST);
        foreach ($links[1] ?? array() as $href) {
            $host = wp_parse_url($href, PHP_URL_HOST);
            if (!$host || $host === $home) { $internal[] = esc_url_raw($href); } else { $external[] = esc_url_raw($href); }
        }
        return array(
            'id' => $post->ID,
            'title' => get_the_title($post),
            'slug' => $post->post_name,
            'status' => $post->post_status,
            'excerpt' => $post->post_excerpt,
            'content' => $content,
            'plain_text' => wp_strip_all_tags(strip_shortcodes($content)),
            'categories' => $categories,
            'tags' => $tags,
            'meta_title' => $this->get_meta_title($post_id),
            'meta_description' => $this->get_meta_description($post_id),
            'internal_links' => array_values(array_unique($internal)),
            'external_links' => array_values(array_unique($external)),
            'published_at' => $post->post_date,
            'modified_at' => $post->post_modified,
        );
    }
    private function get_meta_title($post_id) {
        $keys = array('_yoast_wpseo_title','rank_math_title','_aioseo_title');
        foreach ($keys as $key) { $v = get_post_meta($post_id, $key, true); if ($v) { return $v; } }
        return '';
    }
    private function get_meta_description($post_id) {
        $keys = array('_yoast_wpseo_metadesc','rank_math_description','_aioseo_description');
        foreach ($keys as $key) { $v = get_post_meta($post_id, $key, true); if ($v) { return $v; } }
        return '';
    }
}

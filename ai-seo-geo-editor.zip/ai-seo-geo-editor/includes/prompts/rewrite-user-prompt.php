<?php
return <<<'PROMPT'
Перепиши WordPress-статью по методологии «Скилл статей» строго используя черновой контент из плана улучшения.

Данные (статья + план + результаты аудита):
{{PAYLOAD_JSON}}

═══════════════════════════════════════════════
ИСПОЛЬЗУЙ ГОТОВЫЙ КОНТЕНТ ИЗ ПЛАНА
═══════════════════════════════════════════════

В поле `plan` есть готовые черновики — используй их как основу, не изобретай заново:

- `plan.hero_promise_draft` → вставь как Hero Promise блок <div class="hero-promise"> перед первым H2
- `plan.h2_structure_draft[].tldr_draft` → вставь как первый параграф каждого соответствующего H2
- `plan.faq_draft` → используй готовые вопросы и ответы для FAQ-блока
- `plan.comparison_table_draft` → используй как основу для сравнительной таблицы
- `plan.sources_draft` → используй для блока Источники
- `plan.meta_changes.title_draft` → используй как new_title
- `plan.meta_changes.meta_title_draft` → new_meta_title
- `plan.meta_changes.meta_description_draft` → new_meta_description
- `plan.cta_plan.cta_1_draft / cta_2_draft / cta_3_draft` → три CTA-точки
- `plan.anti_ai_fixes.cliches_found` → конкретные клише из статьи — убери их
- `plan.anti_ai_fixes.symmetries_found` → конкретные симметрии — перепиши

═══════════════════════════════════════════════
СТРУКТУРА — добавь в статью:
═══════════════════════════════════════════════
- Hero Promise блок (<div class="hero-promise">) перед первым H2 — из hero_promise_draft
- Answer-First параграф (TL;DR 40-75 слов) в начало КАЖДОГО H2 — из h2_structure_draft
- Минимум 50% H2 в форме вопроса — используй h2_structure_draft как план H2
- 3 CTA-точки на правильных позициях — из cta_plan
- FAQ-блок (<div class="faq-block">) минимум 3 вопроса — из faq_draft
- Блок «Источники» с минимум 5 ссылками — из sources_draft
- Сравнительную таблицу — из comparison_table_draft
- Нумерованные списки для пошаговых процессов
- Минимум 3 внутренние ссылки

ANTI-AI ХУМАНИЗАЦИЯ — обязательно:
- Все — и – заменить на дефис -
- Убрать конкретные клише из anti_ai_fixes.cliches_found
- Убрать симметрии из anti_ai_fixes.symmetries_found
- Убрать запрещённый зачин если найден в anti_ai_fixes.forbidden_opening_found
- Разбить монотонный ритм из anti_ai_fixes.rhythm_blocks

РЕЖИМЫ:
- problem_blocks_only: перепиши только проблемные участки из плана, сохрани остальное
- geo_boost: добавь Answer-First блоки, FAQ, таблицы, источники
- seo_boost: усили H1, мета, структуру H2, внутренние ссылки
- full_refresh: полное переписывание по методологии с использованием ВСЕХ черновиков из плана
- meta_only: только title, description, excerpt (new_content пустой)

Сохраняй: shortcodes, iframe, embed, формы, юридические блоки, изображения — всё из protected_items.
Верни только JSON строго по структуре из system prompt.
PROMPT;

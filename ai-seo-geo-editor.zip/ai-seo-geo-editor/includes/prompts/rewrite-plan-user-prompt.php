<?php
return <<<'PROMPT'
Сформируй план улучшения для WordPress-статьи.

Данные:
{{PAYLOAD_JSON}}

Сначала опирайся на audit.problems, audit.recommendations и выбранный rewrite_mode. План должен быть практичным: что сохраняем, что улучшаем, что добавляем, что не трогаем. Верни только JSON по структуре.
PROMPT;

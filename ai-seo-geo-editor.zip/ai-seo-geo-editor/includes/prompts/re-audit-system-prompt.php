<?php
return include AISEOGEO_DIR . 'includes/prompts/audit-system-prompt.php';

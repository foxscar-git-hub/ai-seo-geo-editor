<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Prompt_Loader {
    public static function audit_system() { return include AISEOGEO_DIR . 'includes/prompts/audit-system-prompt.php'; }
    public static function audit_user($post_data) { $template = include AISEOGEO_DIR . 'includes/prompts/audit-user-prompt.php'; return str_replace('{{POST_JSON}}', wp_json_encode($post_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $template); }
    public static function rewrite_plan_system() { return include AISEOGEO_DIR . 'includes/prompts/rewrite-plan-system-prompt.php'; }
    public static function rewrite_plan_user($payload) { $template = include AISEOGEO_DIR . 'includes/prompts/rewrite-plan-user-prompt.php'; return str_replace('{{PAYLOAD_JSON}}', wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $template); }
    public static function rewrite_system() { return include AISEOGEO_DIR . 'includes/prompts/rewrite-system-prompt.php'; }
    public static function rewrite_user($payload) { $template = include AISEOGEO_DIR . 'includes/prompts/rewrite-user-prompt.php'; return str_replace('{{PAYLOAD_JSON}}', wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $template); }
}

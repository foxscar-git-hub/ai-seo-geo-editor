<?php
return include AISEOGEO_DIR . 'includes/prompts/audit-user-prompt.php';

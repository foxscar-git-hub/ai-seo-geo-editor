<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_License_Client {
    const PRODUCT_KEY = 'ai-seo-geo-editor';

    private $settings;
    private $logger;

    public function __construct($settings, $logger = null) {
        $this->settings = $settings;
        $this->logger = $logger;
    }

    public function init() {}

    public function product_key() {
        return self::PRODUCT_KEY;
    }

    public function license_key() {
        return trim((string)$this->settings->get('license_key', ''));
    }

    public function is_active() {
        return (string)$this->settings->get('license_status', 'not_checked') === 'active' && $this->license_key() !== '';
    }

    public function features() {
        $features = $this->settings->get('license_features', array());
        if (!is_array($features)) { return array(); }
        return array_values(array_unique(array_filter(array_map('sanitize_key', $features))));
    }

    public function plan() {
        if ($this->is_active()) { return 'agency'; }
        return 'free';
    }

    public function feature_allowed($feature) {
        if (!$this->is_active()) { return false; }
        return true;
    }

    public function status() {
        return array(
            'license_key' => $this->mask_key($this->license_key()),
            'product_key' => $this->product_key(),
            'server_url' => '',
            'status' => (string)$this->settings->get('license_status', 'not_checked'),
            'message' => (string)$this->settings->get('license_message', 'Лицензия ещё не проверялась.'),
            'expires_at' => (string)$this->settings->get('license_expires_at', ''),
            'last_checked_at' => (string)$this->settings->get('license_last_checked_at', ''),
            'features' => $this->settings->get('license_features', array()),
        );
    }

    public function save_settings($data) {
        $license_key = sanitize_text_field(wp_unslash($data['license_key'] ?? ''));
        $this->settings->set('license_key', $license_key);
        update_option('aiseogeo_license_key', $license_key, false);
    }

    public function validate() {
        $key = $this->license_key();
        if ($key === '') {
            $this->store_result('empty', 'Лицензионный ключ не указан.', array());
            return new WP_Error('empty_license_key', 'Лицензионный ключ не указан.');
        }

        if (AISEOGEO_License_Keys::is_valid($key)) {
            $features = array('agency');
            $this->store_result('active', 'Лицензия активна. Все функции доступны.', $features, '2030-12-31');
            return $this->status();
        }

        $this->store_result('invalid', 'Неверный лицензионный ключ.', array());
        return new WP_Error('license_not_active', 'Неверный лицензионный ключ.');
    }

    private function store_result($status, $message, $features = array(), $expires_at = '') {
        $this->settings->set('license_status', sanitize_key($status));
        $this->settings->set('license_message', sanitize_text_field($message));
        $this->settings->set('license_features', $features);
        $this->settings->set('license_expires_at', sanitize_text_field($expires_at));
        $this->settings->set('license_last_checked_at', current_time('mysql'));
        if ($this->logger) { $this->logger->log('info', 'license', 'Проверка лицензии: ' . $status . ' — ' . $message); }
    }

    private function mask_key($key) {
        $key = (string)$key;
        if ($key === '') { return ''; }
        if (mb_strlen($key) <= 8) { return str_repeat('•', mb_strlen($key)); }
        return mb_substr($key, 0, 4) . '••••••' . mb_substr($key, -4);
    }
}

<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_JSON_Helper {
    public static function parse($content) {
        if (is_array($content)) { return $content; }
        if (is_object($content)) { return json_decode(wp_json_encode($content), true); }

        $content = self::clean((string)$content);
        $candidates = self::candidates($content);
        $last_error = 'Пустой ответ.';

        foreach ($candidates as $candidate) {
            $decoded = self::decode($candidate, $last_error);
            if (is_array($decoded)) { return $decoded; }
        }

        foreach ($candidates as $candidate) {
            $repairs = self::repair_candidates($candidate);
            foreach ($repairs as $repaired) {
                $decoded = self::decode($repaired, $last_error);
                if (is_array($decoded)) { return $decoded; }
            }
        }

        return new WP_Error('invalid_json', 'AI вернул некорректный JSON. Деталь: ' . $last_error);
    }

    public static function clean($content) {
        $content = (string)$content;
        $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
        if (function_exists('wp_check_invalid_utf8')) {
            $content = wp_check_invalid_utf8($content, true);
        }
        if (function_exists('mb_convert_encoding')) {
            $converted = @mb_convert_encoding($content, 'UTF-8', 'UTF-8');
            if (is_string($converted) && $converted !== '') { $content = $converted; }
        }
        $content = str_replace(array("\xE2\x80\x9C", "\xE2\x80\x9D", "\xE2\x80\x98", "\xE2\x80\x99"), array('"','"',"'","'"), $content);
        $content = str_replace("\r\n", "\n", $content);
        return trim($content);
    }

    private static function candidates($content) {
        $out = array();
        if ($content !== '') { $out[] = $content; }

        if (preg_match_all('/```(?:json)?\s*([\s\S]*?)```/i', $content, $m)) {
            foreach ($m[1] as $block) { $out[] = trim($block); }
        }

        $balanced = self::extract_balanced($content, '{', '}');
        if ($balanced !== '') { $out[] = $balanced; }
        $balanced_arr = self::extract_balanced($content, '[', ']');
        if ($balanced_arr !== '') { $out[] = $balanced_arr; }

        $start = strpos($content, '{');
        $end = strrpos($content, '}');
        if ($start !== false && $end !== false && $end > $start) { $out[] = substr($content, $start, $end - $start + 1); }

        return array_values(array_unique(array_filter(array_map('trim', $out), 'strlen')));
    }

    private static function decode($candidate, &$last_error = '') {
        $decoded = json_decode($candidate, true);
        if (json_last_error() !== JSON_ERROR_NONE) { $last_error = json_last_error_msg(); }
        if (is_string($decoded)) {
            $decoded2 = json_decode($decoded, true);
            if (json_last_error() !== JSON_ERROR_NONE) { $last_error = json_last_error_msg(); }
            if (is_array($decoded2)) { return $decoded2; }
        }
        return is_array($decoded) ? $decoded : null;
    }

    private static function extract_balanced($s, $open, $close) {
        $len = strlen($s);
        $start = strpos($s, $open);
        if ($start === false) { return ''; }
        $depth = 0; $in_string = false; $escape = false;
        for ($i = $start; $i < $len; $i++) {
            $ch = $s[$i];
            if ($escape) { $escape = false; continue; }
            if ($ch === '\\') { $escape = true; continue; }
            if ($ch === '"') { $in_string = !$in_string; continue; }
            if ($in_string) { continue; }
            if ($ch === $open) { $depth++; }
            if ($ch === $close) { $depth--; if ($depth === 0) { return substr($s, $start, $i - $start + 1); } }
        }
        return '';
    }

    private static function repair_candidates($json) {
        $json = trim((string)$json);
        $out = array();
        $out[] = self::repair_loose_json($json);
        $out[] = self::escape_control_chars_in_strings(self::repair_loose_json($json));
        $out[] = self::repair_unescaped_backslashes(self::escape_control_chars_in_strings(self::repair_loose_json($json)));
        return array_values(array_unique(array_filter(array_map('trim', $out), 'strlen')));
    }

    private static function repair_loose_json($json) {
        $json = trim($json);
        $json = preg_replace('/,\s*([}\]])/', '$1', $json);
        $json = preg_replace('/\/\/.*$/m', '', $json);
        $json = preg_replace('/\/\*[\s\S]*?\*\//', '', $json);
        return trim($json);
    }

    private static function escape_control_chars_in_strings($json) {
        $len = strlen($json);
        $out = '';
        $in_string = false;
        $escape = false;
        for ($i = 0; $i < $len; $i++) {
            $ch = $json[$i];
            $ord = ord($ch);
            if ($escape) { $out .= $ch; $escape = false; continue; }
            if ($ch === '\\') { $out .= $ch; $escape = true; continue; }
            if ($ch === '"') { $out .= $ch; $in_string = !$in_string; continue; }
            if ($ord < 32) {
                if ($in_string) {
                    if ($ch === "\n") { $out .= '\\n'; }
                    elseif ($ch === "\r") { $out .= '\\r'; }
                    elseif ($ch === "\t") { $out .= '\\t'; }
                    else { /* drop invalid control char */ }
                } else {
                    if ($ch === "\n" || $ch === "\r" || $ch === "\t" || $ch === ' ') { $out .= $ch; }
                }
                continue;
            }
            $out .= $ch;
        }
        return $out;
    }

    private static function repair_unescaped_backslashes($json) {
        return preg_replace('/\\(?!["\\\/bfnrtu])/', '\\\\', $json);
    }
}

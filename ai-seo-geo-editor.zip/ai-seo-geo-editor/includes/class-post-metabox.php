<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Post_Metabox {
    private $audit_service;
    public function __construct($audit_service) { $this->audit_service = $audit_service; }
    public function init() { add_action('add_meta_boxes', array($this,'add')); }
    public function add() {
        if (!current_user_can('aiseogeo_view_reports')) { return; }
        add_meta_box('aiseogeo_metabox','AI SEO/GEO анализ',array($this,'render'),'post','side','high');
    }
    public function render($post) {
        $latest = $this->audit_service->get_latest_audit($post->ID);
        echo '<div class="aiseogeo-metabox">';
        if ($latest) {
            echo '<p><strong>Последняя оценка:</strong> ' . esc_html($latest->overall_score) . '/100</p>';
            echo '<p>SEO: ' . esc_html($latest->seo_score) . ' · GEO: ' . esc_html($latest->geo_score) . ' · EEAT: ' . esc_html($latest->eeat_score) . '</p>';
            echo '<p><a class="button" href="' . esc_url(admin_url('admin.php?page=aiseogeo-audit-report&audit_id=' . absint($latest->id))) . '">Открыть отчёт</a></p>';
            if (current_user_can('aiseogeo_run_rewrite')) {
                echo '<p><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=aiseogeo-rewrite-create&post_id=' . absint($post->ID) . '&audit_id=' . absint($latest->id))) . '">Создать улучшенную версию</a></p>';
            }
        } else {
            echo '<p>Эта запись ещё не анализировалась.</p>';
            echo '<p class="description">Сначала выполните AI-анализ статьи, чтобы плагин понял, какие блоки нужно улучшить.</p>';
        }
        echo '<p><a class="button" href="' . esc_url(admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post->ID))) . '">AI анализ</a></p>';
        echo '</div>';
    }
}

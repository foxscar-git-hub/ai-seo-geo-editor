<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Draft_Service {
    private $rewrite_service;
    public function __construct($rewrite_service) { $this->rewrite_service = $rewrite_service; }
    public function create_draft_from_rewrite($rewrite_id) {
        if (!current_user_can('aiseogeo_run_rewrite')) { return new WP_Error('forbidden', 'Недостаточно прав.'); }
        $rewrite = $this->rewrite_service->get_rewrite($rewrite_id);
        if (!$rewrite) { return new WP_Error('rewrite_not_found', 'Версия не найдена.'); }
        if ((int)$rewrite->created_draft_post_id > 0 && get_post((int)$rewrite->created_draft_post_id)) { return (int)$rewrite->created_draft_post_id; }
        $source = get_post((int)$rewrite->post_id);
        if (!$source) { return new WP_Error('post_not_found', 'Исходная запись не найдена.'); }
        $postarr = array(
            'post_type' => 'post', 'post_status' => 'draft', 'post_author' => get_current_user_id() ?: $source->post_author,
            'post_title' => $rewrite->new_title ?: $source->post_title,
            'post_excerpt' => $rewrite->new_excerpt ?: $source->post_excerpt,
            'post_content' => $rewrite->new_content_longtext ?: $source->post_content,
        );
        $draft_id = wp_insert_post($postarr, true);
        if (is_wp_error($draft_id)) { return $draft_id; }
        wp_set_object_terms($draft_id, wp_get_post_terms($source->ID, 'category', array('fields'=>'ids')), 'category');
        wp_set_object_terms($draft_id, wp_get_post_terms($source->ID, 'post_tag', array('fields'=>'ids')), 'post_tag');
        $thumb = get_post_thumbnail_id($source->ID);
        if ($thumb) { set_post_thumbnail($draft_id, $thumb); }
        update_post_meta($draft_id, '_aiseogeo_source_post_id', $source->ID);
        update_post_meta($draft_id, '_aiseogeo_rewrite_id', (int)$rewrite->id);
        update_post_meta($draft_id, '_aiseogeo_is_ai_draft', '1');
        if ($rewrite->new_meta_title) { update_post_meta($draft_id, '_aiseogeo_suggested_meta_title', $rewrite->new_meta_title); }
        if ($rewrite->new_meta_description) { update_post_meta($draft_id, '_aiseogeo_suggested_meta_description', $rewrite->new_meta_description); }
        $this->rewrite_service->mark_draft_created($rewrite->id, $draft_id);
        return $draft_id;
    }
}

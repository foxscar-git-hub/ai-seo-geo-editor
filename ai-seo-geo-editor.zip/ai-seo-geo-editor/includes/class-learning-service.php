<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Auto-learning service.
 * Evaluates rewrite outcomes, extracts patterns, injects insights into prompts.
 */
class AISEOGEO_Learning_Service {

    private $settings;
    private $logger;

    public function __construct($settings, $logger) {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    /* ── Tables ──────────────────────────────────────────────────────────── */

    public function table_learning()  { global $wpdb; return $wpdb->prefix . 'aiseogeo_learning'; }
    public function table_rewrites()  { global $wpdb; return $wpdb->prefix . 'aiseogeo_rewrites'; }
    public function table_audits()    { global $wpdb; return $wpdb->prefix . 'aiseogeo_audits'; }

    /* ── Init ────────────────────────────────────────────────────────────── */

    public function init() {
        if ($this->settings->get('learning_enabled', '0') !== '1') { return; }
        add_action('aiseogeo_daily_evaluate', array($this, 'run_daily_evaluation'));
        if (!wp_next_scheduled('aiseogeo_daily_evaluate')) {
            wp_schedule_event(time() + 3600, 'daily', 'aiseogeo_daily_evaluate');
        }
    }

    /* ── Daily Evaluation (WP-Cron) ─────────────────────────────────────── */

    public function run_daily_evaluation() {
        global $wpdb;
        $min_days  = max(1, (int)$this->settings->get('learning_min_days', '14'));
        $threshold = max(0, (int)$this->settings->get('learning_views_threshold', '20'));
        $cutoff    = date('Y-m-d H:i:s', strtotime("-{$min_days} days"));

        $rewrites = $wpdb->get_results($wpdb->prepare(
            "SELECT r.*, a.geo_score, a.seo_score, a.anti_ai_score, a.structure_score, a.eeat_score
             FROM {$this->table_rewrites()} r
             LEFT JOIN {$this->table_audits()} a ON a.rewrite_id = r.id AND a.audit_type = 'post_rewrite'
             WHERE r.rewrite_status = 'done'
               AND r.apply_status   = 'applied'
               AND (r.learning_evaluated IS NULL OR r.learning_evaluated = 0)
               AND r.created_at < %s
             LIMIT 50",
            $cutoff
        ));

        if (empty($rewrites)) { return; }

        $evaluated = 0;
        foreach ($rewrites as $rw) {
            $this->evaluate_rewrite($rw, $threshold);
            $evaluated++;
        }

        $this->logger->log('info', 'learning', "Оценка завершена: {$evaluated} переписываний.", array(), 0);
    }

    private function evaluate_rewrite($rw, $threshold) {
        global $wpdb;

        $post_id = (int)$rw->post_id;
        $post    = get_post($post_id);
        if (!$post) {
            $this->mark_evaluated($rw->id, 0, 0, 'post_not_found');
            return;
        }

        $views_before = (int)get_post_meta($post_id, '_aiseogeo_views_baseline', true);
        $views_now    = (int)get_post_meta($post_id, '_aiseogeo_views', true);
        $comments_now = (int)$post->comment_count;
        $comments_bef = (int)get_post_meta($post_id, '_aiseogeo_comments_baseline', true);

        // WP Statistics integration
        if (function_exists('wp_statistics_post_views')) {
            $views_now = max($views_now, (int)wp_statistics_post_views($post_id));
        }

        $views_growth = $views_before > 0
            ? round(($views_now - $views_before) / $views_before * 100, 1)
            : 0;
        $comments_growth = $comments_bef > 0
            ? round(($comments_now - $comments_bef) / $comments_bef * 100, 1)
            : 0;

        $success = $views_growth >= $threshold || $comments_growth >= $threshold;

        $this->extract_patterns($rw, $views_growth, $comments_growth, $success);
        $this->mark_evaluated($rw->id, $views_growth, (int)$success, '');
    }

    private function mark_evaluated($rewrite_id, $views_growth, $success, $note) {
        global $wpdb;
        $wpdb->update(
            $this->table_rewrites(),
            array(
                'learning_evaluated'    => 1,
                'learning_views_growth' => $views_growth,
                'learning_success'      => $success,
                'learning_note'         => $note,
            ),
            array('id' => $rewrite_id)
        );
    }

    /* ── Pattern Extraction ──────────────────────────────────────────────── */

    private function extract_patterns($rw, $views_growth, $comments_growth, $success) {
        $features = $this->rw_features($rw);
        foreach ($features as $type => $value) {
            $this->upsert_pattern($type, (string)$value, $views_growth, (int)$success);
        }
    }

    private function rw_features($rw) {
        $features = array();

        // Rewrite mode
        if (!empty($rw->rewrite_mode)) {
            $features['mode'] = $rw->rewrite_mode;
        }

        // AI model
        if (!empty($rw->model)) {
            $features['model'] = $rw->model;
        }

        // Structure data from rewrite result JSON
        $result = array();
        if (!empty($rw->result_json)) {
            $result = json_decode($rw->result_json, true) ?: array();
        }

        $struct = $result['structure_added'] ?? array();
        $hum    = $result['humanization_applied'] ?? array();

        if (isset($struct['h2_count']) && (int)$struct['h2_count'] > 0) {
            $h2 = (int)$struct['h2_count'];
            $bucket = $h2 <= 8 ? '6-8' : ($h2 <= 10 ? '9-10' : ($h2 <= 12 ? '11-12' : '13+'));
            $features['h2_count_bucket'] = $bucket;
        }

        if (isset($struct['has_hero_promise'])) {
            $features['has_hero_promise'] = $struct['has_hero_promise'] ? 'yes' : 'no';
        }
        if (isset($struct['has_faq'])) {
            $features['has_faq'] = $struct['has_faq'] ? 'yes' : 'no';
        }
        if (isset($struct['has_sources_block'])) {
            $features['has_sources_block'] = $struct['has_sources_block'] ? 'yes' : 'no';
        }
        if (isset($struct['cta_count'])) {
            $features['cta_count'] = (int)$struct['cta_count'] >= 3 ? '3+' : (string)(int)$struct['cta_count'];
        }
        if (isset($struct['tables_count'])) {
            $features['has_table'] = (int)$struct['tables_count'] > 0 ? 'yes' : 'no';
        }
        if (isset($struct['internal_links_count'])) {
            $il = (int)$struct['internal_links_count'];
            $features['internal_links'] = $il >= 5 ? '5+' : ($il >= 3 ? '3-4' : (string)$il);
        }

        // Scores from post-rewrite audit
        foreach (array('geo_score', 'anti_ai_score', 'structure_score', 'seo_score') as $s) {
            if (!empty($rw->$s)) {
                $v = (int)$rw->$s;
                $bucket = $v >= 80 ? '80-100' : ($v >= 60 ? '60-79' : ($v >= 40 ? '40-59' : '0-39'));
                $features[$s . '_bucket'] = $bucket;
            }
        }

        // Anti-AI fixes applied
        if (!empty($hum['em_dashes_replaced'])) {
            $features['had_em_dashes'] = (int)$hum['em_dashes_replaced'] > 0 ? 'yes' : 'no';
        }

        return $features;
    }

    private function upsert_pattern($type, $value, $views_growth, $success) {
        global $wpdb;
        $table = $this->table_learning();

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE pattern_type=%s AND pattern_value=%s",
            $type, $value
        ));

        $now = current_time('mysql');

        if ($row) {
            $new_total   = $row->total_count + 1;
            $new_success = $row->success_count + $success;
            $new_avg     = round(($row->avg_views_growth * $row->total_count + $views_growth) / $new_total, 2);
            $confidence  = $new_total > 0 ? round($new_success / $new_total * log($new_total + 1), 4) : 0;
            $wpdb->update($table, array(
                'success_count'     => $new_success,
                'total_count'       => $new_total,
                'avg_views_growth'  => $new_avg,
                'confidence'        => $confidence,
                'updated_at'        => $now,
            ), array('id' => $row->id));
        } else {
            $confidence = $success > 0 ? round(log(2), 4) : 0;
            $wpdb->insert($table, array(
                'pattern_type'      => $type,
                'pattern_value'     => $value,
                'success_count'     => $success,
                'total_count'       => 1,
                'avg_views_growth'  => $views_growth,
                'confidence'        => $confidence,
                'created_at'        => $now,
                'updated_at'        => $now,
            ));
        }
    }

    /* ── Prompt Injection ────────────────────────────────────────────────── */

    public function get_insights_block() {
        $min_samples = max(1, (int)$this->settings->get('learning_min_samples', '3'));
        if ($this->settings->get('learning_enabled', '0') !== '1') { return ''; }

        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_learning()}
             WHERE total_count >= %d
             ORDER BY confidence DESC, avg_views_growth DESC
             LIMIT 20",
            $min_samples
        ));

        if (empty($rows)) { return ''; }

        $lines = array();
        foreach ($rows as $row) {
            $label = $this->label($row->pattern_type, $row->pattern_value);
            if (!$label) { continue; }
            $pct   = $row->avg_views_growth >= 0 ? '+' . $row->avg_views_growth . '%' : $row->avg_views_growth . '%';
            $conf  = round($row->success_count / max(1, $row->total_count) * 100);
            $lines[] = "- {$label}: средний рост просмотров {$pct}, успешно в {$conf}% случаев (из {$row->total_count} статей)";
        }

        if (empty($lines)) { return ''; }

        return "\n\n═══════════════════════════════════════════════\n"
             . "ДАННЫЕ АВТООБУЧЕНИЯ (на основе результатов этого сайта)\n"
             . "═══════════════════════════════════════════════\n"
             . "Что реально работает на этом сайте по данным замеров трафика:\n"
             . implode("\n", $lines)
             . "\nИспользуй эти данные как дополнительный сигнал при принятии решений.";
    }

    private function label($type, $value) {
        $map = array(
            'mode'                  => "Режим переписывания «{$value}»",
            'model'                 => "Модель «{$value}»",
            'h2_count_bucket'       => "Статьи с {$value} разделами H2",
            'has_hero_promise'      => $value === 'yes' ? 'Наличие Hero Promise блока' : 'Отсутствие Hero Promise блока',
            'has_faq'               => $value === 'yes' ? 'Наличие FAQ-блока' : 'Отсутствие FAQ-блока',
            'has_sources_block'     => $value === 'yes' ? 'Наличие блока источников' : 'Отсутствие блока источников',
            'cta_count'             => "Статьи с {$value} CTA-точками",
            'has_table'             => $value === 'yes' ? 'Наличие сравнительной таблицы' : 'Отсутствие таблицы',
            'internal_links'        => "Статьи с {$value} внутренними ссылками",
            'geo_score_bucket'      => "GEO-оценка в диапазоне {$value}",
            'anti_ai_score_bucket'  => "Anti-AI оценка в диапазоне {$value}",
            'structure_score_bucket'=> "Оценка структуры в диапазоне {$value}",
            'seo_score_bucket'      => "SEO-оценка в диапазоне {$value}",
            'had_em_dashes'         => $value === 'yes' ? 'Статьи с тире (до чистки)' : 'Статьи без тире',
        );
        return $map[$type] ?? null;
    }

    /* ── Manual trigger ──────────────────────────────────────────────────── */

    public function force_evaluate_all() {
        global $wpdb;
        $wpdb->query("UPDATE {$this->table_rewrites()} SET learning_evaluated = 0 WHERE apply_status = 'applied'");
        $this->run_daily_evaluation();
    }

    /* ── Stats for UI ────────────────────────────────────────────────────── */

    public function stats() {
        global $wpdb;
        $t  = $this->table_rewrites();
        $lp = $this->table_learning();
        return array(
            'patterns'   => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$lp}"),
            'evaluated'  => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE learning_evaluated=1"),
            'successful' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE learning_success=1"),
            'pending'    => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE apply_status='applied' AND learning_evaluated=0"),
            'top'        => $wpdb->get_results(
                $wpdb->prepare("SELECT * FROM {$lp} WHERE total_count >= 2 ORDER BY confidence DESC, avg_views_growth DESC LIMIT 10", array())
            ),
        );
    }

    public function get_all_patterns($limit = 100) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_learning()} ORDER BY confidence DESC, total_count DESC LIMIT %d",
            $limit
        ));
    }
}

<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Updater {
    const UPDATE_URL = 'https://raw.githubusercontent.com/foxscar-git-hub/ai-seo-geo-editor/main/update.json';
    const CACHE_KEY = 'aiseogeo_update_check';
    const CACHE_TTL = 43200;

    private $plugin_slug;
    private $plugin_basename;
    private $current_version;

    public function __construct() {
        $this->plugin_slug = 'ai-seo-geo-editor';
        $this->plugin_basename = defined('AISEOGEO_BASENAME') ? AISEOGEO_BASENAME : 'ai-seo-geo-editor/ai-seo-geo-editor.php';
        $this->current_version = defined('AISEOGEO_VERSION') ? AISEOGEO_VERSION : '0.0.0';
    }

    public function init() {
        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_update'));
        add_filter('plugins_api', array($this, 'plugin_info'), 20, 3);
        add_filter('upgrader_post_install', array($this, 'after_install'), 10, 3);
        add_action('in_plugin_update_message-' . $this->plugin_basename, array($this, 'update_message'), 10, 2);
    }

    private function get_remote_info() {
        $cached = get_transient(self::CACHE_KEY);
        if ($cached !== false) { return $cached; }

        $response = wp_remote_get(self::UPDATE_URL, array(
            'timeout' => 15,
            'headers' => array('Accept' => 'application/json'),
        ));

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if (!$data || empty($data['version'])) { return false; }

        set_transient(self::CACHE_KEY, $data, self::CACHE_TTL);
        return $data;
    }

    public function check_update($transient) {
        if (empty($transient->checked)) { return $transient; }

        $remote = $this->get_remote_info();
        if (!$remote || !isset($remote['version'])) { return $transient; }

        if (version_compare($remote['version'], $this->current_version, '>')) {
            $plugin = new stdClass();
            $plugin->slug = $this->plugin_slug;
            $plugin->plugin = $this->plugin_basename;
            $plugin->new_version = $remote['version'];
            $plugin->url = $remote['homepage'] ?? '';
            $plugin->package = $remote['download_url'] ?? '';
            $plugin->icons = $remote['icons'] ?? array();
            $plugin->banners = $remote['banners'] ?? array();
            $plugin->tested = $remote['tested'] ?? '';
            $plugin->requires_php = $remote['requires_php'] ?? '7.4';
            $plugin->requires = $remote['requires'] ?? '5.6';
            $transient->response[$this->plugin_basename] = $plugin;
        } else {
            $plugin = new stdClass();
            $plugin->slug = $this->plugin_slug;
            $plugin->plugin = $this->plugin_basename;
            $plugin->new_version = $this->current_version;
            $plugin->url = $remote['homepage'] ?? '';
            $plugin->package = '';
            $transient->no_update[$this->plugin_basename] = $plugin;
        }

        return $transient;
    }

    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information' || !isset($args->slug) || $args->slug !== $this->plugin_slug) {
            return $result;
        }

        $remote = $this->get_remote_info();
        if (!$remote) { return $result; }

        $info = new stdClass();
        $info->name = $remote['name'] ?? 'AI SEO/GEO Редактор статей';
        $info->slug = $this->plugin_slug;
        $info->version = $remote['version'];
        $info->author = $remote['author'] ?? '@foxscar';
        $info->homepage = $remote['homepage'] ?? '';
        $info->requires = $remote['requires'] ?? '5.6';
        $info->requires_php = $remote['requires_php'] ?? '7.4';
        $info->tested = $remote['tested'] ?? '';
        $info->download_link = $remote['download_url'] ?? '';
        $info->trunk = $remote['download_url'] ?? '';
        $info->last_updated = $remote['last_updated'] ?? '';

        $info->sections = array(
            'description' => $remote['description'] ?? 'AI SEO/GEO оптимизация статей для WordPress.',
            'changelog' => $remote['changelog'] ?? '',
        );

        if (!empty($remote['banners'])) { $info->banners = $remote['banners']; }
        if (!empty($remote['icons'])) { $info->icons = $remote['icons']; }

        return $info;
    }

    public function after_install($response, $hook_extra, $result) {
        if (!isset($hook_extra['plugin']) || $hook_extra['plugin'] !== $this->plugin_basename) {
            return $response;
        }

        global $wp_filesystem;
        $install_dir = plugin_dir_path(WP_PLUGIN_DIR . '/' . $this->plugin_basename);
        $wp_filesystem->move($result['destination'], $install_dir);
        $result['destination'] = $install_dir;

        if (is_plugin_active($this->plugin_basename)) {
            activate_plugin($this->plugin_basename);
        }

        delete_transient(self::CACHE_KEY);

        return $response;
    }

    public function update_message($plugin_data, $response) {
        $remote = $this->get_remote_info();
        if (!$remote || empty($remote['update_notice'])) { return; }
        echo '<br><strong>Что нового:</strong> ' . wp_kses_post($remote['update_notice']);
    }

    public static function clear_cache() {
        delete_transient(self::CACHE_KEY);
    }
}

<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Updater {
    const UPDATE_URL = 'https://raw.githubusercontent.com/foxscar-git-hub/ai-seo-geo-editor/main/update.json';
    const CACHE_KEY = 'aiseogeo_update_check';
    const CACHE_TTL = 43200;

    private $plugin_slug;
    private $plugin_basename;
    private $current_version;

    public function __construct() {
        $this->plugin_slug = 'ai-seo-geo-editor';
        $this->plugin_basename = defined('AISEOGEO_BASENAME') ? AISEOGEO_BASENAME : 'ai-seo-geo-editor/ai-seo-geo-editor.php';
        $this->current_version = defined('AISEOGEO_VERSION') ? AISEOGEO_VERSION : '0.0.0';
    }

    public function init() {
        add_filter('pre_set_site_transient_update_plugins', array($this, 'check_update'));
        add_filter('plugins_api', array($this, 'plugin_info'), 20, 3);
        add_filter('upgrader_source_selection', array($this, 'fix_source_dir'), 10, 4);
        add_filter('upgrader_post_install', array($this, 'after_install'), 10, 3);
        add_action('in_plugin_update_message-' . $this->plugin_basename, array($this, 'update_message'), 10, 2);
        add_action('admin_init', array($this, 'handle_force_check'));
        add_action('after_plugin_row_' . $this->plugin_basename, array($this, 'force_update_row'), 30, 2);
    }

    private function get_remote_info($force = false) {
        if (!$force) {
            $cached = get_transient(self::CACHE_KEY);
            if ($cached !== false) { return $cached; }
        }

        // Cache-busting: raw.githubusercontent.com кеширует файл в CDN ~5 мин.
        // Уникальный параметр заставляет CDN отдать свежую версию.
        $url = self::UPDATE_URL . '?nocache=' . time();
        $response = wp_remote_get($url, array(
            'timeout' => 15,
            'headers' => array('Accept' => 'application/json', 'Cache-Control' => 'no-cache', 'Pragma' => 'no-cache'),
        ));

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if (!$data || empty($data['version'])) { return false; }

        set_transient(self::CACHE_KEY, $data, self::CACHE_TTL);
        return $data;
    }

    public function check_update($transient) {
        if (empty($transient->checked)) { return $transient; }

        $remote = $this->get_remote_info();
        if (!$remote || !isset($remote['version'])) { return $transient; }

        if (version_compare($remote['version'], $this->current_version, '>')) {
            $plugin = new stdClass();
            $plugin->slug = $this->plugin_slug;
            $plugin->plugin = $this->plugin_basename;
            $plugin->new_version = $remote['version'];
            $plugin->url = $remote['homepage'] ?? '';
            $plugin->package = $remote['download_url'] ?? '';
            $plugin->icons = $remote['icons'] ?? array();
            $plugin->banners = $remote['banners'] ?? array();
            $plugin->tested = $remote['tested'] ?? '';
            $plugin->requires_php = $remote['requires_php'] ?? '7.4';
            $plugin->requires = $remote['requires'] ?? '5.6';
            $transient->response[$this->plugin_basename] = $plugin;
        } else {
            $plugin = new stdClass();
            $plugin->slug = $this->plugin_slug;
            $plugin->plugin = $this->plugin_basename;
            $plugin->new_version = $this->current_version;
            $plugin->url = $remote['homepage'] ?? '';
            $plugin->package = '';
            $transient->no_update[$this->plugin_basename] = $plugin;
        }

        return $transient;
    }

    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information' || !isset($args->slug) || $args->slug !== $this->plugin_slug) {
            return $result;
        }

        $remote = $this->get_remote_info();
        if (!$remote) { return $result; }

        $info = new stdClass();
        $info->name = $remote['name'] ?? 'AI SEO/GEO Редактор статей';
        $info->slug = $this->plugin_slug;
        $info->version = $remote['version'];
        $info->author = $remote['author'] ?? '@foxscar';
        $info->homepage = $remote['homepage'] ?? '';
        $info->requires = $remote['requires'] ?? '5.6';
        $info->requires_php = $remote['requires_php'] ?? '7.4';
        $info->tested = $remote['tested'] ?? '';
        $info->download_link = $remote['download_url'] ?? '';
        $info->trunk = $remote['download_url'] ?? '';
        $info->last_updated = $remote['last_updated'] ?? '';

        $info->sections = array(
            'description' => $remote['description'] ?? 'AI SEO/GEO оптимизация статей для WordPress.',
            'changelog' => $remote['changelog'] ?? '',
        );

        if (!empty($remote['banners'])) { $info->banners = $remote['banners']; }
        if (!empty($remote['icons'])) { $info->icons = $remote['icons']; }

        return $info;
    }

    /**
     * Переименовывает папку распакованного ZIP в правильное имя плагина.
     * WordPress иногда добавляет суффикс к имени папки при распаковке.
     */
    public function fix_source_dir($source, $remote_source, $upgrader, $hook_extra = array()) {
        global $wp_filesystem;

        // Только для нашего плагина
        if (!isset($hook_extra['plugin']) || $hook_extra['plugin'] !== $this->plugin_basename) {
            return $source;
        }

        $correct_name = $this->plugin_slug; // ai-seo-geo-editor
        $source_name  = basename(rtrim($source, '/'));

        if ($source_name === $correct_name) {
            return $source; // уже правильное имя
        }

        // Переименовываем в правильную папку
        $correct_source = trailingslashit(dirname(rtrim($source, '/'))) . $correct_name . '/';
        if ($wp_filesystem->move($source, $correct_source)) {
            return $correct_source;
        }

        return $source;
    }

    public function after_install($response, $hook_extra, $result) {
        if (!isset($hook_extra['plugin']) || $hook_extra['plugin'] !== $this->plugin_basename) {
            return $response;
        }

        // ZIP уже содержит правильную папку ai-seo-geo-editor/ — перемещение не нужно.
        // Только сбрасываем кеш обновлений.
        delete_transient(self::CACHE_KEY);

        return $response;
    }

    public function update_message($plugin_data, $response) {
        $remote = $this->get_remote_info();
        if (!$remote || empty($remote['update_notice'])) { return; }
        echo '<br><strong>Что нового:</strong> ' . wp_kses_post($remote['update_notice']);
    }

    public function handle_force_check() {
        if (!isset($_GET['aiseogeo_force_update_check']) || !current_user_can('update_plugins')) { return; }
        check_admin_referer('aiseogeo_force_update');
        delete_transient(self::CACHE_KEY);
        delete_site_transient('update_plugins');
        $remote = $this->get_remote_info(true);
        $redirect = admin_url('plugins.php');
        if ($remote && version_compare($remote['version'], $this->current_version, '>')) {
            $redirect = add_query_arg('aiseogeo_update_found', $remote['version'], $redirect);
        } else {
            $redirect = add_query_arg('aiseogeo_update_current', '1', $redirect);
        }
        wp_safe_redirect($redirect);
        exit;
    }

    public function force_update_row($plugin_file, $plugin_data) {
        $check_url = wp_nonce_url(admin_url('plugins.php?aiseogeo_force_update_check=1'), 'aiseogeo_force_update');
        $colspan = is_network_admin() ? 4 : 3;

        if (!empty($_GET['aiseogeo_update_found'])) {
            echo '<tr class="plugin-update-tr"><td colspan="' . $colspan . '" class="plugin-update colspanchange"><div class="notice inline notice-warning notice-alt"><p>Доступна версия <strong>' . esc_html(sanitize_text_field($_GET['aiseogeo_update_found'])) . '</strong>. Перейдите в <a href="' . esc_url(admin_url('update-core.php')) . '">Обновления</a> для установки.</p></div></td></tr>';
        } elseif (!empty($_GET['aiseogeo_update_current'])) {
            echo '<tr class="plugin-update-tr"><td colspan="' . $colspan . '" class="plugin-update colspanchange"><div class="notice inline notice-success notice-alt"><p>У вас актуальная версия (' . esc_html($this->current_version) . ').</p></div></td></tr>';
        }

        echo '<tr class="plugin-update-tr aiseogeo-check-row"><td colspan="' . $colspan . '" class="plugin-update colspanchange" style="padding:4px 12px"><a href="' . esc_url($check_url) . '" style="font-size:12px;color:#2271b1">↻ Проверить наличие обновления AI SEO/GEO</a></td></tr>';
    }

    public static function clear_cache() {
        delete_transient(self::CACHE_KEY);
    }
}

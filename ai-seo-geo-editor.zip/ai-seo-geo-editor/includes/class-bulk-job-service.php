<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Bulk_Job_Service {
    private $audit_service; private $rewrite_service; private $logger; private $settings;
    public function __construct($audit_service, $rewrite_service, $logger, $settings) { $this->audit_service=$audit_service; $this->rewrite_service=$rewrite_service; $this->logger=$logger; $this->settings=$settings; }
    public function jobs_table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_jobs'; }
    public function items_table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_job_items'; }
    public function create_job($job_type, $mode, $filter, $limit, $category = 0) {
        if (!current_user_can('aiseogeo_bulk_process')) { return new WP_Error('forbidden','Недостаточно прав для массовой обработки.'); }
        $max = max(1, absint($this->settings->get('bulk_max_items','20')));
        $limit = min(max(1, absint($limit)), $max);
        $filter_service = new AISEOGEO_Post_Filter_Service($this->audit_service);
        $post_ids = $filter_service->get_posts($filter, $limit, $category);
        if (!$post_ids) { return new WP_Error('empty_job','По выбранному фильтру не найдено записей.'); }
        global $wpdb; $now = current_time('mysql');
        $settings = array('filter'=>$filter,'category'=>absint($category),'limit'=>$limit,'delay'=>absint($this->settings->get('bulk_delay_seconds','30')));
        $wpdb->insert($this->jobs_table(), array('job_type'=>sanitize_key($job_type),'job_status'=>'queued','job_mode'=>sanitize_key($mode),'total_items'=>count($post_ids),'settings_json'=>wp_json_encode($settings, JSON_UNESCAPED_UNICODE),'created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now));
        $job_id = (int)$wpdb->insert_id;
        foreach ($post_ids as $post_id) { $wpdb->insert($this->items_table(), array('job_id'=>$job_id,'post_id'=>absint($post_id),'item_status'=>'queued','created_at'=>$now,'updated_at'=>$now)); }
        AISEOGEO_Action_Scheduler::schedule_next($job_id, 5);
        $this->logger->log('info','bulk','Создана массовая задача.',array('job_id'=>$job_id,'total'=>count($post_ids),'type'=>$job_type,'mode'=>$mode));
        return $this->get_job($job_id);
    }
    public function process_next_item($job_id) {
        global $wpdb;
        $job = $this->get_job($job_id);
        if (!$job || !in_array($job->job_status, array('queued','running'), true)) { return false; }
        $wpdb->update($this->jobs_table(), array('job_status'=>'running','started_at'=>$job->started_at ?: current_time('mysql'),'updated_at'=>current_time('mysql')), array('id'=>$job->id));
        $item = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->items_table()} WHERE job_id=%d AND item_status='queued' ORDER BY id ASC LIMIT 1", $job->id));
        if (!$item) { $this->recount_job($job->id, true); return false; }
        $wpdb->update($this->items_table(), array('item_status'=>'running','started_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')), array('id'=>$item->id));
        $error = ''; $audit_id = 0; $rewrite_id = 0;
        try {
            if ($job->job_type === 'audit') {
                $audit = $this->audit_service->run_audit((int)$item->post_id);
                if (is_wp_error($audit)) { throw new Exception($audit->get_error_message()); }
                $audit_id = (int)$audit->id;
            } elseif ($job->job_type === 'audit_rewrite') {
                $audit = $this->audit_service->get_latest_audit((int)$item->post_id);
                if (!$audit) { $audit = $this->audit_service->run_audit((int)$item->post_id); }
                if (is_wp_error($audit)) { throw new Exception($audit->get_error_message()); }
                $audit_id = (int)$audit->id;
                $rw = $this->rewrite_service->create_rewrite((int)$item->post_id, $audit_id, $job->job_mode ?: 'soft_improve');
                if (is_wp_error($rw)) { throw new Exception($rw->get_error_message()); }
                $rewrite_id = (int)$rw->id;
                $rw2 = $this->rewrite_service->run_rewrite($rewrite_id);
                if (is_wp_error($rw2)) { throw new Exception($rw2->get_error_message()); }
            } elseif ($job->job_type === 're_rewrite') {
                $audit = $this->audit_service->run_audit((int)$item->post_id);
                if (is_wp_error($audit)) { throw new Exception($audit->get_error_message()); }
                $audit_id = (int)$audit->id;
                $rw = $this->rewrite_service->create_rewrite((int)$item->post_id, $audit_id, $job->job_mode ?: 'seo_geo_boost');
                if (is_wp_error($rw)) { throw new Exception($rw->get_error_message()); }
                $rewrite_id = (int)$rw->id;
                $rw2 = $this->rewrite_service->run_rewrite($rewrite_id);
                if (is_wp_error($rw2)) { throw new Exception($rw2->get_error_message()); }
                $count = (int) get_post_meta((int)$item->post_id, '_aiseogeo_manual_rewrite_count', true);
                update_post_meta((int)$item->post_id, '_aiseogeo_manual_rewrite_count', $count + 1);
            } elseif ($job->job_type === 'meta_only') {
                $audit = $this->audit_service->get_latest_audit((int)$item->post_id);
                if (!$audit) { $audit = $this->audit_service->run_audit((int)$item->post_id); }
                if (is_wp_error($audit)) { throw new Exception($audit->get_error_message()); }
                $audit_id = (int)$audit->id;
                $rw = $this->rewrite_service->create_rewrite((int)$item->post_id, $audit_id, 'meta_only');
                if (is_wp_error($rw)) { throw new Exception($rw->get_error_message()); }
                $rewrite_id = (int)$rw->id;
                $rw2 = $this->rewrite_service->run_rewrite($rewrite_id);
                if (is_wp_error($rw2)) { throw new Exception($rw2->get_error_message()); }
            }
            $wpdb->update($this->items_table(), array('item_status'=>'done','audit_id'=>$audit_id,'rewrite_id'=>$rewrite_id,'finished_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')), array('id'=>$item->id));
        } catch (Exception $e) {
            $error = $e->getMessage();
            $wpdb->update($this->items_table(), array('item_status'=>'failed','audit_id'=>$audit_id,'rewrite_id'=>$rewrite_id,'error_message'=>$error,'finished_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')), array('id'=>$item->id));
            $this->logger->log('error','bulk',$error,array('job_id'=>$job->id,'item_id'=>$item->id),(int)$item->post_id);
        }
        $job = $this->recount_job($job->id, false);
        $stop_after = max(5, absint($this->settings->get('bulk_stop_after_errors','5')));
        if ($stop_after && (int)$job->failed_items >= $stop_after) { $this->cancel_job($job->id, 'Остановлено из-за большого количества ошибок.'); return false; }
        if ($job->processed_items < $job->total_items && $job->job_status === 'running') { AISEOGEO_Action_Scheduler::schedule_next($job->id, absint($this->settings->get('bulk_delay_seconds','30'))); }
        else { $this->recount_job($job->id, true); }
        return true;
    }
    public function recount_job($job_id, $finish_if_done = false) {
        global $wpdb; $it=$this->items_table(); $jt=$this->jobs_table();
        $done=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$it} WHERE job_id=%d AND item_status='done'", $job_id));
        $failed=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$it} WHERE job_id=%d AND item_status='failed'", $job_id));
        $total=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$it} WHERE job_id=%d", $job_id));
        $status = $finish_if_done && ($done+$failed >= $total) ? 'done' : 'running';
        $data=array('processed_items'=>$done+$failed,'success_items'=>$done,'failed_items'=>$failed,'updated_at'=>current_time('mysql'),'job_status'=>$status);
        if ($status === 'done') { $data['finished_at'] = current_time('mysql'); }
        $wpdb->update($jt,$data,array('id'=>$job_id));
        return $this->get_job($job_id);
    }
    public function pause_job($job_id){ global $wpdb; return $wpdb->update($this->jobs_table(),array('job_status'=>'paused','updated_at'=>current_time('mysql')),array('id'=>absint($job_id))); }
    public function resume_job($job_id){ global $wpdb; $wpdb->update($this->jobs_table(),array('job_status'=>'queued','updated_at'=>current_time('mysql')),array('id'=>absint($job_id))); AISEOGEO_Action_Scheduler::schedule_next($job_id,5); return true; }
    public function cancel_job($job_id,$msg=''){ global $wpdb; $wpdb->update($this->jobs_table(),array('job_status'=>'cancelled','updated_at'=>current_time('mysql'),'finished_at'=>current_time('mysql')),array('id'=>absint($job_id))); if($msg){$this->logger->log('warning','bulk',$msg,array('job_id'=>$job_id));} return true; }
    public function get_job($job_id){ global $wpdb; return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->jobs_table()} WHERE id=%d", absint($job_id))); }
    public function get_jobs($limit=50){ global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->jobs_table()} ORDER BY id DESC LIMIT %d", absint($limit))); }
    public function get_job_items($job_id,$limit=200){ global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->items_table()} WHERE job_id=%d ORDER BY id ASC LIMIT %d", absint($job_id), absint($limit))); }
}

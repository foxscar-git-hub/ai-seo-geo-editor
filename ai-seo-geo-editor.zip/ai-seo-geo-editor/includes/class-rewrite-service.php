<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Rewrite_Service {
    private $settings; private $logger; private $audit_service; private $client; private $protector; private $version_service; private $gates; private $router;
    public function __construct($settings, $logger, $audit_service) {
        $this->settings=$settings; $this->logger=$logger; $this->audit_service=$audit_service;
        $this->client  = new AISEOGEO_OpenRouter_Client($settings, $logger);
        $this->router  = new AISEOGEO_Model_Router($settings, $logger);
        $this->protector = new AISEOGEO_Content_Protector();
        $this->version_service = new AISEOGEO_Version_Service();
        $this->gates = new AISEOGEO_Quality_Gates();
    }
    public function table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_rewrites'; }

    private $step_no = 0;
    private $step_started = 0;

    // Запускает AI-шаг через умный роутер моделей.
    // $task_type — тип задачи (research/semantics/structure/write/finalize/…)
    // $fn($model) — получает модель, возвращает результат или WP_Error.
    // $fallback — что вернуть если ВСЕ модели в цепочке упали (null = вернуть WP_Error).
    private function run_with_retry($rewrite_id, $post_id, $label, callable $fn, $fallback = null, $task_type = 'write') {
        $result = $this->router->call($task_type, $fn, $post_id ? (int)$post_id : null, $rewrite_id ? (int)$rewrite_id : null);
        if (!is_wp_error($result)) { return $result; }
        if ($fallback !== null) {
            $this->logger->log('warn', 'rewrite_step',
                "[{$label}] Все модели исчерпаны — применяю fallback.",
                array('task' => $task_type, 'error' => $result->get_error_message()),
                $post_id ? (int)$post_id : null
            );
            return $fallback;
        }
        return $result;
    }

    private function step($rewrite_id, $post_id, $stage, $message, $data = array()) {
        $this->step_no++;
        $elapsed = $this->step_started ? round(microtime(true) - $this->step_started, 2) : 0;
        $data = array_merge(array('rewrite_id'=>(int)$rewrite_id,'шаг'=>$this->step_no,'этап'=>$stage,'сек_от_старта'=>$elapsed), $data);
        $this->logger->log('info','rewrite_step','[Шаг '.$this->step_no.'] '.$message, $data, $post_id ? (int)$post_id : null);
    }

    public function create_rewrite($post_id, $audit_id, $rewrite_mode) {
        $plan_service = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        return $plan_service->create_plan($post_id, $audit_id, $rewrite_mode);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // run_rewrite — пошаговое выполнение (5 отдельных AI-запросов)
    // ═══════════════════════════════════════════════════════════════════════════
    public function run_rewrite($rewrite_id) {
        if (!current_user_can('aiseogeo_run_rewrite') && !doing_action('aiseogeo_process_bulk_job_item')) {
            return new WP_Error('forbidden','Недостаточно прав.');
        }
        return $this->execute_steps($rewrite_id, false);
    }

    public function run_rewrite_bypass($rewrite_id) {
        return $this->execute_steps($rewrite_id, true);
    }

    // Останавливает переписывание — записывает статус stopped + шаг в meta_json
    public function stop_rewrite($rewrite_id) {
        global $wpdb;
        $rewrite = $this->get_rewrite($rewrite_id);
        if (!$rewrite) { return new WP_Error('not_found', 'Переписывание не найдено.'); }

        // Определяем последний выполненный шаг из логов
        $last_step = $this->detect_last_completed_step($rewrite_id, (int)$rewrite->post_id);

        $meta = json_decode((string)($rewrite->meta_json ?? ''), true) ?: [];
        $meta['stopped_at_step'] = $last_step;
        $meta['stopped_at']      = current_time('mysql');

        $wpdb->update($this->table(), array(
            'rewrite_status' => 'stopped',
            'status_message' => 'Остановлено вручную на этапе ' . $last_step . '.',
            'meta_json'      => wp_json_encode($meta, JSON_UNESCAPED_UNICODE),
            'updated_at'     => current_time('mysql'),
        ), array('id' => absint($rewrite_id)));

        $this->logger->log('warn', 'rewrite_stop', 'Переписывание остановлено вручную.',
            array('rewrite_id' => $rewrite_id, 'stopped_at_step' => $last_step), (int)$rewrite->post_id);
        return $last_step;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Watchdog — сам обнаруживает зависшие переписывания и перезапускает их без
    // участия человека. Раньше пользователь должен был заметить зависание в
    // Диагностике и вручную нажать "Остановить" → "Продолжить". Теперь это
    // происходит автоматически по крону каждые ~10 минут.
    // ═══════════════════════════════════════════════════════════════════════════
    const WATCHDOG_STALE_MINUTES = 8;   // нет никакой активности дольше этого — считаем зависшим
    const WATCHDOG_MAX_ATTEMPTS  = 3;   // после стольких авто-перезапусков — сдаёмся, нужен человек

    public function watchdog_scan() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT id, post_id, meta_json, updated_at FROM {$this->table()}
             WHERE rewrite_status = 'rewriting'
               AND updated_at >= DATE_SUB(NOW(), INTERVAL 6 HOUR)"
        );
        if (empty($rows)) { return; }

        $logs_table = $wpdb->prefix . 'aiseogeo_logs';
        foreach ($rows as $row) {
            // Последняя ЛЮБАЯ активность по этой статье (не только строгое обновление
            // строки rewrites — модели логируют попытки чаще, чем меняется updated_at).
            $last_activity = $wpdb->get_var($wpdb->prepare(
                "SELECT MAX(created_at) FROM {$logs_table} WHERE post_id=%d", (int)$row->post_id
            ));
            $last_ts = $last_activity ? strtotime($last_activity) : strtotime($row->updated_at);
            $stale_for_min = (time() - $last_ts) / 60;

            if ($stale_for_min < self::WATCHDOG_STALE_MINUTES) { continue; } // ещё живой

            $meta = json_decode((string)($row->meta_json ?? ''), true) ?: [];
            $attempts = (int)($meta['watchdog_attempts'] ?? 0);

            if ($attempts >= self::WATCHDOG_MAX_ATTEMPTS) {
                // Сдаёмся — переводим в failed, чтобы не крутить бесконечно.
                // Остаётся видно в блоке "Остановленные/зависшие" для ручного вмешательства.
                $wpdb->update($this->table(), array(
                    'rewrite_status' => 'failed',
                    'status_message' => 'Watchdog: остановлено после ' . self::WATCHDOG_MAX_ATTEMPTS . ' автоматических попыток возобновления — нужна ручная проверка.',
                    'updated_at'     => current_time('mysql'),
                ), array('id' => (int)$row->id));
                $this->logger->log('error', 'rewrite_watchdog',
                    "Watchdog сдался после {$attempts} попыток — переписывание #{$row->id} требует ручного вмешательства.",
                    array('rewrite_id' => (int)$row->id), (int)$row->post_id
                );
                continue;
            }

            $meta['watchdog_attempts'] = $attempts + 1;
            $wpdb->update($this->table(), array('meta_json' => wp_json_encode($meta, JSON_UNESCAPED_UNICODE)), array('id' => (int)$row->id));

            $this->logger->log('warn', 'rewrite_watchdog',
                "Watchdog обнаружил зависание (нет активности " . round($stale_for_min) . " мин) — автоматически возобновляю (попытка " . ($attempts + 1) . "/" . self::WATCHDOG_MAX_ATTEMPTS . ").",
                array('rewrite_id' => (int)$row->id), (int)$row->post_id
            );

            @set_time_limit(0);
            @ignore_user_abort(true);
            $this->resume_rewrite((int)$row->id, true);
        }
    }

    // Определяет последний успешно завершённый ключевой шаг из логов
    private function detect_last_completed_step($rewrite_id, $post_id) {
        global $wpdb;
        $logs_table = $wpdb->prefix . 'aiseogeo_logs';
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT message, context_json FROM {$logs_table}
             WHERE post_id=%d AND log_level='info' AND log_type='rewrite_step'
               AND created_at >= DATE_SUB(NOW(), INTERVAL 4 HOUR)
             ORDER BY id DESC LIMIT 50",
            $post_id
        ));

        // Маппинг этапов к шагам
        $step_markers = array(
            'Этап 14' => 14, 'Этап 13' => 13, 'Этап 12' => 12, 'Этап 11' => 11,
            'Этап 10' => 10, 'Этап 9'  =>  9, 'Этап 8'  =>  8, 'Этап 7'  =>  7,
            'Этап 6'  =>  6, 'Этап 5'  =>  5, 'Этап 4'  =>  4, 'Этап 3'  =>  3,
            'Этап 2'  =>  2, 'Этап 1'  =>  1,
        );
        foreach ($rows as $row) {
            $ctx = json_decode((string)$row->context_json, true) ?: [];
            $stage = (string)($ctx['этап'] ?? '');
            foreach ($step_markers as $marker => $num) {
                if (strpos($stage, $marker) === 0) { return $num; }
            }
        }
        return 1; // Если ничего не нашли — с начала
    }

    // Быстрая проверка + немедленная пометка "в работе" — без запуска тяжёлого пайплайна.
    // Используется, чтобы кнопка "Продолжить" мгновенно вернула управление UI,
    // а сам пайплайн шёл в фоне (см. class-admin-menu.php::resume_rewrite).
    public function mark_resuming($rewrite_id) {
        if (!current_user_can('aiseogeo_run_rewrite')) {
            return new WP_Error('forbidden', 'Недостаточно прав.');
        }
        global $wpdb;
        $rewrite = $this->get_rewrite($rewrite_id);
        if (!$rewrite) { return new WP_Error('not_found', 'Переписывание не найдено.'); }
        if (!in_array($rewrite->rewrite_status, array('stopped', 'failed', 'rewriting'), true)) {
            return new WP_Error('bad_status', 'Возобновить можно только остановленное или зависшее переписывание.');
        }
        $wpdb->update($this->table(), array(
            'rewrite_status' => 'rewriting',
            'status_message' => 'Возобновление запланировано, ожидает старта воркера...',
            'updated_at'     => current_time('mysql'),
        ), array('id' => absint($rewrite_id)));
        return true;
    }

    // Продолжить переписывание с последнего незавершённого шага.
    // $is_system — вызов не из HTTP-запроса пользователя (крон/watchdog), где
    // current_user_can() всегда вернёт false из-за отсутствия залогиненного юзера.
    public function resume_rewrite($rewrite_id, $is_system = false) {
        if (!$is_system && !current_user_can('aiseogeo_run_rewrite')) {
            return new WP_Error('forbidden', 'Недостаточно прав.');
        }
        global $wpdb;
        $rewrite = $this->get_rewrite($rewrite_id);
        if (!$rewrite) { return new WP_Error('not_found', 'Переписывание не найдено.'); }
        if (!in_array($rewrite->rewrite_status, array('stopped', 'failed', 'rewriting'), true)) {
            return new WP_Error('bad_status', 'Возобновить можно только остановленное или зависшее переписывание.');
        }

        $meta = json_decode((string)($rewrite->meta_json ?? ''), true) ?: [];
        $from_step = max(1, intval($meta['stopped_at_step'] ?? 1));

        // Если зависло в rewriting без meta_json — определяем шаг сами
        if ($rewrite->rewrite_status === 'rewriting' && !isset($meta['stopped_at_step'])) {
            $from_step = $this->detect_last_completed_step($rewrite_id, (int)$rewrite->post_id);
        }

        $this->logger->log('info', 'rewrite_resume', 'Возобновление переписывания.',
            array('rewrite_id' => $rewrite_id, 'from_step' => $from_step), (int)$rewrite->post_id);

        $result = $this->execute_steps($rewrite_id, false, $from_step);

        // "Продолжить" — инструмент восстановления автоматического конвейера (в т.ч. после
        // сбоя автооптимизации). Раньше применение к статье жило только внутри
        // auto-optimize-service и никогда не вызывалось при ручном возобновлении —
        // статья дописывалась, но не публиковалась. Теперь применяем автоматически.
        if (!is_wp_error($result)) {
            $this->auto_apply_after_resume($rewrite_id, $is_system);
        }
        return $result;
    }

    // Автоприменение результата к статье после успешного "Продолжить".
    // Не валит весь resume при ошибке применения — только логирует предупреждение.
    private function auto_apply_after_resume($rewrite_id, $is_system = false) {
        $rewrite = $this->get_rewrite($rewrite_id);
        if (!$rewrite || $rewrite->rewrite_status !== 'done') { return; }
        if ((string)$rewrite->apply_status === 'applied') { return; }

        $apply_service = new AISEOGEO_Apply_Service($this, $this->logger);
        $fields = array_keys(AISEOGEO_Apply_Service::allowed_fields());
        $result = $apply_service->apply($rewrite_id, $fields, $is_system);
        if (is_wp_error($result)) {
            $this->logger->log('warn', 'rewrite_resume',
                'Возобновление завершено, но автоприменение к статье не удалось: ' . $result->get_error_message(),
                array('rewrite_id' => $rewrite_id), (int)$rewrite->post_id
            );
            return;
        }
        $this->logger->log('info', 'rewrite_resume', 'Результат автоматически применён к статье после возобновления.',
            array('rewrite_id' => $rewrite_id), (int)$rewrite->post_id
        );
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Основной оркестратор — одинаков для ручного и авто режима
    // ═══════════════════════════════════════════════════════════════════════════
    private function execute_steps($rewrite_id, $is_bypass, $from_step = 1) {
        $rewrite = $this->get_rewrite($rewrite_id);
        if (!$rewrite) { return new WP_Error('rewrite_not_found','План улучшения не найден.'); }
        if (!in_array($rewrite->rewrite_status, array('plan_created','failed','stopped','rewriting'), true)) {
            return new WP_Error('bad_status','Нельзя запустить переписывание из текущего статуса.');
        }
        $audit = $this->audit_service->get_audit((int)$rewrite->audit_id);
        global $wpdb;
        $wpdb->update($this->table(), array('rewrite_status'=>'rewriting','updated_at'=>current_time('mysql')), array('id'=>(int)$rewrite_id));
        $this->step_no = 0;
        $this->step_started = microtime(true);
        @set_time_limit(0);

        $steps = new AISEOGEO_Rewrite_Steps($this->client, $this->settings);
        $plan_parser = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);

        // Ранний лог
        $resume_msg = $from_step > 1 ? "Возобновление с этапа {$from_step}." : 'Сеанс переписывания запущен. Запрашиваю AI...';
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 1: Анализ аудитории и болей читателя', $resume_msg, array(
            'режим'               => $rewrite->rewrite_mode,
            'модель'              => $this->router->best_model('research'),
            'записей_в_оригинале' => mb_strlen(wp_strip_all_tags((string)$rewrite->original_content_longtext)) . ' симв',
            'возобновление_с_этапа' => $from_step > 1 ? $from_step : null,
        ));

        // Защита изображений до любых AI-запросов
        $img_extracted  = $this->protector->extract_images_for_protection((string)$rewrite->original_content_longtext);
        $content_for_ai = $img_extracted['content'];
        $orig_images    = $img_extracted['images'];
        $orig_chars     = mb_strlen(wp_strip_all_tags((string)$rewrite->original_content_longtext));

        $is_meta_only = ($rewrite->rewrite_mode === 'meta_only');
        if ($is_meta_only) {
            return $this->run_meta_only($rewrite_id, $rewrite, $audit, $orig_images, $plan_parser, $steps, $is_bypass);
        }

        // Восстанавливаем кеш промежуточных шагов из meta_json (при resume)
        $meta_cache = json_decode((string)($rewrite->meta_json ?? ''), true) ?: [];
        $step_cache = $meta_cache['step_cache'] ?? [];

        // ════════════════════════════════════════════════════════════════════
        // ШАГ 1+2 — Анализ аудитории и слабых мест
        // ════════════════════════════════════════════════════════════════════
        if ($from_step <= 2 && !isset($step_cache['research'])) {
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 1: Анализ аудитории и болей читателя', 'Запрос к AI — анализ аудитории.');
            $research = $this->run_with_retry($rewrite_id, $rewrite->post_id, 'Этап 1', function($model) use ($steps, $rewrite, $audit) {
                $steps->set_model($model);
                return $steps->research($rewrite, $audit);
            }, null, 'research');
            if (is_wp_error($research)) {
                $this->step($rewrite_id, $rewrite->post_id, 'Этап 1: Анализ аудитории и болей читателя', 'ОШИБКА после всех попыток: '.$research->get_error_message());
                return $this->fail($rewrite_id, $research->get_error_message(), 'step_research');
            }
            // Кешируем результат для возможного resume
            $this->save_step_cache($rewrite_id, $rewrite, 'research', $research);
        } else {
            $research = $step_cache['research'] ?? array('audience'=>array('primary'=>'','level'=>'beginner','intent'=>'informational','pains'=>[]),'weak_sections'=>[],'missing_topics'=>[],'strengths'=>[]);
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 1: Анализ аудитории и болей читателя', 'Этап 1 восстановлен из кеша (пропускаем).');
        }
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 2: Анализ слабых мест и конкурентных пробелов', 'Анализ аудитории и слабых мест завершён.', array(
            'аудитория'      => $research['audience']['primary'] ?? '—',
            'уровень'        => $research['audience']['level']   ?? '—',
            'болей'          => count($research['audience']['pains'] ?? []),
            'слабых_мест'    => count($research['weak_sections']    ?? []),
            'недостающих_тем'=> count($research['missing_topics']   ?? []),
            '_detail_pains'  => implode('; ', array_slice($research['audience']['pains'] ?? [], 0, 5)),
        ));

        // ════════════════════════════════════════════════════════════════════
        // ШАГ 3+4 — Семантика, ключевые запросы, источники
        // ════════════════════════════════════════════════════════════════════
        $sem_fallback = array('main_keyword' => $rewrite->original_title, 'secondary_keywords' => [], 'sources' => [], 'statistics' => []);
        if ($from_step <= 4 && !isset($step_cache['semantics'])) {
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 3: Семантика: заголовки, мета, Anti-AI правки', 'Запрос к AI — подбор запросов и источников.');
            $semantics = $this->run_with_retry($rewrite_id, $rewrite->post_id, 'Этап 3', function($model) use ($steps, $rewrite, $research) {
                $steps->set_model($model);
                return $steps->semantics($rewrite, $research);
            }, $sem_fallback, 'semantics');
            if (is_wp_error($semantics)) { $semantics = $sem_fallback; }
            $this->save_step_cache($rewrite_id, $rewrite, 'semantics', $semantics);
        } else {
            $semantics = $step_cache['semantics'] ?? $sem_fallback;
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 3: Семантика: заголовки, мета, Anti-AI правки', 'Этапы 3-4 восстановлены из кеша (пропускаем).');
        }
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 4: Исследование источников и экспертных данных', 'Семантика и источники получены.', array(
            'главный_запрос' => $semantics['main_keyword'] ?? '—',
            'доп_запросов'   => count($semantics['secondary_keywords'] ?? []),
            'источников'     => count($semantics['sources'] ?? []),
            'фактов'         => count($semantics['statistics'] ?? []),
            '_detail_kws'    => implode('; ', array_slice($semantics['secondary_keywords'] ?? [], 0, 5)),
        ));

        // ════════════════════════════════════════════════════════════════════
        // ШАГ 5 — Структурный скелет
        // ════════════════════════════════════════════════════════════════════
        $plan_data = json_decode($rewrite->improvement_plan_json, true) ?: [];
        $str_fallback = array(
            'hero_promise_draft' => $plan_data['hero_promise_draft'] ?? '',
            'outline'            => $plan_data['h2_structure_draft'] ?? [],
            'faq_questions'      => $plan_data['faq_draft']          ?? [],
            'cta_hooks'          => [],
        );
        if ($from_step <= 5 && !isset($step_cache['structure'])) {
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 5: Структурный скелет с черновым контентом', 'Запрос к AI — создание плана статьи.');
            $structure = $this->run_with_retry($rewrite_id, $rewrite->post_id, 'Этап 5', function($model) use ($steps, $rewrite, $research, $semantics) {
                $steps->set_model($model);
                return $steps->structure($rewrite, $research, $semantics);
            }, $str_fallback, 'structure');
            if (is_wp_error($structure)) {
                $this->step($rewrite_id, $rewrite->post_id, 'Этап 5: Структурный скелет с черновым контентом', 'ОШИБКА — fallback из плана.');
                $structure = $str_fallback;
            } else {
                $this->step($rewrite_id, $rewrite->post_id, 'Этап 5: Структурный скелет с черновым контентом', 'Структурный скелет создан.', array(
                    'H2_разделов'  => count($structure['outline']       ?? []),
                    'FAQ_вопросов' => count($structure['faq_questions'] ?? []),
                    'hero_promise' => !empty($structure['hero_promise_draft']) ? 'есть' : 'нет',
                    '_detail_h2s'  => implode('; ', array_slice(array_column($structure['outline'] ?? [], 'h2'), 0, 6)),
                ));
                $this->save_step_cache($rewrite_id, $rewrite, 'structure', $structure);
            }
        } else {
            $structure = $step_cache['structure'] ?? $str_fallback;
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 5: Структурный скелет с черновым контентом', 'Этап 5 восстановлен из кеша (пропускаем).');
        }

        // ════════════════════════════════════════════════════════════════════
        // ШАГ 6 — Написание
        // ════════════════════════════════════════════════════════════════════
        $protected_count = count(json_decode($rewrite->protected_items_json, true) ?: []);
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание (AI-запрос → ответ)', 'Запрос к AI — написание полного текста по плану.', array(
            'модель'            => $this->settings->get('model','—'),
            'режим'             => $rewrite->rewrite_mode,
            'объём_оригинала'   => $orig_chars . ' симв',
            'защищённых_блоков' => $protected_count,
        ));
        $write_result = $this->run_with_retry($rewrite_id, $rewrite->post_id, 'Этап 6', function($model) use ($steps, $rewrite, $content_for_ai, $research, $semantics, $structure) {
            $steps->set_model($model);
            return $steps->write($rewrite, $content_for_ai, $research, $semantics, $structure);
        }, null, 'write');
        if (is_wp_error($write_result)) {
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание (AI-запрос → ответ)', 'ОШИБКА после всех попыток: '.$write_result->get_error_message());
            return $this->fail($rewrite_id, $write_result->get_error_message(), 'step_write');
        }
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание (AI-запрос → ответ)', 'Ответ AI получен.', array(
            'модель_ответа' => $write_result['model'] ?? '—',
            'длина_ответа'  => mb_strlen((string)($write_result['content'] ?? '')) . ' симв',
        ));

        // Разбор JSON из написания
        $json = $plan_parser->parse_json($write_result['content']);
        if (is_wp_error($json)) {
            $repaired = $this->repair_json($write_result['content'], $rewrite);
            if (!is_wp_error($repaired)) { $json = $repaired; }
            else { $this->save_raw_error($rewrite_id, $json->get_error_message(), $write_result); return $json; }
        }
        $json = $this->normalize_json($json, $rewrite);
        $written_content = (string)($json['new_content'] ?? '');

        // Проверка объёма + повтор
        $valid = $this->validate_result($json, $rewrite);
        if (is_wp_error($valid) && in_array($valid->get_error_code(), array('empty_new_content','too_short_content'), true)) {
            $retry = $this->retry_content($rewrite, $audit, $written_content, $valid->get_error_message(), $structure, $semantics);
            if (!is_wp_error($retry)) {
                $json = $this->normalize_json($retry, $rewrite);
                $written_content = (string)($json['new_content'] ?? '');
                $valid = $this->validate_result($json, $rewrite);
            }
        }
        if (is_wp_error($valid) && $valid->get_error_code() === 'empty_new_content') {
            $json = $this->safe_fallback($json, $rewrite, $valid->get_error_message());
            $valid = $this->validate_result($json, $rewrite);
        }
        if (is_wp_error($valid)) { $this->save_raw_error($rewrite_id, $valid->get_error_message(), $write_result); return $valid; }

        // ════════════════════════════════════════════════════════════════════
        // ШАГ 7-14 — Редактура, QA, мета, схема (отдельный AI-запрос)
        // ════════════════════════════════════════════════════════════════════
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 7: Редактура логики, фактов и важных блоков', 'Запрос к AI — редактура и финализация.');
        $final_result = $this->run_with_retry($rewrite_id, $rewrite->post_id, 'Этап 7', function($model) use ($steps, $rewrite, $written_content, $research, $semantics) {
            $steps->set_model($model);
            return $steps->finalize($rewrite, $written_content, $research, $semantics);
        }, null, 'finalize');
        if (!is_wp_error($final_result)) {
            $final_json = $steps->parse_json($final_result['content']);
            if (!is_wp_error($final_json) && !empty($final_json['new_content'])) {
                $json = array_merge($json, $final_json);
                $written_content = (string)($json['new_content'] ?? $written_content);

                $human    = is_array($json['humanization_applied'] ?? null) ? $json['humanization_applied'] : [];
                $structure_r = is_array($json['structure_added'] ?? null) ? $json['structure_added'] : [];
                $this->step($rewrite_id, $rewrite->post_id, 'Этап 8: Редактура стиля: симметрий, ритм, кальки', 'Редактура стиля завершена.', array(
                    'симметрий_переписано' => count($human['symmetries_rewritten'] ?? []),
                    'клише_убрано'         => count($human['cliches_removed']     ?? []),
                    'answer_first_добавлен'=> count($human['answer_first_added']  ?? []),
                    'H2_в_вопрос'          => count($human['question_h2_converted']??[]),
                    '_detail_cliches'      => implode('; ', array_slice($human['cliches_removed'] ?? [], 0, 5)),
                ));
            }
        }

        // Возвращаем изображения
        if (!empty($orig_images)) {
            $imgs_before = count($orig_images);
            $written_content = $this->protector->reinject_images($written_content, $orig_images);
            $imgs_after = (int)preg_match_all('/<img\b/i', $written_content);
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание (AI-запрос → ответ)', 'Изображения вставлены в новый текст (PHP по позиции).', array(
                'изображений_в_оригинале'  => $imgs_before,
                'изображений_в_результате' => $imgs_after,
            ));
        }
        $json['new_content'] = $written_content;

        // ══ ФАЗА В — Этап 8: Цикл хуманизации до 0 нарушений ════════════════
        // Детерминированные гейты статейника (anti-ai.md + structure + AI-detection).
        $site_host = parse_url(home_url(), PHP_URL_HOST);
        $gate_opts = array('site_host' => $site_host, 'min_internal_links' => 3);

        // 1. Принудительная unicode-замена (этап 15 Слой A — детерминирована)
        $em_before = (int)preg_match_all('/[\x{2014}\x{2013}]/u', $written_content);
        $written_content = $this->gates->fix_unicode($written_content);
        $em_fixed = $em_before;

        // 2. Прогон гейтов
        $gate1 = $this->gates->run_all($written_content, $gate_opts);

        // 3. Итеративная хуманизация — если есть hard/warn нарушения, просим AI переписать
        $humanize_passes = 0;
        if (($gate1['hard'] > 0 || $gate1['warn'] > 3) && $rewrite->rewrite_mode !== 'meta_only') {
            $humanized = $this->humanize_cycle($written_content, $gate1['issues'], $rewrite);
            if (!is_wp_error($humanized) && trim($humanized) !== '') {
                $humanized = $this->gates->fix_unicode($humanized);
                $gate2 = $this->gates->run_all($humanized, $gate_opts);
                // Берём результат если стало лучше (меньше нарушений)
                if (($gate2['hard'] + $gate2['warn']) < ($gate1['hard'] + $gate1['warn'])) {
                    $written_content = $humanized;
                    $gate1 = $gate2;
                    $humanize_passes = 1;
                }
            }
        }
        $json['new_content'] = $written_content;

        $this->step($rewrite_id, $rewrite->post_id, 'Этап 8: Редактура стиля: симметрий, ритм, кальки', 'Цикл хуманизации (детерминированные гейты статейника).', array(
            'тире_заменено_php'   => $em_fixed,
            'итераций_хуманизации'=> $humanize_passes,
            'нарушений_hard'      => $gate1['hard'],
            'нарушений_warn'      => $gate1['warn'],
            'плотность_AI_маркеров'=> $gate1['density'] . '/1000',
            'ритм_CV'             => $gate1['cv'] !== null ? $gate1['cv'] : '—',
            'AI_score'           => $gate1['ai_score'] . '/100',
            '_detail_issues'     => $this->format_gate_issues($gate1['issues']),
        ));

        // PHP-проверки QA — реальные подсчёты, а не самоотчёт AI. Внутренние ссылки и
        // ссылки-источники берутся из $gate1 (детерминированный regex-подсчёт по финальному
        // тексту, class-quality-gates.php::check_structure) — раньше эти два числа брались
        // из json['structure_added'], т.е. из слов самой AI-модели о собственной работе,
        // без проверки. AI могла заявить "добавил 3 ссылки", реально не добавив ни одной.
        $h2_count    = (int)preg_match_all('/<h2[^>]*>/iu', $written_content);
        $table_count = (int)preg_match_all('/<table[^>]*>/iu', $written_content);
        $ol_count    = (int)preg_match_all('/<ol[^>]*>/iu', $written_content);
        $hp_ok       = stripos($written_content, 'hero-promise') !== false;
        $faq_ok      = stripos($written_content, 'faq-block')    !== false || stripos($written_content, 'Частые вопросы') !== false;
        $src_ok      = stripos($written_content, 'Источники')    !== false;
        $structure_ai = is_array($json['structure_added'] ?? null) ? $json['structure_added'] : [];
        $int_links_n = (int)($gate1['internal_links_count'] ?? 0);      // реальный PHP-подсчёт
        $src_links_n = (int)($gate1['source_links_count']   ?? 0);      // реальный PHP-подсчёт
        $cta_n       = (int)($structure_ai['cta_count'] ?? 0);          // нет детерминированного верификатора CTA — оставлен самоотчёт AI

        $this->step($rewrite_id, $rewrite->post_id, 'Этап 9: SEO/GEO QA — структурная проверка (Блок Б)', 'Проверка структуры статьи.', array(
            'H2_разделов'      => $h2_count,
            'hero_promise'     => $hp_ok  ? 'да' : 'нет',
            'CTA_точек_AI'     => $cta_n,
            'FAQ'              => $faq_ok ? 'да' : 'нет',
            'блок_источников'  => $src_ok ? 'да' : 'нет',
            'ссылок_в_источниках' => $src_links_n,
            'таблиц'           => $table_count,
            'нумерованных_списков' => $ol_count,
            'внутренних_ссылок'=> $int_links_n,
        ));

        $new_meta_t = (string)($json['new_meta_title'] ?? '');
        $new_meta_d = (string)($json['new_meta_description'] ?? '');
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 10: Мета-оптимизация: title, description, excerpt', 'Мета-данные получены от AI.', array(
            'новый_H1'         => mb_substr((string)($json['new_title'] ?? ''), 0, 120),
            'meta_desc_длина'  => mb_strlen($new_meta_d) . ' симв',
            '_detail_meta_title'=> $new_meta_t,
            '_detail_meta_desc' => $new_meta_d,
        ));
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 11: Anti-AI хуманизация (Блок В)', 'PHP: замена тире, клише убраны AI.', array(
            'тире_заменено_php' => $em_fixed,
            'было_тире'         => $em_before,
        ));
        // Живая HTTP-проверка ссылок (Agent 6 — реальная верификация)
        $link_check = $this->gates->check_links_live($written_content, 12);
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 12: Внутренние ссылки (мин. 3, Б.13)', 'Проверка ссылок: структура + живой HTTP.', array(
            'внутренних_ссылок' => $int_links_n,
            'норма'             => $int_links_n >= 3 ? '≥3 выполнена' : 'нужно ≥3',
            'ссылок_проверено'  => $link_check['checked'],
            'рабочих'           => $link_check['ok'],
            'битых'             => count($link_check['broken']),
            '_detail_broken'    => !empty($link_check['broken']) ? "БИТЫЕ ССЫЛКИ:\n• " . implode("\n• ", $link_check['broken']) : 'Все проверенные ссылки рабочие ✓',
        ));

        $new_chars = mb_strlen(wp_strip_all_tags($written_content));
        $growth    = $orig_chars ? round(($new_chars / $orig_chars - 1) * 100) . '%' : '—';
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 13: Финальная QA: JSON + объём статьи', 'Финальная проверка: объём + детерминированные гейты.', array(
            'оригинал_симв'     => $orig_chars,
            'новая_версия_симв' => $new_chars,
            'рост'              => $growth,
            'AI_score'         => $gate1['ai_score'] . '/100',
            'вердикт_гейтов'    => $gate1['verdict'] === 'clean' ? 'чисто ✓' : ($gate1['verdict'] === 'soft_warn' ? 'предупреждения' : 'есть блокеры'),
            'нарушений_всего'   => $gate1['hard'] + $gate1['warn'],
            'json_статус'       => 'OK',
        ));

        $schema_rec  = is_array($json['schema_recommendation'] ?? null) ? $json['schema_recommendation'] : [];
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 14: JSON-LD Schema разметка (Блок Г)', 'Schema из AI.', array(
            'тип_schema'     => (string)($schema_rec['type'] ?? '—'),
            '_detail_schema' => wp_json_encode($schema_rec, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
        ));

        // Сохранение
        $protected    = json_decode($rewrite->protected_items_json, true) ?: [];
        $preserve_w   = $this->protector->validate_preserved_items($rewrite->original_content_longtext, $written_content, $protected);
        $heading_w    = $this->protector->validate_heading_context($rewrite->original_content_longtext, $written_content);
        $warnings     = array_merge(is_array($json['warnings'] ?? null) ? $json['warnings'] : [], $preserve_w, $heading_w);
        if (!empty($json['removed_important_blocks'])) {
            $rmv = is_array($json['removed_important_blocks']) ? $json['removed_important_blocks'] : [$json['removed_important_blocks']];
            foreach ($rmv as $b) { $warnings[] = 'AI удалил блок: ' . (is_array($b) ? wp_json_encode($b, JSON_UNESCAPED_UNICODE) : (string)$b); }
        }
        $warnings     = array_values(array_unique(array_filter($warnings)));
        $change_sum   = is_array($json['change_summary'] ?? null) ? $json['change_summary'] : [];
        $change_sum   = array_merge($this->build_change_summary($rewrite, $json, $written_content), $change_sum);

        $wpdb->update($this->table(), array(
            'rewrite_status'       => 'done',
            'new_title'            => sanitize_text_field($json['new_title'] ?? $rewrite->original_title),
            'new_excerpt'          => wp_kses_post($json['new_excerpt'] ?? ''),
            'new_content_longtext' => wp_kses_post($written_content),
            'new_meta_title'       => sanitize_text_field($json['new_meta_title'] ?? ''),
            'new_meta_description' => sanitize_textarea_field($json['new_meta_description'] ?? ''),
            'new_faq_json'         => wp_json_encode($json['faq'] ?? [], JSON_UNESCAPED_UNICODE),
            'new_schema_json'      => wp_json_encode($schema_rec, JSON_UNESCAPED_UNICODE),
            'change_summary_json'  => wp_json_encode($change_sum, JSON_UNESCAPED_UNICODE),
            'warnings_json'        => wp_json_encode($warnings, JSON_UNESCAPED_UNICODE),
            'preserved_items_json' => wp_json_encode($json['preserved_items'] ?? [], JSON_UNESCAPED_UNICODE),
            'raw_rewrite_response' => $this->settings->get('save_raw_response','1') === '1' ? mb_substr((string)($write_result['content'] ?? ''), 0, 200000) : '',
            'model'                => $write_result['model'] ?? '',
            'status_message'       => $is_bypass ? 'Улучшенная версия создана (авто).' : 'Улучшенная версия создана.',
            'error_message'        => '',
            'updated_at'           => current_time('mysql'),
            'result_json'          => wp_json_encode(array(
                'structure_added'       => $json['structure_added']       ?? [],
                'humanization_applied'  => $json['humanization_applied']  ?? [],
                'research'              => $research,
                'semantics_keywords'    => ['main' => $semantics['main_keyword'] ?? '', 'secondary' => array_slice($semantics['secondary_keywords'] ?? [], 0, 5)],
                'quality_gates'         => array(
                    'ai_score' => $gate1['ai_score'], 'verdict' => $gate1['verdict'],
                    'hard' => $gate1['hard'], 'warn' => $gate1['warn'], 'soft' => $gate1['soft'],
                    'density' => $gate1['density'], 'cv' => $gate1['cv'],
                    'issues' => array_slice($gate1['issues'], 0, 30),
                ),
            ), JSON_UNESCAPED_UNICODE),
        ), array('id' => (int)$rewrite_id));

        $updated = $this->get_rewrite($rewrite_id);
        $this->version_service->create_versions($updated, $audit);
        $this->step($rewrite_id, $rewrite->post_id, 'Готово', 'Улучшенная версия создана и сохранена.', array(
            'итоговый_объём_симв' => $new_chars,
            'всего_шагов'         => $this->step_no,
            'всего_AI_запросов'   => 5,
        ));
        $this->logger->log('info', $is_bypass ? 'auto_rewrite' : 'rewrite_run', 'Улучшенная версия создана.', array('rewrite_id' => $rewrite_id), (int)$rewrite->post_id);
        return $updated;
    }

    // ── meta_only — один AI-запрос только для мета ──────────────────────────
    private function run_meta_only($rewrite_id, $rewrite, $audit, $orig_images, $plan_parser, $steps, $is_bypass) {
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание (AI-запрос → ответ)', 'Режим meta_only — запрос к AI только для мета-данных.');
        $plan_data = json_decode($rewrite->improvement_plan_json, true) ?: [];
        $payload = array('rewrite_id'=>(int)$rewrite->id,'rewrite_mode'=>'meta_only','original'=>array('title'=>$rewrite->original_title,'excerpt'=>$rewrite->original_excerpt,'content'=>wp_strip_all_tags((string)$rewrite->original_content_longtext)),'audit'=>$audit ? array('summary'=>$audit->summary,'scores'=>array('overall'=>$audit->overall_score,'seo'=>$audit->seo_score,'geo'=>$audit->geo_score,'eeat'=>$audit->eeat_score),'problems'=>json_decode($audit->problems_json,true),'recommendations'=>json_decode($audit->recommendations_json,true)) : [],'plan'=>$plan_data);
        $messages = array(array('role'=>'system','content'=>AISEOGEO_Prompt_Loader::rewrite_system()),array('role'=>'user','content'=>AISEOGEO_Prompt_Loader::rewrite_user($payload)));
        $result = $this->client->chat($messages, 8000);
        if (is_wp_error($result)) { return $this->fail($rewrite_id, $result->get_error_message(), 'meta_only'); }
        $json = $plan_parser->parse_json($result['content']);
        if (is_wp_error($json)) { $json = $this->repair_json($result['content'], $rewrite); }
        if (is_wp_error($json)) { $this->save_raw_error($rewrite_id, $json->get_error_message(), $result); return $json; }
        $json = $this->normalize_json($json, $rewrite);
        $content = (string)$rewrite->original_content_longtext;
        global $wpdb;
        $wpdb->update($this->table(), array('rewrite_status'=>'done','new_title'=>sanitize_text_field($json['new_title'] ?? $rewrite->original_title),'new_excerpt'=>wp_kses_post($json['new_excerpt'] ?? ''),'new_content_longtext'=>wp_kses_post($content),'new_meta_title'=>sanitize_text_field($json['new_meta_title'] ?? ''),'new_meta_description'=>sanitize_textarea_field($json['new_meta_description'] ?? ''),'new_faq_json'=>wp_json_encode($json['faq'] ?? [], JSON_UNESCAPED_UNICODE),'new_schema_json'=>wp_json_encode($json['schema_recommendation'] ?? [], JSON_UNESCAPED_UNICODE),'change_summary_json'=>wp_json_encode([], JSON_UNESCAPED_UNICODE),'warnings_json'=>wp_json_encode([], JSON_UNESCAPED_UNICODE),'model'=>$result['model'],'status_message'=>'Мета-данные обновлены.','error_message'=>'','updated_at'=>current_time('mysql')), array('id'=>(int)$rewrite_id));
        $updated = $this->get_rewrite($rewrite_id);
        $this->version_service->create_versions($updated, $audit);
        $this->step($rewrite_id, $rewrite->post_id, 'Готово', 'Мета-данные обновлены (режим meta_only).', array('всего_шагов'=>$this->step_no));
        return $updated;
    }

    // ── Повтор при коротком/пустом контенте ─────────────────────────────────
    private function retry_content($rewrite, $audit, $prev_content, $reason, $structure, $semantics) {
        if ($rewrite->rewrite_mode === 'meta_only') { return new WP_Error('meta_only_no_retry','meta_only не требует повтора.'); }
        $outline_str = wp_json_encode($structure['outline'] ?? [], JSON_UNESCAPED_UNICODE);
        $kw_str = ($semantics['main_keyword'] ?? '') . '; ' . implode(', ', array_slice($semantics['secondary_keywords'] ?? [], 0, 5));
        $messages = array(
            array('role'=>'system','content'=>AISEOGEO_Prompt_Loader::rewrite_system()."\n\nВАЖНО: предыдущий ответ был неполным. new_content обязателен — полный HTML статьи. Используй этот план разделов:\n".$outline_str."\nКлючевые запросы: ".$kw_str),
            array('role'=>'user','content'=>'Причина повтора: '.$reason."\n\nНапиши полный текст статьи. Заголовок: ".$rewrite->original_title."\n\nПредыдущий неполный ответ:\n".mb_substr((string)$prev_content, 0, 30000)),
        );
        $retry = $this->client->chat($messages, max(18000, $this->write_max_tokens($rewrite)));
        if (is_wp_error($retry)) { return $retry; }
        $parser = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        $json = $parser->parse_json($retry['content']);
        if (is_wp_error($json)) { $json = $this->repair_json($retry['content'], $rewrite); }
        return $json;
    }

    // ── Цикл хуманизации: просим AI убрать найденные гейтами нарушения ──────
    private function humanize_cycle($content, $issues, $rewrite) {
        // Собираем список нарушений для AI (только hard + warn, не soft)
        $fix_list = array();
        foreach ($issues as $i) {
            if ($i['level'] === 'soft') { continue; }
            $fix_list[] = '- ' . $i['msg'];
        }
        if (empty($fix_list)) { return $content; }

        $rules = "Убери из текста статьи AI-маркеры по списку нарушений. Сохрани смысл, структуру, все ссылки, изображения, HTML-разметку и объём. Меняй ТОЛЬКО проблемные формулировки.\n\n" .
            "ПРАВИЛА ЖИВОЙ РЕЧИ (методология «Скилл статей», Блок В):\n" .
            "• Симметрии «не А, а Б» и «Это не X. Это Y» — переписать прямым утверждением\n" .
            "• Канцелярит (однако, таким образом, важно отметить, является, представляет собой) — убрать\n" .
            "• Безличные конструкции (вы узнаете, давайте разберём, обратите внимание) — заменить прямой речью\n" .
            "• Крючки-подзаголовки (и самое мощное, вот в чём суть) — убрать, начать сразу с сути\n" .
            "• Кальки с английского (погружаемся в, бесшовно, всеобъемлющий) — простое русское слово\n" .
            "• Шаблонные финалы/старты (спасибо за внимание, в этой статье вы узнаете) — убрать\n" .
            "• Ритм: длинное-короткое-длинное предложение, не три коротких подряд\n" .
            "• Тире — только дефис. Без длинного тире.\n\n" .
            "НАЙДЕННЫЕ НАРУШЕНИЯ:\n" . implode("\n", $fix_list) . "\n\n" .
            "Верни ТОЛЬКО валидный JSON: {\"new_content\": \"исправленный полный HTML статьи\"}";

        $result = $this->client->chat(array(
            array('role' => 'system', 'content' => 'Ты редактор-хуманизатор. Убираешь следы AI из текста. Верни только валидный JSON, без markdown.'),
            array('role' => 'user',   'content' => $rules . "\n\nСТАТЬЯ:\n" . mb_substr($content, 0, 55000)),
        ), max(24000, intval($this->settings->get('max_tokens', '6000'))));

        if (is_wp_error($result)) { return $result; }
        $json = $this->gates_parse($result['content']);
        if (is_wp_error($json) || empty($json['new_content'])) { return $content; }
        return (string)$json['new_content'];
    }

    private function gates_parse($content) {
        $content = trim((string)$content);
        if (preg_match('/```(?:json)?\s*([\s\S]+?)\s*```/s', $content, $m)) { $content = trim($m[1]); }
        $d = json_decode($content, true);
        if (!is_array($d) && preg_match('/(\{[\s\S]+\})/s', $content, $m)) { $d = json_decode($m[1], true); }
        return is_array($d) ? $d : new WP_Error('parse', 'no json');
    }

    private function format_gate_issues($issues) {
        if (empty($issues)) { return 'Нарушений нет — текст чистый ✓'; }
        $lines = array();
        $icon = array('hard' => '🔴', 'warn' => '🟡', 'soft' => '🟢');
        foreach ($issues as $i) { $lines[] = ($icon[$i['level']] ?? '•') . ' ' . $i['msg']; }
        return implode("\n", $lines);
    }

    // ── Repair JSON ──────────────────────────────────────────────────────────
    private function repair_json($raw_content, $rewrite) {
        $messages = array(
            array('role'=>'system','content'=>'Исправь технически некорректный JSON. Верни только валидный JSON без markdown. Сохрани максимум данных из исходного ответа.'),
            array('role'=>'user','content'=>'Режим: '.$rewrite->rewrite_mode."\n\nНекорректный ответ:\n".mb_substr((string)$raw_content, 0, 110000)),
        );
        $repair = $this->client->chat($messages, max(12000, intval($this->settings->get('max_tokens','6000'))));
        if (is_wp_error($repair)) { return $repair; }
        $parser = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        return $parser->parse_json($repair['content']);
    }

    private function write_max_tokens($rewrite) {
        $base = intval($this->settings->get('max_tokens','6000'));
        $len  = mb_strlen(wp_strip_all_tags((string)$rewrite->original_content_longtext));
        if ($len > 15000) { return max(32000, $base); }
        if ($len > 10000) { return max(24000, $base); }
        if ($len > 5000)  { return max(18000, $base); }
        return max(14000, $base);
    }

    private function normalize_json($json, $rewrite) {
        if (isset($json['result']) && is_array($json['result'])) { $json = array_merge($json, $json['result']); }
        if (isset($json['data'])   && is_array($json['data']))   { $json = array_merge($json, $json['data']); }
        $map = array('new_title'=>array('title','seo_title','headline'),'new_excerpt'=>array('excerpt','description','summary'),'new_meta_title'=>array('meta_title','seo_meta_title'),'new_meta_description'=>array('meta_description','seo_description'),'new_content'=>array('content','html','article_content','body','body_html','rewritten_content','final_content','improved_content','full_text','text'),'faq'=>array('faqs','questions'),'schema_recommendation'=>array('schema','json_ld','schema_json'),'change_summary'=>array('changes','change_log'),'warnings'=>array('risks','notes'),'preserved_items'=>array('protected_items','saved_items'));
        foreach ($map as $target => $sources) {
            if (!isset($json[$target]) || $json[$target] === '' || $json[$target] === []) {
                foreach ($sources as $src) { if (isset($json[$src]) && $json[$src] !== '' && $json[$src] !== []) { $json[$target] = $json[$src]; break; } }
            }
        }
        if ((empty($json['new_content']) || is_array($json['new_content'])) && !empty($json['sections']) && is_array($json['sections'])) { $json['new_content'] = $this->blocks_to_html($json['sections']); }
        if (empty($json['new_content']) || is_array($json['new_content'])) {
            $deep = $this->find_longest_string($json);
            if ($deep !== '') { $json['new_content'] = $deep; }
        }
        foreach (array('new_title','new_excerpt','new_meta_title','new_meta_description','new_content') as $k) {
            if (!isset($json[$k])) { $json[$k] = ''; }
            if (is_array($json[$k]) || is_object($json[$k])) { $json[$k] = $k === 'new_content' ? $this->blocks_to_html((array)$json[$k]) : wp_json_encode($json[$k], JSON_UNESCAPED_UNICODE); }
            $json[$k] = (string)$json[$k];
        }
        foreach (array('faq','change_summary','warnings','preserved_items') as $k) {
            if (!isset($json[$k]) || $json[$k] === '') { $json[$k] = []; }
            if (!is_array($json[$k])) { $json[$k] = [(string)$json[$k]]; }
        }
        if (!isset($json['schema_recommendation']) || $json['schema_recommendation'] === '') { $json['schema_recommendation'] = []; }
        if (!is_array($json['schema_recommendation'])) { $json['schema_recommendation'] = ['note'=>(string)$json['schema_recommendation']]; }
        if ($rewrite->rewrite_mode === 'meta_only' && trim($json['new_content']) === '') { $json['new_content'] = $rewrite->original_content_longtext; }
        return $json;
    }

    private function validate_result($json, $rewrite) {
        if ($rewrite->rewrite_mode !== 'meta_only') {
            if (empty($json['new_content'])) { return new WP_Error('empty_new_content','AI не вернул текст.'); }
            $orig_len = mb_strlen(wp_strip_all_tags($rewrite->original_content_longtext));
            $new_len  = mb_strlen(wp_strip_all_tags($json['new_content']));
            $min_ratio = in_array($rewrite->rewrite_mode, array('problem_blocks_only','meta_only'), true) ? 0.5 : 0.9;
            if ($orig_len > 800 && $new_len < max(500, (int)($orig_len * $min_ratio))) {
                return new WP_Error('too_short_content', sprintf('AI вернул слишком короткий текст: %d симв. (нужно мин. %d).', $new_len, (int)($orig_len * $min_ratio)));
            }
        }
        return true;
    }

    private function safe_fallback($json, $rewrite, $reason = '') {
        $content = (string)$rewrite->original_content_longtext;
        $warnings = is_array($json['warnings'] ?? null) ? $json['warnings'] : [];
        $warnings[] = 'AI не вернул полный текст. Использован fallback: исходный контент сохранён. Причина: ' . $reason;
        $json['new_content'] = $content;
        $json['warnings']    = $warnings;
        if (empty($json['change_summary']) || !is_array($json['change_summary'])) { $json['change_summary'] = []; }
        $json['change_summary'][] = array('type'=>'content','before'=>'исходный текст','after'=>'исходный текст сохранён','comment'=>'Fallback.');
        return $json;
    }

    private function blocks_to_html($blocks) {
        if (!is_array($blocks)) { return ''; }
        $html = '';
        foreach ($blocks as $block) {
            if (is_string($block)) { $html .= '<p>'.esc_html($block).'</p>'."\n"; continue; }
            if (!is_array($block)) { continue; }
            $heading = $block['heading'] ?? ($block['title'] ?? ($block['h2'] ?? ''));
            $level   = min(6, max(2, isset($block['level']) ? (int)$block['level'] : 2));
            $text    = $block['text'] ?? ($block['content'] ?? ($block['body'] ?? ($block['paragraph'] ?? '')));
            if ($heading !== '') { $html .= '<h'.$level.'>'.esc_html(wp_strip_all_tags((string)$heading)).'</h'.$level.'>'."\n"; }
            if (is_array($text)) { foreach ($text as $p) { if (trim((string)$p)!=='') { $html .= '<p>'.esc_html(wp_strip_all_tags((string)$p)).'</p>'."\n"; } } }
            elseif (trim((string)$text) !== '') { $html .= '<p>'.esc_html(wp_strip_all_tags((string)$text)).'</p>'."\n"; }
        }
        return trim($html);
    }

    private function find_longest_string($data, $depth = 0) {
        if ($depth > 5 || !is_array($data)) { return ''; }
        $best = '';
        $preferred = array('new_content','content','article_content','rewritten_content','improved_content','final_content','html','body','body_html','full_article','wordpress_content');
        foreach ($preferred as $key) {
            if (isset($data[$key]) && is_string($data[$key])) {
                if (mb_strlen(wp_strip_all_tags($data[$key])) > mb_strlen(wp_strip_all_tags($best))) { $best = $data[$key]; }
            }
        }
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $plain = mb_strlen(wp_strip_all_tags($value));
                $looks = $plain > 500 && preg_match('/<(p|h2|h3|ul|ol|li)/iu', $value);
                if ($looks && $plain > mb_strlen(wp_strip_all_tags($best))) { $best = $value; }
            } elseif (is_array($value) || is_object($value)) {
                $candidate = $this->find_longest_string((array)$value, $depth + 1);
                if (mb_strlen(wp_strip_all_tags($candidate)) > mb_strlen(wp_strip_all_tags($best))) { $best = $candidate; }
            }
        }
        return trim($best);
    }

    private function build_change_summary($rewrite, $json, $new_content) {
        $summary = [];
        $new_title = (string)($json['new_title'] ?? '');
        if ($new_title !== '' && trim($new_title) !== trim((string)$rewrite->original_title)) { $summary[] = array('type'=>'title','before'=>$rewrite->original_title,'after'=>$new_title,'comment'=>'Изменён H1.'); }
        $new_meta_t = (string)($json['new_meta_title'] ?? '');
        $new_meta_d = (string)($json['new_meta_description'] ?? '');
        if ($new_meta_t !== '') { $summary[] = array('type'=>'meta','before'=>'','after'=>$new_meta_t,'comment'=>'Новый meta title.'); }
        if ($new_meta_d !== '') { $summary[] = array('type'=>'meta','before'=>'','after'=>$new_meta_d,'comment'=>'Новое meta description.'); }
        $old_h = $this->extract_headings((string)$rewrite->original_content_longtext);
        $new_h = $this->extract_headings((string)$new_content);
        $added = array_values(array_diff($new_h, $old_h));
        $removed = array_values(array_diff($old_h, $new_h));
        if ($added || $removed) { $summary[] = array('type'=>'headings','before'=>implode(' | ', array_slice($old_h,0,6)),'after'=>implode(' | ', array_slice($new_h,0,6)),'comment'=>'Изменена структура H2/H3. Добавлено: '.count($added).', удалено: '.count($removed).'.'); }
        $old_words = $this->count_words(wp_strip_all_tags((string)$rewrite->original_content_longtext));
        $new_words = $this->count_words(wp_strip_all_tags((string)$new_content));
        if ($old_words !== $new_words) { $summary[] = array('type'=>'content','before'=>$old_words.' слов','after'=>$new_words.' слов','comment'=>'Изменён объём.'); }
        return $summary;
    }

    private function extract_headings($content) {
        $out = [];
        if (preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\1>/isu', $content, $m, PREG_SET_ORDER)) {
            foreach ($m as $r) { $t = trim(wp_strip_all_tags($r[2])); if ($t !== '') { $out[] = 'H'.$r[1].': '.$t; } }
        }
        return $out;
    }
    private function count_words($text) { preg_match_all('/[\p{L}\p{N}]+/u', (string)$text, $m); return count($m[0]); }
    private function has_marker($text, $markers) { $text = mb_strtolower((string)$text); foreach ($markers as $m) { if (mb_stripos($text, mb_strtolower($m)) !== false) { return true; } } return false; }

    // Сохраняет промежуточный результат шага в meta_json для resume
    private function save_step_cache($rewrite_id, $rewrite, $key, $data) {
        global $wpdb;
        $meta = json_decode((string)($rewrite->meta_json ?? ''), true) ?: [];
        if (!isset($meta['step_cache'])) { $meta['step_cache'] = []; }
        $meta['step_cache'][$key] = $data;
        $wpdb->update($this->table(), array('meta_json' => wp_json_encode($meta, JSON_UNESCAPED_UNICODE)), array('id' => absint($rewrite_id)));
        // Обновляем локальный объект чтобы следующий save_step_cache не затёр предыдущий
        $rewrite->meta_json = wp_json_encode($meta, JSON_UNESCAPED_UNICODE);
    }

    private function fail($rewrite_id, $message, $context) {
        global $wpdb;
        $wpdb->update($this->table(), array('rewrite_status'=>'failed','error_message'=>$message,'updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id)));
        $this->logger->log('error',$context,$message,array('rewrite_id'=>$rewrite_id));
        return new WP_Error('rewrite_failed',$message);
    }
    private function save_raw_error($rewrite_id, $message, $result) {
        global $wpdb;
        $wpdb->update($this->table(), array('rewrite_status'=>'failed','error_message'=>$message,'raw_rewrite_response'=>$result['content'] ?? '','model'=>$result['model'] ?? '','updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id)));
        $this->logger->log('error','rewrite_run',$message,array('rewrite_id'=>$rewrite_id));
    }

    public function get_rewrite($rewrite_id)  { global $wpdb; return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table()} WHERE id=%d", absint($rewrite_id))); }
    public function get_post_rewrites($post_id){ global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} WHERE post_id=%d AND rewrite_status <> 'deleted' ORDER BY id DESC", absint($post_id))); }
    public function history($limit=100)         { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} WHERE rewrite_status <> 'deleted' ORDER BY id DESC LIMIT %d", absint($limit))); }
    public function delete_rewrite($rewrite_id) { global $wpdb; return $wpdb->update($this->table(), array('rewrite_status'=>'deleted','updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id))); }
    public function mark_draft_created($rewrite_id, $draft_id) { global $wpdb; return $wpdb->update($this->table(), array('rewrite_status'=>'draft_created','created_draft_post_id'=>absint($draft_id),'updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id))); }
    public function mark_reaudited($rewrite_id, $audit_id)     { global $wpdb; $wpdb->update($this->table(), array('rewrite_status'=>'re_audited','re_audit_id'=>absint($audit_id),'updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id))); $this->version_service->update_rewrite_scores($rewrite_id, $this->audit_service->get_audit($audit_id)); }

    public function create_rewrite_bypass($post_id, $audit_id, $rewrite_mode) {
        $plan_service = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        return $plan_service->create_plan_bypass($post_id, $audit_id, $rewrite_mode);
    }
}

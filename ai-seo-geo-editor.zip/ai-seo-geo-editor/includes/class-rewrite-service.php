<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Rewrite_Service {
    private $settings; private $logger; private $audit_service; private $client; private $protector; private $version_service;
    public function __construct($settings, $logger, $audit_service) {
        $this->settings=$settings; $this->logger=$logger; $this->audit_service=$audit_service;
        $this->client = new AISEOGEO_OpenRouter_Client($settings, $logger);
        $this->protector = new AISEOGEO_Content_Protector();
        $this->version_service = new AISEOGEO_Version_Service();
    }
    public function table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_rewrites'; }

    private $step_no = 0;
    private $step_started = 0;
    /** Пошаговый лог процесса переписывания — виден в Диагностика → Логи. Каждый шаг привязан к этапу методологии «Скилл статей». */
    private function step($rewrite_id, $post_id, $stage, $message, $data = array()) {
        $this->step_no++;
        $elapsed = $this->step_started ? round(microtime(true) - $this->step_started, 2) : 0;
        $data = array_merge(array('rewrite_id'=>(int)$rewrite_id, 'шаг'=>$this->step_no, 'этап'=>$stage, 'сек_от_старта'=>$elapsed), $data);
        $this->logger->log('info', 'rewrite_step', '[Шаг ' . $this->step_no . '] ' . $message, $data, $post_id ? (int)$post_id : null);
    }

    public function create_rewrite($post_id, $audit_id, $rewrite_mode) {
        $plan_service = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        return $plan_service->create_plan($post_id, $audit_id, $rewrite_mode);
    }
    public function run_rewrite($rewrite_id) {
        if (!current_user_can('aiseogeo_run_rewrite') && !doing_action('aiseogeo_process_bulk_job_item')) { return new WP_Error('forbidden', 'Недостаточно прав.'); }
        $rewrite = $this->get_rewrite($rewrite_id);
        if (!$rewrite) { return new WP_Error('rewrite_not_found','План улучшения не найден.'); }
        if (!in_array($rewrite->rewrite_status, array('plan_created','failed'), true)) { return new WP_Error('bad_status','Для этой версии нельзя запустить переписывание из текущего статуса.'); }
        $audit = $this->audit_service->get_audit((int)$rewrite->audit_id);
        global $wpdb; $now=current_time('mysql');
        $wpdb->update($this->table(), array('rewrite_status'=>'rewriting','updated_at'=>$now), array('id'=>(int)$rewrite_id));

        $this->step_no = 0; $this->step_started = microtime(true);
        $plan_data  = json_decode($rewrite->improvement_plan_json, true) ?: array();
        $orig_chars = mb_strlen(wp_strip_all_tags((string)$rewrite->original_content_longtext));

        // ══ ФАЗА А — Этап 5: Структурный план (загружен из create_plan) ══════
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 5: Структурный план', 'Загружен черновой план — структурный скелет с готовым контентом.', array(
            'h2_с_tldr'        => is_array($plan_data['h2_structure_draft']   ?? null) ? count($plan_data['h2_structure_draft'])  : 0,
            'faq_черновик'     => is_array($plan_data['faq_draft']            ?? null) ? count($plan_data['faq_draft'])           : 0,
            'источники_черновик'=> is_array($plan_data['sources_draft']       ?? null) ? count($plan_data['sources_draft'])      : 0,
            'hero_promise'     => !empty($plan_data['hero_promise_draft'])    ? 'есть' : 'нет',
            'таблица'          => !empty($plan_data['comparison_table_draft']) ? 'есть' : 'нет',
            'сравнит_таблица'  => !empty($plan_data['comparison_table_draft']) ? 'есть' : 'нет',
        ));

        // ══ ФАЗА Б — Этап 6: Написание ══════════════════════════════════════
        // Извлекаем изображения из оригинала ПЕРЕД отправкой AI.
        // AI получает контент без <img> — это надёжнее чем токены (AI их игнорирует).
        // После ответа изображения вставляются обратно по пропорциональным позициям в PHP.
        $img_extracted  = $this->protector->extract_images_for_protection((string)$rewrite->original_content_longtext);
        $content_for_ai = $img_extracted['content'];
        $orig_images    = $img_extracted['images'];

        $payload = array(
            'rewrite_id'     => (int)$rewrite->id,
            'rewrite_mode'   => $rewrite->rewrite_mode,
            'original'       => array('title'=>$rewrite->original_title,'excerpt'=>$rewrite->original_excerpt,'content'=>$content_for_ai),
            'audit'          => $audit ? array('summary'=>$audit->summary,'scores'=>array('overall'=>$audit->overall_score,'seo'=>$audit->seo_score,'geo'=>$audit->geo_score,'eeat'=>$audit->eeat_score),'problems'=>json_decode($audit->problems_json,true),'recommendations'=>json_decode($audit->recommendations_json,true),'suggested'=>json_decode($audit->suggested_json,true)) : array(),
            'plan'           => $plan_data,
            'protected_items'=> json_decode($rewrite->protected_items_json,true),
        );
        $protected_count = is_array($payload['protected_items']) ? count($payload['protected_items']) : 0;

        $messages = array(
            array('role'=>'system','content'=>AISEOGEO_Prompt_Loader::rewrite_system()),
            array('role'=>'user','content'=>AISEOGEO_Prompt_Loader::rewrite_user($payload)),
        );
        $rewrite_max_tokens = $this->rewrite_max_tokens($rewrite);
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание', 'Запрос к AI — полное переписывание по плану (Блок А+Б+В+Г).', array(
            'модель'              => $this->settings->get('model','—'),
            'лимит_токенов'       => $rewrite_max_tokens,
            'объём_оригинала_симв'=> $orig_chars,
            'режим'               => $rewrite->rewrite_mode,
            'защищённых_блоков'   => $protected_count,
            'аудит_SEO'           => $audit ? (int)$audit->seo_score : null,
            'аудит_GEO'           => $audit ? (int)$audit->geo_score : null,
        ));

        $result = $this->client->chat($messages, $rewrite_max_tokens);
        if (is_wp_error($result)) {
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание', 'ОШИБКА запроса к AI: ' . $result->get_error_message());
            return $this->fail($rewrite_id, $result->get_error_message(), 'rewrite_run');
        }
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание', 'Ответ AI получен.', array(
            'модель_ответа'    => $result['model'] ?? '—',
            'длина_ответа_симв'=> mb_strlen((string)($result['content'] ?? '')),
        ));

        // ── Разбор JSON ──────────────────────────────────────────────────────
        $plan_parser = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        $json = $plan_parser->parse_json($result['content']);
        if (is_wp_error($json)) {
            $repaired = $this->repair_json_response($result['content'], $rewrite);
            if (!is_wp_error($repaired)) {
                $json = $repaired;
                $result['content'] .= "\n\n--- AISEOGEO_JSON_REPAIR_APPLIED ---";
            } else {
                $this->save_raw_error($rewrite_id, $json->get_error_message(), $result);
                return $json;
            }
        }
        $json = $this->normalize_rewrite_json($json, $rewrite);

        // ── Проверка объёма + повтор если нужно ──────────────────────────────
        $valid = $this->validate_rewrite_result($json, $rewrite);
        if (is_wp_error($valid) && in_array($valid->get_error_code(), array('empty_new_content','too_short_content'), true)) {
            $retry = $this->retry_missing_or_short_content($rewrite, $audit, $payload, $result['content'], $valid->get_error_message());
            if (!is_wp_error($retry)) {
                $json  = $this->normalize_rewrite_json($retry, $rewrite);
                $result['content'] .= "\n\n--- AISEOGEO_REWRITE_CONTENT_RETRY_APPLIED ---";
                $valid = $this->validate_rewrite_result($json, $rewrite);
            }
        }
        if (is_wp_error($valid) && $valid->get_error_code() === 'empty_new_content') {
            $json  = $this->apply_safe_content_fallback($json, $rewrite, $valid->get_error_message());
            $valid = $this->validate_rewrite_result($json, $rewrite);
        }
        if (is_wp_error($valid)) {
            $this->save_raw_error($rewrite_id, $valid->get_error_message(), $result);
            return $valid;
        }

        $new_content = (string)($json['new_content'] ?? '');
        if ($rewrite->rewrite_mode === 'meta_only' && trim($new_content) === '') { $new_content = $rewrite->original_content_longtext; }

        // ── Возвращаем изображения в новый контент по позициям ───────────────
        if (!empty($orig_images)) {
            $imgs_before = count($orig_images);
            $new_content = $this->protector->reinject_images($new_content, $orig_images);
            $imgs_after  = (int)preg_match_all('/<img\b/i', $new_content);
            $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание', 'Изображения вставлены в новый текст (PHP-инъекция по позиции).', array(
                'изображений_в_оригинале'  => $imgs_before,
                'изображений_в_результате' => $imgs_after,
            ));
        }

        // ══ ФАЗА В — Этап 7: Редактура логики ═══════════════════════════════
        $protected     = json_decode($rewrite->protected_items_json,true) ?: array();
        $preserve_warn = $this->protector->validate_preserved_items($rewrite->original_content_longtext, $new_content, $protected);
        $warnings      = $json['warnings'] ?? array(); if (!is_array($warnings)) { $warnings = array((string)$warnings); }
        if (!empty($json['removed_important_blocks'])) {
            $removed = is_array($json['removed_important_blocks']) ? $json['removed_important_blocks'] : array((string)$json['removed_important_blocks']);
            foreach ($removed as $b) { $warnings[] = 'AI удалил важный блок: ' . (is_array($b) ? wp_json_encode($b,JSON_UNESCAPED_UNICODE) : (string)$b); }
        }
        $heading_warn = $this->protector->validate_heading_context($rewrite->original_content_longtext, $new_content);
        $warnings     = array_merge($warnings, $preserve_warn, $heading_warn);
        $warn_clean   = array_values(array_unique(array_filter($warnings)));
        $pres_items   = is_array($json['preserved_items'] ?? null) ? array_values(array_filter($json['preserved_items'])) : array();
        $conf         = isset($json['confidence']) ? round((float)$json['confidence'] * 100) . '%' : '—';

        $this->step($rewrite_id, $rewrite->post_id, 'Этап 7: Редактура логики', 'Проверка логики, фактов, сохранности важных блоков.', array(
            'предупреждений'   => count($warn_clean),
            'уверенность_AI'   => $conf,
            'сохранено_блоков' => count($pres_items),
            '_detail_warnings' => count($warn_clean) ? "• " . implode("\n• ", array_slice($warn_clean,0,20)) : 'Предупреждений нет',
            '_detail_preserved'=> count($pres_items) ? implode('; ', array_slice($pres_items,0,10)) : '—',
        ));

        // ══ ФАЗА В — Этап 8: Редактура стиля (PHP пост-обработка) ═══════════
        $human       = is_array($json['humanization_applied'] ?? null) ? $json['humanization_applied'] : array();
        $sym_list    = is_array($human['symmetries_rewritten'] ?? null) ? array_values(array_filter($human['symmetries_rewritten'])) : array();
        $clich_list  = is_array($human['cliches_removed']     ?? null) ? array_values(array_filter($human['cliches_removed']))     : array();
        $af_list     = is_array($human['answer_first_added']  ?? null) ? array_values(array_filter($human['answer_first_added']))  : array();
        $qh2_list    = is_array($human['question_h2_converted']?? null) ? array_values(array_filter($human['question_h2_converted'])): array();
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 8: Редактура стиля', 'Живая речь: симметрии, ритм, кальки с английского (отчёт AI).', array(
            'симметрий_переписано' => count($sym_list),
            '_detail_symmetries'   => count($sym_list) ? "• " . implode("\n• ", $sym_list) : 'Не зафиксировано AI',
        ));

        // ══ ФАЗА Г — Этап 9: SEO/GEO структурная QA ═════════════════════════
        $structure   = is_array($json['structure_added'] ?? null) ? $json['structure_added'] : array();
        $h2_count    = (int)preg_match_all('/<h2[^>]*>/iu', $new_content);
        $table_count = (int)preg_match_all('/<table[^>]*>/iu', $new_content);
        $ol_count    = (int)preg_match_all('/<ol[^>]*>/iu', $new_content);
        $int_links_n = (int)($structure['internal_links_count'] ?? 0);
        $hp_ok       = !empty($structure['hero_promise']) || stripos($new_content,'hero-promise') !== false;
        $faq_ok      = !empty($structure['faq_added'])   || stripos($new_content,'faq-block')    !== false;
        $src_ok      = !empty($structure['sources_block_added']) || stripos($new_content,'Источники') !== false;
        $cta_n       = (int)($structure['cta_count'] ?? 0);

        $this->step($rewrite_id, $rewrite->post_id, 'Этап 9: SEO/GEO QA', 'Проверка обязательной структуры статьи (Блок Б).', array(
            'H2_разделов'      => $h2_count,
            'hero_promise'     => $hp_ok  ? 'да' : 'нет',
            'CTA_точек'        => $cta_n,
            'FAQ'              => $faq_ok ? 'да' : 'нет',
            'блок_источников'  => $src_ok ? 'да' : 'нет',
            'таблиц'           => $table_count,
            'нумерованных_списков' => $ol_count,
            'внутренних_ссылок'=> $int_links_n,
            'hero_promise'     => $hp_ok  ? 'да' : 'нет',
        ));

        // ══ ФАЗА Г — Этап 10: Мета ═══════════════════════════════════════════
        $new_title_log = mb_substr((string)($json['new_title']            ?? ''), 0, 120);
        $new_meta_t    = (string)($json['new_meta_title']       ?? '');
        $new_meta_d    = (string)($json['new_meta_description'] ?? '');
        $new_exc       = mb_substr((string)($json['new_excerpt'] ?? ''), 0, 300);
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 10: Мета', 'SEO-оптимизация мета-данных: H1, title, description, excerpt.', array(
            'новый_H1'         => $new_title_log,
            'meta_desc_длина'  => mb_strlen($new_meta_d) . ' симв',
            '_detail_meta_title'=> $new_meta_t,
            '_detail_meta_desc' => $new_meta_d,
            '_detail_excerpt'   => $new_exc,
        ));

        // ══ ФАЗА Г — Этап 11: Anti-AI хуманизация (PHP-применение В.1) ══════
        // PHP принудительно заменяет тире, даже если AI не заменил
        $em_before = (int)preg_match_all('/[—–]/u', $new_content);
        $new_content = preg_replace('/—/u', '-', $new_content);  // U+2014 длинное тире → дефис
        $new_content = preg_replace('/–/u', '-', $new_content);  // U+2013 среднее тире → дефис
        $new_content = preg_replace('/\x{2026}/u', '...', $new_content); // U+2026 многоточие → три точки
        $em_after    = (int)preg_match_all('/[—–]/u', $new_content);
        $em_fixed    = $em_before - $em_after;
        $json['new_content'] = $new_content; // сохраняем исправленный контент

        $this->step($rewrite_id, $rewrite->post_id, 'Этап 11: Anti-AI хуманизация', 'В.1-В.8: удаление AI-маркеров из текста (применено PHP).', array(
            'длинных_тире_было'     => $em_before,
            'тире_заменено_php'     => $em_fixed,
            'длинных_тире_осталось' => $em_after,
            'клише_убрано_AI'       => count($clich_list),
            'симметрий_переписано'  => count($sym_list),
            'answer_first_в_H2'    => count($af_list),
            'H2_в_вопрос'          => count($qh2_list),
        ));

        // ══ ФАЗА Г — Этап 12: Внутренние ссылки ══════════════════════════════
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 12: Внутренние ссылки', 'Простановка внутренних ссылок на связанные материалы сайта (Б.13).', array(
            'внутренних_ссылок' => $int_links_n,
            'норма'             => $int_links_n >= 3 ? 'выполнена (≥3)' : 'не выполнена (нужно ≥3)',
        ));

        // ══ ФАЗА Г — Этап 13: Финальная QA (JSON + объём) ════════════════════
        $new_chars_check = mb_strlen(wp_strip_all_tags($new_content));
        $growth_pct      = $orig_chars ? (round(($new_chars_check / $orig_chars - 1) * 100) . '%') : '—';
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 13: Финальная QA', 'Проверка полноты: JSON корректен, объём соответствует норме.', array(
            'оригинал_симв'     => $orig_chars,
            'новая_версия_симв' => $new_chars_check,
            'рост'              => $growth_pct,
            'json_статус'       => 'OK',
        ));

        // ══ ФАЗА Г — Этап 14: Schema JSON-LD ══════════════════════════════════
        $schema_rec  = is_array($json['schema_recommendation'] ?? null) ? $json['schema_recommendation'] : array();
        $schema_type = (string)($schema_rec['type'] ?? '—');
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 14: Schema', 'JSON-LD разметка для поиска и AI-агрегаторов (Блок Г).', array(
            'тип_schema'      => $schema_type,
            '_detail_schema'  => wp_json_encode($schema_rec, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
        ));

        $change_summary = $json['change_summary'] ?? array();
        if (!is_array($change_summary)) { $change_summary = array((string)$change_summary); }
        $change_summary = array_merge($this->build_auto_change_summary($rewrite, $json, $new_content), $change_summary);
        $wpdb->update($this->table(), array(
            'rewrite_status'=>'done','new_title'=>sanitize_text_field($json['new_title'] ?? $rewrite->original_title),'new_excerpt'=>wp_kses_post($json['new_excerpt'] ?? ''),'new_content_longtext'=>wp_kses_post($new_content),
            'new_meta_title'=>sanitize_text_field($json['new_meta_title'] ?? ''),'new_meta_description'=>sanitize_textarea_field($json['new_meta_description'] ?? ''),
            'new_faq_json'=>wp_json_encode($json['faq'] ?? array(), JSON_UNESCAPED_UNICODE),'new_schema_json'=>wp_json_encode($json['schema_recommendation'] ?? array(), JSON_UNESCAPED_UNICODE),
            'change_summary_json'=>wp_json_encode($change_summary, JSON_UNESCAPED_UNICODE),'warnings_json'=>wp_json_encode(array_values(array_unique(array_filter($warnings))), JSON_UNESCAPED_UNICODE),
            'preserved_items_json'=>wp_json_encode($json['preserved_items'] ?? array(), JSON_UNESCAPED_UNICODE),'raw_rewrite_response'=>$this->settings->get('save_raw_response','1') === '1' ? $result['content'] : '',
            'model'=>$result['model'],'status_message'=>'Улучшенная версия создана.','error_message'=>'','updated_at'=>current_time('mysql'),
            'result_json'=>wp_json_encode(array(
                'structure_added'=>$json['structure_added'] ?? array(),
                'humanization_applied'=>$json['humanization_applied'] ?? array(),
            ), JSON_UNESCAPED_UNICODE),
        ), array('id'=>(int)$rewrite_id));
        $updated = $this->get_rewrite($rewrite_id);
        $this->version_service->create_versions($updated, $audit);
        $this->step($rewrite_id, $rewrite->post_id, 'Готово', 'Улучшенная версия создана и сохранена. Версии для сравнения готовы.', array(
            'итоговый_объём_симв'=>mb_strlen(wp_strip_all_tags($new_content)),
            'всего_шагов'=>$this->step_no,
        ));
        $this->logger->log('info','rewrite_run','Улучшенная версия создана.',array('rewrite_id'=>$rewrite_id),(int)$rewrite->post_id);
        return $updated;
    }
    private function repair_json_response($raw_content, $rewrite) {
        $schema = 'Верни строго валидный JSON с ключами: new_title, new_excerpt, new_meta_title, new_meta_description, new_content, faq, schema_recommendation, change_summary, preserved_items, warnings, confidence. Если режим meta_only, new_content может быть пустым. Во всех остальных режимах new_content должен содержать улучшенный HTML/Gutenberg-контент.';
        $messages = array(
            array('role'=>'system','content'=>'Ты исправляешь технически некорректный JSON-ответ редактора. Верни только валидный JSON без markdown и пояснений. Не переписывай статью заново, а аккуратно сохрани максимум полезных данных из исходного ответа. Все многострочные значения должны быть корректными JSON-строками.'),
            array('role'=>'user','content'=>$schema . "\n\nРежим переписывания: " . $rewrite->rewrite_mode . "\n\nНекорректный ответ:\n" . mb_substr((string)$raw_content, 0, 110000)),
        );
        $repair_max_tokens = max(12000, intval($this->settings->get('max_tokens', '6000')));
        $repair = $this->client->chat($messages, $repair_max_tokens);
        if (is_wp_error($repair)) { return $repair; }
        $parser = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        return $parser->parse_json($repair['content']);
    }


    private function rewrite_max_tokens($rewrite) {
        $base = intval($this->settings->get('max_tokens', '6000'));
        $content_len = mb_strlen(wp_strip_all_tags((string)$rewrite->original_content_longtext));
        // Статейник добавляет Hero Promise, Answer-First в каждый H2, FAQ, источники, CTA — статья растёт в 1.5-2x
        if ($content_len > 15000) { return max(32000, $base); }
        if ($content_len > 10000) { return max(24000, $base); }
        if ($content_len > 5000)  { return max(18000, $base); }
        return max(14000, $base);
    }

    private function retry_missing_or_short_content($rewrite, $audit, $payload, $previous_response, $reason) {
        if ($rewrite->rewrite_mode === 'meta_only') { return new WP_Error('meta_only_no_retry', 'Для режима meta_only повторная генерация текста не нужна.'); }
        $messages = array(
            array('role'=>'system','content'=>AISEOGEO_Prompt_Loader::rewrite_system() . "\n\nВАЖНО: предыдущий ответ был неполным. В этом ответе поле new_content обязательно должно содержать полный улучшенный HTML/Gutenberg-текст статьи. Не возвращай только план, мета-данные, sections или список блоков. Верни один валидный JSON-объект."),
            array('role'=>'user','content'=>'Причина повторной генерации: ' . $reason . "\n\nПредыдущий ответ модели был неполным или не содержал new_content. Сгенерируй полный результат заново по исходной статье, анализу и плану.\n\nДанные для переписывания:\n" . wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n\nПредыдущий неполный ответ для ориентира, не копируй его ошибки:\n" . mb_substr((string)$previous_response, 0, 50000)),
        );
        $retry = $this->client->chat($messages, max(18000, $this->rewrite_max_tokens($rewrite)));
        if (is_wp_error($retry)) { return $retry; }
        $parser = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        $json = $parser->parse_json($retry['content']);
        if (is_wp_error($json)) {
            $repaired = $this->repair_json_response($retry['content'], $rewrite);
            if (!is_wp_error($repaired)) { return $repaired; }
        }
        return $json;
    }

    private function normalize_rewrite_json($json, $rewrite) {
        if (isset($json['result']) && is_array($json['result'])) { $json = array_merge($json, $json['result']); }
        if (isset($json['data']) && is_array($json['data'])) { $json = array_merge($json, $json['data']); }
        if (isset($json['article']) && is_array($json['article'])) { $json = array_merge($json, $json['article']); }

        $map = array(
            'new_title' => array('title','seo_title','headline'),
            'new_excerpt' => array('excerpt','description','summary'),
            'new_meta_title' => array('meta_title','seo_meta_title'),
            'new_meta_description' => array('meta_description','seo_description'),
            'new_content' => array('content','html','article_content','body','body_html','rewritten_content','final_content','improved_content','wordpress_content','full_text','text'),
            'faq' => array('faqs','questions'),
            'schema_recommendation' => array('schema','json_ld','schema_json'),
            'change_summary' => array('changes','change_log','summary_of_changes'),
            'warnings' => array('risks','notes'),
            'preserved_items' => array('protected_items','saved_items'),
        );
        foreach ($map as $target => $sources) {
            if (!isset($json[$target]) || $json[$target] === '' || $json[$target] === array()) {
                foreach ($sources as $source) {
                    if (isset($json[$source]) && $json[$source] !== '' && $json[$source] !== array()) { $json[$target] = $json[$source]; break; }
                }
            }
        }

        if ((empty($json['new_content']) || is_array($json['new_content'])) && !empty($json['sections']) && is_array($json['sections'])) {
            $json['new_content'] = $this->structured_blocks_to_html($json['sections']);
        }
        if ((empty($json['new_content']) || is_array($json['new_content'])) && !empty($json['content_blocks']) && is_array($json['content_blocks'])) {
            $json['new_content'] = $this->structured_blocks_to_html($json['content_blocks']);
        }
        if (empty($json['new_content']) || is_array($json['new_content'])) {
            $deep_content = $this->find_longest_content_string($json);
            if ($deep_content !== '') { $json['new_content'] = $deep_content; }
        }

        foreach (array('new_title','new_excerpt','new_meta_title','new_meta_description','new_content') as $key) {
            if (!isset($json[$key])) { $json[$key] = ''; }
            if (is_array($json[$key]) || is_object($json[$key])) { $json[$key] = ($key === 'new_content') ? $this->structured_blocks_to_html((array)$json[$key]) : wp_json_encode($json[$key], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }
            $json[$key] = (string)$json[$key];
        }
        foreach (array('faq','change_summary','warnings','preserved_items') as $key) {
            if (!isset($json[$key]) || $json[$key] === '') { $json[$key] = array(); }
            if (!is_array($json[$key])) { $json[$key] = array((string)$json[$key]); }
        }
        if (!isset($json['schema_recommendation']) || $json['schema_recommendation'] === '') { $json['schema_recommendation'] = array(); }
        if (!is_array($json['schema_recommendation'])) { $json['schema_recommendation'] = array('note'=>(string)$json['schema_recommendation']); }
        if (!isset($json['confidence'])) { $json['confidence'] = 0; }

        if ($rewrite->rewrite_mode === 'meta_only' && trim($json['new_content']) === '') { $json['new_content'] = $rewrite->original_content_longtext; }
        return $json;
    }


    private function find_longest_content_string($data, $depth = 0) {
        if ($depth > 6) { return ''; }
        $best = '';
        $preferred_keys = array('new_content','content','article_content','rewritten_content','improved_content','optimized_content','updated_content','final_content','html','body','body_html','full_article','rewritten_article','improved_article','optimized_article','article_html','wordpress_content','post_content');
        if (is_array($data)) {
            foreach ($preferred_keys as $key) {
                if (isset($data[$key]) && is_string($data[$key])) {
                    $candidate = trim($data[$key]);
                    if (mb_strlen(wp_strip_all_tags($candidate)) > mb_strlen(wp_strip_all_tags($best))) { $best = $candidate; }
                }
            }
            foreach ($data as $key => $value) {
                $key_l = is_string($key) ? mb_strtolower($key) : '';
                if (is_string($value)) {
                    $candidate = trim($value);
                    $plain_len = mb_strlen(wp_strip_all_tags($candidate));
                    $looks_like_content = $plain_len > 500 && (preg_match('/<(p|h2|h3|ul|ol|li|blockquote|!-- wp:)/iu', $candidate) || preg_match('/(статья|бизнес|клиент|решение|автоматизац|ассистент|контент|услуг)/iu', $candidate));
                    $key_looks_right = preg_match('/(content|article|body|html|text|post)/iu', $key_l);
                    if (($key_looks_right || $looks_like_content) && $plain_len > mb_strlen(wp_strip_all_tags($best))) { $best = $candidate; }
                } elseif (is_array($value) || is_object($value)) {
                    $candidate = $this->find_longest_content_string((array)$value, $depth + 1);
                    if (mb_strlen(wp_strip_all_tags($candidate)) > mb_strlen(wp_strip_all_tags($best))) { $best = $candidate; }
                }
            }
        }
        return trim($best);
    }

    private function apply_safe_content_fallback($json, $rewrite, $reason = '') {
        if (!is_array($json)) { $json = array(); }
        $content = (string)$rewrite->original_content_longtext;
        $warnings = isset($json['warnings']) && is_array($json['warnings']) ? $json['warnings'] : array();
        $warnings[] = 'AI не вернул полный новый текст статьи. Использован безопасный fallback: исходный контент сохранён, а улучшения применены только к доступным SEO-полям/FAQ. Причина: ' . (string)$reason;

        if (!empty($json['faq']) && is_array($json['faq']) && !$this->has_marker(wp_strip_all_tags($content), array('частые вопросы','faq','вопросы и ответы'))) {
            $faq_html = "

<h2>Частые вопросы</h2>
";
            foreach ($json['faq'] as $faq) {
                if (!is_array($faq)) { continue; }
                $q = trim((string)($faq['question'] ?? ''));
                $a = trim((string)($faq['answer'] ?? ''));
                if ($q !== '' && $a !== '') {
                    $faq_html .= '<h3>' . esc_html(wp_strip_all_tags($q)) . "</h3>
";
                    $faq_html .= '<p>' . esc_html(wp_strip_all_tags($a)) . "</p>
";
                }
            }
            if (trim(wp_strip_all_tags($faq_html)) !== 'Частые вопросы') {
                $content .= $faq_html;
                $warnings[] = 'FAQ из ответа AI добавлен к сохранённому исходному тексту.';
            }
        }

        $json['new_content'] = $content;
        $json['warnings'] = $warnings;
        if (empty($json['change_summary']) || !is_array($json['change_summary'])) { $json['change_summary'] = array(); }
        $json['change_summary'][] = array('type'=>'content','before'=>'исходный текст','after'=>'исходный текст сохранён','comment'=>'AI не вернул полный новый текст; чтобы не потерять статью, основной контент сохранён без опасной пустой замены.');
        return $json;
    }

    private function structured_blocks_to_html($blocks) {
        if (!is_array($blocks)) { return ''; }
        $html = '';
        foreach ($blocks as $block) {
            if (is_string($block)) { $html .= '<p>' . esc_html($block) . '</p>' . "\n"; continue; }
            if (!is_array($block)) { continue; }
            $heading = $block['heading'] ?? ($block['title'] ?? ($block['h2'] ?? ''));
            $level = isset($block['level']) ? intval($block['level']) : 2;
            $level = min(6, max(2, $level));
            $text = $block['text'] ?? ($block['content'] ?? ($block['body'] ?? ($block['paragraph'] ?? '')));
            if ($heading !== '') { $html .= '<h' . $level . '>' . esc_html(wp_strip_all_tags((string)$heading)) . '</h' . $level . '>' . "\n"; }
            if (is_array($text)) {
                foreach ($text as $p) { if (trim((string)$p) !== '') { $html .= '<p>' . esc_html(wp_strip_all_tags((string)$p)) . '</p>' . "\n"; } }
            } elseif (trim((string)$text) !== '') {
                $html .= '<p>' . esc_html(wp_strip_all_tags((string)$text)) . '</p>' . "\n";
            }
            if (!empty($block['items']) && is_array($block['items'])) {
                $html .= '<ul>';
                foreach ($block['items'] as $item) { $html .= '<li>' . esc_html(wp_strip_all_tags(is_array($item) ? wp_json_encode($item, JSON_UNESCAPED_UNICODE) : (string)$item)) . '</li>'; }
                $html .= '</ul>' . "\n";
            }
        }
        return trim($html);
    }

    private function build_auto_change_summary($rewrite, $json, $new_content) {
        $summary = array();
        $new_title = (string)($json['new_title'] ?? '');
        $new_excerpt = (string)($json['new_excerpt'] ?? '');
        $new_meta_title = (string)($json['new_meta_title'] ?? '');
        $new_meta_description = (string)($json['new_meta_description'] ?? '');

        if ($new_title !== '' && trim($new_title) !== trim((string)$rewrite->original_title)) {
            $summary[] = array('type'=>'title','before'=>(string)$rewrite->original_title,'after'=>$new_title,'comment'=>'Изменён заголовок статьи.');
        }
        if ($new_excerpt !== '' && trim(wp_strip_all_tags($new_excerpt)) !== trim(wp_strip_all_tags((string)$rewrite->original_excerpt))) {
            $summary[] = array('type'=>'excerpt','before'=>mb_substr(wp_strip_all_tags((string)$rewrite->original_excerpt),0,220),'after'=>mb_substr(wp_strip_all_tags($new_excerpt),0,220),'comment'=>'Изменено краткое описание / excerpt.');
        }
        if ($new_meta_title !== '') { $summary[] = array('type'=>'meta','before'=>'','after'=>$new_meta_title,'comment'=>'Сформирован новый SEO title.'); }
        if ($new_meta_description !== '') { $summary[] = array('type'=>'meta','before'=>'','after'=>$new_meta_description,'comment'=>'Сформировано новое meta description.'); }

        $old_h = $this->extract_headings_for_summary((string)$rewrite->original_content_longtext);
        $new_h = $this->extract_headings_for_summary((string)$new_content);
        $added = array_values(array_diff($new_h, $old_h));
        $removed = array_values(array_diff($old_h, $new_h));
        if ($added || $removed || count($old_h) !== count($new_h)) {
            $summary[] = array('type'=>'headings','before'=>implode(' | ', array_slice($old_h,0,8)),'after'=>implode(' | ', array_slice($new_h,0,8)),'comment'=>'Изменена структура подзаголовков. Добавлено: '.count($added).', удалено: '.count($removed).'.');
        }

        $old_plain = trim(preg_replace('/\s+/u',' ',wp_strip_all_tags((string)$rewrite->original_content_longtext)));
        $new_plain = trim(preg_replace('/\s+/u',' ',wp_strip_all_tags((string)$new_content)));
        $old_words = $this->count_words_for_summary($old_plain);
        $new_words = $this->count_words_for_summary($new_plain);
        if ($old_words !== $new_words) {
            $summary[] = array('type'=>'content','before'=>$old_words.' слов','after'=>$new_words.' слов','comment'=>'Изменён объём текста.');
        }

        $old_faq = $this->has_marker($old_plain, array('частые вопросы','faq','вопросы и ответы'));
        $new_faq = $this->has_marker($new_plain, array('частые вопросы','faq','вопросы и ответы')) || !empty($json['faq']);
        if ($old_faq || $new_faq) { $summary[] = array('type'=>'faq','before'=>$old_faq?'был':'не было','after'=>$new_faq?'есть':'нет','comment'=>$old_faq && !$new_faq ? 'Внимание: FAQ был в исходной статье, но не найден в новой версии.' : 'Проверено наличие FAQ-блока.'); }

        $old_cta = $this->has_marker($old_plain, array('следующий шаг','оставить заявку','получить консультацию','заказать','попробовать','начать'));
        $new_cta = $this->has_marker($new_plain, array('следующий шаг','оставить заявку','получить консультацию','заказать','попробовать','начать'));
        if ($old_cta || $new_cta) { $summary[] = array('type'=>'cta','before'=>$old_cta?'был':'не было','after'=>$new_cta?'есть':'нет','comment'=>$old_cta && !$new_cta ? 'Внимание: CTA был в исходной статье, но не найден в новой версии.' : 'Проверено наличие CTA / следующего шага.'); }

        return $summary;
    }

    private function extract_headings_for_summary($content) {
        $out = array();
        if (preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\1>/isu', $content, $m, PREG_SET_ORDER)) {
            foreach ($m as $row) {
                $text = trim(preg_replace('/\s+/u',' ',wp_strip_all_tags($row[2])));
                if ($text !== '') { $out[] = 'H'.$row[1].': '.$text; }
            }
        }
        return $out;
    }

    private function count_words_for_summary($text) {
        preg_match_all('/[\p{L}\p{N}]+/u', (string)$text, $m);
        return count($m[0]);
    }

    private function has_marker($text, $markers) {
        $text = mb_strtolower((string)$text);
        foreach ($markers as $marker) { if (mb_stripos($text, mb_strtolower($marker)) !== false) { return true; } }
        return false;
    }

    private function validate_rewrite_result($json, $rewrite) {
        if ($rewrite->rewrite_mode !== 'meta_only') {
            if (empty($json['new_content'])) { return new WP_Error('empty_new_content','AI не вернул новый текст статьи.'); }
            $orig_len = mb_strlen(wp_strip_all_tags($rewrite->original_content_longtext));
            $new_len = mb_strlen(wp_strip_all_tags($json['new_content']));
            // По методологии статейника новая статья должна быть минимум 90% от оригинала
            // (full_refresh и geo_boost должны быть длиннее, но 90% защищает от обрезки)
            $min_ratio = in_array($rewrite->rewrite_mode, array('problem_blocks_only', 'meta_only'), true) ? 0.5 : 0.9;
            if ($orig_len > 800 && $new_len < max(500, (int)($orig_len * $min_ratio))) {
                return new WP_Error('too_short_content', sprintf(
                    'AI вернул слишком короткий текст: %d симв. (оригинал %d симв., требуется минимум %d симв.).',
                    $new_len, $orig_len, (int)($orig_len * $min_ratio)
                ));
            }
        }
        return true;
    }
    private function fail($rewrite_id, $message, $context) { global $wpdb; $wpdb->update($this->table(), array('rewrite_status'=>'failed','error_message'=>$message,'updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id))); $this->logger->log('error',$context,$message,array('rewrite_id'=>$rewrite_id)); return new WP_Error('rewrite_failed',$message); }
    private function save_raw_error($rewrite_id, $message, $result) { global $wpdb; $wpdb->update($this->table(), array('rewrite_status'=>'failed','error_message'=>$message,'raw_rewrite_response'=>$result['content'] ?? '','model'=>$result['model'] ?? '','updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id))); $this->logger->log('error','rewrite_run',$message,array('rewrite_id'=>$rewrite_id)); }
    public function get_rewrite($rewrite_id) { global $wpdb; return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table()} WHERE id=%d", absint($rewrite_id))); }
    public function get_post_rewrites($post_id) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} WHERE post_id=%d AND rewrite_status <> 'deleted' ORDER BY id DESC", absint($post_id))); }
    public function history($limit=100) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} WHERE rewrite_status <> 'deleted' ORDER BY id DESC LIMIT %d", absint($limit))); }
    public function delete_rewrite($rewrite_id) { global $wpdb; return $wpdb->update($this->table(), array('rewrite_status'=>'deleted','updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id))); }
    public function mark_draft_created($rewrite_id, $draft_id) { global $wpdb; return $wpdb->update($this->table(), array('rewrite_status'=>'draft_created','created_draft_post_id'=>absint($draft_id),'updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id))); }
    public function mark_reaudited($rewrite_id, $audit_id) { global $wpdb; $wpdb->update($this->table(), array('rewrite_status'=>'re_audited','re_audit_id'=>absint($audit_id),'updated_at'=>current_time('mysql')), array('id'=>absint($rewrite_id))); $this->version_service->update_rewrite_scores($rewrite_id, $this->audit_service->get_audit($audit_id)); }

    public function create_rewrite_bypass($post_id, $audit_id, $rewrite_mode) {
        $plan_service = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        return $plan_service->create_plan_bypass($post_id, $audit_id, $rewrite_mode);
    }
    public function run_rewrite_bypass($rewrite_id) {
        $rewrite = $this->get_rewrite($rewrite_id);
        if (!$rewrite) { return new WP_Error('rewrite_not_found','План улучшения не найден.'); }
        if (!in_array($rewrite->rewrite_status, array('plan_created','failed'), true)) { return new WP_Error('bad_status','Нельзя запустить переписывание из текущего статуса.'); }
        $audit = $this->audit_service->get_audit((int)$rewrite->audit_id);
        global $wpdb; $now=current_time('mysql');
        $wpdb->update($this->table(), array('rewrite_status'=>'rewriting','updated_at'=>$now), array('id'=>(int)$rewrite_id));
        $this->step_no = 0; $this->step_started = microtime(true);
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание (авто)', 'Старт автоматического переписывания.', array('режим'=>$rewrite->rewrite_mode));
        $payload = array(
            'rewrite_id'=>(int)$rewrite->id, 'rewrite_mode'=>$rewrite->rewrite_mode,
            'original'=>array('title'=>$rewrite->original_title,'excerpt'=>$rewrite->original_excerpt,'content'=>$rewrite->original_content_longtext),
            'audit'=>$audit ? array('summary'=>$audit->summary,'scores'=>array('overall'=>$audit->overall_score,'seo'=>$audit->seo_score,'geo'=>$audit->geo_score,'eeat'=>$audit->eeat_score),'problems'=>json_decode($audit->problems_json,true),'recommendations'=>json_decode($audit->recommendations_json,true),'suggested'=>json_decode($audit->suggested_json,true)) : array(),
            'plan'=>json_decode($rewrite->improvement_plan_json,true),
            'protected_items'=>json_decode($rewrite->protected_items_json,true),
        );
        $messages = array(
            array('role'=>'system','content'=>AISEOGEO_Prompt_Loader::rewrite_system()),
            array('role'=>'user','content'=>AISEOGEO_Prompt_Loader::rewrite_user($payload)),
        );
        $rewrite_max_tokens = $this->rewrite_max_tokens($rewrite);
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание (авто)', 'Запрос к AI.', array('лимит_токенов'=>$rewrite_max_tokens));
        $result = $this->client->chat($messages, $rewrite_max_tokens);
        if (is_wp_error($result)) { $this->step($rewrite_id, $rewrite->post_id, 'Этап 6', 'ОШИБКА AI: '.$result->get_error_message()); return $this->fail($rewrite_id, $result->get_error_message(), 'rewrite_run'); }
        $this->step($rewrite_id, $rewrite->post_id, 'Этап 6: Написание (авто)', 'Ответ AI получен.', array('длина_симв'=>mb_strlen((string)($result['content'] ?? ''))));
        $plan_parser = new AISEOGEO_Rewrite_Plan_Service($this->settings, $this->logger, $this->audit_service);
        $json = $plan_parser->parse_json($result['content']);
        if (is_wp_error($json)) {
            $repaired = $this->repair_json_response($result['content'], $rewrite);
            if (!is_wp_error($repaired)) { $json = $repaired; }
        }
        if (is_wp_error($json)) { $this->save_raw_error($rewrite_id, $json->get_error_message(), $result); return $json; }
        $json = $this->normalize_rewrite_json($json, $rewrite);
        $valid = $this->validate_rewrite_result($json, $rewrite);
        if (is_wp_error($valid) && in_array($valid->get_error_code(), array('empty_new_content','too_short_content'), true)) {
            $retry = $this->retry_missing_or_short_content($rewrite, $audit, $payload, $result['content'], $valid->get_error_message());
            if (!is_wp_error($retry)) { $json = $this->normalize_rewrite_json($retry, $rewrite); $valid = $this->validate_rewrite_result($json, $rewrite); }
        }
        if (is_wp_error($valid) && $valid->get_error_code() === 'empty_new_content') {
            $json = $this->apply_safe_content_fallback($json, $rewrite, $valid->get_error_message());
            $valid = $this->validate_rewrite_result($json, $rewrite);
        }
        if (is_wp_error($valid)) { $this->save_raw_error($rewrite_id, $valid->get_error_message(), $result); return $valid; }
        $new_content = (string)($json['new_content'] ?? '');
        if ($rewrite->rewrite_mode === 'meta_only' && trim($new_content) === '') { $new_content = $rewrite->original_content_longtext; }
        $protected = json_decode($rewrite->protected_items_json,true) ?: array();
        $preserve_warnings = $this->protector->validate_preserved_items($rewrite->original_content_longtext, $new_content, $protected);
        $warnings = $json['warnings'] ?? array(); if (!is_array($warnings)) { $warnings = array((string)$warnings); }
        $heading_warnings = $this->protector->validate_heading_context($rewrite->original_content_longtext, $new_content);
        $warnings = array_merge($warnings, $preserve_warnings, $heading_warnings);
        $change_summary = $json['change_summary'] ?? array();
        if (!is_array($change_summary)) { $change_summary = array((string)$change_summary); }
        $change_summary = array_merge($this->build_auto_change_summary($rewrite, $json, $new_content), $change_summary);
        $wpdb->update($this->table(), array(
            'rewrite_status'=>'done','new_title'=>sanitize_text_field($json['new_title'] ?? $rewrite->original_title),'new_excerpt'=>wp_kses_post($json['new_excerpt'] ?? ''),'new_content_longtext'=>wp_kses_post($new_content),
            'new_meta_title'=>sanitize_text_field($json['new_meta_title'] ?? ''),'new_meta_description'=>sanitize_textarea_field($json['new_meta_description'] ?? ''),
            'new_faq_json'=>wp_json_encode($json['faq'] ?? array(), JSON_UNESCAPED_UNICODE),'new_schema_json'=>wp_json_encode($json['schema_recommendation'] ?? array(), JSON_UNESCAPED_UNICODE),
            'change_summary_json'=>wp_json_encode($change_summary, JSON_UNESCAPED_UNICODE),'warnings_json'=>wp_json_encode(array_values(array_unique(array_filter($warnings))), JSON_UNESCAPED_UNICODE),
            'preserved_items_json'=>wp_json_encode($json['preserved_items'] ?? array(), JSON_UNESCAPED_UNICODE),'raw_rewrite_response'=>$this->settings->get('save_raw_response','1') === '1' ? $result['content'] : '',
            'model'=>$result['model'],'status_message'=>'Улучшенная версия создана (авто).','error_message'=>'','updated_at'=>current_time('mysql')
        ), array('id'=>(int)$rewrite_id));
        $updated = $this->get_rewrite($rewrite_id);
        $this->version_service->create_versions($updated, $audit);
        $this->step($rewrite_id, $rewrite->post_id, 'Готово (авто)', 'Автоматическая улучшенная версия создана.', array('итоговый_объём_симв'=>mb_strlen(wp_strip_all_tags($new_content)),'всего_шагов'=>$this->step_no));
        $this->logger->log('info','auto_rewrite','Автоматическая улучшенная версия создана.',array('rewrite_id'=>$rewrite_id),(int)$rewrite->post_id);
        return $updated;
    }
}

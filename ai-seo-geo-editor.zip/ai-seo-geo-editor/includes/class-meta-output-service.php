<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Ensures a real <meta name="description"> is printed on singular posts.
 *
 * This class is intentionally assertive: external SEO checkers validate the
 * final HTML, not WP excerpt fields. Therefore, when the plugin can determine
 * a safe description, it prints it even if SEO-plugin meta fields exist but the
 * SEO plugin/theme does not output the tag.
 */
class AISEOGEO_Meta_Output_Service {
    private $settings;
    private static $printed = false;

    public function __construct($settings) {
        $this->settings = $settings;
    }

    public function init() {
        // Early enough for normal themes, but protected from double output by self::$printed.
        add_action('wp_head', array($this, 'output_meta_description'), 1);
        // Late fallback for themes/plugins that manipulate head after early hooks.
        add_action('wp_head', array($this, 'output_meta_description'), 99);
    }

    public function output_meta_description() {
        if (self::$printed) { return; }
        if (is_admin() || !is_singular('post')) { return; }

        $enabled = $this->settings ? (string)$this->settings->get('frontend_meta_description_enabled', '1') : '1';
        if ($enabled !== '1') { return; }

        $post_id = get_queried_object_id();
        if (!$post_id) { return; }

        $description = $this->get_best_description($post_id);
        if ($description === '') { return; }

        self::$printed = true;
        echo "\n" . '<meta name="description" content="' . esc_attr($description) . '" class="aiseogeo-meta-description" />' . "\n";
    }

    public function get_best_description($post_id) {
        $candidates = array(
            get_post_meta($post_id, '_aiseogeo_meta_description', true),
            get_post_meta($post_id, '_yoast_wpseo_metadesc', true),
            get_post_meta($post_id, 'rank_math_description', true),
            get_post_meta($post_id, '_aioseo_description', true),
            get_post_meta($post_id, '_aioseop_description', true),
            get_post_field('post_excerpt', $post_id),
        );

        foreach ($candidates as $candidate) {
            $description = $this->clean_description($candidate);
            if ($description !== '') { return $description; }
        }

        // Last-resort fallback: create a clean snippet from the beginning of the post body.
        $content = get_post_field('post_content', $post_id);
        $description = $this->clean_description($content);
        return $description;
    }

    private function clean_description($value) {
        $value = strip_shortcodes((string)$value);
        $value = wp_strip_all_tags($value, true);
        $value = html_entity_decode($value, ENT_QUOTES, get_bloginfo('charset'));
        $value = preg_replace('/\s+/u', ' ', $value);
        $value = trim($value);
        if ($value === '') { return ''; }

        // Keep checker-friendly length. 150-170 chars is usually enough for snippets.
        if (function_exists('mb_strlen') && mb_strlen($value) > 170) {
            $value = mb_substr($value, 0, 167) . '...';
        } elseif (strlen($value) > 170) {
            $value = substr($value, 0, 167) . '...';
        }
        return $value;
    }
}

<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Ensures a real <meta name="description"> is printed on singular posts.
 *
 * This class is intentionally assertive: external SEO checkers validate the
 * final HTML, not WP excerpt fields. Therefore, when the plugin can determine
 * a safe description, it prints it even if SEO-plugin meta fields exist but the
 * SEO plugin/theme does not output the tag.
 */
class AISEOGEO_Meta_Output_Service {
    private $settings;
    private static $printed = false;

    public function __construct($settings) {
        $this->settings = $settings;
    }

    private static $schema_printed = false;

    public function init() {
        // Early enough for normal themes, but protected from double output by self::$printed.
        add_action('wp_head', array($this, 'output_meta_description'), 1);
        // Late fallback for themes/plugins that manipulate head after early hooks.
        add_action('wp_head', array($this, 'output_meta_description'), 99);
        // JSON-LD Article + FAQPage — раньше генерировалось AI, но никогда не печаталось в HTML.
        add_action('wp_head', array($this, 'output_schema_jsonld'), 5);
    }

    public function output_schema_jsonld() {
        if (self::$schema_printed) { return; }
        if (is_admin() || !is_singular('post')) { return; }
        $post_id = get_queried_object_id();
        if (!$post_id) { return; }

        $graph = array();

        // Article
        $post = get_post($post_id);
        if ($post) {
            $article = array(
                '@type'            => 'Article',
                'headline'         => wp_strip_all_tags(get_the_title($post_id)),
                'datePublished'    => mysql2date('c', $post->post_date_gmt, false),
                'dateModified'     => mysql2date('c', $post->post_modified_gmt, false),
                'mainEntityOfPage' => get_permalink($post_id),
            );
            $description = $this->get_best_description($post_id);
            if ($description !== '') { $article['description'] = $description; }
            if (has_post_thumbnail($post_id)) {
                $img = wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'full');
                if ($img) { $article['image'] = $img[0]; }
            }
            $author_name = get_the_author_meta('display_name', (int)$post->post_author);
            if ($author_name) {
                $article['author'] = array('@type' => 'Person', 'name' => $author_name);
            }
            $graph[] = $article;
        }

        // FAQPage — из данных, применённых через AI-переписывание
        $faq_raw = get_post_meta($post_id, '_aiseogeo_faq_json', true);
        $faq = $faq_raw ? json_decode((string)$faq_raw, true) : null;
        if (is_array($faq) && !empty($faq)) {
            $qa = array();
            foreach ($faq as $item) {
                $q = trim((string)($item['question'] ?? ''));
                $a = trim((string)($item['answer'] ?? ''));
                if ($q === '' || $a === '') { continue; }
                $qa[] = array(
                    '@type'          => 'Question',
                    'name'           => $q,
                    'acceptedAnswer' => array('@type' => 'Answer', 'text' => $a),
                );
            }
            if (!empty($qa)) {
                $graph[] = array('@type' => 'FAQPage', 'mainEntity' => $qa);
            }
        }

        if (empty($graph)) { return; }

        self::$schema_printed = true;
        $payload = array('@context' => 'https://schema.org', '@graph' => $graph);
        echo "\n" . '<script type="application/ld+json" class="aiseogeo-schema">'
           . wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
           . '</script>' . "\n";
    }

    public function output_meta_description() {
        if (self::$printed) { return; }
        if (is_admin() || !is_singular('post')) { return; }

        $enabled = $this->settings ? (string)$this->settings->get('frontend_meta_description_enabled', '1') : '1';
        if ($enabled !== '1') { return; }

        $post_id = get_queried_object_id();
        if (!$post_id) { return; }

        $description = $this->get_best_description($post_id);
        if ($description === '') { return; }

        self::$printed = true;
        echo "\n" . '<meta name="description" content="' . esc_attr($description) . '" class="aiseogeo-meta-description" />' . "\n";
    }

    public function get_best_description($post_id) {
        $candidates = array(
            get_post_meta($post_id, '_aiseogeo_meta_description', true),
            get_post_meta($post_id, '_yoast_wpseo_metadesc', true),
            get_post_meta($post_id, 'rank_math_description', true),
            get_post_meta($post_id, '_aioseo_description', true),
            get_post_meta($post_id, '_aioseop_description', true),
            get_post_field('post_excerpt', $post_id),
        );

        foreach ($candidates as $candidate) {
            $description = $this->clean_description($candidate);
            if ($description !== '') { return $description; }
        }

        // Last-resort fallback: create a clean snippet from the beginning of the post body.
        $content = get_post_field('post_content', $post_id);
        $description = $this->clean_description($content);
        return $description;
    }

    private function clean_description($value) {
        $value = strip_shortcodes((string)$value);
        $value = wp_strip_all_tags($value, true);
        $value = html_entity_decode($value, ENT_QUOTES, get_bloginfo('charset'));
        $value = preg_replace('/\s+/u', ' ', $value);
        $value = trim($value);
        if ($value === '') { return ''; }

        // Keep checker-friendly length. 150-170 chars is usually enough for snippets.
        if (function_exists('mb_strlen') && mb_strlen($value) > 170) {
            $value = mb_substr($value, 0, 167) . '...';
        } elseif (strlen($value) > 170) {
            $value = substr($value, 0, 167) . '...';
        }
        return $value;
    }
}

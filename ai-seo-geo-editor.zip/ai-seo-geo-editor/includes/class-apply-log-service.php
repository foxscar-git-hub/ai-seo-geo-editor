<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Apply_Log_Service {
    public function table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_apply_logs'; }
    public function add($post_id, $rewrite_id, $backup_id, $fields, $status = 'done', $error = '') {
        global $wpdb;
        $wpdb->insert($this->table(), array(
            'post_id' => absint($post_id),
            'rewrite_id' => absint($rewrite_id),
            'backup_id' => absint($backup_id),
            'applied_fields_json' => wp_json_encode(array_values((array)$fields), JSON_UNESCAPED_UNICODE),
            'applied_by' => get_current_user_id(),
            'status' => sanitize_key($status),
            'error_message' => $error,
            'created_at' => current_time('mysql'),
        ));
        return (int)$wpdb->insert_id;
    }
    public function history($limit = 100) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} ORDER BY id DESC LIMIT %d", absint($limit))); }
    public function get_by_post($post_id, $limit = 20) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} WHERE post_id=%d ORDER BY id DESC LIMIT %d", absint($post_id), absint($limit))); }
}

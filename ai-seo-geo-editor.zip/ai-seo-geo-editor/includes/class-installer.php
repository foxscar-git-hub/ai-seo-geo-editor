<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Installer {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $audits = $wpdb->prefix . 'aiseogeo_audits';
        $logs = $wpdb->prefix . 'aiseogeo_logs';
        $settings = $wpdb->prefix . 'aiseogeo_settings';
        $rewrites = $wpdb->prefix . 'aiseogeo_rewrites';
        $versions = $wpdb->prefix . 'aiseogeo_versions';
        $backups = $wpdb->prefix . 'aiseogeo_backups';
        $jobs = $wpdb->prefix . 'aiseogeo_jobs';
        $job_items = $wpdb->prefix . 'aiseogeo_job_items';
        $apply_logs = $wpdb->prefix . 'aiseogeo_apply_logs';
        dbDelta("CREATE TABLE {$audits} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            post_title TEXT NULL,
            post_status VARCHAR(40) NULL,
            audit_type VARCHAR(80) NOT NULL DEFAULT 'full',
            rewrite_id BIGINT UNSIGNED NULL,
            source_audit_id BIGINT UNSIGNED NULL,
            content_source VARCHAR(32) NULL DEFAULT 'post',
            overall_score INT NULL,
            seo_score INT NULL,
            geo_score INT NULL,
            eeat_score INT NULL,
            readability_score INT NULL,
            structure_score INT NULL,
            meta_score INT NULL,
            internal_links_score INT NULL,
            summary LONGTEXT NULL,
            problems_json LONGTEXT NULL,
            recommendations_json LONGTEXT NULL,
            suggested_json LONGTEXT NULL,
            raw_ai_response LONGTEXT NULL,
            model VARCHAR(190) NULL,
            status VARCHAR(40) NOT NULL DEFAULT 'done',
            error_message TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY status (status),
            KEY rewrite_id (rewrite_id),
            KEY source_audit_id (source_audit_id),
            KEY content_source (content_source),
            KEY created_at (created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$logs} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            level VARCHAR(20) NOT NULL DEFAULT 'info',
            context VARCHAR(100) NULL,
            post_id BIGINT UNSIGNED NULL,
            message TEXT NULL,
            data_json LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY level (level),
            KEY context (context),
            KEY created_at (created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$settings} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            setting_key VARCHAR(190) NOT NULL,
            setting_value LONGTEXT NULL,
            autoload TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY setting_key (setting_key)
        ) {$charset};");
        dbDelta("CREATE TABLE {$rewrites} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            audit_id BIGINT UNSIGNED NOT NULL,
            rewrite_mode VARCHAR(64) NOT NULL,
            rewrite_status VARCHAR(32) NOT NULL DEFAULT 'draft',
            improvement_plan_json LONGTEXT NULL,
            protected_items_json LONGTEXT NULL,
            original_title TEXT NULL,
            original_excerpt LONGTEXT NULL,
            original_content_longtext LONGTEXT NULL,
            new_title TEXT NULL,
            new_excerpt LONGTEXT NULL,
            new_content_longtext LONGTEXT NULL,
            new_meta_title TEXT NULL,
            new_meta_description TEXT NULL,
            new_faq_json LONGTEXT NULL,
            new_schema_json LONGTEXT NULL,
            change_summary_json LONGTEXT NULL,
            warnings_json LONGTEXT NULL,
            preserved_items_json LONGTEXT NULL,
            re_audit_id BIGINT UNSIGNED NULL,
            created_draft_post_id BIGINT UNSIGNED NULL,
            model VARCHAR(191) NULL,
            status_message TEXT NULL,
            error_message LONGTEXT NULL,
            raw_plan_response LONGTEXT NULL,
            raw_rewrite_response LONGTEXT NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY audit_id (audit_id),
            KEY rewrite_status (rewrite_status),
            KEY rewrite_mode (rewrite_mode),
            KEY created_draft_post_id (created_draft_post_id)
        ) {$charset};");
        dbDelta("CREATE TABLE {$versions} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            rewrite_id BIGINT UNSIGNED NOT NULL,
            version_type VARCHAR(32) NOT NULL,
            title TEXT NULL,
            excerpt LONGTEXT NULL,
            content_longtext LONGTEXT NULL,
            meta_title TEXT NULL,
            meta_description TEXT NULL,
            score_before INT NULL,
            score_after INT NULL,
            seo_score_before INT NULL,
            seo_score_after INT NULL,
            geo_score_before INT NULL,
            geo_score_after INT NULL,
            eeat_score_before INT NULL,
            eeat_score_after INT NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'active',
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY rewrite_id (rewrite_id),
            KEY version_type (version_type),
            KEY status (status)
        ) {$charset};");
        dbDelta("CREATE TABLE {$backups} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            rewrite_id BIGINT UNSIGNED NULL,
            backup_type VARCHAR(64) NOT NULL DEFAULT 'before_apply',
            title TEXT NULL,
            excerpt LONGTEXT NULL,
            content_longtext LONGTEXT NULL,
            meta_json LONGTEXT NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY rewrite_id (rewrite_id),
            KEY backup_type (backup_type),
            KEY created_at (created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$jobs} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            job_type VARCHAR(64) NOT NULL,
            job_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            job_mode VARCHAR(64) NULL,
            total_items INT NOT NULL DEFAULT 0,
            processed_items INT NOT NULL DEFAULT 0,
            success_items INT NOT NULL DEFAULT 0,
            failed_items INT NOT NULL DEFAULT 0,
            settings_json LONGTEXT NULL,
            created_by BIGINT UNSIGNED NULL,
            started_at DATETIME NULL,
            finished_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY job_type (job_type),
            KEY job_status (job_status),
            KEY created_at (created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$job_items} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            job_id BIGINT UNSIGNED NOT NULL,
            post_id BIGINT UNSIGNED NOT NULL,
            item_status VARCHAR(32) NOT NULL DEFAULT 'pending',
            audit_id BIGINT UNSIGNED NULL,
            rewrite_id BIGINT UNSIGNED NULL,
            error_message LONGTEXT NULL,
            started_at DATETIME NULL,
            finished_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY job_id (job_id),
            KEY post_id (post_id),
            KEY item_status (item_status)
        ) {$charset};");
        dbDelta("CREATE TABLE {$apply_logs} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            rewrite_id BIGINT UNSIGNED NOT NULL,
            backup_id BIGINT UNSIGNED NULL,
            applied_fields_json LONGTEXT NULL,
            applied_by BIGINT UNSIGNED NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'done',
            error_message LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY rewrite_id (rewrite_id),
            KEY backup_id (backup_id),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset};");
        update_option('aiseogeo_version', AISEOGEO_VERSION);
        self::seed_defaults();
    }
    private static function seed_defaults() {
        $defaults = array(
            'base_url' => 'https://openrouter.ai/api/v1',
            'api_key' => '',
            'model' => 'google/gemini-2.5-flash',
            'fallback_model' => 'deepseek/deepseek-v4-flash',
            'timeout' => '60',
            'max_retry' => '1',
            'retry_delay' => '2',
            'temperature' => '0.2',
            'max_tokens' => '6000',
            'log_requests' => '1',
            'enable_metabox' => '1',
            'save_raw_response' => '1',
            'bulk_max_items' => '20',
            'bulk_hour_limit' => '30',
            'bulk_day_limit' => '100',
            'bulk_delay_seconds' => '30',
            'bulk_stop_after_errors' => '5',
            'license_key' => '',
            'license_product_key' => 'ai-seo-geo-editor',
            'license_server_url' => '',
            'license_status' => 'not_checked',
            'license_message' => 'Лицензия ещё не проверялась.',
            'frontend_meta_description_enabled' => '1',
            'free_audit_limit' => '10',
            'auto_optimize_enabled' => '0',
            'auto_optimize_mode' => 'soft_improve',
            'auto_optimize_model' => '',
        );
        $settings = new AISEOGEO_Settings();
        foreach ($defaults as $k => $v) {
            if ($settings->get($k, null) === null) { $settings->set($k, $v); }
        }
    }
}

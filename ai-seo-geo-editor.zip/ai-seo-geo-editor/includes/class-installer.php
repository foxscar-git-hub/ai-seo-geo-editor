<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Installer {
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $audits = $wpdb->prefix . 'aiseogeo_audits';
        $logs = $wpdb->prefix . 'aiseogeo_logs';
        $settings = $wpdb->prefix . 'aiseogeo_settings';
        $rewrites = $wpdb->prefix . 'aiseogeo_rewrites';
        $versions = $wpdb->prefix . 'aiseogeo_versions';
        $backups = $wpdb->prefix . 'aiseogeo_backups';
        $apply_logs = $wpdb->prefix . 'aiseogeo_apply_logs';
        $learning   = $wpdb->prefix . 'aiseogeo_learning';
        dbDelta("CREATE TABLE {$audits} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            post_title TEXT NULL,
            post_status VARCHAR(40) NULL,
            audit_type VARCHAR(80) NOT NULL DEFAULT 'full',
            rewrite_id BIGINT UNSIGNED NULL,
            source_audit_id BIGINT UNSIGNED NULL,
            content_source VARCHAR(32) NULL DEFAULT 'post',
            overall_score INT NULL,
            seo_score INT NULL,
            geo_score INT NULL,
            eeat_score INT NULL,
            readability_score INT NULL,
            structure_score INT NULL,
            meta_score INT NULL,
            internal_links_score INT NULL,
            anti_ai_score INT NULL,
            summary LONGTEXT NULL,
            problems_json LONGTEXT NULL,
            recommendations_json LONGTEXT NULL,
            suggested_json LONGTEXT NULL,
            raw_ai_response LONGTEXT NULL,
            model VARCHAR(190) NULL,
            status VARCHAR(40) NOT NULL DEFAULT 'done',
            error_message TEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY status (status),
            KEY rewrite_id (rewrite_id),
            KEY source_audit_id (source_audit_id),
            KEY content_source (content_source),
            KEY created_at (created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$logs} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            level VARCHAR(20) NOT NULL DEFAULT 'info',
            context VARCHAR(100) NULL,
            post_id BIGINT UNSIGNED NULL,
            message TEXT NULL,
            data_json LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY level (level),
            KEY context (context),
            KEY created_at (created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$settings} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            setting_key VARCHAR(190) NOT NULL,
            setting_value LONGTEXT NULL,
            autoload TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY setting_key (setting_key)
        ) {$charset};");
        dbDelta("CREATE TABLE {$rewrites} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            audit_id BIGINT UNSIGNED NOT NULL,
            rewrite_mode VARCHAR(64) NOT NULL,
            rewrite_status VARCHAR(32) NOT NULL DEFAULT 'draft',
            improvement_plan_json LONGTEXT NULL,
            protected_items_json LONGTEXT NULL,
            original_title TEXT NULL,
            original_excerpt LONGTEXT NULL,
            original_content_longtext LONGTEXT NULL,
            new_title TEXT NULL,
            new_excerpt LONGTEXT NULL,
            new_content_longtext LONGTEXT NULL,
            new_meta_title TEXT NULL,
            new_meta_description TEXT NULL,
            new_faq_json LONGTEXT NULL,
            new_schema_json LONGTEXT NULL,
            change_summary_json LONGTEXT NULL,
            warnings_json LONGTEXT NULL,
            preserved_items_json LONGTEXT NULL,
            re_audit_id BIGINT UNSIGNED NULL,
            created_draft_post_id BIGINT UNSIGNED NULL,
            model VARCHAR(191) NULL,
            status_message TEXT NULL,
            error_message LONGTEXT NULL,
            raw_plan_response LONGTEXT NULL,
            raw_rewrite_response LONGTEXT NULL,
            apply_status VARCHAR(32) NULL DEFAULT NULL,
            result_json LONGTEXT NULL,
            learning_evaluated TINYINT(1) NOT NULL DEFAULT 0,
            learning_views_growth FLOAT NULL,
            learning_success TINYINT(1) NULL,
            learning_note TEXT NULL,
            meta_json LONGTEXT NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY audit_id (audit_id),
            KEY rewrite_status (rewrite_status),
            KEY rewrite_mode (rewrite_mode),
            KEY created_draft_post_id (created_draft_post_id),
            KEY apply_status (apply_status),
            KEY learning_evaluated (learning_evaluated)
        ) {$charset};");
        dbDelta("CREATE TABLE {$versions} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            rewrite_id BIGINT UNSIGNED NOT NULL,
            version_type VARCHAR(32) NOT NULL,
            title TEXT NULL,
            excerpt LONGTEXT NULL,
            content_longtext LONGTEXT NULL,
            meta_title TEXT NULL,
            meta_description TEXT NULL,
            score_before INT NULL,
            score_after INT NULL,
            seo_score_before INT NULL,
            seo_score_after INT NULL,
            geo_score_before INT NULL,
            geo_score_after INT NULL,
            eeat_score_before INT NULL,
            eeat_score_after INT NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'active',
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY rewrite_id (rewrite_id),
            KEY version_type (version_type),
            KEY status (status)
        ) {$charset};");
        dbDelta("CREATE TABLE {$backups} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            rewrite_id BIGINT UNSIGNED NULL,
            backup_type VARCHAR(64) NOT NULL DEFAULT 'before_apply',
            title TEXT NULL,
            excerpt LONGTEXT NULL,
            content_longtext LONGTEXT NULL,
            meta_json LONGTEXT NULL,
            created_by BIGINT UNSIGNED NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY rewrite_id (rewrite_id),
            KEY backup_type (backup_type),
            KEY created_at (created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$apply_logs} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            rewrite_id BIGINT UNSIGNED NOT NULL,
            backup_id BIGINT UNSIGNED NULL,
            applied_fields_json LONGTEXT NULL,
            applied_by BIGINT UNSIGNED NULL,
            status VARCHAR(32) NOT NULL DEFAULT 'done',
            error_message LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY rewrite_id (rewrite_id),
            KEY backup_id (backup_id),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset};");
        dbDelta("CREATE TABLE {$learning} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            pattern_type VARCHAR(80) NOT NULL,
            pattern_value VARCHAR(190) NOT NULL,
            success_count INT NOT NULL DEFAULT 0,
            total_count INT NOT NULL DEFAULT 0,
            avg_views_growth FLOAT NOT NULL DEFAULT 0,
            confidence FLOAT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY pattern (pattern_type, pattern_value),
            KEY confidence (confidence),
            KEY total_count (total_count)
        ) {$charset};");

        self::migrate_applied_status_bug();
        update_option('aiseogeo_version', AISEOGEO_VERSION);
        self::seed_defaults();
    }

    // Разовая починка данных: v1.7.9-1.7.12 ошибочно писали rewrite_status='applied'
    // вместо отдельного apply_status. Возвращаем rewrite_status='done', apply_status
    // уже сохранён отдельно и остаётся нетронутым (реальный факт применения не теряется).
    private static function migrate_applied_status_bug() {
        if (get_option('aiseogeo_migrated_applied_status_bug')) { return; }
        global $wpdb;
        $table = $wpdb->prefix . 'aiseogeo_rewrites';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table) {
            $wpdb->query(
                "UPDATE {$table} SET rewrite_status='done', apply_status=IF(apply_status IS NULL OR apply_status='', 'applied', apply_status) WHERE rewrite_status='applied'"
            );
        }
        update_option('aiseogeo_migrated_applied_status_bug', '1');
    }

    private static function seed_defaults() {
        $defaults = array(
            'base_url' => 'https://openrouter.ai/api/v1',
            'api_key' => '',
            'model' => 'google/gemini-2.5-flash',
            'fallback_model' => 'deepseek/deepseek-v4-flash',
            'timeout' => '60',
            'max_retry' => '1',
            'retry_delay' => '2',
            'temperature' => '0.2',
            'max_tokens' => '6000',
            'log_requests' => '1',
            'enable_metabox' => '1',
            'save_raw_response' => '1',
            'bulk_max_items' => '20',
            'bulk_hour_limit' => '30',
            'bulk_day_limit' => '100',
            'bulk_delay_seconds' => '30',
            'bulk_stop_after_errors' => '5',
            'license_key' => '',
            'license_product_key' => 'ai-seo-geo-editor',
            'license_server_url' => '',
            'license_status' => 'not_checked',
            'license_message' => 'Лицензия ещё не проверялась.',
            'frontend_meta_description_enabled' => '1',
            'free_audit_limit' => '10',
            'auto_optimize_enabled' => '0',
            'auto_optimize_mode' => 'soft_improve',
            'auto_optimize_model' => '',
            'learning_enabled' => '0',
            'learning_min_days' => '14',
            'learning_views_threshold' => '20',
            'learning_min_samples' => '3',
            'learning_inject_audit' => '1',
            'learning_inject_rewrite' => '1',
        );
        $settings = new AISEOGEO_Settings();
        foreach ($defaults as $k => $v) {
            if ($settings->get($k, null) === null) { $settings->set($k, $v); }
        }
    }
}

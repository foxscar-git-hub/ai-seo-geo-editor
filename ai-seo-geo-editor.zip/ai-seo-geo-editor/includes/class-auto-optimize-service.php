<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Auto_Optimize_Service {
    private $settings;
    private $logger;
    private $audit_service;
    private $rewrite_service;

    public function __construct($settings, $logger, $audit_service, $rewrite_service) {
        $this->settings        = $settings;
        $this->logger          = $logger;
        $this->audit_service   = $audit_service;
        $this->rewrite_service = $rewrite_service;
    }

    public function init() {
        if ($this->settings->get('auto_optimize_enabled', '0') !== '1') { return; }
        // Триггер 1: стандартная смена статуса (редактор WordPress)
        add_action('transition_post_status', array($this, 'on_publish'), 20, 3);
        // Триггер 2: wp_after_insert_post — самый надёжный для REST API / Make.com /
        // программной публикации. Срабатывает после сохранения поста и всех мета.
        add_action('wp_after_insert_post', array($this, 'on_after_insert'), 20, 4);
        // Запасной крон-сканер: каждый час подбирает статьи, что опубликованы,
        // но не переписаны (если основной триггер не сработал на хостинге).
        add_action('aiseogeo_auto_safety_scan', array($this, 'safety_scan'));
        if (!wp_next_scheduled('aiseogeo_auto_safety_scan')) {
            wp_schedule_event(time() + 300, 'hourly', 'aiseogeo_auto_safety_scan');
        }
    }

    // Срабатывает для REST/Make.com/программной публикации (после сохранения мета).
    public function on_after_insert($post_id, $post, $update, $post_before) {
        if (!$post || $post->post_status !== 'publish' || $post->post_type !== 'post') { return; }
        // Был ли пост уже опубликован раньше (это обновление, не новая публикация)?
        if ($post_before && isset($post_before->post_status) && $post_before->post_status === 'publish') { return; }
        if (get_post_meta($post_id, '_aiseogeo_is_optimized_copy', true)) { return; }
        if (get_post_meta($post_id, '_aiseogeo_auto_version', true) === '2') { return; }
        if (get_post_meta($post_id, '_aiseogeo_auto_rewriting', true)) { return; }
        // Дедупликация: если transition_post_status уже запланировал в этом же запросе
        if (get_post_meta($post_id, '_aiseogeo_auto_scheduled', true)) {
            $when = (int)get_post_meta($post_id, '_aiseogeo_auto_scheduled', true);
            if (time() - $when < 120) { return; }
        }

        $mode = $this->settings->get('auto_optimize_mode', 'soft_improve');
        update_post_meta($post_id, '_aiseogeo_auto_scheduled', time());
        $this->logger->log('info', 'auto_optimize', 'Автооптимизация запланирована (wp_after_insert_post — REST/Make/прямая публикация).', array('mode' => $mode), $post_id);
        $this->schedule($post_id, $mode);
    }

    public function on_publish($new_status, $old_status, $post) {
        if ($new_status !== 'publish')  { return; }
        if ($old_status === 'publish')  { return; }
        if (!$post || $post->post_type !== 'post') { return; }
        if (get_post_meta($post->ID, '_aiseogeo_is_optimized_copy', true)) { return; }
        // Уже переписана (v2) — повтор не нужен
        if (get_post_meta($post->ID, '_aiseogeo_auto_version', true) === '2') { return; }
        // Уже выполняется прямо сейчас
        if (get_post_meta($post->ID, '_aiseogeo_auto_rewriting', true)) { return; }

        $mode = $this->settings->get('auto_optimize_mode', 'soft_improve');
        // Отметка времени планирования (не блокирует повтор — нужна только для дедупликации)
        update_post_meta($post->ID, '_aiseogeo_auto_scheduled', time());

        $this->logger->log('info', 'auto_optimize', 'Автооптимизация запланирована при публикации.', array(
            'mode'       => $mode,
            'old_status' => $old_status,
            'new_status' => $new_status,
        ), $post->ID);

        $this->schedule($post->ID, $mode);
    }

    private function schedule($post_id, $mode) {
        $self = $this;

        // Метод 1 (основной, самый надёжный): выполнить в shutdown текущего запроса.
        // Не зависит от WP Cron и HTTP-loopback, которые часто заблокированы на хостинге.
        add_action('shutdown', function() use ($self, $post_id, $mode) {
            if (function_exists('fastcgi_finish_request')) { fastcgi_finish_request(); }
            @ignore_user_abort(true);
            @set_time_limit(0);
            $self->process_post($post_id, $mode);
        }, 999);

        // Метод 2 (страховка): WP Cron через 5 минут — если shutdown убит хостингом.
        $args = array($post_id, $mode);
        if (!wp_next_scheduled('aiseogeo_auto_optimize_post', $args)) {
            wp_schedule_single_event(time() + 300, 'aiseogeo_auto_optimize_post', $args);
        }
        @spawn_cron();
    }

    public function register_cron() {
        add_action('aiseogeo_auto_optimize_post', array($this, 'process_post'), 10, 2);
    }

    // ── Запасной сканер: ловит статьи, что не переписались ──────────────────
    public function safety_scan() {
        if ($this->settings->get('auto_optimize_enabled', '0') !== '1') { return; }
        $mode = $this->settings->get('auto_optimize_mode', 'soft_improve');
        // Статьи опубликованы за последние 3 дня, не переписаны, не копии, не в работе
        $q = new WP_Query(array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => 3, // не больше 3 за прогон — не перегружать
            'date_query'     => array(array('after' => '3 days ago')),
            'meta_query'     => array(
                'relation' => 'AND',
                array('key' => '_aiseogeo_auto_version', 'compare' => 'NOT EXISTS'),
                array('key' => '_aiseogeo_is_optimized_copy', 'compare' => 'NOT EXISTS'),
                // Не в работе ИЛИ зависло дольше 20 минут (process_post сам снимет блокировку)
                array(
                    'relation' => 'OR',
                    array('key' => '_aiseogeo_auto_rewriting', 'compare' => 'NOT EXISTS'),
                    array('key' => '_aiseogeo_auto_rewriting', 'value' => time() - 1200, 'compare' => '<', 'type' => 'NUMERIC'),
                ),
            ),
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ));
        if (empty($q->posts)) { return; }
        foreach ($q->posts as $pid) {
            $this->logger->log('info', 'auto_optimize', 'Запасной сканер: подбираю непереписанную статью.', array('mode' => $mode), $pid);
            $this->process_post($pid, $mode);
            break; // по одной за прогон, чтобы не словить таймаут
        }
    }

    public function process_post($post_id, $mode = 'soft_improve') {
        $post_id = absint($post_id);
        $post    = get_post($post_id);

        if (!$post || $post->post_type !== 'post') { return; }
        if (get_post_meta($post_id, '_aiseogeo_is_optimized_copy', true)) { return; }

        // Защита от двойного запуска (shutdown + cron одновременно).
        // Флаг хранит время запуска — если процесс "завис" (PHP fatal / хостинг убил процесс)
        // дольше 20 минут, снимаем блокировку и позволяем повторить.
        $running_since = (int)get_post_meta($post_id, '_aiseogeo_auto_rewriting', true);
        if ($running_since > 0) {
            if ((time() - $running_since) < 1200) {
                $this->logger->log('info', 'auto_optimize', 'Пропущено: переписывание уже запущено (_aiseogeo_auto_rewriting).', array(), $post_id);
                return;
            }
            $this->logger->log('warn', 'auto_optimize', 'Обнаружен зависший процесс (>20 мин) — снимаю блокировку и повторяю.', array(), $post_id);
        }
        update_post_meta($post_id, '_aiseogeo_auto_rewriting', time());

        // Счётчик попыток — чтобы при постоянных ошибках API не повторять вечно
        $attempts = (int)get_post_meta($post_id, '_aiseogeo_auto_attempts', true) + 1;
        update_post_meta($post_id, '_aiseogeo_auto_attempts', $attempts);
        if ($attempts > 3) {
            update_post_meta($post_id, '_aiseogeo_auto_version', 'failed'); // больше не подбирать сканером
            $this->logger->log('error', 'auto_optimize', 'Отказ после 3 неудачных попыток автооптимизации.', array(), $post_id);
            delete_post_meta($post_id, '_aiseogeo_auto_rewriting');
            return;
        }

        $custom_model   = $this->settings->get('auto_optimize_model', '');
        $original_model = '';
        if ($custom_model !== '') {
            $original_model = $this->settings->get('model', '');
            $this->settings->set('model', $custom_model);
        }

        @set_time_limit(0);
        ignore_user_abort(true);

        // Защита от PHP fatal error / необработанного исключения — иначе флаг
        // _aiseogeo_auto_rewriting навсегда останется висеть и заблокирует статью.
        try {
            $this->run_pipeline($post_id, $post, $mode, $custom_model, $original_model);
        } catch (\Throwable $e) {
            $this->logger->log('error', 'auto_optimize', 'Фатальная ошибка в конвейере автооптимизации: ' . $e->getMessage(), array(
                'file' => $e->getFile(), 'line' => $e->getLine(),
            ), $post_id);
            $this->finish($post_id, $custom_model, $original_model);
        }
    }

    private function run_pipeline($post_id, $post, $mode, $custom_model, $original_model) {
        $this->logger->log('info', 'auto_optimize', 'Автооптимизация запущена (process_post).', array(
            'mode'        => $mode,
            'model'       => $custom_model ?: '(основная)',
            'post_status' => $post->post_status,
        ), $post_id);

        // ── 1. Анализ ─────────────────────────────────────────────────────────
        $audit = $this->audit_service->run_audit_bypass($post_id);
        if (is_wp_error($audit)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка анализа: ' . $audit->get_error_message(), array(), $post_id);
            $this->finish($post_id, $custom_model, $original_model);
            return;
        }
        $this->logger->log('info', 'auto_optimize', 'Анализ выполнен.', array(
            'audit_id' => $audit->id,
            'score'    => $audit->overall_score,
        ), $post_id);

        // ── 2. Создание плана ─────────────────────────────────────────────────
        $rewrite = $this->rewrite_service->create_rewrite_bypass($post_id, $audit->id, $mode);
        if (is_wp_error($rewrite)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка создания плана: ' . $rewrite->get_error_message(), array(), $post_id);
            $this->finish($post_id, $custom_model, $original_model);
            return;
        }
        $this->logger->log('info', 'auto_optimize', 'План создан.', array('rewrite_id' => $rewrite->id), $post_id);

        // ── 3. Переписывание ──────────────────────────────────────────────────
        $result = $this->rewrite_service->run_rewrite_bypass($rewrite->id);
        if (is_wp_error($result)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка переписывания: ' . $result->get_error_message(), array(), $post_id);
            $this->finish($post_id, $custom_model, $original_model);
            return;
        }

        $rewrite_data = $this->rewrite_service->get_rewrite($rewrite->id);
        if (!$rewrite_data || $rewrite_data->rewrite_status !== 'done') {
            $this->logger->log('error', 'auto_optimize', 'Переписывание не завершено. Статус: ' . ($rewrite_data->rewrite_status ?? 'неизвестно'), array(), $post_id);
            $this->finish($post_id, $custom_model, $original_model);
            return;
        }

        // ── 4. Обновляем оригинальную запись ─────────────────────────────────
        $update = array('ID' => $post_id);
        if (trim((string)$rewrite_data->new_title) !== '') {
            $update['post_title'] = wp_strip_all_tags($rewrite_data->new_title);
        }
        if (trim((string)$rewrite_data->new_content_longtext) !== '') {
            $update['post_content'] = $rewrite_data->new_content_longtext;
        }
        if (trim((string)$rewrite_data->new_excerpt) !== '') {
            $update['post_excerpt'] = $rewrite_data->new_excerpt;
        }
        if (count($update) > 1) {
            wp_update_post($update);
        }

        // Помечаем переписывание как применённое. rewrite_status остаётся 'done' (пайплайн
        // действительно завершён), apply_status='applied' — отдельно фиксирует факт применения
        // к статье. Так же делает ручное применение (class-apply-service.php).
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'aiseogeo_rewrites',
            array('apply_status' => 'applied', 'updated_at' => current_time('mysql')),
            array('id' => absint($rewrite->id))
        );
        update_post_meta($post_id, '_aiseogeo_auto_optimized', '1');

        // ── 5. Мета-данные SEO ────────────────────────────────────────────────
        if (trim((string)$rewrite_data->new_meta_title) !== '') {
            update_post_meta($post_id, '_aiseogeo_meta_title', sanitize_text_field($rewrite_data->new_meta_title));
            update_post_meta($post_id, '_yoast_wpseo_title', sanitize_text_field($rewrite_data->new_meta_title));
            update_post_meta($post_id, 'rank_math_title', sanitize_text_field($rewrite_data->new_meta_title));
        }
        $meta_desc = trim((string)$rewrite_data->new_meta_description);
        if ($meta_desc === '') { $meta_desc = trim((string)$rewrite_data->new_excerpt); }
        if ($meta_desc !== '') {
            update_post_meta($post_id, '_aiseogeo_meta_description', sanitize_textarea_field($meta_desc));
            update_post_meta($post_id, '_yoast_wpseo_metadesc', sanitize_textarea_field($meta_desc));
            update_post_meta($post_id, 'rank_math_description', sanitize_textarea_field($meta_desc));
        }
        // FAQ + Schema — раньше сохранялись только при ручном apply, автооптимизация их пропускала
        if (trim((string)$rewrite_data->new_faq_json) !== '') {
            update_post_meta($post_id, '_aiseogeo_faq_json', (string)$rewrite_data->new_faq_json);
        }
        if (trim((string)$rewrite_data->new_schema_json) !== '') {
            update_post_meta($post_id, '_aiseogeo_schema_json', (string)$rewrite_data->new_schema_json);
        }
        update_post_meta($post_id, '_aiseogeo_auto_version', '2');

        $this->logger->log('info', 'auto_optimize', sprintf(
            'Автооптимизация завершена. Запись #%d обновлена. Rewrite #%d.',
            $post_id, $rewrite->id
        ), array('rewrite_id' => $rewrite->id, 'audit_id' => $audit->id), $post_id);

        $this->finish($post_id, $custom_model, $original_model);
    }

    private function finish($post_id, $custom_model, $original_model) {
        delete_post_meta($post_id, '_aiseogeo_auto_rewriting');
        if ($custom_model !== '' && $original_model !== '') {
            $this->settings->set('model', $original_model);
        }
    }
}

<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Auto_Optimize_Service {
    private $settings;
    private $logger;
    private $audit_service;
    private $rewrite_service;

    public function __construct($settings, $logger, $audit_service, $rewrite_service) {
        $this->settings = $settings;
        $this->logger = $logger;
        $this->audit_service = $audit_service;
        $this->rewrite_service = $rewrite_service;
    }

    public function init() {
        if ($this->settings->get('auto_optimize_enabled', '0') !== '1') { return; }
        add_action('transition_post_status', array($this, 'on_publish'), 20, 3);
    }

    public function on_publish($new_status, $old_status, $post) {
        if ($new_status !== 'publish') { return; }
        if ($old_status === 'publish') { return; }
        if (!$post || $post->post_type !== 'post') { return; }
        if (get_post_meta($post->ID, '_aiseogeo_auto_optimized', true)) { return; }
        if (get_post_meta($post->ID, '_aiseogeo_is_optimized_copy', true)) { return; }
        if (get_post_meta($post->ID, '_aiseogeo_skip_auto_optimize', true)) { return; }

        $gate = new AISEOGEO_License_Gate($this->settings, $this->logger);
        if (!$gate->is_active()) { return; }

        update_post_meta($post->ID, '_aiseogeo_auto_optimized', '1');
        $mode = $this->settings->get('auto_optimize_mode', 'soft_improve');
        $this->schedule_optimization($post->ID, $mode);
    }

    private function schedule_optimization($post_id, $mode) {
        $args = array($post_id, $mode);
        if (!wp_next_scheduled('aiseogeo_auto_optimize_post', $args)) {
            wp_schedule_single_event(time() + 5, 'aiseogeo_auto_optimize_post', $args);
        }
    }

    public function register_cron() {
        add_action('aiseogeo_auto_optimize_post', array($this, 'process_post'), 10, 2);
    }

    public function process_post($post_id, $mode = 'soft_improve') {
        $post = get_post($post_id);
        if (!$post || $post->post_status !== 'publish') { return; }

        $custom_model = $this->settings->get('auto_optimize_model', '');
        $original_model = '';
        if ($custom_model !== '') {
            $original_model = $this->settings->get('model', '');
            $this->settings->set('model', $custom_model);
        }

        $save_mode = $this->settings->get('auto_optimize_save_mode', 'new_post');

        $this->logger->log('info', 'auto_optimize', 'Автооптимизация запущена.', array('mode' => $mode, 'save_mode' => $save_mode, 'model' => $custom_model ?: '(основная)'), $post_id);

        $audit = $this->audit_service->run_audit_bypass($post_id);
        if (is_wp_error($audit)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка анализа: ' . $audit->get_error_message(), array(), $post_id);
            $this->restore_model($custom_model, $original_model);
            return;
        }

        $gate = new AISEOGEO_License_Gate($this->settings, $this->logger);
        $gate->track('audit');

        $rewrite = $this->rewrite_service->create_rewrite_bypass($post_id, $audit->id, $mode);
        if (is_wp_error($rewrite)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка создания плана: ' . $rewrite->get_error_message(), array(), $post_id);
            $this->restore_model($custom_model, $original_model);
            return;
        }
        $gate->track('rewrite_plan');

        $result = $this->rewrite_service->run_rewrite_bypass($rewrite->id);
        if (is_wp_error($result)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка переписывания: ' . $result->get_error_message(), array(), $post_id);
            $this->restore_model($custom_model, $original_model);
            return;
        }
        $gate->track('rewrite');

        $rewrite_data = $this->rewrite_service->get_rewrite($rewrite->id);
        if (!$rewrite_data || $rewrite_data->rewrite_status !== 'done') {
            $this->logger->log('error', 'auto_optimize', 'Переписывание не завершено.', array(), $post_id);
            $this->restore_model($custom_model, $original_model);
            return;
        }

        $new_title   = $rewrite_data->new_title ?: $post->post_title;
        $new_content = $rewrite_data->new_content_longtext ?: $post->post_content;
        $new_excerpt = $rewrite_data->new_excerpt ?: $post->post_excerpt;
        $meta_title  = trim((string)$rewrite_data->new_meta_title);
        $meta_desc   = trim((string)$rewrite_data->new_meta_description);
        if ($meta_desc === '') { $meta_desc = trim((string)$rewrite_data->new_excerpt); }

        if ($save_mode === 'overwrite') {
            $this->apply_overwrite($post, $new_title, $new_content, $new_excerpt, $meta_title, $meta_desc);
        } else {
            $this->apply_new_post($post, $new_title, $new_content, $new_excerpt, $meta_title, $meta_desc);
        }

        $gate->track('apply');
        $this->restore_model($custom_model, $original_model);
    }

    private function apply_overwrite($post, $new_title, $new_content, $new_excerpt, $meta_title, $meta_desc) {
        $post_id = $post->ID;

        remove_action('transition_post_status', array($this, 'on_publish'), 20);

        wp_update_post(array(
            'ID'           => $post_id,
            'post_title'   => $new_title,
            'post_content' => $new_content,
            'post_excerpt' => $new_excerpt,
        ));

        $this->apply_seo_meta($post_id, $meta_title, $meta_desc);

        add_action('transition_post_status', array($this, 'on_publish'), 20, 3);

        $this->logger->log('info', 'auto_optimize', sprintf(
            'Автооптимизация завершена. Запись #%d обновлена (перезапись оригинала).',
            $post_id
        ), array('post_id' => $post_id, 'save_mode' => 'overwrite'), $post_id);
    }

    private function apply_new_post($post, $new_title, $new_content, $new_excerpt, $meta_title, $meta_desc) {
        $post_id = $post->ID;

        $new_post_data = array(
            'post_title'    => $new_title,
            'post_content'  => $new_content,
            'post_excerpt'  => $new_excerpt,
            'post_status'   => 'publish',
            'post_type'     => 'post',
            'post_author'   => $post->post_author,
            'post_category' => wp_get_post_categories($post_id),
        );

        update_post_meta($post_id, '_aiseogeo_skip_auto_optimize', '1');

        $new_post_id = wp_insert_post($new_post_data, true);
        if (is_wp_error($new_post_id)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка создания новой записи: ' . $new_post_id->get_error_message(), array(), $post_id);
            return;
        }

        $tags = wp_get_post_tags($post_id, array('fields' => 'ids'));
        if (!empty($tags)) { wp_set_post_tags($new_post_id, $tags); }

        update_post_meta($new_post_id, '_aiseogeo_is_optimized_copy', '1');
        update_post_meta($new_post_id, '_aiseogeo_original_post_id', $post_id);
        update_post_meta($new_post_id, '_aiseogeo_auto_optimized', '1');
        update_post_meta($new_post_id, '_aiseogeo_skip_auto_optimize', '1');

        $this->apply_seo_meta($new_post_id, $meta_title, $meta_desc);

        wp_update_post(array('ID' => $post_id, 'post_status' => 'draft'));
        update_post_meta($post_id, '_aiseogeo_replaced_by', $new_post_id);

        $this->logger->log('info', 'auto_optimize', sprintf(
            'Автооптимизация завершена. Оригинал #%d → черновик, новая запись #%d опубликована.',
            $post_id, $new_post_id
        ), array('original_id' => $post_id, 'new_id' => $new_post_id, 'save_mode' => 'new_post'), $post_id);
    }

    private function apply_seo_meta($post_id, $meta_title, $meta_desc) {
        if ($meta_title !== '') {
            update_post_meta($post_id, '_aiseogeo_meta_title', sanitize_text_field($meta_title));
            update_post_meta($post_id, '_yoast_wpseo_title', sanitize_text_field($meta_title));
            update_post_meta($post_id, 'rank_math_title', sanitize_text_field($meta_title));
        }
        if ($meta_desc !== '') {
            update_post_meta($post_id, '_aiseogeo_meta_description', sanitize_textarea_field($meta_desc));
            update_post_meta($post_id, '_yoast_wpseo_metadesc', sanitize_textarea_field($meta_desc));
            update_post_meta($post_id, 'rank_math_description', sanitize_textarea_field($meta_desc));
        }
    }

    private function restore_model($custom_model, $original_model) {
        if ($custom_model !== '' && $original_model !== '') {
            $this->settings->set('model', $original_model);
        }
    }
}

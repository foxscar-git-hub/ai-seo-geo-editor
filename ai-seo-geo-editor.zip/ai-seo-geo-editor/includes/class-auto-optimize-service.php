<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Auto_Optimize_Service {
    private $settings;
    private $logger;
    private $audit_service;
    private $rewrite_service;

    public function __construct($settings, $logger, $audit_service, $rewrite_service) {
        $this->settings       = $settings;
        $this->logger         = $logger;
        $this->audit_service  = $audit_service;
        $this->rewrite_service = $rewrite_service;
    }

    public function init() {
        if ($this->settings->get('auto_optimize_enabled', '0') !== '1') { return; }
        add_action('transition_post_status', array($this, 'on_publish'), 20, 3);
    }

    public function on_publish($new_status, $old_status, $post) {
        if ($new_status !== 'publish') { return; }
        if ($old_status === 'publish') { return; }
        if (!$post || $post->post_type !== 'post') { return; }
        if (get_post_meta($post->ID, '_aiseogeo_auto_optimized', true)) { return; }
        if (get_post_meta($post->ID, '_aiseogeo_is_optimized_copy', true)) { return; }

        // Помечаем сразу чтобы повторный publish не запустил второй процесс
        update_post_meta($post->ID, '_aiseogeo_auto_optimized', '1');

        $mode    = $this->settings->get('auto_optimize_mode', 'soft_improve');
        $post_id = $post->ID;
        $self    = $this;

        // Запускаем ВНУТРИ текущего PHP-процесса через shutdown.
        // Это надёжнее WP Cron: не требует HTTP-loopback и не зависит от посетителей сайта.
        add_action('shutdown', function() use ($self, $post_id, $mode) {
            // Закрываем соединение с браузером — ответ уже отправлен
            if (function_exists('fastcgi_finish_request')) {
                fastcgi_finish_request();
            }
            ignore_user_abort(true);
            set_time_limit(0); // Долгие задачи (анализ + переписывание) не должны прерываться

            $self->process_post($post_id, $mode);
        }, 999);

        // WP Cron как страховочная сетка: если shutdown не сработал (CLI, REST), запустит позже
        $this->schedule_cron_fallback($post_id, $mode);
    }

    private function schedule_cron_fallback($post_id, $mode) {
        $args = array($post_id, $mode);
        // Через 10 минут — если shutdown уже выполнил задачу, process_post проверит флаг и выйдет
        if (!wp_next_scheduled('aiseogeo_auto_optimize_post', $args)) {
            wp_schedule_single_event(time() + 600, 'aiseogeo_auto_optimize_post', $args);
        }
    }

    public function register_cron() {
        add_action('aiseogeo_auto_optimize_post', array($this, 'process_post'), 10, 2);
    }

    public function process_post($post_id, $mode = 'soft_improve') {
        $post_id = absint($post_id);
        $post    = get_post($post_id);

        if (!$post || $post->post_type !== 'post') { return; }
        if (get_post_meta($post_id, '_aiseogeo_is_optimized_copy', true)) { return; }

        // Проверяем что ещё не переписывалось (защита от двойного запуска shutdown + cron)
        if (get_post_meta($post_id, '_aiseogeo_auto_rewriting', true)) { return; }
        update_post_meta($post_id, '_aiseogeo_auto_rewriting', '1');

        $custom_model = $this->settings->get('auto_optimize_model', '');
        $original_model = '';
        if ($custom_model !== '') {
            $original_model = $this->settings->get('model', '');
            $this->settings->set('model', $custom_model);
        }

        $this->logger->log('info', 'auto_optimize', 'Автооптимизация запущена.', array(
            'mode'  => $mode,
            'model' => $custom_model ?: '(основная)',
            'post_status' => $post->post_status,
        ), $post_id);

        // ── 1. Анализ ─────────────────────────────────────────────────────────
        $audit = $this->audit_service->run_audit_bypass($post_id);
        if (is_wp_error($audit)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка анализа: ' . $audit->get_error_message(), array(), $post_id);
            $this->finish($post_id, $custom_model, $original_model);
            return;
        }
        $this->logger->log('info', 'auto_optimize', 'Анализ выполнен.', array('audit_id' => $audit->id, 'score' => $audit->overall_score), $post_id);

        // ── 2. Создание плана переписывания ───────────────────────────────────
        $rewrite = $this->rewrite_service->create_rewrite_bypass($post_id, $audit->id, $mode);
        if (is_wp_error($rewrite)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка создания плана: ' . $rewrite->get_error_message(), array(), $post_id);
            $this->finish($post_id, $custom_model, $original_model);
            return;
        }
        $this->logger->log('info', 'auto_optimize', 'План создан.', array('rewrite_id' => $rewrite->id), $post_id);

        // ── 3. Переписывание ──────────────────────────────────────────────────
        $result = $this->rewrite_service->run_rewrite_bypass($rewrite->id);
        if (is_wp_error($result)) {
            $this->logger->log('error', 'auto_optimize', 'Ошибка переписывания: ' . $result->get_error_message(), array(), $post_id);
            $this->finish($post_id, $custom_model, $original_model);
            return;
        }

        $rewrite_data = $this->rewrite_service->get_rewrite($rewrite->id);
        if (!$rewrite_data || $rewrite_data->rewrite_status !== 'done') {
            $this->logger->log('error', 'auto_optimize', 'Переписывание не завершено. Статус: ' . ($rewrite_data->rewrite_status ?? 'неизвестно'), array(), $post_id);
            $this->finish($post_id, $custom_model, $original_model);
            return;
        }

        // ── 4. Обновляем ОРИГИНАЛЬНУЮ запись (не создаём новую) ──────────────
        // Это сохраняет URL, slug, и не путает с дублями.
        $update = array('ID' => $post_id);
        if (trim((string)$rewrite_data->new_title) !== '') {
            $update['post_title'] = wp_strip_all_tags($rewrite_data->new_title);
        }
        if (trim((string)$rewrite_data->new_content_longtext) !== '') {
            $update['post_content'] = $rewrite_data->new_content_longtext;
        }
        if (trim((string)$rewrite_data->new_excerpt) !== '') {
            $update['post_excerpt'] = $rewrite_data->new_excerpt;
        }

        if (count($update) > 1) {
            wp_update_post($update);
        }

        // ── 5. Мета-данные ────────────────────────────────────────────────────
        if (trim((string)$rewrite_data->new_meta_title) !== '') {
            update_post_meta($post_id, '_aiseogeo_meta_title', sanitize_text_field($rewrite_data->new_meta_title));
            update_post_meta($post_id, '_yoast_wpseo_title', sanitize_text_field($rewrite_data->new_meta_title));
            update_post_meta($post_id, 'rank_math_title', sanitize_text_field($rewrite_data->new_meta_title));
        }
        $meta_desc = trim((string)$rewrite_data->new_meta_description);
        if ($meta_desc === '') { $meta_desc = trim((string)$rewrite_data->new_excerpt); }
        if ($meta_desc !== '') {
            update_post_meta($post_id, '_aiseogeo_meta_description', sanitize_textarea_field($meta_desc));
            update_post_meta($post_id, '_yoast_wpseo_metadesc', sanitize_textarea_field($meta_desc));
            update_post_meta($post_id, 'rank_math_description', sanitize_textarea_field($meta_desc));
        }
        update_post_meta($post_id, '_aiseogeo_auto_version', '2');

        $this->logger->log('info', 'auto_optimize', sprintf(
            'Автооптимизация завершена. Запись #%d обновлена. Rewrite #%d.',
            $post_id, $rewrite->id
        ), array('rewrite_id' => $rewrite->id, 'audit_id' => $audit->id), $post_id);

        $this->finish($post_id, $custom_model, $original_model);
    }

    private function finish($post_id, $custom_model, $original_model) {
        delete_post_meta($post_id, '_aiseogeo_auto_rewriting');
        if ($custom_model !== '' && $original_model !== '') {
            $this->settings->set('model', $original_model);
        }
    }
}

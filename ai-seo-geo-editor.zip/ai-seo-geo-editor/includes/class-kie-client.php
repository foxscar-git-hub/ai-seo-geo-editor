<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Клиент KIE.ai — резервный провайдер моделей, когда OpenRouter недоступен
 * (закончились кредиты, модель снята с провижининга, зависание и т.д.).
 *
 * В отличие от OpenRouter, KIE НЕ даёт единый OpenAI-совместимый эндпоинт для
 * всех моделей — у каждого семейства свой нативный формат:
 *   - Claude   → Anthropic Messages API (api.kie.ai/claude/v1/messages)
 *   - GPT      → OpenAI Responses API   (api.kie.ai/codex/v1/responses)
 *   - Gemini   → OpenAI-совместимый chat/completions только для
 *                gemini-3-5-flash-openai (единственный подтверждённый вариант)
 *
 * Модели передаются с префиксом "kie:" (напр. "kie:claude-sonnet-4-6"),
 * чтобы диспетчер в class-openrouter-client.php мог отличить их от обычных
 * OpenRouter ID и направить сюда.
 */
class AISEOGEO_Kie_Client {
    private $settings;
    private $logger;

    const BASE = 'https://api.kie.ai';

    public function __construct($settings, $logger) {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    public function has_key() {
        return trim((string)$this->settings->get('kie_api_key', '')) !== '';
    }

    /**
     * @param array       $messages   Массив ['role'=>..,'content'=>..] — стандартный формат плагина.
     * @param int|null    $max_tokens
     * @param string      $model      Без префикса "kie:" — просто ID модели (claude-sonnet-4-6, gpt-5-5, gemini-3-5-flash-openai).
     * @param bool        $web_search Игнорируется — KIE web-grounding не используется в этой интеграции.
     */
    public function chat($messages, $max_tokens = null, $model = '', $web_search = false) {
        $api_key = trim((string)$this->settings->get('kie_api_key', ''));
        if ($api_key === '') {
            return new WP_Error('kie_api_key_missing', 'API-ключ KIE не указан.');
        }
        $max_tokens = $max_tokens ?: intval($this->settings->get('max_tokens', '6000'));

        if (strpos($model, 'claude') !== false) {
            return $this->chat_claude($messages, $max_tokens, $model, $api_key);
        }
        if (strpos($model, 'gpt') !== false) {
            return $this->chat_gpt($messages, $max_tokens, $model, $api_key);
        }
        if (strpos($model, 'gemini') !== false) {
            return $this->chat_gemini_openai($messages, $max_tokens, $model, $api_key);
        }
        return new WP_Error('kie_unknown_family', 'Неизвестное семейство модели KIE: ' . $model);
    }

    private function timeout_for($max_tokens) {
        $base = max(30, intval($this->settings->get('timeout', '90')));
        $cap  = $max_tokens > 8000 ? 420 : 90;
        return max($base, min($cap, (int)($max_tokens / 100) + 30));
    }

    private function post($url, $body, $headers, $timeout) {
        $args = array(
            'timeout' => $timeout,
            'headers' => $headers,
            'body'    => wp_json_encode($body, JSON_UNESCAPED_UNICODE),
        );
        $hard_timeout = $timeout;
        $force = function ($handle) use ($hard_timeout) {
            if (function_exists('curl_setopt')) {
                curl_setopt($handle, CURLOPT_TIMEOUT, $hard_timeout);
                curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 20);
            }
        };
        add_action('http_api_curl', $force, 10, 1);
        $response = wp_remote_post($url, $args);
        remove_action('http_api_curl', $force, 10);
        return $response;
    }

    // ── Claude — Anthropic Messages API ─────────────────────────────────────
    private function chat_claude($messages, $max_tokens, $model, $api_key) {
        // Anthropic отделяет system-промпт от messages
        $system = '';
        $anthropic_messages = array();
        foreach ($messages as $m) {
            if ($m['role'] === 'system') { $system .= ($system !== '' ? "\n\n" : '') . $m['content']; continue; }
            $anthropic_messages[] = array('role' => $m['role'], 'content' => $m['content']);
        }
        $body = array(
            'model'      => $model,
            'messages'   => $anthropic_messages,
            'max_tokens' => $max_tokens,
            'stream'     => false,
        );
        if ($system !== '') { $body['system'] = $system; }

        $timeout  = $this->timeout_for($max_tokens);
        $response = $this->post(self::BASE . '/claude/v1/messages', $body, array(
            'Authorization'     => 'Bearer ' . $api_key,
            'Content-Type'      => 'application/json',
            'anthropic-version' => '2023-06-01',
        ), $timeout);

        return $this->handle_response($response, $model, function ($json) {
            $blocks = $json['content'] ?? array();
            $text = '';
            foreach ((array)$blocks as $b) {
                if (($b['type'] ?? '') === 'text') { $text .= $b['text']; }
            }
            return $text;
        });
    }

    // ── GPT — OpenAI Responses API ──────────────────────────────────────────
    private function chat_gpt($messages, $max_tokens, $model, $api_key) {
        $input = array();
        foreach ($messages as $m) {
            $type = ($m['role'] === 'assistant') ? 'output_text' : 'input_text';
            $input[] = array(
                'role'    => $m['role'],
                'content' => array(array('type' => $type, 'text' => $m['content'])),
            );
        }
        $body = array('model' => $model, 'stream' => false, 'input' => $input);

        $timeout  = $this->timeout_for($max_tokens);
        $response = $this->post(self::BASE . '/codex/v1/responses', $body, array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        ), $timeout);

        return $this->handle_response($response, $model, function ($json) {
            if (!empty($json['output_text']) && is_string($json['output_text'])) {
                return $json['output_text'];
            }
            $text = '';
            foreach ((array)($json['output'] ?? array()) as $item) {
                foreach ((array)($item['content'] ?? array()) as $c) {
                    if (($c['type'] ?? '') === 'output_text') { $text .= $c['text']; }
                }
            }
            return $text;
        });
    }

    // ── Gemini (OpenAI-совместимый вариант) ─────────────────────────────────
    private function chat_gemini_openai($messages, $max_tokens, $model, $api_key) {
        $body = array(
            'model'      => $model,
            'messages'   => $messages,
            'max_tokens' => $max_tokens,
            'stream'     => false,
        );
        $timeout  = $this->timeout_for($max_tokens);
        // Эндпоинт зашит под конкретный вариант модели (единственный подтверждённый
        // OpenAI-совместимый путь на сегодня — gemini-3-5-flash-openai).
        $response = $this->post(self::BASE . '/gemini-3-5-flash-openai/v1/chat/completions', $body, array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        ), $timeout);

        return $this->handle_response($response, $model, function ($json) {
            return $json['choices'][0]['message']['content'] ?? '';
        });
    }

    private function handle_response($response, $model, callable $extract_text) {
        if (is_wp_error($response)) {
            $this->logger->log('error', 'kie', 'Ошибка запроса KIE: ' . $response->get_error_message(), array('model' => $model));
            return $response;
        }
        $code = intval(wp_remote_retrieve_response_code($response));
        $body = wp_remote_retrieve_body($response);

        if ($code < 200 || $code >= 300) {
            $this->logger->log('error', 'kie', 'KIE HTTP ' . $code, array('model' => $model, 'body' => mb_substr($body, 0, 500)));
            return new WP_Error('kie_http_' . $code, 'KIE HTTP ' . $code . ' (модель: ' . $model . ')', array('body' => mb_substr($body, 0, 500)));
        }

        $json = json_decode($body, true);
        if (!is_array($json)) {
            return new WP_Error('kie_bad_json', 'KIE вернул невалидный JSON (модель: ' . $model . ')');
        }
        $text = $extract_text($json);
        if (trim((string)$text) === '') {
            return new WP_Error('kie_empty_response', 'KIE вернул пустой ответ (модель: ' . $model . ')');
        }
        return array('content' => $text, 'model' => 'kie:' . $model, 'raw' => $body);
    }
}

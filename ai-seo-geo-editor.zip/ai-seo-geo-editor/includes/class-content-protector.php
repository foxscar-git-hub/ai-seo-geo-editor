<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Content_Protector {
    public function extract_protected_items($content) {
        $content = (string)$content;
        $items = array();

        $this->match_all($items, 'shortcode', '/\[[A-Za-z0-9_\-]+[^\]]*\](?:.*?\[\/[A-Za-z0-9_\-]+\])?/s', $content);
        $this->match_all($items, 'gutenberg_block', '/<!--\s*wp:[\s\S]*?-->/m', $content);
        $this->match_all($items, 'iframe', '/<iframe\b[\s\S]*?<\/iframe>/i', $content);
        $this->match_all($items, 'embed', '/<(video|audio|embed)\b[\s\S]*?<\/\1>/i', $content);
        $this->match_all($items, 'image', '/<img\b[^>]*>/i', $content);
        $this->match_all($items, 'link', '/<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>[\s\S]*?<\/a>/i', $content);
        $this->match_all($items, 'html_with_class', '/<([a-z0-9]+)\b[^>]*class=["\'][^"\']+["\'][^>]*>[\s\S]*?<\/\1>/i', $content, 20);

        foreach ($this->detect_important_blocks($content) as $block) {
            $items[] = $block;
        }

        return array_values($items);
    }

    private function match_all(&$items, $type, $pattern, $content, $limit = 50) {
        if (!preg_match_all($pattern, $content, $m)) { return; }
        $count = 0;
        foreach ($m[0] as $raw) {
            if ($count++ >= $limit) { break; }
            $items[] = array(
                'type' => $type,
                'hash' => md5($raw),
                'sample' => mb_substr(trim(wp_strip_all_tags($raw)), 0, 220),
                'raw' => mb_substr($raw, 0, 1200),
                'must_preserve' => in_array($type, array('shortcode','iframe','embed','image','link'), true),
            );
        }
    }

    public function detect_important_blocks($content) {
        $content = (string)$content;
        $blocks = array();
        $plain = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($content)));

        $patterns = array(
            'faq_block' => array(
                'label' => 'FAQ / Частые вопросы',
                'regex' => '/(<h[1-6][^>]*>\s*(?:FAQ|F\.A\.Q\.|Частые\s+вопросы|Вопросы\s+и\s+ответы)[\s\S]*?)(?=<h[1-6][^>]*>|$)/iu',
                'plain_markers' => array('частые вопросы', 'faq', 'вопросы и ответы'),
            ),
            'cta_block' => array(
                'label' => 'CTA / призыв к действию',
                'regex' => '/(<h[1-6][^>]*>\s*(?:Следующий\s+шаг|Что\s+делать\s+дальше|Оставить\s+заявку|Получить\s+консультацию|Заказать|Попробовать|Начать)[\s\S]*?)(?=<h[1-6][^>]*>|$)/iu',
                'plain_markers' => array('следующий шаг', 'оставить заявку', 'получить консультацию', 'заказать', 'попробовать', 'начать'),
            ),
            'summary_block' => array(
                'label' => 'Итог / вывод',
                'regex' => '/(<h[1-6][^>]*>\s*(?:Итог|Вывод|Что\s+важно\s+запомнить|Коротко\s+главное)[\s\S]*?)(?=<h[1-6][^>]*>|$)/iu',
                'plain_markers' => array('итог', 'вывод', 'что важно запомнить', 'коротко главное'),
            ),
        );

        foreach ($patterns as $type => $cfg) {
            if (preg_match($cfg['regex'], $content, $m)) {
                $raw = trim($m[1]);
                $blocks[] = array(
                    'type' => $type,
                    'label' => $cfg['label'],
                    'hash' => md5($raw),
                    'sample' => mb_substr(trim(wp_strip_all_tags($raw)), 0, 260),
                    'raw' => mb_substr($raw, 0, 2200),
                    'must_preserve' => true,
                );
                continue;
            }
            $low = mb_strtolower($plain);
            foreach ($cfg['plain_markers'] as $marker) {
                if (mb_strpos($low, mb_strtolower($marker)) !== false) {
                    $blocks[] = array(
                        'type' => $type,
                        'label' => $cfg['label'],
                        'hash' => md5($marker),
                        'sample' => $cfg['label'] . ': найден маркер «' . $marker . '»',
                        'raw' => $marker,
                        'must_preserve' => true,
                    );
                    break;
                }
            }
        }

        return $blocks;
    }

    public function validate_preserved_items($original_content, $new_content, $protected_items) {
        $warnings = array();
        $new_content = (string)$new_content;
        $original_content = (string)$original_content;

        foreach ((array)$protected_items as $item) {
            $type = isset($item['type']) ? (string)$item['type'] : 'element';
            $raw = isset($item['raw']) ? (string)$item['raw'] : '';
            $sample = isset($item['sample']) ? (string)$item['sample'] : '';
            $must = !empty($item['must_preserve']) || in_array($type, array('faq_block','cta_block','summary_block','shortcode','iframe','embed','image','link'), true);

            if (!$must) { continue; }

            if (in_array($type, array('faq_block','cta_block','summary_block'), true)) {
                if (!$this->important_block_still_exists($type, $sample, $new_content)) {
                    $label = isset($item['label']) ? $item['label'] : $type;
                    $warnings[] = 'Важный блок мог быть удалён или сильно изменён: ' . $label . '. Проверьте новую версию перед публикацией.';
                }
                continue;
            }

            if ($raw !== '' && mb_strlen($raw) < 80) {
                if (mb_stripos($new_content, $raw) === false) {
                    $warnings[] = 'Защищённый элемент мог быть изменён или удалён: ' . $type . ' — ' . mb_substr(wp_strip_all_tags($raw), 0, 120);
                }
                continue;
            }

            if ($raw !== '' && strpos($new_content, $raw) === false) {
                $sample_text = trim(wp_strip_all_tags($raw));
                if ($sample_text !== '' && mb_stripos(wp_strip_all_tags($new_content), mb_substr($sample_text, 0, 80)) === false) {
                    $warnings[] = 'Защищённый элемент мог быть изменён или удалён: ' . $type . ' — ' . mb_substr($sample_text, 0, 120);
                }
            }
        }

        $orig_blocks = $this->detect_important_blocks($original_content);
        foreach ($orig_blocks as $block) {
            if (!$this->important_block_still_exists($block['type'], $block['sample'], $new_content)) {
                $warnings[] = 'В исходной статье был важный блок «' . ($block['label'] ?? $block['type']) . '», но в новой версии он не обнаружен.';
            }
        }

        return array_values(array_unique(array_filter($warnings)));
    }

    private function important_block_still_exists($type, $sample, $content) {
        $plain = mb_strtolower(trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags((string)$content))));
        if ($type === 'faq_block') {
            return (mb_stripos($plain, 'частые вопросы') !== false || mb_stripos($plain, 'faq') !== false || mb_stripos($plain, 'вопрос') !== false);
        }
        if ($type === 'cta_block') {
            $markers = array('следующий шаг','оставить заявку','получить консультацию','заказать','попробовать','начать','свяжитесь','подключить');
            foreach ($markers as $m) { if (mb_stripos($plain, $m) !== false) { return true; } }
            return false;
        }
        if ($type === 'summary_block') {
            $markers = array('итог','вывод','важно запомнить','главное');
            foreach ($markers as $m) { if (mb_stripos($plain, $m) !== false) { return true; } }
            return false;
        }
        $sample = trim((string)$sample);
        return $sample === '' || mb_stripos($plain, mb_strtolower(mb_substr($sample, 0, 80))) !== false;
    }

    /**
     * Извлекает изображения из контента вместе с их позицией (индекс символа).
     * Возвращает ['content' => контент_без_изображений, 'images' => [['html'=>..., 'pos_ratio'=>0.0-1.0], ...]].
     *
     * Поддерживает:
     *  - Gutenberg: <!-- wp:image ... --><figure>...</figure><!-- /wp:image -->
     *  - <figure> с <img> внутри
     *  - Одиночные <img>
     */
    public function extract_images_for_protection($content) {
        $content = (string)$content;
        $total   = mb_strlen($content);
        $images  = array();

        // Единый паттерн: сначала Gutenberg-блок, потом figure+img, потом одиночный img
        $pattern = '/(?:<!--\s*wp:image[\s\S]*?-->\s*<figure\b[\s\S]*?<\/figure>\s*<!--\s*\/wp:image\s*-->|<figure\b[^>]*>[\s\S]*?<img\b[\s\S]*?<\/figure>|<img\b[^>]*\/?>)/i';

        if (!preg_match_all($pattern, $content, $m, PREG_OFFSET_CAPTURE)) {
            return array('content' => $content, 'images' => array());
        }

        // Собираем изображения с их позицией, удаляем из контента (с конца чтобы не сместить offset)
        $found = array_reverse($m[0]);
        foreach ($found as $match) {
            $html   = $match[0];
            $offset = $match[1];
            $ratio  = $total > 0 ? $offset / $total : 0;
            array_unshift($images, array('html' => $html, 'pos_ratio' => round($ratio, 4)));
            $content = substr($content, 0, $offset) . substr($content, $offset + strlen($html));
        }

        return array('content' => trim($content), 'images' => $images);
    }

    /**
     * Вставляет изображения обратно в новый контент по пропорциональным позициям.
     * Если изображение уже есть в новом контенте (по src) — не дублируем.
     */
    public function reinject_images($new_content, $images) {
        if (empty($images)) { return $new_content; }
        $new_content = (string)$new_content;

        // Фильтруем: не вставляем изображения, которые уже есть в новом контенте
        $to_inject = array();
        foreach ($images as $img) {
            $src = '';
            if (preg_match('/src=["\']([^"\']+)["\']/i', $img['html'], $sm)) {
                $src = $sm[1];
            }
            // Если src найден и уже есть в новом контенте — пропускаем
            if ($src !== '' && strpos($new_content, $src) !== false) { continue; }
            $to_inject[] = $img;
        }

        if (empty($to_inject)) { return $new_content; }

        // Находим позиции разрывов в новом контенте (конец каждого параграфа/блока)
        // Ищем </p>, </h2>, </h3>, </ul>, </ol>, </blockquote>
        $break_pattern = '/<\/(?:p|h[2-6]|ul|ol|blockquote|div)>/i';
        preg_match_all($break_pattern, $new_content, $bm, PREG_OFFSET_CAPTURE);
        $breaks = array();
        foreach ($bm[0] as $b) {
            $breaks[] = $b[1] + strlen($b[0]); // позиция ПОСЛЕ закрывающего тега
        }

        $total_new = mb_strlen($new_content);

        // Для каждого изображения выбираем ближайший break по пропорции
        $injections = array(); // [insert_pos => html]
        foreach ($to_inject as $img) {
            $target_pos = (int)($img['pos_ratio'] * $total_new);
            if (empty($breaks)) {
                $insert = $total_new; // в конец
            } else {
                // Находим ближайший break к target_pos
                $best = $breaks[0];
                $best_dist = abs($breaks[0] - $target_pos);
                foreach ($breaks as $bp) {
                    $dist = abs($bp - $target_pos);
                    if ($dist < $best_dist) { $best_dist = $dist; $best = $bp; }
                }
                $insert = $best;
            }
            // Если несколько изображений попали в одну позицию — слегка смещаем
            while (isset($injections[$insert])) { $insert++; }
            $injections[$insert] = "\n" . $img['html'] . "\n";
        }

        // Вставляем с конца чтобы не сместить позиции
        krsort($injections);
        foreach ($injections as $pos => $html) {
            $pos = min($pos, strlen($new_content));
            $new_content = substr($new_content, 0, $pos) . $html . substr($new_content, $pos);
        }

        return $new_content;
    }

    /**
     * @deprecated Используй extract_images_for_protection() + reinject_images()
     */
    public function tokenize_images($content) {
        $result = $this->extract_images_for_protection($content);
        $map = array();
        foreach ($result['images'] as $i => $img) {
            $map['[[IMG_' . ($i + 1) . ']]'] = $img['html'];
        }
        $stripped = $result['content'];
        foreach ($map as $token => $html) {
            // токены не используются в новом подходе, контент просто очищен от картинок
        }
        return array('content' => $stripped, 'map' => $map);
    }

    public function restore_images($new_content, $map) {
        // Для обратной совместимости — используем reinject
        $images = array();
        $i = 0;
        foreach ($map as $token => $html) {
            $images[] = array('html' => $html, 'pos_ratio' => $i / max(1, count($map)));
            $i++;
        }
        return $this->reinject_images($new_content, $images);
    }

    public function validate_heading_context($original_content, $new_content) {
        $warnings = array();
        $original = $this->extract_heading_texts($original_content);
        $blocks = $this->extract_heading_blocks($new_content);
        foreach ($blocks as $block) {
            $text_key = $this->normalize_heading_text($block['text']);
            if ($text_key === '' || in_array($text_key, $original, true)) { continue; }
            if ((int)$block['level'] > 3) { continue; }
            $body_text = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($block['body'])));
            preg_match_all('/[\p{L}\p{N}]+/u', $body_text, $words);
            $word_count = count($words[0]);
            $has_list = preg_match('/<(ul|ol)\b[\s\S]*?<li\b/iu', $block['body']);
            if ($word_count < 18 && !$has_list) {
                $warnings[] = 'Новый подзаголовок «' . $block['text'] . '» добавлен без тематического раскрытия ниже. Под ним нужен отдельный текст, список или его лучше удалить.';
            }
        }
        return array_values(array_unique($warnings));
    }

    private function extract_heading_texts($content) {
        $out = array();
        if (preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\1>/isu', (string)$content, $m, PREG_SET_ORDER)) {
            foreach ($m as $row) { $out[] = $this->normalize_heading_text(wp_strip_all_tags($row[2])); }
        }
        return array_values(array_unique(array_filter($out)));
    }

    private function extract_heading_blocks($content) {
        $content = (string)$content;
        $out = array();
        if (!preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\1>/isu', $content, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) { return $out; }
        $count = count($m);
        for ($i = 0; $i < $count; $i++) {
            $full = $m[$i][0][0];
            $start = $m[$i][0][1];
            $end = $start + strlen($full);
            $next = ($i + 1 < $count) ? $m[$i+1][0][1] : strlen($content);
            $out[] = array(
                'level' => (int)$m[$i][1][0],
                'text' => trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($m[$i][2][0]))),
                'body' => substr($content, $end, max(0, $next - $end)),
            );
        }
        return $out;
    }

    private function normalize_heading_text($text) {
        return mb_strtolower(trim(preg_replace('/\s+/u', ' ', (string)$text)));
    }

}

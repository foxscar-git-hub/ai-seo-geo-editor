<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Backup_Service {
    public function table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_backups'; }
    public function create_backup($post_id, $rewrite_id = 0, $type = 'before_apply') {
        $post = get_post(absint($post_id));
        if (!$post || $post->post_type !== 'post') { return new WP_Error('post_not_found', 'Запись для резервной копии не найдена.'); }
        global $wpdb;
        $meta = array();
        foreach (get_post_meta($post->ID) as $key => $values) {
            if (strpos($key, '_edit_') === 0) { continue; }
            $meta[$key] = array_map('maybe_unserialize', (array)$values);
        }
        $ok = $wpdb->insert($this->table(), array(
            'post_id' => $post->ID,
            'rewrite_id' => absint($rewrite_id),
            'backup_type' => sanitize_key($type),
            'title' => $post->post_title,
            'excerpt' => $post->post_excerpt,
            'content_longtext' => $post->post_content,
            'meta_json' => wp_json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'created_by' => get_current_user_id(),
            'created_at' => current_time('mysql'),
        ));
        if (!$ok) { return new WP_Error('backup_failed', 'Не удалось создать резервную копию записи.'); }
        return (int)$wpdb->insert_id;
    }
    public function get_backup($backup_id) { global $wpdb; return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table()} WHERE id=%d", absint($backup_id))); }
    public function get_post_backups($post_id, $limit = 20) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} WHERE post_id=%d ORDER BY id DESC LIMIT %d", absint($post_id), absint($limit))); }
}

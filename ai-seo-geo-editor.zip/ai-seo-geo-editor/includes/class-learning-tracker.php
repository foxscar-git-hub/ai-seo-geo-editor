<?php
if (!defined('ABSPATH')) { exit; }

/**
 * View & engagement tracker.
 * Counts post views into post_meta and saves baseline on rewrite.
 */
class AISEOGEO_Learning_Tracker {

    private $settings;

    public function __construct($settings) { $this->settings = $settings; }

    public function init() {
        if ($this->settings->get('learning_enabled', '0') !== '1') { return; }
        add_action('template_redirect', array($this, 'track_view'));
        add_action('aiseogeo_rewrite_applied', array($this, 'save_baseline'), 10, 1);
    }

    /** Increment view counter on single post pages. */
    public function track_view() {
        if (!is_singular('post') || is_user_logged_in()) { return; }
        $post_id = get_the_ID();
        if (!$post_id) { return; }
        $views = (int)get_post_meta($post_id, '_aiseogeo_views', true);
        update_post_meta($post_id, '_aiseogeo_views', $views + 1);
    }

    /**
     * Save baseline metrics at the moment a rewrite is applied.
     * Called via do_action('aiseogeo_rewrite_applied', $post_id).
     */
    public function save_baseline($post_id) {
        $post_id = (int)$post_id;
        if (!$post_id) { return; }

        $views = (int)get_post_meta($post_id, '_aiseogeo_views', true);
        if (function_exists('wp_statistics_post_views')) {
            $views = max($views, (int)wp_statistics_post_views($post_id));
        }

        $post = get_post($post_id);
        $comments = $post ? (int)$post->comment_count : 0;

        update_post_meta($post_id, '_aiseogeo_views_baseline', $views);
        update_post_meta($post_id, '_aiseogeo_comments_baseline', $comments);
        update_post_meta($post_id, '_aiseogeo_baseline_date', current_time('mysql'));
    }

    /** Current views for a post (best available source). */
    public static function get_views($post_id) {
        $meta = (int)get_post_meta($post_id, '_aiseogeo_views', true);
        if (function_exists('wp_statistics_post_views')) {
            return max($meta, (int)wp_statistics_post_views($post_id));
        }
        return $meta;
    }
}

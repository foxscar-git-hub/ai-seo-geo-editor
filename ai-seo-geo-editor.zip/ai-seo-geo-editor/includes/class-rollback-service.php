<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Rollback_Service {
    private $backup_service; private $logger;
    public function __construct($logger = null) { $this->backup_service = new AISEOGEO_Backup_Service(); $this->logger = $logger; }
    public function rollback($backup_id, $fields = array('title','content','excerpt','meta')) {
        if (!current_user_can('aiseogeo_rollback')) { return new WP_Error('forbidden', 'Недостаточно прав для отката.'); }
        $backup = $this->backup_service->get_backup(absint($backup_id));
        if (!$backup) { return new WP_Error('backup_not_found', 'Резервная копия не найдена.'); }
        $post = get_post((int)$backup->post_id);
        if (!$post) { return new WP_Error('post_not_found', 'Запись для отката не найдена.'); }
        $fields = array_map('sanitize_key', (array)$fields);
        $update = array('ID'=>$post->ID);
        if (in_array('title', $fields, true)) { $update['post_title'] = $backup->title; }
        if (in_array('content', $fields, true)) { $update['post_content'] = $backup->content_longtext; }
        if (in_array('excerpt', $fields, true)) { $update['post_excerpt'] = $backup->excerpt; }
        $result = count($update) > 1 ? wp_update_post($update, true) : $post->ID;
        if (is_wp_error($result)) { return $result; }
        if (in_array('meta', $fields, true)) {
            $meta = json_decode((string)$backup->meta_json, true);
            if (is_array($meta)) {
                foreach ($meta as $key => $values) {
                    delete_post_meta($post->ID, $key);
                    foreach ((array)$values as $v) { add_post_meta($post->ID, $key, maybe_unserialize($v)); }
                }
            }
        }
        if ($this->logger) { $this->logger->log('info','rollback','Запись восстановлена из резервной копии.',array('backup_id'=>$backup->id),$post->ID); }
        return array('post_id'=>$post->ID,'backup_id'=>(int)$backup->id);
    }
}

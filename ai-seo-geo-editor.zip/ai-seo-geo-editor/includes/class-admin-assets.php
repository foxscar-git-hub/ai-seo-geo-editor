<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Admin_Assets {
    public function init() { add_action('admin_enqueue_scripts', array($this,'enqueue')); }
    public function enqueue($hook) {
        if (strpos($hook, 'aiseogeo') !== false || $hook === 'edit.php') {
            wp_enqueue_style('aiseogeo-admin', AISEOGEO_URL . 'assets/css/admin.css', array(), AISEOGEO_VERSION);
            wp_enqueue_script('aiseogeo-admin', AISEOGEO_URL . 'assets/js/admin.js', array('jquery'), AISEOGEO_VERSION, true);
        }
    }
}

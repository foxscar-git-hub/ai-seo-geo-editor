<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Site_Optimization_Insights_Service {
    public function insights() {
        global $wpdb;
        $rewrites_table = $wpdb->prefix . 'aiseogeo_rewrites';
        $apply_table = $wpdb->prefix . 'aiseogeo_apply_logs';

        $rewrites = $wpdb->get_results("SELECT r.* FROM {$rewrites_table} r INNER JOIN (SELECT post_id, MAX(id) mid FROM {$rewrites_table} WHERE rewrite_status IN ('done','re_audited','draft_created') AND new_content_longtext IS NOT NULL AND new_content_longtext <> '' GROUP BY post_id) x ON x.mid = r.id ORDER BY r.id DESC LIMIT 500");

        $total = count($rewrites);
        $applied = $this->table_exists($apply_table) ? (int)$wpdb->get_var("SELECT COUNT(*) FROM {$apply_table} WHERE status='done'") : 0;

        $forecast_sums = array();
        $forecast_count = 0;

        $changed_title = 0;
        $changed_excerpt = 0;
        $new_meta_description = 0;
        $faq_saved_or_added = 0;
        $cta_saved = 0;
        $links_preserved = 0;
        $warnings_count = 0;
        $old_words_total = 0;
        $new_words_total = 0;
        $similarity_total = 0;
        $similarity_count = 0;
        $mode_counts = array();

        foreach ($rewrites as $rewrite) {
            $mode = (string)$rewrite->rewrite_mode;
            $mode_counts[$mode] = ($mode_counts[$mode] ?? 0) + 1;

            if (trim((string)$rewrite->new_title) !== '' && trim((string)$rewrite->new_title) !== trim((string)$rewrite->original_title)) { $changed_title++; }
            if (trim((string)$rewrite->new_excerpt) !== '' && trim((string)$rewrite->new_excerpt) !== trim((string)$rewrite->original_excerpt)) { $changed_excerpt++; }
            if (trim((string)$rewrite->new_meta_description) !== '') { $new_meta_description++; }

            $old_content = (string)$rewrite->original_content_longtext;
            $new_content = (string)$rewrite->new_content_longtext;
            $old_plain = $this->plain($old_content);
            $new_plain = $this->plain($new_content);
            $old_words = $this->word_count($old_plain);
            $new_words = $this->word_count($new_plain);
            $old_words_total += $old_words;
            $new_words_total += $new_words;
            $similarity_total += $this->similarity_percent($old_plain, $new_plain);
            $similarity_count++;

            $old_blocks = $this->detect_business_blocks($old_content);
            $new_blocks = $this->detect_business_blocks($new_content);
            if ((!empty($old_blocks['faq']) && !empty($new_blocks['faq'])) || (empty($old_blocks['faq']) && !empty($new_blocks['faq'])) || $this->has_faq_json($rewrite->new_faq_json)) { $faq_saved_or_added++; }
            if (empty($old_blocks['cta']) || !empty($new_blocks['cta'])) { $cta_saved++; }

            $old_links = $this->extract_links($old_content);
            $new_links = $this->extract_links($new_content);
            $missing_links = array_diff($old_links, $new_links);
            if (count($missing_links) === 0) { $links_preserved++; }

            $warnings = json_decode((string)$rewrite->warnings_json, true);
            if (is_array($warnings) && count($warnings) > 0) { $warnings_count++; }

            if (class_exists('AISEOGEO_Search_Forecast_Service')) {
                $before_scores = $this->scores_from_audit_row($this->get_audit((int)$rewrite->audit_id));
                $after_audit = !empty($rewrite->re_audit_id) ? $this->get_audit((int)$rewrite->re_audit_id) : null;
                if ($after_audit) { $after_scores = $this->scores_from_audit_row($after_audit); }
                else { $after_scores = AISEOGEO_Search_Forecast_Service::suggested_after_scores((object)$this->audit_object_from_scores($before_scores), $mode); }
                $rows = AISEOGEO_Search_Forecast_Service::metrics_from_score_sets($before_scores, $after_scores, !$after_audit);
                foreach ($rows as $row) {
                    $key = $row['key'];
                    if (!isset($forecast_sums[$key])) {
                        $forecast_sums[$key] = array('key'=>$key,'label'=>$row['label'],'before'=>0,'after'=>0,'delta'=>0,'note'=>$row['note'],'is_forecast'=>false,'items'=>0);
                    }
                    $forecast_sums[$key]['before'] += (int)$row['before'];
                    $forecast_sums[$key]['after'] += (int)$row['after'];
                    $forecast_sums[$key]['delta'] += (int)$row['delta'];
                    $forecast_sums[$key]['is_forecast'] = $forecast_sums[$key]['is_forecast'] || !empty($row['is_forecast']);
                    $forecast_sums[$key]['items']++;
                }
                $forecast_count++;
            }
        }

        $forecast_rows = array();
        foreach ($forecast_sums as $row) {
            $items = max(1, (int)$row['items']);
            $forecast_rows[] = array(
                'key' => $row['key'],
                'label' => $row['label'],
                'before' => (int)round($row['before'] / $items),
                'after' => (int)round($row['after'] / $items),
                'delta' => (int)round($row['delta'] / $items),
                'note' => $row['note'],
                'is_forecast' => !empty($row['is_forecast']),
            );
        }

        return array(
            'has_data' => $total > 0,
            'total_rewrites' => $total,
            'applied_rewrites' => $applied,
            'forecast_rows' => $forecast_rows,
            'change_summary' => array(
                'changed_title' => $changed_title,
                'changed_excerpt' => $changed_excerpt,
                'new_meta_description' => $new_meta_description,
                'faq_saved_or_added' => $faq_saved_or_added,
                'cta_saved' => $cta_saved,
                'links_preserved' => $links_preserved,
                'warnings_count' => $warnings_count,
                'avg_text_growth_percent' => $old_words_total > 0 ? (int)round((($new_words_total - $old_words_total) / max(1, $old_words_total)) * 100) : 0,
                'avg_similarity' => $similarity_count ? (int)round($similarity_total / $similarity_count) : 0,
            ),
            'mode_counts' => $mode_counts,
            "note" => "Показатели являются прогнозными SEO/GEO-индексами и рассчитаны только по материалам, которые уже были обработаны плагином. Необработанные записи сайта в расчёт ‘до/после’ не входят. Это не фактические данные из Яндекс.Метрики, Google Analytics или Search Console.",
        );
    }

    private function table_exists($table) {
        global $wpdb;
        return (string)$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === (string)$table;
    }

    private function get_audit($audit_id) {
        global $wpdb;
        if (!$audit_id) { return null; }
        $table = $wpdb->prefix . 'aiseogeo_audits';
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", $audit_id));
    }

    private function scores_from_audit_row($audit) {
        if (!$audit) { return array('overall'=>0,'seo'=>0,'geo'=>0,'eeat'=>0,'readability'=>0,'structure'=>0,'meta'=>0,'internal_links'=>0); }
        return array(
            'overall'=>(int)$audit->overall_score,
            'seo'=>(int)$audit->seo_score,
            'geo'=>(int)$audit->geo_score,
            'eeat'=>(int)$audit->eeat_score,
            'readability'=>(int)$audit->readability_score,
            'structure'=>(int)$audit->structure_score,
            'meta'=>(int)$audit->meta_score,
            'internal_links'=>(int)$audit->internal_links_score,
        );
    }

    private function audit_object_from_scores($scores) {
        return array(
            'overall_score'=>(int)($scores['overall'] ?? 0),
            'seo_score'=>(int)($scores['seo'] ?? 0),
            'geo_score'=>(int)($scores['geo'] ?? 0),
            'eeat_score'=>(int)($scores['eeat'] ?? 0),
            'readability_score'=>(int)($scores['readability'] ?? 0),
            'structure_score'=>(int)($scores['structure'] ?? 0),
            'meta_score'=>(int)($scores['meta'] ?? 0),
            'internal_links_score'=>(int)($scores['internal_links'] ?? 0),
        );
    }

    private function plain($content) {
        return trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags((string)$content)));
    }

    private function word_count($plain) {
        $plain = trim((string)$plain);
        if ($plain === '') { return 0; }
        preg_match_all('/[\p{L}\p{N}]+/u', $plain, $m);
        return count($m[0]);
    }

    private function similarity_percent($a, $b) {
        $a = mb_substr((string)$a, 0, 6000);
        $b = mb_substr((string)$b, 0, 6000);
        if ($a === '' && $b === '') { return 100; }
        similar_text($a, $b, $pct);
        return (int)round($pct);
    }

    private function extract_links($content) {
        $out = array();
        if (preg_match_all('/<a\b[^>]*href=["\']([^"\']+)["\']/iu', (string)$content, $m)) {
            foreach ($m[1] as $url) { $out[] = trim(html_entity_decode($url)); }
        }
        return array_values(array_unique(array_filter($out)));
    }

    private function detect_business_blocks($content) {
        $plain = mb_strtolower($this->plain($content));
        return array(
            'faq' => (mb_stripos($plain, 'частые вопросы') !== false || mb_stripos($plain, 'часто задаваемые вопросы') !== false || mb_stripos($plain, 'faq') !== false || preg_match('/вопросы\s+и\s+ответы/u', $plain)),
            'cta' => (mb_stripos($plain, 'следующий шаг') !== false || mb_stripos($plain, 'оставить заявку') !== false || mb_stripos($plain, 'получить консультацию') !== false || mb_stripos($plain, 'попробовать') !== false || mb_stripos($plain, 'заказать') !== false),
        );
    }

    private function has_faq_json($json) {
        $arr = json_decode((string)$json, true);
        return is_array($arr) && count($arr) > 0;
    }
}

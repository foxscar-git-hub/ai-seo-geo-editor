<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Пошаговое выполнение переписывания.
 * Каждый метод — отдельный AI-запрос. Каждый использует данные предыдущих.
 */
class AISEOGEO_Rewrite_Steps {
    private $client;
    private $settings;
    private $override_model = null; // Устанавливается роутером перед каждым вызовом

    public function __construct($client, $settings) {
        $this->client   = $client;
        $this->settings = $settings;
    }

    // Роутер вызывает этот метод перед каждым chat()-запросом
    public function set_model($model) {
        $this->override_model = $model ?: null;
    }

    // Внутренний helper — передаёт override_model в client->chat()
    private function do_chat($messages, $max_tokens, $web_search = false) {
        return $this->client->chat($messages, $max_tokens, $this->override_model, $web_search);
    }

    // ── Шаг 1+2: Анализ аудитории и слабых мест ─────────────────────────────
    public function research($rewrite, $audit) {
        $orig_plain = mb_substr(wp_strip_all_tags((string)$rewrite->original_content_longtext), 0, 8000);
        $audit_ctx  = '';
        if ($audit) {
            $probs = json_decode($audit->problems_json, true) ?: [];
            $recs  = json_decode($audit->recommendations_json, true) ?: [];
            $audit_ctx = "\n\nДанные аудита:\nПроблемы: " . implode('; ', array_slice((array)$probs, 0, 8)) .
                         "\nРекомендации: " . implode('; ', array_slice((array)$recs, 0, 8));
        }

        $user = "Проанализируй статью по двум направлениям:\n" .
            "1. Аудитория: кто читает, уровень знаний, главные боли и вопросы\n" .
            "2. Слабые места: что не раскрыто, структурные пробелы, что конкуренты раскрывают лучше\n\n" .
            "Заголовок: " . $rewrite->original_title . "\n" .
            "Режим переписывания: " . $rewrite->rewrite_mode . "\n" .
            "Контент статьи:\n" . $orig_plain .
            $audit_ctx . "\n\n" .
            'Верни ТОЛЬКО валидный JSON (без markdown):
{
  "audience": {
    "primary": "описание основной аудитории",
    "level": "beginner|intermediate|expert",
    "intent": "informational|commercial|navigational",
    "pains": ["боль 1", "боль 2", "боль 3"]
  },
  "weak_sections": [
    {"heading": "название раздела или тема", "issue": "в чём проблема", "priority": "high|medium|low"}
  ],
  "missing_topics": ["тема которой не хватает"],
  "strengths": ["что хорошо в оригинале — сохранить"]
}';

        $result = $this->do_chat([
            ['role' => 'system', 'content' => 'Ты аналитик контента. Верни только валидный JSON, без markdown, без пояснений.'],
            ['role' => 'user',   'content' => $user],
        ], 4000, true); // web_search=true

        if (is_wp_error($result)) { return $result; }
        return $this->parse_json($result['content']);
    }

    // ── Шаг 3+4: Семантика, ключевые запросы, источники ──────────────────────
    public function semantics($rewrite, $research) {
        $user = "На основе анализа аудитории подбери семантику и источники для статьи.\n\n" .
            "Тема: " . $rewrite->original_title . "\n" .
            "Режим: " . $rewrite->rewrite_mode . "\n\n" .
            "Анализ аудитории:\n" . wp_json_encode($research, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "\n\n" .
            'Верни ТОЛЬКО валидный JSON:
{
  "main_keyword": "главный SEO/GEO-запрос для этой темы",
  "secondary_keywords": ["запрос2", "запрос3", "запрос4"],
  "geo_keywords": ["гео-запрос если применимо"],
  "h2_bank": ["Как X?", "Что такое Y?", "Почему Z важно?", "Когда использовать X?"],
  "sources": [
    {"title": "Название источника", "what_confirms": "что именно подтверждает"}
  ],
  "statistics": [
    {"fact": "конкретная цифра или факт", "source": "откуда взято"}
  ]
}';

        $result = $this->do_chat([
            ['role' => 'system', 'content' => 'Ты SEO/GEO-редактор. Подбирай реальные существующие источники с рабочими URL. Верни только валидный JSON, без markdown.'],
            ['role' => 'user',   'content' => $user],
        ], 3000, true); // web_search=true

        if (is_wp_error($result)) { return $result; }
        return $this->parse_json($result['content']);
    }

    // ── Шаг 5: Структурный скелет с Answer-First ─────────────────────────────
    public function structure($rewrite, $research, $semantics) {
        $audience_str  = wp_json_encode($research['audience'] ?? [], JSON_UNESCAPED_UNICODE);
        $weak_str      = wp_json_encode($research['weak_sections'] ?? [], JSON_UNESCAPED_UNICODE);
        $main_kw       = $semantics['main_keyword'] ?? '';
        $sec_kw        = implode(', ', array_slice($semantics['secondary_keywords'] ?? [], 0, 6));
        $sources_str   = wp_json_encode(array_slice($semantics['sources'] ?? [], 0, 8), JSON_UNESCAPED_UNICODE);
        $stats_str     = wp_json_encode(array_slice($semantics['statistics'] ?? [], 0, 6), JSON_UNESCAPED_UNICODE);

        $user = "Создай детальный структурный скелет статьи по методологии «Скилл Статей».\n\n" .
            "Тема: " . $rewrite->original_title . "\n" .
            "Главный запрос: " . $main_kw . "\n" .
            "Доп. запросы: " . $sec_kw . "\n" .
            "Аудитория: " . $audience_str . "\n" .
            "Слабые места: " . $weak_str . "\n" .
            "Источники: " . $sources_str . "\n" .
            "Статистика: " . $stats_str . "\n" .
            "Режим: " . $rewrite->rewrite_mode . "\n\n" .
            "Правила:\n" .
            "- Минимум 8, максимум 14 разделов H2\n" .
            "- Минимум 50% заголовков H2 в форме вопроса\n" .
            "- Answer-First (TL;DR) — обязателен для каждого H2: 40-75 слов, прямой ответ\n" .
            "- Hero Promise — перед первым H2, 3-5 буллетов что получит читатель\n" .
            "- 3 CTA-точки: после hero, в середине, после источников\n\n" .
            'Верни ТОЛЬКО валидный JSON:
{
  "hero_promise_draft": "HTML блок-обещания: что читатель получит, за сколько минут, сколько сэкономит",
  "outline": [
    {
      "h2": "Заголовок раздела",
      "answer_first": "TL;DR: прямой ответ на вопрос раздела, 40-75 слов",
      "key_points": ["тезис 1 для раскрытия", "тезис 2"],
      "format": "paragraph|table|ordered_list|unordered_list",
      "source_index": 0
    }
  ],
  "faq_questions": ["Вопрос 1?", "Вопрос 2?", "Вопрос 3?"],
  "cta_hooks": [
    "после hero: призыв к первому контакту",
    "середина: связка темы с оффером",
    "финал: конкретное следующее действие"
  ]
}';

        $result = $this->do_chat([
            ['role' => 'system', 'content' => 'Ты архитектор контента. Верни только валидный JSON, без markdown.'],
            ['role' => 'user',   'content' => $user],
        ], 6000);

        if (is_wp_error($result)) { return $result; }
        return $this->parse_json($result['content']);
    }

    // ── Шаг 6: Написание полного текста ──────────────────────────────────────
    public function write($rewrite, $content_for_ai, $research, $semantics, $structure) {
        $main_kw   = $semantics['main_keyword'] ?? '';
        $sec_kws   = implode(', ', array_slice($semantics['secondary_keywords'] ?? [], 0, 6));
        $sources   = wp_json_encode(array_slice($semantics['sources'] ?? [], 0, 10), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        $stats     = wp_json_encode(array_slice($semantics['statistics'] ?? [], 0, 8), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        $audience  = wp_json_encode($research['audience'] ?? [], JSON_UNESCAPED_UNICODE);
        $pains     = implode('; ', $research['audience']['pains'] ?? []);
        $outline   = wp_json_encode($structure['outline'] ?? [], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        $hero      = $structure['hero_promise_draft'] ?? '';
        $faq_q     = implode('; ', $structure['faq_questions'] ?? []);
        $cta       = wp_json_encode($structure['cta_hooks'] ?? [], JSON_UNESCAPED_UNICODE);

        $context = "═══ ДАННЫЕ ПРЕДЫДУЩИХ ШАГОВ АНАЛИЗА — использовать строго ═══\n\n" .
            "АУДИТОРИЯ: " . $audience . "\n" .
            "БОЛИ ЧИТАТЕЛЕЙ: " . $pains . "\n\n" .
            "ГЛАВНЫЙ ЗАПРОС: " . $main_kw . "\n" .
            "ДОПОЛНИТЕЛЬНЫЕ ЗАПРОСЫ: " . $sec_kws . "\n\n" .
            "ИСТОЧНИКИ ДЛЯ ССЫЛОК В ТЕКСТЕ:\n" . $sources . "\n\n" .
            "СТАТИСТИКА И ФАКТЫ:\n" . $stats . "\n\n" .
            "HERO PROMISE (перед первым H2):\n" . $hero . "\n\n" .
            "ПЛАН СТАТЬИ (СТРОГО СЛЕДОВАТЬ):\n" . $outline . "\n\n" .
            "FAQ ВОПРОСЫ (добавить блок в конце): " . $faq_q . "\n" .
            "CTA ХУКИ: " . $cta . "\n\n" .
            "═══ ИСХОДНАЯ СТАТЬЯ (переписать, сохранить смысл и ссылки) ═══\n\n" .
            "Заголовок: " . $rewrite->original_title . "\n\n" .
            $content_for_ai;

        $tokens = $this->write_max_tokens($rewrite);
        return $this->do_chat([
            ['role' => 'system', 'content' => AISEOGEO_Prompt_Loader::rewrite_system()],
            ['role' => 'user',   'content' => $context],
        ], $tokens);
    }

    // ── Шаги 7-14: Редактура, Anti-AI, мета, FAQ, схема ─────────────────────
    public function finalize($rewrite, $new_content, $research, $semantics) {
        $main_kw = $semantics['main_keyword'] ?? '';
        $sec_kws = implode(', ', array_slice($semantics['secondary_keywords'] ?? [], 0, 5));
        $pains   = implode('; ', $research['audience']['pains'] ?? []);

        $user = "Доработай написанную статью по чеклисту редактора.\n\n" .
            "Главный запрос: " . $main_kw . "\n" .
            "Доп. запросы: " . $sec_kws . "\n" .
            "Боли читателей: " . $pains . "\n\n" .
            "ЧЕКЛИСТ РЕДАКТУРЫ (выполнить всё):\n" .
            "Этап 7 — Логика: убери противоречия, проверь факты\n" .
            "Этап 8 — Стиль: длинное-короткое-длинное предложение; убери «удар-удар-удар»\n" .
            "Этап 9 — SEO/GEO: главный запрос в первых 100 словах и в 2-3 H2\n" .
            "Этап 10 — Мета: напиши new_title, new_meta_title, new_meta_description, new_excerpt\n" .
            "Этап 11 — Anti-AI: тире (—–) → дефис; убери клише и кальки с английского\n" .
            "Этап 12 — Внутренние ссылки: проверь минимум 3 ссылки на другие страницы сайта\n" .
            "Этап 13 — QA: убедись что new_content полный, не обрезанный\n" .
            "Этап 14 — Schema: подготовь JSON-LD schema\n\n" .
            "Статья для доработки:\n" . mb_substr($new_content, 0, 55000) . "\n\n" .
            'Верни ТОЛЬКО валидный JSON:
{
  "new_content": "итоговый полный HTML статьи после всех правок",
  "new_title": "H1 заголовок 50-70 символов",
  "new_meta_title": "мета-заголовок 50-70 символов с главным запросом",
  "new_meta_description": "описание 100-160 символов: зачем читать",
  "new_excerpt": "анонс 1-2 предложения",
  "faq": [{"question": "Вопрос?", "answer": "Ответ."}],
  "schema_recommendation": {"type": "Article|HowTo|FAQPage", "json_ld": {}},
  "humanization_applied": {
    "em_dashes_replaced": 0,
    "cliches_removed": ["что удалено"],
    "symmetries_rewritten": ["что переписано"],
    "answer_first_added": ["H2 где добавлен TL;DR"],
    "question_h2_converted": ["H2 переведённые в вопрос"]
  },
  "structure_added": {
    "hero_promise": true,
    "cta_count": 3,
    "faq_added": true,
    "sources_block_added": true,
    "tables_count": 0,
    "numbered_lists_count": 0,
    "internal_links_count": 0
  },
  "warnings": [],
  "preserved_items": [],
  "confidence": 0.9
}';

        $tokens = max(24000, intval($this->settings->get('max_tokens', '6000')));
        return $this->do_chat([
            ['role' => 'system', 'content' => 'Ты редактор-финалайзер. Верни только валидный JSON, без markdown.'],
            ['role' => 'user',   'content' => $user],
        ], $tokens);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    public function parse_json($content) {
        $content = trim((string)$content);
        if (preg_match('/```(?:json)?\s*([\s\S]+?)\s*```/s', $content, $m)) { $content = trim($m[1]); }
        $decoded = json_decode($content, true);
        if (!is_array($decoded) && preg_match('/(\{[\s\S]+\})/s', $content, $m)) {
            $decoded = json_decode($m[1], true);
        }
        if (!is_array($decoded)) {
            return new WP_Error('step_json_error', 'Шаг вернул не-JSON: ' . mb_substr($content, 0, 300));
        }
        return $decoded;
    }

    private function write_max_tokens($rewrite) {
        $base = intval($this->settings->get('max_tokens', '6000'));
        $len  = mb_strlen(wp_strip_all_tags((string)$rewrite->original_content_longtext));
        if ($len > 15000) { return max(32000, $base); }
        if ($len > 10000) { return max(24000, $base); }
        if ($len > 5000)  { return max(18000, $base); }
        return max(14000, $base);
    }
}

<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Post_Filter_Service {
    private $audit_service;
    public function __construct($audit_service) { $this->audit_service = $audit_service; }
    public static function filters() {
        return array(
            'all_published'=>'Все опубликованные', 'no_audit'=>'Без анализа', 'score_below_80'=>'Оценка ниже 80',
            'score_below_60'=>'Оценка ниже 60', 'score_below_40'=>'Оценка ниже 40', 'old_posts'=>'Давно не обновлялись',
            'no_meta_description'=>'Без meta description', 'short_posts'=>'Короткие статьи'
        );
    }
    public function get_posts($filter, $limit = 20, $category = 0) {
        global $wpdb;
        $limit = max(1, min(200, absint($limit)));
        $args = array('post_type'=>'post','post_status'=>'publish','posts_per_page'=>$limit,'fields'=>'ids','orderby'=>'modified','order'=>'ASC');
        if ($category) { $args['cat'] = absint($category); }
        if ($filter === 'old_posts') { $args['date_query'] = array(array('column'=>'post_modified_gmt','before'=>'180 days ago')); }
        if ($filter === 'short_posts') { $args['suppress_filters'] = false; }
        $ids = get_posts($args);
        if ($filter === 'no_audit') {
            $out = array();
            foreach ($ids as $id) { if (!$this->audit_service->get_latest_audit($id)) { $out[] = $id; } }
            return $out;
        }
        if (in_array($filter, array('score_below_80','score_below_60','score_below_40'), true)) {
            $threshold = (int)str_replace('score_below_', '', $filter);
            $audit_table = $this->audit_service->table();
            $sql = $wpdb->prepare("SELECT a.post_id FROM {$audit_table} a INNER JOIN (SELECT post_id, MAX(id) mid FROM {$audit_table} WHERE status='done' AND content_source='post' GROUP BY post_id) x ON x.mid=a.id WHERE a.overall_score < %d LIMIT %d", $threshold, $limit);
            $res = array_map('intval', $wpdb->get_col($sql));
            return $res;
        }
        if ($filter === 'no_meta_description') {
            $out = array();
            foreach ($ids as $id) {
                $d = get_post_meta($id, '_yoast_wpseo_metadesc', true) ?: get_post_meta($id, 'rank_math_description', true) ?: get_post_meta($id, '_aiseogeo_meta_description', true);
                if (trim((string)$d) === '') { $out[] = $id; }
            }
            return $out;
        }
        if ($filter === 'short_posts') {
            $out = array();
            foreach ($ids as $id) { if (str_word_count(wp_strip_all_tags(get_post_field('post_content', $id))) < 350) { $out[] = $id; } }
            return $out;
        }
        return array_map('intval', $ids);
    }
}

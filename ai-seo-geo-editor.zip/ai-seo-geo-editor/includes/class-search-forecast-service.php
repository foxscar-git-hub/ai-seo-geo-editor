<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Search_Forecast_Service {
    public static function clamp($value) {
        return max(0, min(100, (int)round($value)));
    }

    public static function audit_scores($audit) {
        return array(
            'overall' => $audit ? (int)$audit->overall_score : 0,
            'seo' => $audit ? (int)$audit->seo_score : 0,
            'geo' => $audit ? (int)$audit->geo_score : 0,
            'eeat' => $audit ? (int)$audit->eeat_score : 0,
            'readability' => $audit ? (int)$audit->readability_score : 0,
            'structure' => $audit ? (int)$audit->structure_score : 0,
            'meta' => $audit ? (int)$audit->meta_score : 0,
            'internal_links' => $audit ? (int)$audit->internal_links_score : 0,
        );
    }

    public static function estimate_serp_conversion_from_scores($scores) {
        $meta = (int)($scores['meta'] ?? 0);
        $seo = (int)($scores['seo'] ?? 0);
        $geo = (int)($scores['geo'] ?? 0);
        $structure = (int)($scores['structure'] ?? 0);
        $readability = (int)($scores['readability'] ?? 0);
        $eeat = (int)($scores['eeat'] ?? 0);
        return self::clamp(($meta * 0.42) + ($seo * 0.22) + ($geo * 0.16) + ($structure * 0.10) + ($readability * 0.05) + ($eeat * 0.05));
    }

    public static function suggested_after_scores($audit, $mode = '') {
        $s = self::audit_scores($audit);
        $mode = (string)$mode;
        $boosts = array(
            'soft_improve' => array('overall'=>8,'seo'=>7,'geo'=>7,'eeat'=>5,'readability'=>10,'structure'=>8,'meta'=>6,'internal_links'=>5),
            'seo_boost' => array('overall'=>12,'seo'=>18,'geo'=>7,'eeat'=>5,'readability'=>7,'structure'=>12,'meta'=>25,'internal_links'=>12),
            'geo_boost' => array('overall'=>12,'seo'=>8,'geo'=>22,'eeat'=>8,'readability'=>8,'structure'=>12,'meta'=>8,'internal_links'=>7),
            'full_refresh' => array('overall'=>18,'seo'=>18,'geo'=>20,'eeat'=>12,'readability'=>15,'structure'=>18,'meta'=>22,'internal_links'=>12),
            'meta_only' => array('overall'=>6,'seo'=>10,'geo'=>4,'eeat'=>2,'readability'=>0,'structure'=>0,'meta'=>35,'internal_links'=>0),
            'problem_blocks_only' => array('overall'=>10,'seo'=>9,'geo'=>9,'eeat'=>6,'readability'=>12,'structure'=>8,'meta'=>6,'internal_links'=>5),
        );
        $boost = $boosts[$mode] ?? array('overall'=>12,'seo'=>12,'geo'=>14,'eeat'=>8,'readability'=>8,'structure'=>10,'meta'=>18,'internal_links'=>8);
        foreach ($s as $k => $v) {
            $add = $boost[$k] ?? 8;
            if ($v < 40) { $add += 6; }
            elseif ($v < 60) { $add += 3; }
            $s[$k] = self::clamp($v + $add);
        }
        return $s;
    }

    public static function forecast_from_audit($audit, $mode = '') {
        $before_scores = self::audit_scores($audit);
        $after_scores = self::suggested_after_scores($audit, $mode);
        return self::metrics_from_score_sets($before_scores, $after_scores, true);
    }

    public static function forecast_from_rewrite($before_audit, $after_audit = null, $rewrite = null) {
        $before_scores = self::audit_scores($before_audit);
        if ($after_audit) {
            $after_scores = self::audit_scores($after_audit);
            $is_forecast = false;
        } else {
            $after_scores = self::suggested_after_scores($before_audit, $rewrite ? $rewrite->rewrite_mode : '');
            $is_forecast = true;
        }
        return self::metrics_from_score_sets($before_scores, $after_scores, $is_forecast);
    }

    public static function metrics_from_score_sets($before_scores, $after_scores, $is_forecast = true) {
        $before_conv = self::estimate_serp_conversion_from_scores($before_scores);
        $after_conv = self::estimate_serp_conversion_from_scores($after_scores);
        $rows = array(
            array(
                'key' => 'serp_conversion',
                'label' => 'Индекс конверсии в выдаче',
                'before' => $before_conv,
                'after' => $after_conv,
                'delta' => $after_conv - $before_conv,
                'note' => 'Сводный прогноз по качеству сниппета, релевантности, структуре и пригодности страницы к переходу из поиска.',
            ),
            array(
                'key' => 'snippet_ctr',
                'label' => 'Кликабельность сниппета',
                'before' => self::clamp(($before_scores['meta'] * 0.65) + ($before_scores['seo'] * 0.25) + ($before_scores['readability'] * 0.10)),
                'after' => self::clamp(($after_scores['meta'] * 0.65) + ($after_scores['seo'] * 0.25) + ($after_scores['readability'] * 0.10)),
                'note' => 'Зависит от title, description, понятности обещания и совпадения с интентом пользователя.',
            ),
            array(
                'key' => 'search_visibility',
                'label' => 'Потенциал видимости',
                'before' => self::clamp(($before_scores['seo'] * 0.45) + ($before_scores['structure'] * 0.25) + ($before_scores['internal_links'] * 0.15) + ($before_scores['eeat'] * 0.15)),
                'after' => self::clamp(($after_scores['seo'] * 0.45) + ($after_scores['structure'] * 0.25) + ($after_scores['internal_links'] * 0.15) + ($after_scores['eeat'] * 0.15)),
                'note' => 'Показывает, насколько страница подготовлена к лучшему пониманию поисковыми системами.',
            ),
            array(
                'key' => 'ai_citation',
                'label' => 'AI-цитируемость',
                'before' => self::clamp(($before_scores['geo'] * 0.55) + ($before_scores['structure'] * 0.25) + ($before_scores['eeat'] * 0.20)),
                'after' => self::clamp(($after_scores['geo'] * 0.55) + ($after_scores['structure'] * 0.25) + ($after_scores['eeat'] * 0.20)),
                'note' => 'Оценивает готовность материала попадать в AI-ответы и краткие обзорные блоки.',
            ),
        );
        foreach ($rows as &$row) {
            if (!isset($row['delta'])) { $row['delta'] = $row['after'] - $row['before']; }
            $row['is_forecast'] = $is_forecast;
        }
        unset($row);
        return $rows;
    }
}

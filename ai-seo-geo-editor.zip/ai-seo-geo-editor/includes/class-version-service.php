<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Version_Service {
    public function table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_versions'; }
    public function create_versions($rewrite, $audit = null) {
        $this->create_original_version($rewrite, $audit);
        $this->create_rewritten_version($rewrite, $audit);
    }
    public function create_original_version($rewrite, $audit = null) {
        return $this->insert_version($rewrite, 'original', $rewrite->original_title, $rewrite->original_excerpt, $rewrite->original_content_longtext, '', '', $audit ? intval($audit->overall_score) : null, null, $audit);
    }
    public function create_rewritten_version($rewrite, $audit = null) {
        return $this->insert_version($rewrite, 'rewritten', $rewrite->new_title, $rewrite->new_excerpt, $rewrite->new_content_longtext, $rewrite->new_meta_title, $rewrite->new_meta_description, $audit ? intval($audit->overall_score) : null, null, $audit);
    }
    private function insert_version($rewrite, $type, $title, $excerpt, $content, $meta_title, $meta_description, $score_before = null, $score_after = null, $audit = null) {
        global $wpdb;
        $now = current_time('mysql');
        $wpdb->insert($this->table(), array(
            'post_id'=>(int)$rewrite->post_id, 'rewrite_id'=>(int)$rewrite->id, 'version_type'=>$type,
            'title'=>$title, 'excerpt'=>$excerpt, 'content_longtext'=>$content, 'meta_title'=>$meta_title, 'meta_description'=>$meta_description,
            'score_before'=>$score_before, 'score_after'=>$score_after,
            'seo_score_before'=>$audit ? intval($audit->seo_score) : null, 'geo_score_before'=>$audit ? intval($audit->geo_score) : null, 'eeat_score_before'=>$audit ? intval($audit->eeat_score) : null,
            'status'=>'active', 'created_by'=>get_current_user_id(), 'created_at'=>$now, 'updated_at'=>$now,
        ));
        return $wpdb->insert_id;
    }
    public function get_versions($limit = 100) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} WHERE status <> 'deleted' ORDER BY id DESC LIMIT %d", absint($limit))); }
    public function get_versions_by_post($post_id) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} WHERE post_id=%d AND status <> 'deleted' ORDER BY id DESC", absint($post_id))); }
    public function get_version($version_id) { global $wpdb; return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table()} WHERE id=%d", absint($version_id))); }
    public function delete_version($version_id) { global $wpdb; return $wpdb->update($this->table(), array('status'=>'deleted','updated_at'=>current_time('mysql')), array('id'=>absint($version_id))); }
    public function update_rewrite_scores($rewrite_id, $audit) {
        global $wpdb;
        return $wpdb->update($this->table(), array('score_after'=>intval($audit->overall_score),'seo_score_after'=>intval($audit->seo_score),'geo_score_after'=>intval($audit->geo_score),'eeat_score_after'=>intval($audit->eeat_score),'updated_at'=>current_time('mysql')), array('rewrite_id'=>absint($rewrite_id), 'version_type'=>'rewritten'));
    }
}

<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Commercial license gate for AI SEO/GEO Editor.

 */
class AISEOGEO_License_Gate {
    const PRODUCT_KEY = 'ai-seo-geo-editor';
    const FREE_AUDIT_LIMIT = 10;

    private $settings;
    private $logger;
    private $client;

    public function __construct($settings, $logger = null) {
        $this->settings = $settings;
        $this->logger = $logger;
        $this->client = new AISEOGEO_License_Client($settings, $logger);
    }

    public function is_active() {
        return $this->client->is_active();
    }

    public function plan() {
        return $this->client->plan();
    }

    public function status() {
        return $this->client->status();
    }

    public function free_audit_limit() {
        return (int)$this->settings->get('free_audit_limit', self::FREE_AUDIT_LIMIT);
    }

    public function usage($event) {
        $event = sanitize_key($event);
        return (int)$this->settings->get('usage_' . $event . '_total', 0);
    }

    public function remaining_free_audits() {
        if ($this->is_active()) { return null; }
        return max(0, $this->free_audit_limit() - $this->usage('audit'));
    }

    public function can($feature) {
        $feature = sanitize_key($feature);

        // Free features. They must keep the plugin useful after installation.
        $free_features = array(
            'view_reports',
            'view_history',
            'openrouter_settings',
            'diagnostics',
            'meta_description_fallback',
            'posts_column',
        );
        if (in_array($feature, $free_features, true)) { return true; }

        if ($feature === 'audit') {
            if ($this->is_active()) { return true; }
            return $this->usage('audit') < $this->free_audit_limit();
        }

        // Everything below is commercial value: rewrite, apply, bulk, front report, export.
        if (!$this->is_active()) { return false; }

        return $this->client->feature_allowed($feature);
    }

    public function require_feature($feature, $context = '') {
        if ($this->can($feature)) { return true; }
        $feature = sanitize_key($feature);
        if ($feature === 'audit') {
            return new WP_Error('aiseogeo_free_audit_limit', sprintf('Бесплатный лимит анализов исчерпан: %d из %d. Введите лицензионный ключ, чтобы продолжить анализ и открыть коммерческие функции.', $this->usage('audit'), $this->free_audit_limit()));
        }
        return new WP_Error('aiseogeo_license_required', $this->feature_message($feature));
    }

    public function feature_message($feature) {
        $labels = $this->feature_labels();
        $label = isset($labels[$feature]) ? $labels[$feature] : 'эта функция';
        return sprintf('%s доступна в платной версии. Бесплатный режим показывает ценность через анализ и отчёты, а лицензия открывает переписывание, черновики, применение, откат, массовую обработку и фронтенд-отчёт.', $label);
    }

    public function feature_labels() {
        return array(
            'audit' => 'AI-анализ сверх бесплатного лимита',
            'rewrite_plan' => 'План улучшения статьи',
            'rewrite' => 'AI-переписывание статьи',
            'draft_create' => 'Создание черновика улучшенной версии',
            're_audit' => 'Повторный анализ AI-версии',
            'apply' => 'Применение изменений к оригинальной записи',
            'rollback' => 'Откат изменений из backup',
            'bulk_process' => 'Массовая обработка',
            'site_report_shortcode' => 'Фронтенд-шорткод отчёта по сайту',
            'export' => 'Экспорт отчётов',
        );
    }

    public function track($event, $count = 1) {
        $event = sanitize_key($event);
        $count = max(1, absint($count));
        $key = 'usage_' . $event . '_total';
        $this->settings->set($key, $this->usage($event) + $count);
        $this->settings->set('usage_last_event_at', current_time('mysql'));

        if ($this->logger) {
            $this->logger->log('info', 'license_usage', 'Лицензионное событие: ' . $event . ' ×' . $count);
        }
    }

    public function usage_summary() {
        $events = array('audit','rewrite_plan','rewrite','draft_create','re_audit','apply','rollback','bulk_job','frontend_report');
        $out = array();
        foreach ($events as $event) { $out[$event] = $this->usage($event); }
        return $out;
    }

    public function render_required_box($feature, $title = '') {
        $feature = sanitize_key($feature);
        $title = $title ?: 'Нужна лицензия';
        $message = $this->feature_message($feature);
        $license_url = admin_url('admin.php?page=aiseogeo-license');
        echo '<div class="notice notice-warning aiseogeo-license-required"><p><strong>' . esc_html($title) . '</strong></p><p>' . esc_html($message) . '</p><p><a class="button button-primary" href="' . esc_url($license_url) . '">Ввести лицензионный ключ</a></p></div>';
    }

    public function feature_badge($feature) {
        if ($this->can($feature)) { return '<span class="aiseogeo-license-badge ok">Доступно</span>'; }
        return '<span class="aiseogeo-license-badge locked">Нужна лицензия</span>';
    }
}

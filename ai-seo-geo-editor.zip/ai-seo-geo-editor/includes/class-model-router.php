<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Умный роутер моделей.
 *
 * Каждый тип задачи (step_type) получает оптимальную модель.
 * При ошибке/таймауте автоматически переключается на следующую в цепочке.
 *
 * Типы задач:
 *   research   — анализ аудитории/слабых мест (нужен веб-поиск)
 *   semantics  — подбор семантики/источников (веб-поиск)
 *   structure  — JSON-план статьи (точность JSON)
 *   write      — написание полного текста (макс. контекст + скорость)
 *   finalize   — редактура + JSON (точность + объём)
 *   meta       — только мета-данные (быстро)
 *   humanize   — анти-AI цикл (точность инструкций)
 *   repair     — починка JSON (надёжность)
 *   audit      — анализ статьи (умеренный объём)
 */
class AISEOGEO_Model_Router {

    private $settings;
    private $logger;

    // Приоритетные модели по типу задачи (в порядке предпочтения).
    // Первая модель — оптимальная; остальные — резервные при ошибке.
    private static $TASK_CHAINS = array(
        'research' => array(
            'google/gemini-flash-1.5',       // быстрый, поддерживает grounding
            'google/gemini-2.0-flash-001',
            'openai/gpt-4o-mini',
            'deepseek/deepseek-chat',
            'meta-llama/llama-3.3-70b-instruct',
        ),
        'semantics' => array(
            'google/gemini-flash-1.5',
            'openai/gpt-4o-mini',
            'deepseek/deepseek-chat',
            'meta-llama/llama-3.3-70b-instruct',
        ),
        'structure' => array(
            'openai/gpt-4o-mini',            // отлично держит JSON-структуру
            'google/gemini-flash-1.5',
            'anthropic/claude-haiku-3-5',
            'deepseek/deepseek-chat',
        ),
        'write' => array(
            'google/gemini-flash-1.5',       // 1M контекст, быстро, дёшево
            'openai/gpt-4o-mini',
            'deepseek/deepseek-chat',
            'anthropic/claude-haiku-3-5',
            'meta-llama/llama-3.3-70b-instruct',
        ),
        'finalize' => array(
            'openai/gpt-4o-mini',
            'google/gemini-flash-1.5',
            'anthropic/claude-haiku-3-5',
            'deepseek/deepseek-chat',
        ),
        'meta' => array(
            'google/gemini-flash-1.5-8b',    // минимум токенов, очень дёшево
            'openai/gpt-4o-mini',
            'google/gemini-flash-1.5',
            'meta-llama/llama-3.1-8b-instruct',
        ),
        'humanize' => array(
            'anthropic/claude-haiku-3-5',    // точное следование правилам
            'openai/gpt-4o-mini',
            'google/gemini-flash-1.5',
            'deepseek/deepseek-chat',
        ),
        'repair' => array(
            'openai/gpt-4o-mini',            // лучший JSON-парсер
            'anthropic/claude-haiku-3-5',
            'google/gemini-flash-1.5',
        ),
        'audit' => array(
            'openai/gpt-4o-mini',
            'google/gemini-flash-1.5',
            'deepseek/deepseek-chat',
        ),
    );

    // Общая резервная цепочка — используется если task_type неизвестен или все специфичные упали
    private static $FALLBACK_CHAIN = array(
        'google/gemini-flash-1.5',
        'openai/gpt-4o-mini',
        'deepseek/deepseek-chat',
        'anthropic/claude-haiku-3-5',
        'meta-llama/llama-3.3-70b-instruct',
        'meta-llama/llama-3.1-8b-instruct',
    );

    public function __construct($settings, $logger) {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    /**
     * Возвращает цепочку моделей для задачи.
     * Если у пользователя настроена конкретная модель — она идёт ПЕРВОЙ,
     * потом оптимальные для задачи, потом общий fallback.
     */
    public function get_chain($task_type) {
        $user_model    = trim((string)$this->settings->get('model', ''));
        $user_fallback = trim((string)$this->settings->get('fallback_model', ''));
        $task_chain    = self::$TASK_CHAINS[$task_type] ?? self::$FALLBACK_CHAIN;

        // Строим цепочку: пользовательская → оптимальные для задачи → общий fallback
        $chain = array();
        if ($user_model !== '') { $chain[] = $user_model; }
        foreach ($task_chain as $m) { $chain[] = $m; }
        if ($user_fallback !== '' && $user_fallback !== $user_model) { $chain[] = $user_fallback; }
        foreach (self::$FALLBACK_CHAIN as $m) { $chain[] = $m; }

        // Дедупликация с сохранением порядка
        $seen   = array();
        $result = array();
        foreach ($chain as $m) {
            if (!isset($seen[$m])) { $seen[$m] = true; $result[] = $m; }
        }
        return $result;
    }

    /**
     * Выполняет $fn($model) перебирая модели из цепочки задачи.
     * $fn должна возвращать WP_Error при неудаче (таймаут / HTTP-ошибка / пустой ответ)
     * или успешный результат любого типа.
     *
     * Пропускает модель только при:
     *   - cURL error 28 (timeout)
     *   - cURL error 6/7 (connect failed)
     *   - HTTP 429 (rate limit)
     *   - HTTP 5xx (server error)
     *   - HTTP 404 (модель не найдена)
     *
     * НЕ пропускает при HTTP 400/401/403 (ошибка запроса/ключа — нет смысла менять модель).
     */
    public function call($task_type, callable $fn, $post_id = null) {
        $chain         = $this->get_chain($task_type);
        $max_per_model = max(1, (int)$this->settings->get('max_retry', '1')) + 1;

        foreach ($chain as $idx => $model) {
            for ($attempt = 1; $attempt <= $max_per_model; $attempt++) {
                $result = $fn($model);

                if (!is_wp_error($result)) {
                    if ($idx > 0 || $attempt > 1) {
                        $this->logger->log('info', 'model_router',
                            "Успех с моделью «{$model}» (задача: {$task_type}, попытка {$attempt}, позиция в цепочке: " . ($idx + 1) . ').',
                            array('task' => $task_type, 'model' => $model, 'attempt' => $attempt),
                            $post_id
                        );
                    }
                    return $result;
                }

                $err_msg  = $result->get_error_message();
                $err_code = $result->get_error_code();

                // Определяем тип ошибки
                $is_timeout     = strpos($err_msg, 'cURL error 28') !== false || strpos($err_msg, 'timed out') !== false;
                $is_connect_err = preg_match('/cURL error (6|7)\b/', $err_msg);
                $is_not_found   = strpos($err_msg, 'HTTP 404') !== false;
                $is_rate_limit  = strpos($err_msg, 'HTTP 429') !== false;
                $is_server_err  = preg_match('/HTTP 5\d\d/', $err_msg);
                $is_auth_err    = strpos($err_msg, 'HTTP 401') !== false || strpos($err_msg, 'HTTP 403') !== false;
                $is_bad_request = strpos($err_msg, 'HTTP 400') !== false;

                $this->logger->log('warn', 'model_router',
                    "Модель «{$model}» (задача: {$task_type}) — попытка {$attempt}/{$max_per_model}: {$err_msg}",
                    array('task' => $task_type, 'model' => $model, 'attempt' => $attempt, 'chain_pos' => $idx + 1),
                    $post_id
                );

                // При ошибке авторизации нет смысла пробовать другие модели
                if ($is_auth_err) {
                    return $result;
                }

                // При 400 Bad Request — повторять с той же моделью бессмысленно, переходим к следующей
                $should_switch_model = $is_timeout || $is_connect_err || $is_not_found || $is_rate_limit || $is_server_err || $is_bad_request;

                if ($should_switch_model) {
                    // Пауза перед следующей моделью только при rate limit
                    if ($is_rate_limit) { sleep(3); }
                    break; // выходим из внутреннего цикла → следующая модель
                }

                // Другая ошибка — ещё попытка с той же моделью
                if ($attempt < $max_per_model) {
                    $delay = max(2, (int)$this->settings->get('retry_delay', '2'));
                    sleep($delay);
                }
            }

            $this->logger->log('warn', 'model_router',
                "Переключаюсь на следующую модель в цепочке (задача: {$task_type}). Провалилась: «{$model}».",
                array('task' => $task_type, 'failed_model' => $model, 'next_pos' => $idx + 2),
                $post_id
            );
        }

        return new WP_Error(
            'all_models_failed',
            "Все модели в цепочке не ответили (задача: {$task_type}). Последняя: «" . end($chain) . '».'
        );
    }

    /**
     * Возвращает лучшую одиночную модель для задачи (без автоперебора).
     * Использовать когда нужен только model ID, а не вызов.
     */
    public function best_model($task_type) {
        $chain = $this->get_chain($task_type);
        return $chain[0] ?? 'google/gemini-flash-1.5';
    }
}

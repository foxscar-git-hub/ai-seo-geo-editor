<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Умный роутер моделей.
 *
 * Каждый тип задачи (step_type) получает оптимальную модель.
 * При ошибке/таймауте автоматически переключается на следующую в цепочке.
 *
 * Типы задач:
 *   research   — анализ аудитории/слабых мест (нужен веб-поиск)
 *   semantics  — подбор семантики/источников (веб-поиск)
 *   structure  — JSON-план статьи (точность JSON)
 *   write      — написание полного текста (макс. контекст + скорость)
 *   finalize   — редактура + JSON (точность + объём)
 *   meta       — только мета-данные (быстро)
 *   humanize   — анти-AI цикл (точность инструкций)
 *   repair     — починка JSON (надёжность)
 *   audit      — анализ статьи (умеренный объём)
 */
class AISEOGEO_Model_Router {

    private $settings;
    private $logger;

    // Приоритетные модели по типу задачи (в порядке предпочтения).
    // Первая модель — оптимальная; остальные — резервные при ошибке.
    // Список сверен напрямую с https://openrouter.ai/api/v1/models (2026-07-01).
    // OpenRouter регулярно снимает старые ID с провижининга (HTTP 404 "No endpoints found") —
    // если модели снова начнут падать по 404, свериться с этим эндпоинтом заново.
    private static $TASK_CHAINS = array(
        'research' => array(
            'google/gemini-3.1-flash-lite',
            'openai/gpt-4o-mini',
            'deepseek/deepseek-chat',
            'meta-llama/llama-3.3-70b-instruct',
        ),
        'semantics' => array(
            'google/gemini-3.1-flash-lite',
            'openai/gpt-4o-mini',
            'deepseek/deepseek-chat',
            'meta-llama/llama-3.3-70b-instruct',
        ),
        'structure' => array(
            'openai/gpt-4o-mini',            // отлично держит JSON-структуру
            'google/gemini-3.1-flash-lite',
            'anthropic/claude-haiku-4.5',
            'deepseek/deepseek-chat',
        ),
        // write/finalize: Claude Sonnet 5 теперь ПЕРВАЯ — gpt-4o-mini регулярно возвращал
        // слишком короткий текст (не проходил валидацию объёма, см. логи "AI вернул слишком
        // короткий текст"), т.е. это не только вопрос скорости, но и реального качества/
        // полноты вывода. Раньше Sonnet ставили второй из-за риска зависаний — но с тех пор
        // (1) добавлен принудительный cURL-таймаут в обход хостинга, (2) сокращены раздутые
        // лимиты токенов на "план"/"finalize" (меньше шанс обрыва соединения), (3) есть
        // watchdog, который сам перезапускает зависшие процессы. gpt-4o-mini оставлен вторым
        // как быстрый резерв на случай сбоя Sonnet 5.
        'write' => array(
            'anthropic/claude-sonnet-5',     // лучшее качество и полнота текста
            'openai/gpt-4o-mini',            // быстрый резерв
            'google/gemini-3.5-flash',        // 1M контекст, лучше держит объём чем lite
            'deepseek/deepseek-chat',
            'anthropic/claude-haiku-4.5',
            'meta-llama/llama-3.3-70b-instruct',
        ),
        'finalize' => array(
            'anthropic/claude-sonnet-5',     // качественная финальная редактура
            'openai/gpt-4o-mini',            // быстрый резерв
            'google/gemini-3.5-flash',
            'anthropic/claude-haiku-4.5',
            'deepseek/deepseek-chat',
        ),
        'meta' => array(
            'openai/gpt-4o-mini',
            'google/gemini-3.1-flash-lite',
            'meta-llama/llama-3.1-8b-instruct',
        ),
        'humanize' => array(
            'anthropic/claude-haiku-4.5',
            'openai/gpt-4o-mini',
            'google/gemini-3.1-flash-lite',
            'deepseek/deepseek-chat',
        ),
        'repair' => array(
            'openai/gpt-4o-mini',
            'anthropic/claude-haiku-4.5',
            'google/gemini-3.1-flash-lite',
        ),
        'audit' => array(
            'openai/gpt-4o-mini',
            'google/gemini-3.1-flash-lite',
            'deepseek/deepseek-chat',
        ),
    );

    // Модели которые возвращают 404 / больше не провижинятся на OpenRouter — пропускаем немедленно.
    // gemini-2.0-flash-001 и claude-haiku-3-5 были верны ранее, но OpenRouter их сняли с провижининга.
    private static $DEAD_MODELS = array(
        'google/gemini-flash-1.5',
        'google/gemini-flash-1.5-8b',
        'google/gemini-2.0-flash-001',
        'google/gemini-2.0-flash-lite-001',
        'anthropic/claude-haiku-3-5',
        'deepseek/deepseek-v4-flash',
        'deepseek/deepseek-v4-pro',
    );

    // Общая резервная цепочка
    private static $FALLBACK_CHAIN = array(
        'openai/gpt-4o-mini',
        'google/gemini-3.1-flash-lite',
        'deepseek/deepseek-chat',
        'anthropic/claude-haiku-4.5',
        'meta-llama/llama-3.3-70b-instruct',
        'meta-llama/llama-3.1-8b-instruct',
    );

    // Задачи для которых НЕ используем пользовательскую модель первой.
    // Раньше только write/finalize — но на практике мощные "думающие" модели
    // (напр. claude-sonnet-4) регулярно зависали на 10+ минут на ЛЮБОМ шаге
    // (research/semantics/structure/audit), т.к. модель тратит много времени
    // на рассуждения перед ответом. Для полностью автоматического конвейера
    // приоритет — скорость и надёжность, поэтому пользовательская модель
    // теперь не идёт первой нигде, а добавляется в конец цепочки как опция.
    private static $SKIP_USER_MODEL = array('research', 'semantics', 'structure', 'write', 'finalize', 'audit', 'meta', 'humanize', 'repair');

    public function __construct($settings, $logger) {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    /**
     * Возвращает цепочку моделей для задачи.
     * Если у пользователя настроена конкретная модель — она идёт ПЕРВОЙ,
     * потом оптимальные для задачи, потом общий fallback.
     */
    public function get_chain($task_type) {
        $user_model    = trim((string)$this->settings->get('model', ''));
        $user_fallback = trim((string)$this->settings->get('fallback_model', ''));
        $task_chain    = self::$TASK_CHAINS[$task_type] ?? self::$FALLBACK_CHAIN;
        $dead          = array_flip(self::$DEAD_MODELS);
        $skip_user     = in_array($task_type, self::$SKIP_USER_MODEL, true);

        $chain = array();
        // Пользовательская модель идёт первой только для быстрых задач
        if (!$skip_user && $user_model !== '' && !isset($dead[$user_model])) {
            $chain[] = $user_model;
        }
        foreach ($task_chain as $m) {
            if (!isset($dead[$m])) { $chain[] = $m; }
        }
        // Пользовательская модель добавляется после специализированных для write/finalize
        if ($skip_user && $user_model !== '' && !isset($dead[$user_model])) {
            $chain[] = $user_model;
        }
        if ($user_fallback !== '' && $user_fallback !== $user_model && !isset($dead[$user_fallback])) {
            $chain[] = $user_fallback;
        }
        foreach (self::$FALLBACK_CHAIN as $m) {
            if (!isset($dead[$m])) { $chain[] = $m; }
        }

        // Дедупликация с сохранением порядка
        $seen = array(); $result = array();
        foreach ($chain as $m) {
            if (!isset($seen[$m])) { $seen[$m] = true; $result[] = $m; }
        }
        return $result;
    }

    /**
     * Выполняет $fn($model) перебирая модели из цепочки задачи.
     * $fn должна возвращать WP_Error при неудаче (таймаут / HTTP-ошибка / пустой ответ)
     * или успешный результат любого типа.
     *
     * Пропускает модель только при:
     *   - cURL error 28 (timeout)
     *   - cURL error 6/7 (connect failed)
     *   - HTTP 429 (rate limit)
     *   - HTTP 5xx (server error)
     *   - HTTP 404 (модель не найдена)
     *   - HTTP 402 (недостаточно кредитов на балансе именно для этой модели)
     *
     * НЕ пропускает при HTTP 401/403 (ошибка ключа — нет смысла менять модель).
     */
    public function call($task_type, callable $fn, $post_id = null, $rewrite_id = null) {
        $chain         = $this->get_chain($task_type);
        $max_per_model = max(1, (int)$this->settings->get('max_retry', '1')) + 1;
        $any_credit_issue = false;

        foreach ($chain as $idx => $model) {
            for ($attempt = 1; $attempt <= $max_per_model; $attempt++) {
                // Лог СРАЗУ перед запросом — чтобы во время долгого ожидания ответа AI
                // в Диагностике было видно, какая модель сейчас пробуется, а не тишина.
                $this->logger->log('info', 'model_router',
                    "⏳ Пробую модель «{$model}» (задача: {$task_type}, попытка {$attempt}/{$max_per_model}, позиция в цепочке: " . ($idx + 1) . '/' . count($chain) . ')...',
                    array('rewrite_id' => $rewrite_id, 'task' => $task_type, 'model' => $model, 'attempt' => $attempt, 'chain_pos' => $idx + 1, 'chain_total' => count($chain)),
                    $post_id
                );

                $result = $fn($model);

                if (!is_wp_error($result)) {
                    $this->logger->log('info', 'model_router',
                        "✓ Ответ получен от «{$model}» (задача: {$task_type}, попытка {$attempt}, позиция в цепочке: " . ($idx + 1) . ').',
                        array('rewrite_id' => $rewrite_id, 'task' => $task_type, 'model' => $model, 'attempt' => $attempt),
                        $post_id
                    );
                    return $result;
                }

                $err_msg  = $result->get_error_message();
                $err_code = $result->get_error_code();

                // Определяем тип ошибки
                $is_timeout       = strpos($err_msg, 'cURL error 28') !== false || strpos($err_msg, 'timed out') !== false;
                $is_connect_err   = preg_match('/cURL error (6|7)\b/', $err_msg);
                $is_not_found     = strpos($err_msg, 'HTTP 404') !== false;
                $is_rate_limit    = strpos($err_msg, 'HTTP 429') !== false;
                $is_server_err    = preg_match('/HTTP 5\d\d/', $err_msg);
                $is_auth_err      = strpos($err_msg, 'HTTP 401') !== false || strpos($err_msg, 'HTTP 403') !== false;
                $is_bad_request   = strpos($err_msg, 'HTTP 400') !== false;
                // 402 = недостаточно кредитов на балансе OpenRouter именно для ЭТОЙ (обычно
                // более дорогой) модели. Повторять с той же моделью бессмысленно — сразу
                // переходим к более дешёвой в цепочке.
                $is_insufficient_credits = strpos($err_msg, 'HTTP 402') !== false;

                if ($is_insufficient_credits) {
                    $any_credit_issue = true;
                    $this->logger->log('warn', 'model_router',
                        "💳 Недостаточно кредитов OpenRouter для модели «{$model}» — перехожу на более дешёвую. Пополнить баланс: https://openrouter.ai/settings/credits",
                        array('rewrite_id' => $rewrite_id, 'task' => $task_type, 'model' => $model, 'chain_pos' => $idx + 1),
                        $post_id
                    );
                } else {
                    $this->logger->log('warn', 'model_router',
                        "✗ Модель «{$model}» (задача: {$task_type}) — попытка {$attempt}/{$max_per_model}: {$err_msg}",
                        array('rewrite_id' => $rewrite_id, 'task' => $task_type, 'model' => $model, 'attempt' => $attempt, 'chain_pos' => $idx + 1),
                        $post_id
                    );
                }

                // При ошибке авторизации нет смысла пробовать другие модели
                if ($is_auth_err) {
                    return $result;
                }

                // При 400/402 — повторять с той же моделью бессмысленно, переходим к следующей
                $should_switch_model = $is_timeout || $is_connect_err || $is_not_found || $is_rate_limit || $is_server_err || $is_bad_request || $is_insufficient_credits;

                if ($should_switch_model) {
                    // Пауза перед следующей моделью только при rate limit
                    if ($is_rate_limit) { sleep(3); }
                    break; // выходим из внутреннего цикла → следующая модель
                }

                // Другая ошибка — ещё попытка с той же моделью
                if ($attempt < $max_per_model) {
                    $delay = max(2, (int)$this->settings->get('retry_delay', '2'));
                    sleep($delay);
                }
            }

            $this->logger->log('warn', 'model_router',
                "→ Переключаюсь на следующую модель в цепочке (задача: {$task_type}). Провалилась: «{$model}».",
                array('rewrite_id' => $rewrite_id, 'task' => $task_type, 'failed_model' => $model, 'next_pos' => $idx + 2),
                $post_id
            );
        }

        $credit_hint = $any_credit_issue
            ? ' Похоже, закончились кредиты OpenRouter — пополните баланс: https://openrouter.ai/settings/credits'
            : '';
        $this->logger->log('error', 'model_router',
            "✗ Все модели в цепочке не ответили (задача: {$task_type})." . $credit_hint,
            array('rewrite_id' => $rewrite_id, 'task' => $task_type, 'chain' => $chain, 'credit_issue' => $any_credit_issue),
            $post_id
        );
        return new WP_Error(
            'all_models_failed',
            "Все модели в цепочке не ответили (задача: {$task_type}). Последняя: «" . end($chain) . '».' . $credit_hint
        );
    }

    /**
     * Возвращает лучшую одиночную модель для задачи (без автоперебора).
     * Использовать когда нужен только model ID, а не вызов.
     */
    public function best_model($task_type) {
        $chain = $this->get_chain($task_type);
        return $chain[0] ?? 'openai/gpt-4o-mini';
    }
}

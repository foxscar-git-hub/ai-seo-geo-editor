<?php if (!defined('ABSPATH')) { exit; } $all=$settings->all();
$model_list = array(
    'google/gemini-2.5-flash' => 'Gemini 2.5 Flash',
    'google/gemini-2.5-pro' => 'Gemini 2.5 Pro',
    'google/gemini-3.1-flash-lite' => 'Gemini 3.1 Flash Lite',
    'deepseek/deepseek-r1' => 'DeepSeek R1',
    'deepseek/deepseek-chat-v3' => 'DeepSeek V3 (Chat)',
    'deepseek/deepseek-v4-flash' => 'DeepSeek V4 Flash',
    'deepseek/deepseek-v4-pro' => 'DeepSeek V4 Pro',
    'anthropic/claude-sonnet-4' => 'Claude Sonnet 4',
    'anthropic/claude-3.5-sonnet' => 'Claude 3.5 Sonnet',
    'anthropic/claude-3-haiku' => 'Claude 3 Haiku',
    'openai/gpt-4o' => 'GPT-4o',
    'openai/gpt-4.1' => 'GPT-4.1',
);
?>
<div class="wrap aiseogeo-wrap"><h1>OpenRouter</h1>
<?php if(!empty($_GET['saved'])): ?><div class="notice notice-success"><p>Настройки сохранены.</p></div><?php endif; ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="aiseogeo-card">
<input type="hidden" name="action" value="aiseogeo_save_settings"><?php wp_nonce_field('aiseogeo_save_settings'); ?>
<table class="form-table"><tbody>
<tr><th>API-ключ</th><td><input type="password" class="regular-text" name="api_key" value="<?php echo esc_attr($settings->get('api_key','')); ?>"></td></tr>
<tr><th>Base URL</th><td><input type="text" class="regular-text" name="base_url" value="<?php echo esc_attr($settings->get('base_url','https://openrouter.ai/api/v1')); ?>"></td></tr>
<tr><th>Основная модель</th><td>
<select name="model">
<?php $current_model = $settings->get('model','google/gemini-2.5-flash'); foreach ($model_list as $k=>$v): ?>
<option value="<?php echo esc_attr($k); ?>" <?php selected($current_model, $k); ?>><?php echo esc_html($v); ?></option>
<?php endforeach; ?>
</select>
<p class="description">Модель для анализа и переписывания статей.</p></td></tr>
<tr><th>Резервная модель</th><td>
<select name="fallback_model">
<option value="" <?php selected($settings->get('fallback_model',''), ''); ?>>— Не использовать —</option>
<?php $current_fb = $settings->get('fallback_model','deepseek/deepseek-v4'); foreach ($model_list as $k=>$v): ?>
<option value="<?php echo esc_attr($k); ?>" <?php selected($current_fb, $k); ?>><?php echo esc_html($v); ?></option>
<?php endforeach; ?>
</select>
<p class="description">Если основная модель вернёт ошибку, запрос автоматически повторится на резервной модели.</p></td></tr>
<tr><th>Timeout</th><td><input type="number" name="timeout" value="<?php echo esc_attr($settings->get('timeout','60')); ?>"></td></tr>
<tr><th>Max retry</th><td><input type="number" name="max_retry" value="<?php echo esc_attr($settings->get('max_retry','1')); ?>"></td></tr>
<tr><th>Задержка между повторами</th><td><input type="number" name="retry_delay" value="<?php echo esc_attr($settings->get('retry_delay','2')); ?>"></td></tr>
<tr><th>Temperature</th><td><input type="text" name="temperature" value="<?php echo esc_attr($settings->get('temperature','0.2')); ?>"></td></tr>
<tr><th>Max tokens</th><td><input type="number" name="max_tokens" value="<?php echo esc_attr($settings->get('max_tokens','6000')); ?>"></td></tr>
<tr><th>Логирование запросов</th><td><label><input type="checkbox" name="log_requests" value="1" <?php checked($settings->get('log_requests','1'),'1'); ?>> Включено</label></td></tr>
<tr><th>Веб-поиск (grounding)</th><td>
  <input type="hidden" name="web_search_enabled" value="0">
  <label><input type="checkbox" name="web_search_enabled" value="1" <?php checked($settings->get('web_search_enabled','0'),'1'); ?>> Включить веб-поиск на этапах ресёрча</label>
  <p class="description">Модель ищет реальные источники в интернете (Gemini grounding / OpenRouter web). Если ваш шлюз не поддерживает — выключите, иначе возможны ошибки запросов. Источники в любом случае проверяются живой HTTP-проверкой.</p>
</td></tr>
</tbody></table>

<h2 style="margin-top:2em;">Автооптимизация новых публикаций</h2>
<table class="form-table"><tbody>
<tr><th>Автооптимизация</th><td><label><input type="checkbox" name="auto_optimize_enabled" value="1" <?php checked($settings->get('auto_optimize_enabled','0'),'1'); ?>> Включить</label><p class="description">При публикации новой статьи плагин автоматически: анализирует → переписывает → публикует улучшенную версию, а оригинал переводит в черновик. Требуется активная лицензия.</p></td></tr>
<tr><th>Режим переписывания</th><td>
<select name="auto_optimize_mode">
<?php $modes = array('soft_improve'=>'Мягкое улучшение','seo_boost'=>'SEO-усиление','geo_boost'=>'GEO-усиление','seo_geo_boost'=>'SEO + GEO усиление','full_refresh'=>'Полное обновление'); $current = $settings->get('auto_optimize_mode','soft_improve'); foreach ($modes as $k=>$v): ?>
<option value="<?php echo esc_attr($k); ?>" <?php selected($current, $k); ?>><?php echo esc_html($v); ?></option>
<?php endforeach; ?>
</select></td></tr>
<tr><th>Модель для автооптимизации</th><td>
<select name="auto_optimize_model">
<option value="" <?php selected($settings->get('auto_optimize_model',''), ''); ?>>— Использовать основную модель —</option>
<?php $current_am = $settings->get('auto_optimize_model',''); foreach ($model_list as $k=>$v): ?>
<option value="<?php echo esc_attr($k); ?>" <?php selected($current_am, $k); ?>><?php echo esc_html($v); ?></option>
<?php endforeach; ?>
</select>
<p class="description">Отдельная модель для автообработки. Если не выбрано — используется основная.</p></td></tr>
</tbody></table>

<p><button class="button button-primary">Сохранить настройки</button></p></form>
</div>

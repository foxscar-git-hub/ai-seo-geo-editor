<?php if (!defined('ABSPATH')) { exit; } $all=$settings->all();
// Реальные ID моделей на OpenRouter — сверены напрямую с https://openrouter.ai/api/v1/models
// (дата сверки: 2026-07-01). OpenRouter периодически снимает старые ID с провижининга —
// если модель начнёт падать по HTTP 404 "No endpoints found", свериться с этим эндпоинтом заново.
// Звёздочка = быстрая модель, рекомендуется для автоматического конвейера.
$model_list = array(
    // Google Gemini — быстрые, большой контекст (1M токенов)
    'google/gemini-3.1-flash-lite'     => '⚡ Gemini 3.1 Flash Lite (очень быстро, дёшево)',
    'google/gemini-3.5-flash'          => '⚡ Gemini 3.5 Flash (быстро, лучше качество)',
    'google/gemini-2.5-flash'          => 'Gemini 2.5 Flash',
    'google/gemini-2.5-pro'            => 'Gemini 2.5 Pro',
    // OpenAI
    'openai/gpt-4o-mini'               => '⚡ GPT-4o Mini (быстро, надёжно)',
    'openai/gpt-4o'                    => 'GPT-4o',
    'openai/gpt-4.1-mini'              => '⚡ GPT-4.1 Mini',
    'openai/gpt-4.1'                   => 'GPT-4.1',
    // Anthropic
    'anthropic/claude-haiku-4.5'       => '⚡ Claude Haiku 4.5 (быстро)',
    'anthropic/claude-3-haiku'         => '⚡ Claude 3 Haiku',
    'anthropic/claude-sonnet-4'        => 'Claude Sonnet 4 (медленнее, качественнее)',
    'anthropic/claude-sonnet-4.5'      => 'Claude Sonnet 4.5 (медленнее, качественнее)',
    'anthropic/claude-sonnet-5'        => '🌟 Claude Sonnet 5 (новая, лучшее качество, медленнее)',
    // DeepSeek
    'deepseek/deepseek-chat'           => '⚡ DeepSeek V3 (Chat)',
    'deepseek/deepseek-r1'             => 'DeepSeek R1',
    // Meta
    'meta-llama/llama-3.1-8b-instruct' => '⚡ Llama 3.1 8B (очень быстро)',
    'meta-llama/llama-3.3-70b-instruct'=> 'Llama 3.3 70B',
    // Mistral
    'mistralai/mistral-small-3.2-24b-instruct' => '⚡ Mistral Small 3.2 (быстро)',
    'mistralai/mistral-large'          => 'Mistral Large',
);
?>
<div class="wrap aiseogeo-wrap"><h1>OpenRouter</h1>
<?php if(!empty($_GET['saved'])): ?><div class="notice notice-success"><p>Настройки сохранены.</p></div><?php endif; ?>
<?php
$cur = $settings->get('model','');
// Модели, которые OpenRouter снял с провижининга (HTTP 404) — известно на 2026-07-01.
$bad_models = array(
    'deepseek/deepseek-v4-flash', 'deepseek/deepseek-v4-pro', 'deepseek/deepseek-chat-v3',
    'google/gemini-flash-1.5', 'google/gemini-flash-1.5-8b', 'google/gemini-2.0-flash-001', 'google/gemini-2.0-flash-lite-001',
    'anthropic/claude-haiku-3-5', 'anthropic/claude-3.5-sonnet', 'mistralai/mistral-small',
);
if (in_array($cur, $bad_models, true)):
?><div class="notice notice-error"><p><strong>⚠ Модель «<?php echo esc_html($cur); ?>» не существует на OpenRouter (снята с провижининга)</strong> — именно поэтому запросы падают с ошибкой HTTP 404 или зависают. Выберите другую модель и сохраните. Рекомендуем: <strong>⚡ Gemini 3.1 Flash Lite</strong> или <strong>⚡ GPT-4o Mini</strong> — быстрые и надёжные для автоматического конвейера.</p></div>
<?php endif; ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="aiseogeo-card">
<input type="hidden" name="action" value="aiseogeo_save_settings"><?php wp_nonce_field('aiseogeo_save_settings'); ?>
<table class="form-table"><tbody>
<tr><th>API-ключ</th><td><input type="password" class="regular-text" name="api_key" value="<?php echo esc_attr($settings->get('api_key','')); ?>"></td></tr>
<tr><th>Base URL</th><td><input type="text" class="regular-text" name="base_url" value="<?php echo esc_attr($settings->get('base_url','https://openrouter.ai/api/v1')); ?>"></td></tr>
<tr><th>KIE.ai ключ (резерв)</th><td>
<input type="password" class="regular-text" name="kie_api_key" value="<?php echo esc_attr($settings->get('kie_api_key','')); ?>">
<p class="description">Необязательно. Если указан — при исчерпании кредитов/недоступности OpenRouter плагин автоматически пробует те же задачи через KIE.ai (Claude Sonnet, GPT, Gemini) как последний резерв в цепочке моделей. Взять ключ: <a href="https://kie.ai" target="_blank">kie.ai</a> → личный кабинет → API Keys.</p>
</td></tr>
<tr><th>Основная модель</th><td>
<select name="model">
<?php $current_model = $settings->get('model','google/gemini-2.5-flash'); foreach ($model_list as $k=>$v): ?>
<option value="<?php echo esc_attr($k); ?>" <?php selected($current_model, $k); ?>><?php echo esc_html($v); ?></option>
<?php endforeach; ?>
</select>
<p class="description">Модель для анализа и переписывания статей.</p></td></tr>
<tr><th>Резервная модель</th><td>
<select name="fallback_model">
<option value="" <?php selected($settings->get('fallback_model',''), ''); ?>>— Не использовать —</option>
<?php $current_fb = $settings->get('fallback_model',''); foreach ($model_list as $k=>$v): ?>
<option value="<?php echo esc_attr($k); ?>" <?php selected($current_fb, $k); ?>><?php echo esc_html($v); ?></option>
<?php endforeach; ?>
</select>
<p class="description">Если основная модель вернёт ошибку, запрос автоматически повторится на резервной модели.</p></td></tr>
<tr><th>Timeout (сек, базовый)</th><td>
<input type="number" name="timeout" value="<?php echo esc_attr($settings->get('timeout','90')); ?>" min="30" max="600">
<p class="description">Базовый таймаут запроса к AI. Для длинных статей таймаут увеличивается автоматически (~1 сек на 100 токенов). При 14000 токенов = ~170 сек. Рекомендуется: <strong>90</strong>. Если статьи большие — поставьте 180.</p>
</td></tr>
<tr><th>Max retry</th><td><input type="number" name="max_retry" value="<?php echo esc_attr($settings->get('max_retry','1')); ?>"></td></tr>
<tr><th>Задержка между повторами</th><td><input type="number" name="retry_delay" value="<?php echo esc_attr($settings->get('retry_delay','2')); ?>"></td></tr>
<tr><th>Temperature</th><td><input type="text" name="temperature" value="<?php echo esc_attr($settings->get('temperature','0.2')); ?>"></td></tr>
<tr><th>Max tokens</th><td><input type="number" name="max_tokens" value="<?php echo esc_attr($settings->get('max_tokens','6000')); ?>"></td></tr>
<tr><th>Логирование запросов</th><td><label><input type="checkbox" name="log_requests" value="1" <?php checked($settings->get('log_requests','1'),'1'); ?>> Включено</label></td></tr>
<tr><th>Веб-поиск (grounding)</th><td>
  <input type="hidden" name="web_search_enabled" value="0">
  <label><input type="checkbox" name="web_search_enabled" value="1" <?php checked($settings->get('web_search_enabled','0'),'1'); ?>> Включить веб-поиск на этапах ресёрча</label>
  <p class="description">Модель ищет реальные источники в интернете (Gemini grounding / OpenRouter web). Если ваш шлюз не поддерживает — выключите, иначе возможны ошибки запросов. Источники в любом случае проверяются живой HTTP-проверкой.</p>
</td></tr>
</tbody></table>

<h2 style="margin-top:2em;">Автооптимизация новых публикаций</h2>
<table class="form-table"><tbody>
<tr><th>Автооптимизация</th><td><label><input type="checkbox" name="auto_optimize_enabled" value="1" <?php checked($settings->get('auto_optimize_enabled','0'),'1'); ?>> Включить</label><p class="description">При публикации новой статьи плагин автоматически: анализирует → переписывает → публикует улучшенную версию, а оригинал переводит в черновик. Требуется активная лицензия.</p></td></tr>
<tr><th>Режим переписывания</th><td>
<select name="auto_optimize_mode">
<?php $modes = array('soft_improve'=>'Мягкое улучшение','seo_boost'=>'SEO-усиление','geo_boost'=>'GEO-усиление','seo_geo_boost'=>'SEO + GEO усиление','full_refresh'=>'Полное обновление'); $current = $settings->get('auto_optimize_mode','soft_improve'); foreach ($modes as $k=>$v): ?>
<option value="<?php echo esc_attr($k); ?>" <?php selected($current, $k); ?>><?php echo esc_html($v); ?></option>
<?php endforeach; ?>
</select></td></tr>
<tr><th>Модель для автооптимизации</th><td>
<select name="auto_optimize_model">
<option value="" <?php selected($settings->get('auto_optimize_model',''), ''); ?>>— Использовать основную модель —</option>
<?php $current_am = $settings->get('auto_optimize_model',''); foreach ($model_list as $k=>$v): ?>
<option value="<?php echo esc_attr($k); ?>" <?php selected($current_am, $k); ?>><?php echo esc_html($v); ?></option>
<?php endforeach; ?>
</select>
<p class="description">Отдельная модель для автообработки. Если не выбрано — используется основная.</p></td></tr>
</tbody></table>

<p><button class="button button-primary">Сохранить настройки</button></p></form>
</div>

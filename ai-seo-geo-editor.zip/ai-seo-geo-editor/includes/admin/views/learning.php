<?php if (!defined('ABSPATH')) { exit; }
/** @var AISEOGEO_Settings $settings */
/** @var AISEOGEO_Learning_Service $learning_service */
?>
<div class="wrap aiseogeo-wrap">
  <h1>Автообучение</h1>
  <p>Плагин анализирует результаты опубликованных переписываний и на их основе улучшает будущие рекомендации. Просмотры и вовлечённость замеряются через <?php echo isset($settings) ? (int)$settings->get('learning_min_days', '14') : 14; ?> дней после применения.</p>

  <?php if (!empty($saved_notice)): ?>
    <div class="notice notice-success is-dismissible"><p><?php echo esc_html($saved_notice); ?></p></div>
  <?php endif; ?>
  <?php if (!empty($error_notice)): ?>
    <div class="notice notice-error is-dismissible"><p><?php echo esc_html($error_notice); ?></p></div>
  <?php endif; ?>

  <div class="aiseogeo-grid two">

    <!-- Settings -->
    <div class="aiseogeo-card">
      <h2>Настройки</h2>
      <form method="post" action="">
        <?php wp_nonce_field('aiseogeo_learning_settings'); ?>
        <input type="hidden" name="aiseogeo_learning_action" value="save_settings">

        <table class="form-table">
          <tr>
            <th><label for="learning_enabled">Автообучение</label></th>
            <td>
              <label>
                <input type="checkbox" id="learning_enabled" name="learning_enabled" value="1" <?php checked($settings->get('learning_enabled', '0'), '1'); ?>>
                Включить автообучение
              </label>
              <p class="description">Включает трекинг просмотров и ежедневную оценку результатов переписываний.</p>
            </td>
          </tr>
          <tr>
            <th><label for="learning_min_days">Выдержка перед оценкой, дней</label></th>
            <td>
              <input type="number" id="learning_min_days" name="learning_min_days" value="<?php echo esc_attr($settings->get('learning_min_days', '14')); ?>" min="1" max="180" class="small-text">
              <p class="description">Через сколько дней после применения переписывания замерять результат. Рекомендуется 14-30 дней.</p>
            </td>
          </tr>
          <tr>
            <th><label for="learning_views_threshold">Порог роста просмотров, %</label></th>
            <td>
              <input type="number" id="learning_views_threshold" name="learning_views_threshold" value="<?php echo esc_attr($settings->get('learning_views_threshold', '20')); ?>" min="0" max="500" class="small-text">
              <p class="description">Минимальный рост просмотров (%) чтобы переписывание считалось успешным и его паттерны сохранялись.</p>
            </td>
          </tr>
          <tr>
            <th><label for="learning_min_samples">Мин. выборка для инжекции</label></th>
            <td>
              <input type="number" id="learning_min_samples" name="learning_min_samples" value="<?php echo esc_attr($settings->get('learning_min_samples', '3')); ?>" min="1" max="50" class="small-text">
              <p class="description">Минимальное количество оценённых переписываний с этим паттерном, прежде чем данные попадут в промпт.</p>
            </td>
          </tr>
          <tr>
            <th>Инжекция в промпты</th>
            <td>
              <label>
                <input type="checkbox" name="learning_inject_audit" value="1" <?php checked($settings->get('learning_inject_audit', '1'), '1'); ?>>
                Добавлять данные обучения в промпт аудита
              </label><br>
              <label>
                <input type="checkbox" name="learning_inject_rewrite" value="1" <?php checked($settings->get('learning_inject_rewrite', '1'), '1'); ?>>
                Добавлять данные обучения в промпт переписывания
              </label>
              <p class="description">Накопленные паттерны будут автоматически добавляться в системный промпт, чтобы AI учитывал что работает именно на вашем сайте.</p>
            </td>
          </tr>
        </table>

        <?php submit_button('Сохранить настройки'); ?>
      </form>
    </div>

    <!-- Stats -->
    <div class="aiseogeo-card">
      <h2>Статистика</h2>
      <?php if (!empty($stats)): ?>
        <p><strong>Паттернов изучено:</strong> <?php echo esc_html($stats['patterns']); ?></p>
        <p><strong>Переписываний оценено:</strong> <?php echo esc_html($stats['evaluated']); ?></p>
        <p><strong>Из них успешных:</strong> <?php echo esc_html($stats['successful']); ?></p>
        <p><strong>Ожидают оценки:</strong> <?php echo esc_html($stats['pending']); ?></p>

        <?php if (!empty($stats['top'])): ?>
          <h3>Топ паттернов по эффективности</h3>
          <table class="widefat striped" style="font-size:12px">
            <thead>
              <tr><th>Паттерн</th><th>Выборка</th><th>Средний рост</th><th>Успешных</th></tr>
            </thead>
            <tbody>
              <?php foreach ($stats['top'] as $p): ?>
                <tr>
                  <td><?php echo esc_html($p->pattern_type . ': ' . $p->pattern_value); ?></td>
                  <td><?php echo esc_html($p->total_count); ?></td>
                  <td><?php echo esc_html(($p->avg_views_growth >= 0 ? '+' : '') . round($p->avg_views_growth, 1) . '%'); ?></td>
                  <td><?php echo esc_html(round($p->success_count / max(1, $p->total_count) * 100)); ?>%</td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>

        <br>
        <form method="post" action="" style="display:inline">
          <?php wp_nonce_field('aiseogeo_learning_settings'); ?>
          <input type="hidden" name="aiseogeo_learning_action" value="force_evaluate">
          <button type="submit" class="button">Запустить оценку сейчас</button>
        </form>
        <form method="post" action="" style="display:inline; margin-left:8px">
          <?php wp_nonce_field('aiseogeo_learning_settings'); ?>
          <input type="hidden" name="aiseogeo_learning_action" value="reset_patterns">
          <button type="submit" class="button button-link-delete" onclick="return confirm('Сбросить все накопленные паттерны?')">Сбросить паттерны</button>
        </form>
      <?php else: ?>
        <p>Автообучение ещё не собрало данных. Включите его выше и дождитесь оценки первых переписываний.</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- Insights preview -->
  <?php if (!empty($insights_preview)): ?>
  <div class="aiseogeo-card">
    <h2>Что AI видит в промпте (предпросмотр инжекции)</h2>
    <pre style="white-space:pre-wrap;font-size:12px;background:#f9f9f9;padding:12px;border:1px solid #ddd"><?php echo esc_html($insights_preview); ?></pre>
  </div>
  <?php endif; ?>

  <!-- Full pattern table -->
  <?php if (!empty($patterns)): ?>
  <div class="aiseogeo-card">
    <h2>Все паттерны</h2>
    <table class="widefat striped">
      <thead>
        <tr><th>Тип</th><th>Значение</th><th>Выборка</th><th>Средний рост</th><th>Успешных</th><th>Уверенность</th><th>Обновлено</th></tr>
      </thead>
      <tbody>
        <?php foreach ($patterns as $p): ?>
          <tr>
            <td><?php echo esc_html($p->pattern_type); ?></td>
            <td><?php echo esc_html($p->pattern_value); ?></td>
            <td><?php echo esc_html($p->total_count); ?></td>
            <td><?php echo esc_html(($p->avg_views_growth >= 0 ? '+' : '') . round($p->avg_views_growth, 1) . '%'); ?></td>
            <td><?php echo esc_html(round($p->success_count / max(1, $p->total_count) * 100)); ?>%</td>
            <td><?php echo esc_html(round($p->confidence, 3)); ?></td>
            <td><?php echo esc_html(mysql2date('d.m.Y', $p->updated_at)); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

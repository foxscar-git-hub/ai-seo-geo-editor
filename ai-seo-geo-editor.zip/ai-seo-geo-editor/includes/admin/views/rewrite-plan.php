<?php if (!defined('ABSPATH')) { exit; }
if (!function_exists('aiseogeo_stage2_list')) { function aiseogeo_stage2_list($items){ if(empty($items)){echo '—'; return;} if(!is_array($items)){$items=array($items);} echo '<ul class="aiseogeo-list">'; foreach($items as $item){ $txt=is_array($item)?wp_json_encode($item,JSON_UNESCAPED_UNICODE):(string)$item; echo '<li>'.esc_html($txt).'</li>'; } echo '</ul>'; } } $plan=$rewrite ? (json_decode($rewrite->improvement_plan_json,true) ?: array()) : array(); ?>
<div class="wrap aiseogeo-wrap">
  <h1>План улучшения</h1>
  <?php if (!$rewrite): ?><div class="notice notice-error"><p>План не найден.</p></div><?php return; endif; ?>
  <?php if (!empty($_GET['aiseogeo_error'])): ?><div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div><?php endif; ?>
  <div class="aiseogeo-card">
    <h2><?php echo esc_html($rewrite->original_title); ?></h2>
    <p><strong>Режим:</strong> <?php echo esc_html($rewrite->rewrite_mode); ?> · <strong>Статус:</strong> <?php echo esc_html($rewrite->rewrite_status); ?></p>
    <p><?php echo esc_html($plan['strategy_summary'] ?? ''); ?></p>
  </div>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card"><h2>Что сохранить</h2><?php aiseogeo_stage2_list($plan['what_to_keep'] ?? array()); ?><h3>Что не трогать</h3><?php aiseogeo_stage2_list($plan['what_not_to_touch'] ?? array()); ?></div>
    <div class="aiseogeo-card"><h2>Что улучшить</h2><?php aiseogeo_stage2_list($plan['what_to_improve'] ?? array()); ?><h3>Что добавить</h3><?php aiseogeo_stage2_list($plan['what_to_add'] ?? array()); ?></div>
  </div>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card"><h2>Заголовки и GEO-блоки</h2><h3>Изменения заголовков</h3><?php aiseogeo_stage2_list($plan['heading_changes'] ?? array()); ?><h3>GEO-блоки</h3><?php aiseogeo_stage2_list($plan['geo_blocks_to_add'] ?? array()); ?></div>
    <div class="aiseogeo-card"><h2>Риски</h2><?php aiseogeo_stage2_list($plan['risks'] ?? array()); ?><h3>Ожидаемое улучшение</h3><pre><?php echo esc_html(wp_json_encode($plan['expected_improvement'] ?? array(), JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); ?></pre></div>
  </div>
  <div class="aiseogeo-card">
    <h2>Создать улучшенную версию </h2>
  </div>
</div>

<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap">
  <h1>Откат изменений</h1>
  <?php if (!empty($_GET['rolled_back'])): ?><div class="notice notice-success"><p>Запись восстановлена из резервной копии.</p></div><?php endif; ?>
  <?php if (!empty($_GET['aiseogeo_error'])): ?><div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div><?php endif; ?>
  <?php if ($backup): ?>
    <div class="aiseogeo-card">
      <h2>Резервная копия #<?php echo absint($backup->id); ?></h2>
      <p><strong>Запись:</strong> <?php echo esc_html(get_the_title($backup->post_id)); ?> · <strong>Дата:</strong> <?php echo esc_html($backup->created_at); ?></p>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="aiseogeo_rollback_backup">
        <input type="hidden" name="backup_id" value="<?php echo absint($backup->id); ?>">
        <?php wp_nonce_field('aiseogeo_rollback_backup_' . $backup->id); ?>
        <h3>Что восстановить</h3>
        <label><input type="checkbox" name="fields[]" value="title" checked> Заголовок</label><br>
        <label><input type="checkbox" name="fields[]" value="content" checked> Основной текст</label><br>
        <label><input type="checkbox" name="fields[]" value="excerpt" checked> Краткое описание</label><br>
        <label><input type="checkbox" name="fields[]" value="meta" checked> Meta-поля</label>
        <p><button class="button button-primary">Восстановить выбранные поля</button></p>
      </form>
    </div>
  <?php endif; ?>
  <div class="aiseogeo-card">
    <h2>Доступные резервные копии</h2>
    <table class="widefat striped"><thead><tr><th>ID</th><th>Запись</th><th>Rewrite</th><th>Тип</th><th>Дата</th><th></th></tr></thead><tbody>
    <?php foreach ((array)$backups as $b): ?><tr><td><?php echo absint($b->id); ?></td><td><?php echo esc_html(get_the_title($b->post_id)); ?></td><td><?php echo absint($b->rewrite_id); ?></td><td><?php echo esc_html($b->backup_type); ?></td><td><?php echo esc_html($b->created_at); ?></td><td><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rollback&backup_id=' . absint($b->id))); ?>">Открыть</a></td></tr><?php endforeach; ?>
    <?php if (empty($backups)): ?><tr><td colspan="6">Резервных копий пока нет.</td></tr><?php endif; ?>
    </tbody></table>
  </div>
</div>

<?php if (!defined('ABSPATH')) { exit; }
if (!function_exists('aiseogeo_rewrite_mode_description')) { function aiseogeo_rewrite_mode_description($key){ $d=array('soft_improve'=>'Сохраняет структуру и мягко улучшает слабые места.','seo_boost'=>'Усиливает SEO, заголовки, интент и мета-данные.','geo_boost'=>'Готовит статью к AI-поиску: краткие ответы, FAQ, цитируемость.','full_refresh'=>'Глубоко обновляет слабую или устаревшую статью.','meta_only'=>'Меняет только title, description, excerpt, FAQ и schema-рекомендации.','problem_blocks_only'=>'Переписывает только проблемные блоки из отчёта.'); return $d[$key] ?? ''; }} $problems=$audit ? (json_decode($audit->problems_json,true) ?: array()) : array(); $suggested=$audit ? (json_decode($audit->suggested_json,true) ?: array()) : array(); ?>
<div class="wrap aiseogeo-wrap">
  <h1>Создание улучшенной версии</h1>
  <?php if (!empty($_GET['aiseogeo_error'])): ?><div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div><?php endif; ?>
  <?php if (!$post || !$audit || $audit->status !== 'done'): ?>
    <div class="notice notice-error"><p>Для переписывания сначала нужен успешный AI-анализ статьи.</p></div>
    <?php if ($post): ?><p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post->ID))); ?>">Перейти к анализу</a></p><?php endif; ?>
    <?php return; ?>
  <?php endif; ?>
  <div class="aiseogeo-card">
    <h2><?php echo esc_html(get_the_title($post)); ?></h2>
    <p><strong>Статус:</strong> <?php echo esc_html($post->post_status); ?> · <strong>Последний анализ:</strong> <?php echo esc_html(mysql2date('d.m.Y H:i',$audit->created_at)); ?></p>
    <p><strong>Оценки:</strong> Общая <?php echo esc_html($audit->overall_score); ?>/100 · SEO <?php echo esc_html($audit->seo_score); ?> · GEO <?php echo esc_html($audit->geo_score); ?> · EEAT <?php echo esc_html($audit->eeat_score); ?></p>
    <p><?php echo esc_html($audit->summary); ?></p>
  </div>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card"><h2>Основные проблемы</h2><?php if(function_exists('aiseogeo_list')){aiseogeo_list($problems['main_problems'] ?? array());} else { echo '<pre>'.esc_html(wp_json_encode($problems,JSON_UNESCAPED_UNICODE)).'</pre>'; } ?></div>
    <div class="aiseogeo-card"><h2>Рекомендуемая стратегия</h2><p><?php echo esc_html($suggested['rewrite_strategy'] ?? 'Выберите режим вручную.'); ?></p></div>
  </div>
  <div class="aiseogeo-card">
    <h2>Выберите режим переписывания</h2>
    <?php
    $mode_icons = array(
        'soft_improve'       => '✨',
        'seo_boost'          => '🔍',
        'geo_boost'          => '🌐',
        'seo_geo_boost'      => '🚀',
        'full_refresh'       => '🔄',
        'meta_only'          => '🏷️',
        'problem_blocks_only'=> '🛠️',
    );
    $suggested_mode = $suggested['recommended_mode'] ?? '';
    ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;margin-bottom:20px">
    <?php foreach ($modes as $key => $label):
        $desc = aiseogeo_rewrite_mode_description($key);
        $is_suggested = ($key === $suggested_mode);
        $icon = $mode_icons[$key] ?? '📝';
    ?>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="aiseogeo_create_rewrite_plan">
        <input type="hidden" name="post_id" value="<?php echo absint($post->ID); ?>">
        <input type="hidden" name="audit_id" value="<?php echo absint($audit->id); ?>">
        <input type="hidden" name="rewrite_mode" value="<?php echo esc_attr($key); ?>">
        <?php wp_nonce_field('aiseogeo_create_rewrite_plan_' . absint($post->ID) . '_' . absint($audit->id)); ?>
        <button type="submit" style="
          width:100%;text-align:left;padding:14px 16px;border-radius:6px;cursor:pointer;
          background:<?php echo $is_suggested ? '#eff6ff' : '#fff'; ?>;
          border:<?php echo $is_suggested ? '2px solid #3b82f6' : '1px solid #ddd'; ?>;
          position:relative;transition:box-shadow .15s
        " onmouseover="this.style.boxShadow='0 2px 8px rgba(0,0,0,.1)'" onmouseout="this.style.boxShadow=''">
          <?php if ($is_suggested): ?>
            <span style="position:absolute;top:8px;right:10px;font-size:10px;background:#3b82f6;color:#fff;border-radius:8px;padding:1px 7px;font-weight:600">Рекомендуется</span>
          <?php endif; ?>
          <div style="font-size:20px;margin-bottom:6px"><?php echo $icon; ?></div>
          <div style="font-weight:600;font-size:13px;margin-bottom:4px;color:#1e293b"><?php echo esc_html($label); ?></div>
          <?php if ($desc): ?>
            <div style="font-size:12px;color:#64748b;line-height:1.4"><?php echo esc_html($desc); ?></div>
          <?php endif; ?>
        </button>
      </form>
    <?php endforeach; ?>
    </div>

    <p style="font-size:12px;color:#888;margin:0">После выбора режима создастся план переписывания и откроется страница запуска.</p>
  </div>
</div>

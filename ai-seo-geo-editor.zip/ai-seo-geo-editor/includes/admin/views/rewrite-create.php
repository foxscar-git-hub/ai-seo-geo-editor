<?php if (!defined('ABSPATH')) { exit; }
$problems = $audit ? (json_decode($audit->problems_json, true) ?: array()) : array();
$suggested = $audit ? (json_decode($audit->suggested_json, true) ?: array()) : array();
// Автовыбор лучшего режима из анализа, иначе seo_geo_boost
$auto_mode = !empty($suggested['recommended_mode']) ? $suggested['recommended_mode'] : 'seo_geo_boost';
?>
<div class="wrap aiseogeo-wrap">
  <h1>AI Переписывание статьи</h1>
  <?php if (!empty($_GET['aiseogeo_error'])): ?>
    <div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div>
  <?php endif; ?>
  <?php if (!$post || !$audit || $audit->status !== 'done'): ?>
    <div class="notice notice-error"><p>Для переписывания сначала нужен успешный AI-анализ статьи.</p></div>
    <?php if ($post): ?><p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post->ID))); ?>">Перейти к анализу</a></p><?php endif; ?>
    <?php return; ?>
  <?php endif; ?>

  <div class="aiseogeo-card">
    <h2 style="margin-top:0"><?php echo esc_html(get_the_title($post)); ?></h2>
    <div style="display:flex;flex-wrap:wrap;gap:20px;align-items:flex-start">
      <div style="flex:1;min-width:240px">
        <p style="margin:0 0 6px"><strong>Оценка до переписывания</strong></p>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <span class="aiseogeo-score <?php echo intval($audit->overall_score)>=60?'ok':(intval($audit->overall_score)>=40?'weak':'bad'); ?>" style="font-size:18px;padding:4px 12px"><?php echo esc_html($audit->overall_score); ?>/100</span>
          <span style="font-size:12px;color:#555;padding-top:4px">SEO <?php echo esc_html($audit->seo_score); ?> · GEO <?php echo esc_html($audit->geo_score); ?> · E-E-A-T <?php echo esc_html($audit->eeat_score); ?></span>
        </div>
        <?php if ($audit->summary): ?>
          <p style="margin:10px 0 0;color:#444;font-size:13px"><?php echo esc_html($audit->summary); ?></p>
        <?php endif; ?>
      </div>
      <?php if (!empty($problems['main_problems'])): ?>
      <div style="flex:1;min-width:200px;background:#fef2f2;border-radius:8px;padding:12px">
        <p style="margin:0 0 6px;font-size:12px;font-weight:600;color:#b91c1c">Главные проблемы:</p>
        <ul style="margin:0;padding-left:16px;font-size:12px;color:#7f1d1d">
          <?php foreach (array_slice((array)$problems['main_problems'], 0, 4) as $pr): ?>
            <li style="margin-bottom:3px"><?php echo esc_html($pr); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="aiseogeo-card" style="text-align:center;padding:40px 24px">
    <div style="font-size:48px;margin-bottom:16px">🚀</div>
    <h2 style="margin:0 0 8px;font-size:22px">Полное переписывание по новой технологии</h2>
    <p style="color:#555;margin:0 0 8px;font-size:14px;max-width:520px;margin-inline:auto">
      16-этапный AI-процесс: анализ аудитории → семантика → структура → написание → редактура → Anti-AI гейты → мета-данные → Schema.
    </p>
    <?php if (!empty($suggested['rewrite_strategy'])): ?>
      <p style="color:#2271b1;font-size:13px;margin:0 0 24px;font-style:italic"><?php echo esc_html($suggested['rewrite_strategy']); ?></p>
    <?php else: ?>
      <p style="margin-bottom:24px"></p>
    <?php endif; ?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action"       value="aiseogeo_create_rewrite_plan">
      <input type="hidden" name="post_id"      value="<?php echo absint($post->ID); ?>">
      <input type="hidden" name="audit_id"     value="<?php echo absint($audit->id); ?>">
      <input type="hidden" name="rewrite_mode" value="<?php echo esc_attr($auto_mode); ?>">
      <?php wp_nonce_field('aiseogeo_create_rewrite_plan_' . absint($post->ID) . '_' . absint($audit->id)); ?>
      <button type="submit" style="background:#2271b1;color:#fff;border:0;border-radius:8px;padding:14px 40px;font-size:16px;font-weight:700;cursor:pointer;transition:background .15s"
        onmouseover="this.style.background='#1d5f9a'" onmouseout="this.style.background='#2271b1'">
        ✦ Переписать статью
      </button>
    </form>
    <p style="margin:16px 0 0;font-size:12px;color:#999">Обычно занимает 3–7 минут · Все 16 этапов выполняются автоматически</p>
  </div>
</div>

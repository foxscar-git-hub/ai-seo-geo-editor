<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap">
  <h1>Массовая задача</h1>
  <?php if (!$job): ?><div class="notice notice-error"><p>Задача не найдена.</p></div><?php return; endif; ?>
  <?php if (!empty($_GET['created'])): ?><div class="notice notice-success"><p>Задача создана и поставлена в очередь.</p></div><?php endif; ?>
  <div class="aiseogeo-card">
    <h2>Задача #<?php echo absint($job->id); ?></h2>
    <div class="aiseogeo-kpis">
      <div><span>Статус</span><strong><?php echo esc_html($job->job_status); ?></strong></div>
      <div><span>Всего</span><strong><?php echo absint($job->total_items); ?></strong></div>
      <div><span>Выполнено</span><strong><?php echo absint($job->success_items); ?></strong></div>
      <div><span>Ошибки</span><strong><?php echo absint($job->failed_items); ?></strong></div>
    </div>
    <p><strong>Тип:</strong> <?php echo esc_html($job->job_type); ?> · <strong>Режим:</strong> <?php echo esc_html($job->job_mode); ?> · <strong>Создана:</strong> <?php echo esc_html($job->created_at); ?></p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="aiseogeo_pause_bulk_job"><input type="hidden" name="job_id" value="<?php echo absint($job->id); ?>"><?php wp_nonce_field('aiseogeo_pause_bulk_job_' . $job->id); ?><button class="button">Пауза</button></form>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="aiseogeo_resume_bulk_job"><input type="hidden" name="job_id" value="<?php echo absint($job->id); ?>"><?php wp_nonce_field('aiseogeo_resume_bulk_job_' . $job->id); ?><button class="button">Продолжить</button></form>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="aiseogeo_cancel_bulk_job"><input type="hidden" name="job_id" value="<?php echo absint($job->id); ?>"><?php wp_nonce_field('aiseogeo_cancel_bulk_job_' . $job->id); ?><button class="button button-link-delete">Остановить</button></form>
    </div>
  </div>
  <div class="aiseogeo-card">
    <h2>Записи в задаче</h2>
    <table class="widefat striped"><thead><tr><th>ID</th><th>Запись</th><th>Статус</th><th>Анализ</th><th>Rewrite</th><th>Ошибка</th></tr></thead><tbody>
      <?php foreach ((array)$items as $item): ?><tr><td><?php echo absint($item->id); ?></td><td><a href="<?php echo esc_url(get_edit_post_link($item->post_id)); ?>"><?php echo esc_html(get_the_title($item->post_id)); ?></a></td><td><?php echo esc_html($item->item_status); ?></td><td><?php echo absint($item->audit_id); ?></td><td><?php echo absint($item->rewrite_id); ?></td><td><?php echo esc_html($item->error_message); ?></td></tr><?php endforeach; ?>
    </tbody></table>
  </div>
</div>

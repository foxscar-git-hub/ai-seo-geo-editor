<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap"><h1>История анализов</h1>
<table class="widefat striped"><thead><tr><th>Дата</th><th>Запись</th><th>Статус</th><th>Общая</th><th>SEO</th><th>GEO</th><th>EEAT</th><th>Модель</th><th></th></tr></thead><tbody>
<?php foreach($items as $a):
$is_auto = get_post_meta($a->post_id, '_aiseogeo_auto_optimized', true);
$row_style = $is_auto ? ' style="background:#f0fff4"' : '';
?><tr<?php echo $row_style; ?>><td><?php echo esc_html(mysql2date('d.m.Y H:i',$a->created_at)); ?></td><td><?php echo esc_html($a->post_title); if ($is_auto): ?> <span class="aiseogeo-badge-auto">авто</span><?php endif; ?></td><td><?php echo esc_html($a->status); ?></td><td><?php echo esc_html($a->overall_score); ?></td><td><?php echo esc_html($a->seo_score); ?></td><td><?php echo esc_html($a->geo_score); ?></td><td><?php echo esc_html($a->eeat_score); ?></td><td><?php echo esc_html($a->model); ?></td><td><a href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-report&audit_id='.absint($a->id))); ?>">Отчёт</a></td></tr><?php endforeach; ?>
</tbody></table></div>

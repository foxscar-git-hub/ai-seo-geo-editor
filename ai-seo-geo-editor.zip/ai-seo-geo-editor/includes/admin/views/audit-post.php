<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap">
  <h1>Анализ записи</h1>
  <?php if (!$post): ?><div class="notice notice-error"><p>Запись не найдена.</p></div><?php return; endif; ?>
  <?php if (!empty($_GET['aiseogeo_error'])): ?><div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div><?php endif; ?>
  <div class="aiseogeo-card">
    <h2><?php echo esc_html(get_the_title($post)); ?></h2>
    <p><strong>Статус:</strong> <?php echo esc_html($post->post_status); ?> · <strong>Дата публикации:</strong> <?php echo esc_html(get_the_date('d.m.Y H:i', $post)); ?></p>
    <?php if ($latest): ?>
      <p><strong>Последний анализ:</strong> <?php echo esc_html(mysql2date('d.m.Y H:i', $latest->created_at)); ?></p>
      <p><strong>Оценки:</strong> Общая <?php echo esc_html($latest->overall_score); ?>/100 · SEO <?php echo esc_html($latest->seo_score); ?> · GEO <?php echo esc_html($latest->geo_score); ?> · EEAT <?php echo esc_html($latest->eeat_score); ?></p>
      <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-report&audit_id=' . absint($latest->id))); ?>">Открыть последний отчёт</a></p>
    <?php else: ?><p>Эта запись ещё не анализировалась.</p><?php endif; ?>
    <div class="notice notice-warning inline"><p>Анализ использует OpenRouter API и может расходовать баланс API-ключа. Запуск происходит только после нажатия кнопки ниже.</p></div>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action" value="aiseogeo_run_audit">
      <input type="hidden" name="post_id" value="<?php echo absint($post->ID); ?>">
      <?php wp_nonce_field('aiseogeo_run_audit_' . $post->ID); ?>
      <button class="button button-primary button-hero">Запустить анализ</button>
    </form>
  </div>
  <?php if ($audits): ?><h2>История этой записи</h2><table class="widefat striped"><thead><tr><th>Дата</th><th>Статус</th><th>Общая</th><th>SEO</th><th>GEO</th><th>EEAT</th><th>Модель</th><th></th></tr></thead><tbody><?php foreach($audits as $a): ?><tr><td><?php echo esc_html(mysql2date('d.m.Y H:i',$a->created_at)); ?></td><td><?php echo esc_html($a->status); ?></td><td><?php echo esc_html($a->overall_score); ?></td><td><?php echo esc_html($a->seo_score); ?></td><td><?php echo esc_html($a->geo_score); ?></td><td><?php echo esc_html($a->eeat_score); ?></td><td><?php echo esc_html($a->model); ?></td><td><a href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-report&audit_id=' . absint($a->id))); ?>">Отчёт</a></td></tr><?php endforeach; ?></tbody></table><?php endif; ?>
</div>

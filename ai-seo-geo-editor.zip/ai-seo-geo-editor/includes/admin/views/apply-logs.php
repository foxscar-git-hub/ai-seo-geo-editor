<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap">
  <h1>История применений</h1>
  <div class="aiseogeo-card">
    <table class="widefat striped"><thead><tr><th>ID</th><th>Запись</th><th>Rewrite</th><th>Backup</th><th>Поля</th><th>Статус</th><th>Дата</th><th></th></tr></thead><tbody>
      <?php foreach ((array)$logs as $log): $fields=json_decode((string)$log->applied_fields_json,true) ?: array(); ?><tr><td><?php echo absint($log->id); ?></td><td><a href="<?php echo esc_url(get_edit_post_link($log->post_id)); ?>"><?php echo esc_html(get_the_title($log->post_id)); ?></a></td><td><?php echo absint($log->rewrite_id); ?></td><td><?php echo absint($log->backup_id); ?></td><td><?php echo esc_html(implode(', ', $fields)); ?></td><td><?php echo esc_html($log->status); ?></td><td><?php echo esc_html($log->created_at); ?></td><td><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rollback&backup_id=' . absint($log->backup_id))); ?>">Откатить</a></td></tr><?php endforeach; ?>
      <?php if(empty($logs)): ?><tr><td colspan="8">Применений пока нет.</td></tr><?php endif; ?>
    </tbody></table>
  </div>
</div>

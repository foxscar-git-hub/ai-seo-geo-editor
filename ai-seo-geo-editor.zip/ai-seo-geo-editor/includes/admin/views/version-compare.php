<?php if (!defined('ABSPATH')) { exit; }
if (!function_exists('aiseogeo_stage2_list')) { function aiseogeo_stage2_list($items){ if(empty($items)){echo '—'; return;} if(!is_array($items)){$items=array($items);} echo '<ul class="aiseogeo-list">'; foreach($items as $item){ $txt=is_array($item)?wp_json_encode($item,JSON_UNESCAPED_UNICODE):(string)$item; echo '<li>'.esc_html($txt).'</li>'; } echo '</ul>'; } }

if (!function_exists('aiseogeo_render_change_intelligence')) {
    function aiseogeo_render_change_intelligence($change) {
        if (empty($change) || !is_array($change)) { return; }
        $word_delta = (int)($change['new_words'] ?? 0) - (int)($change['old_words'] ?? 0);
        echo '<div class="aiseogeo-card aiseogeo-diff-card"><div class="aiseogeo-section-head"><div><h2>Понятное сравнение изменений</h2><p>Что реально изменилось между исходной статьёй и AI-версией.</p></div><span class="aiseogeo-badge">до / после</span></div>';
        echo '<div class="aiseogeo-diff-kpi">';
        echo '<div><span>Объём текста</span><strong>'.esc_html((int)$change['old_words']).' → '.esc_html((int)$change['new_words']).'</strong><em>'.esc_html(($word_delta>0?'+':'').$word_delta).' слов</em></div>';
        echo '<div><span>Подзаголовки</span><strong>'.esc_html((int)$change['old_headings_count']).' → '.esc_html((int)$change['new_headings_count']).'</strong><em>структура</em></div>';
        echo '<div><span>Ссылки</span><strong>'.esc_html((int)$change['old_links_count']).' → '.esc_html((int)$change['new_links_count']).'</strong><em>перелинковка</em></div>';
        echo '<div><span>Похожесть текста</span><strong>'.esc_html((int)$change['content_similarity']).'%</strong><em>'.esc_html(((int)$change['content_similarity'] > 85) ? 'мягкая правка' : 'существенная правка').'</em></div>';
        echo '</div>';

        echo '<div class="aiseogeo-grid two">';
        echo '<div class="aiseogeo-mini-panel"><h3>Заголовок</h3><p><b>Было:</b> '.esc_html($change['old_title'] ?? '').'</p><p><b>Стало:</b> '.esc_html($change['new_title'] ?? '').'</p></div>';
        echo '<div class="aiseogeo-mini-panel"><h3>Excerpt / краткое описание</h3><p><b>Было:</b> '.esc_html(mb_substr((string)($change['old_excerpt'] ?? ''),0,260)).'</p><p><b>Стало:</b> '.esc_html(mb_substr((string)($change['new_excerpt'] ?? ''),0,260)).'</p></div>';
        echo '</div>';

        echo '<div class="aiseogeo-grid two">';
        echo '<div class="aiseogeo-mini-panel"><h3>Добавленные подзаголовки</h3>'; aiseogeo_stage2_list($change['added_headings'] ?? array()); echo '</div>';
        echo '<div class="aiseogeo-mini-panel"><h3>Удалённые подзаголовки</h3>'; aiseogeo_stage2_list($change['removed_headings'] ?? array()); echo '</div>';
        echo '</div>';

        echo '<div class="aiseogeo-mini-panel"><h3>Контроль важных блоков</h3><div class="aiseogeo-protection-grid">';
        foreach (($change['blocks'] ?? array()) as $block) {
            $status = $block['status'] ?? 'missing';
            $class = $status === 'removed' ? 'bad' : (($block['before'] || $block['after']) ? 'ok' : 'muted');
            $text = $status === 'removed' ? 'Был, но не найден после' : (($block['before'] && $block['after']) ? 'Сохранён' : ((!empty($block['after'])) ? 'Добавлен' : 'Не найден'));
            echo '<div class="aiseogeo-protection-item '.esc_attr($class).'"><strong>'.esc_html($block['label'] ?? '').'</strong><span>'.esc_html($text).'</span></div>';
        }
        echo '</div></div>';

        if (!empty($change['removed_links']) || !empty($change['removed_shortcodes'])) {
            echo '<div class="notice notice-warning inline"><p><strong>Проверь перед публикацией:</strong> в новой версии могли исчезнуть ссылки или шорткоды.</p></div>';
            echo '<div class="aiseogeo-grid two"><div class="aiseogeo-mini-panel"><h3>Удалённые ссылки</h3>'; aiseogeo_stage2_list($change['removed_links'] ?? array()); echo '</div><div class="aiseogeo-mini-panel"><h3>Удалённые шорткоды</h3>'; aiseogeo_stage2_list($change['removed_shortcodes'] ?? array()); echo '</div></div>';
        }
        echo '</div>';
    }
}

if (!function_exists('aiseogeo_compare_forecast_cards')) {
    function aiseogeo_compare_forecast_cards($rows) {
        if (empty($rows) || !is_array($rows)) { return; }
        $is_forecast = !empty($rows[0]['is_forecast']);
        echo '<div class="aiseogeo-card aiseogeo-forecast-card">';
        echo '<div class="aiseogeo-section-head"><div><h2>Конверсия в выдаче: до и после</h2><p>' . esc_html($is_forecast ? 'Показатели «Стало» рассчитаны как прогноз до повторного анализа новой версии. После нажатия «Повторно проанализировать новую версию» здесь появятся фактические оценки AI-аудита.' : 'Показатели «Стало» рассчитаны по повторному анализу улучшенной версии.') . '</p></div><span class="aiseogeo-badge">' . esc_html($is_forecast ? 'прогноз' : 'после анализа') . '</span></div>';
        echo '<div class="aiseogeo-forecast-grid">';
        foreach ($rows as $row) {
            $before = isset($row['before']) ? (int)$row['before'] : 0;
            $after = isset($row['after']) ? (int)$row['after'] : 0;
            $delta = isset($row['delta']) ? (int)$row['delta'] : ($after - $before);
            echo '<div class="aiseogeo-forecast-item"><h3>' . esc_html($row['label'] ?? '') . '</h3>';
            echo '<div class="aiseogeo-before-after"><div><span>До</span><strong>' . esc_html($before) . '</strong></div><div><span>После</span><strong>' . esc_html($after) . '</strong></div><div class="aiseogeo-delta"><span>Рост</span><strong>' . esc_html(($delta > 0 ? '+' : '') . $delta) . '</strong></div></div>';
            echo '<div class="aiseogeo-meter"><i style="width:' . esc_attr(max(0, min(100, $after))) . '%"></i></div>';
            if (!empty($row['note'])) { echo '<p class="aiseogeo-note">' . esc_html($row['note']) . '</p>'; }
            echo '</div>';
        }
        echo '</div></div>';
    }
}
?>
<div class="wrap aiseogeo-wrap">
  <h1>Сравнение версии</h1>
  <?php if (!$rewrite): ?><div class="notice notice-error"><p>Версия не найдена.</p></div><?php return; endif; ?>
  <?php $scores = $comparison->get_score_comparison($rewrite->id); $is_forecast = !empty($scores) && !empty($scores[0]['is_forecast']); ?>
  <div class="aiseogeo-card">
    <h2><?php echo esc_html($rewrite->original_title); ?></h2>
    <p><strong>Режим:</strong> <?php echo esc_html($rewrite->rewrite_mode); ?> · <strong>Статус:</strong> <?php echo esc_html($rewrite->rewrite_status); ?><?php if ($is_forecast): ?> · <strong>Показатели «Стало»:</strong> прогноз до повторного анализа<?php endif; ?></p>
  </div>
  <div class="aiseogeo-card"><h2>Сравнение оценок</h2><table class="widefat striped"><thead><tr><th>Показатель</th><th>Было</th><th>Стало<?php echo $is_forecast ? ' (прогноз)' : ''; ?></th><th>Изменение</th></tr></thead><tbody><?php foreach($scores as $s): ?><tr><td><?php echo esc_html($s['label']); ?></td><td><?php echo $s['before']===null?'—':esc_html($s['before']); ?></td><td><?php echo $s['after']===null?'—':esc_html($s['after']); ?></td><td><?php echo $s['delta']===null?'—':esc_html(($s['delta']>0?'+':'').$s['delta']); ?></td></tr><?php endforeach; ?></tbody></table><?php if($is_forecast): ?><p class="description">Чтобы получить не прогноз, а фактические показатели, открой результат переписывания и нажми «Повторно проанализировать новую версию».</p><?php endif; ?></div>
  <?php if (method_exists($comparison, 'get_search_forecast')) { aiseogeo_compare_forecast_cards($comparison->get_search_forecast($rewrite->id)); } ?>
  <?php if (method_exists($comparison, 'get_content_change_summary')) { aiseogeo_render_change_intelligence($comparison->get_content_change_summary($rewrite->id)); } ?>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card"><h2>Было</h2><h3><?php echo esc_html($rewrite->original_title); ?></h3><p><?php echo esc_html($rewrite->original_excerpt); ?></p><div style="max-height:500px;overflow:auto;border:1px solid #dcdcde;padding:12px"><?php echo wp_kses_post($rewrite->original_content_longtext); ?></div></div>
    <div class="aiseogeo-card"><h2>Стало</h2><h3><?php echo esc_html($rewrite->new_title); ?></h3><p><?php echo esc_html($rewrite->new_excerpt); ?></p><div style="max-height:500px;overflow:auto;border:1px solid #dcdcde;padding:12px"><?php echo wp_kses_post($rewrite->new_content_longtext); ?></div></div>
  </div>
  <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id=' . absint($rewrite->id))); ?>">Вернуться к версии</a></p>
</div>

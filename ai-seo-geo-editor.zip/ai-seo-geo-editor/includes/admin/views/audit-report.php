<?php if (!defined('ABSPATH')) { exit; }

if (!function_exists('aiseogeo_value_to_text')) {
    function aiseogeo_value_to_text($value) {
        if (is_scalar($value) || $value === null) {
            return trim((string)$value);
        }
        if (is_array($value)) {
            $preferred_keys = array('problem','issue','title','recommendation','action','text','summary','message','question','answer','description','value');
            $parts = array();
            foreach ($preferred_keys as $key) {
                if (isset($value[$key]) && (is_scalar($value[$key]) || $value[$key] === null)) {
                    $txt = trim((string)$value[$key]);
                    if ($txt !== '') { $parts[] = $txt; }
                }
            }
            if (!empty($parts)) {
                return implode(' — ', array_unique($parts));
            }
            $flat = array();
            foreach ($value as $k => $v) {
                if (is_scalar($v) || $v === null) {
                    $txt = trim((string)$v);
                    if ($txt !== '') { $flat[] = is_string($k) ? ($k . ': ' . $txt) : $txt; }
                } elseif (is_array($v)) {
                    $txt = aiseogeo_value_to_text($v);
                    if ($txt !== '') { $flat[] = is_string($k) ? ($k . ': ' . $txt) : $txt; }
                }
            }
            return trim(implode('; ', $flat));
        }
        return '';
    }
}

if (!function_exists('aiseogeo_list')) {
    function aiseogeo_list($items) {
        if (empty($items)) { echo '—'; return; }
        if (!is_array($items)) { $items = array($items); }
        echo '<ul class="aiseogeo-list">';
        foreach ($items as $item) {
            $text = aiseogeo_value_to_text($item);
            if ($text === '') { continue; }
            echo '<li>' . esc_html($text) . '</li>';
        }
        echo '</ul>';
    }
}

if (!function_exists('aiseogeo_faq_list')) {
    function aiseogeo_faq_list($items) {
        if (empty($items)) { echo '—'; return; }
        if (!is_array($items)) { $items = array($items); }
        echo '<ol class="aiseogeo-list">';
        foreach ($items as $item) {
            if (is_array($item)) {
                $question = aiseogeo_value_to_text($item['question'] ?? ($item['q'] ?? ''));
                $answer = aiseogeo_value_to_text($item['answer'] ?? ($item['a'] ?? ''));
                if ($question === '' && $answer === '') {
                    $text = aiseogeo_value_to_text($item);
                    if ($text !== '') { echo '<li>' . esc_html($text) . '</li>'; }
                } else {
                    echo '<li>';
                    if ($question !== '') { echo '<strong>' . esc_html($question) . '</strong>'; }
                    if ($answer !== '') { echo ($question !== '' ? '<br>' : '') . esc_html($answer); }
                    echo '</li>';
                }
            } else {
                $text = aiseogeo_value_to_text($item);
                if ($text !== '') { echo '<li>' . esc_html($text) . '</li>'; }
            }
        }
        echo '</ol>';
    }
}

if (!function_exists('aiseogeo_forecast_cards')) {
    function aiseogeo_forecast_cards($rows, $title = 'Предполагаемая конверсия в выдаче после изменений') {
        if (empty($rows) || !is_array($rows)) { return; }
        echo '<div class="aiseogeo-card aiseogeo-forecast-card">';
        echo '<div class="aiseogeo-section-head"><div><h2>' . esc_html($title) . '</h2><p>Это прогнозный индекс 0–100, а не данные Яндекс/Google Analytics. Он показывает, как может вырасти привлекательность страницы в поисковой выдаче после внедрения рекомендаций.</p></div><span class="aiseogeo-badge">прогноз</span></div>';
        echo '<div class="aiseogeo-forecast-grid">';
        foreach ($rows as $row) {
            $before = isset($row['before']) ? (int)$row['before'] : 0;
            $after = isset($row['after']) ? (int)$row['after'] : 0;
            $delta = isset($row['delta']) ? (int)$row['delta'] : ($after - $before);
            echo '<div class="aiseogeo-forecast-item">';
            echo '<h3>' . esc_html($row['label'] ?? '') . '</h3>';
            echo '<div class="aiseogeo-before-after"><div><span>До</span><strong>' . esc_html($before) . '</strong></div><div><span>После</span><strong>' . esc_html($after) . '</strong></div><div class="aiseogeo-delta"><span>Рост</span><strong>' . esc_html(($delta > 0 ? '+' : '') . $delta) . '</strong></div></div>';
            echo '<div class="aiseogeo-meter"><i style="width:' . esc_attr(max(0, min(100, $after))) . '%"></i></div>';
            if (!empty($row['note'])) { echo '<p class="aiseogeo-note">' . esc_html($row['note']) . '</p>'; }
            echo '</div>';
        }
        echo '</div></div>';
    }
}

?>
<div class="wrap aiseogeo-wrap">
  <h1>Отчёт анализа</h1>
  <?php if (!$audit): ?><div class="notice notice-error"><p>Отчёт не найден.</p></div><?php return; endif; ?>
  <?php $problems=json_decode($audit->problems_json,true) ?: array(); $recs=json_decode($audit->recommendations_json,true) ?: array(); $sug=json_decode($audit->suggested_json,true) ?: array(); ?>
  <div class="aiseogeo-card">
    <h2><?php echo esc_html($audit->post_title); ?></h2>
    <p><strong>Дата анализа:</strong> <?php echo esc_html(mysql2date('d.m.Y H:i',$audit->created_at)); ?> · <strong>Модель:</strong> <?php echo esc_html($audit->model); ?> · <strong>Статус:</strong> <?php echo esc_html($audit->status); ?></p>
    <?php if($audit->status==='error'): ?><div class="notice notice-error inline"><p><?php echo esc_html($audit->error_message); ?></p></div><?php endif; ?>
  </div>
  <div class="aiseogeo-grid scores">
    <div class="aiseogeo-card"><h2>Общая</h2><div class="aiseogeo-big"><?php echo esc_html((int)$audit->overall_score); ?>/100</div></div>
    <div class="aiseogeo-card"><h2>SEO</h2><div class="aiseogeo-big"><?php echo esc_html((int)$audit->seo_score); ?></div></div>
    <div class="aiseogeo-card"><h2>GEO / AI</h2><div class="aiseogeo-big"><?php echo esc_html((int)$audit->geo_score); ?></div></div>
    <div class="aiseogeo-card"><h2>EEAT</h2><div class="aiseogeo-big"><?php echo esc_html((int)$audit->eeat_score); ?></div></div>
    <div class="aiseogeo-card"><h2>Структура</h2><div class="aiseogeo-big"><?php echo esc_html((int)$audit->structure_score); ?></div></div>
    <div class="aiseogeo-card"><h2>Anti-AI</h2><div class="aiseogeo-big"><?php echo esc_html((int)$audit->anti_ai_score); ?></div></div>
    <div class="aiseogeo-card"><h2>Читаемость</h2><div class="aiseogeo-big"><?php echo esc_html((int)$audit->readability_score); ?></div></div>
    <div class="aiseogeo-card"><h2>Мета</h2><div class="aiseogeo-big"><?php echo esc_html((int)$audit->meta_score); ?></div></div>
  </div>
  <?php
  $geo_v = json_decode($audit->problems_json, true)['geo_violations'] ?? array();
  $ai_v  = json_decode($audit->problems_json, true)['anti_ai_violations'] ?? array();
  $str_v = json_decode($audit->problems_json, true)['structure_violations'] ?? array();
  if (!empty($geo_v) || !empty($ai_v) || !empty($str_v)):
  ?>
  <div class="aiseogeo-grid two">
    <?php if (!empty($geo_v)): ?>
    <div class="aiseogeo-card">
      <h2>GEO-нарушения (цитируемость)</h2>
      <?php if (!empty($geo_v['no_answer_first_h2'])): ?><p><strong>H2 без TL;DR-блока:</strong></p><?php aiseogeo_list($geo_v['no_answer_first_h2']); ?><?php endif; ?>
      <?php if (!empty($geo_v['non_question_h2'])): ?><p><strong>H2 не в форме вопроса:</strong></p><?php aiseogeo_list($geo_v['non_question_h2']); ?><?php endif; ?>
      <?php if (!empty($geo_v['standalone_violations'])): ?><p><strong>Зависимые фразы (standalone):</strong></p><?php aiseogeo_list($geo_v['standalone_violations']); ?><?php endif; ?>
      <?php if (!empty($geo_v['long_paragraphs_count'])): ?><p><strong>Длинных параграфов (>4 предл.):</strong> <?php echo esc_html((int)$geo_v['long_paragraphs_count']); ?></p><?php endif; ?>
      <?php if (!empty($geo_v['missing_table'])): ?><p>⚠️ <strong>Нет сравнительной таблицы</strong></p><?php endif; ?>
      <?php if (!empty($geo_v['missing_numbered_lists'])): ?><p>⚠️ <strong>Процессы не в нумерованных списках</strong></p><?php endif; ?>
      <?php if (!empty($geo_v['sources_missing'])): ?><p>⚠️ <strong>Нет именованных источников (нужно мин. 5, найдено: <?php echo esc_html((int)($geo_v['sources_count'] ?? 0)); ?>)</strong></p><?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if (!empty($ai_v)): ?>
    <div class="aiseogeo-card">
      <h2>Anti-AI нарушения</h2>
      <?php if (!empty($ai_v['em_dashes_count'])): ?><p>⚠️ <strong>Длинных тире — (маркер ИИ):</strong> <?php echo esc_html((int)$ai_v['em_dashes_count']); ?></p><?php endif; ?>
      <?php if (!empty($ai_v['en_dashes_count'])): ?><p>⚠️ <strong>Коротких тире –:</strong> <?php echo esc_html((int)$ai_v['en_dashes_count']); ?></p><?php endif; ?>
      <?php if (!empty($ai_v['cliche_phrases'])): ?><p><strong>Клише:</strong></p><?php aiseogeo_list($ai_v['cliche_phrases']); ?><?php endif; ?>
      <?php if (!empty($ai_v['symmetry_patterns'])): ?><p><strong>Симметрии:</strong></p><?php aiseogeo_list($ai_v['symmetry_patterns']); ?><?php endif; ?>
      <?php if (!empty($ai_v['forbidden_opening'])): ?><p>⚠️ <strong>Запрещённый зачин статьи</strong></p><?php endif; ?>
      <?php if (!empty($ai_v['forbidden_closing'])): ?><p>⚠️ <strong>Запрещённая концовка статьи</strong></p><?php endif; ?>
      <?php if (!empty($ai_v['english_calques'])): ?><p><strong>Кальки с английского:</strong></p><?php aiseogeo_list($ai_v['english_calques']); ?><?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
  <?php if (!empty($str_v)): ?>
  <div class="aiseogeo-card">
    <h2>Структура статьи (методология «Скилл статей»)</h2>
    <p><strong>Разделов H2:</strong> <?php echo esc_html((int)($str_v['h2_count'] ?? 0)); ?> <?php echo ((int)($str_v['h2_count'] ?? 0) < 8 || (int)($str_v['h2_count'] ?? 0) > 14) ? '⚠️ (норма 8-14)' : '✅'; ?></p>
    <p><strong>Hero Promise:</strong> <?php echo !empty($str_v['has_hero_promise']) ? '✅ есть' : '❌ отсутствует'; ?></p>
    <p><strong>CTA-точек:</strong> <?php echo esc_html((int)($str_v['cta_count'] ?? 0)); ?> <?php echo ((int)($str_v['cta_count'] ?? 0) < 3) ? '⚠️ (норма 3)' : '✅'; ?></p>
    <p><strong>FAQ-блок:</strong> <?php echo !empty($str_v['has_faq']) ? '✅ есть (' . esc_html((int)($str_v['faq_count'] ?? 0)) . ' вопросов)' : '❌ отсутствует'; ?></p>
    <p><strong>Блок источников:</strong> <?php echo !empty($str_v['has_sources_block']) ? '✅ есть' : '❌ отсутствует'; ?></p>
    <p><strong>Внутренних ссылок:</strong> <?php echo esc_html((int)($str_v['internal_links_count'] ?? 0)); ?> <?php echo ((int)($str_v['internal_links_count'] ?? 0) < 3) ? '⚠️ (норма мин. 3)' : '✅'; ?></p>
  </div>
  <?php endif; ?>
  <?php endif; ?>
  <div class="aiseogeo-card"><h2>Краткий вывод</h2><p><?php echo esc_html($audit->summary); ?></p></div>
  <?php if (class_exists('AISEOGEO_Search_Forecast_Service')) { aiseogeo_forecast_cards(AISEOGEO_Search_Forecast_Service::forecast_from_audit($audit)); } ?>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card"><h2>Основные проблемы</h2><?php aiseogeo_list($problems['main_problems'] ?? array()); ?><h3>Критические проблемы</h3><?php aiseogeo_list($problems['critical_issues'] ?? array()); ?></div>
    <div class="aiseogeo-card"><h2>Рекомендации</h2><?php aiseogeo_list($recs['recommended_actions'] ?? array()); ?><h3>Быстрые улучшения</h3><?php aiseogeo_list($recs['quick_wins'] ?? array()); ?></div>
  </div>
  <div class="aiseogeo-card"><h2>Предложения AI</h2>
    <p><strong>Title:</strong> <?php echo esc_html(aiseogeo_value_to_text($sug['suggested_title'] ?? '')); ?></p>
    <p><strong>Description:</strong> <?php echo esc_html(aiseogeo_value_to_text($sug['suggested_meta_description'] ?? '')); ?></p>
    <p><strong>Schema:</strong> <?php echo esc_html(aiseogeo_value_to_text($sug['schema_recommendation'] ?? '')); ?></p>
    <p><strong>Нужно переписывание:</strong> <?php echo !empty($sug['rewrite_needed']) ? 'Да' : 'Нет'; ?> · <strong>Приоритет:</strong> <?php echo esc_html(aiseogeo_value_to_text($sug['rewrite_priority'] ?? '')); ?></p>
    <p><strong>Стратегия:</strong> <?php echo esc_html(aiseogeo_value_to_text($sug['rewrite_strategy'] ?? '')); ?></p>
    <h3>Предлагаемые H2</h3><?php aiseogeo_list($sug['suggested_h2'] ?? array()); ?>
    <h3>FAQ</h3><?php aiseogeo_faq_list($sug['suggested_faq'] ?? array()); ?>
  </div>
  <p>
    <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($audit->post_id))); ?>">Вернуться к записи</a>
    <?php if ($audit->status === 'done' && current_user_can('aiseogeo_run_rewrite')): ?>
      <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rewrite-create&post_id=' . absint($audit->post_id) . '&audit_id=' . absint($audit->id))); ?>">Переписать по результатам анализа</a>
    <?php endif; ?>
  </p>
</div>

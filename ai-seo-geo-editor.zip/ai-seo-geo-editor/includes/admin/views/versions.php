<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap">
  <h1>История версий</h1>
  <?php if (!empty($_GET['deleted'])): ?><div class="notice notice-success"><p>Версия удалена из истории.</p></div><?php endif; ?>
  <div class="aiseogeo-card"><p>Здесь хранятся все AI-версии, созданные на основе исходных записей. Оригинальные записи на Этапе 2 не изменяются.</p></div>
  <table class="widefat striped">
    <thead><tr><th>ID</th><th>Исходная запись</th><th>Режим</th><th>Статус</th><th>Старая/новая оценка</th><th>Черновик</th><th>Дата</th><th>Действия</th></tr></thead>
    <tbody>
      <?php if (empty($items)): ?><tr><td colspan="8">Версий пока нет.</td></tr><?php endif; ?>
      <?php foreach ($items as $r): ?>
      <tr>
        <td><?php echo esc_html($r->id); ?></td>
        <td><strong><?php echo esc_html($r->original_title); ?></strong><br><a href="<?php echo esc_url(get_edit_post_link($r->post_id)); ?>">Исходная запись</a></td>
        <td><?php echo esc_html($r->rewrite_mode); ?></td>
        <td><?php echo esc_html($r->rewrite_status); ?></td>
        <td><?php echo esc_html($r->audit_id); ?><?php echo $r->re_audit_id ? ' → '.esc_html($r->re_audit_id) : ''; ?></td>
        <td><?php echo $r->created_draft_post_id ? '<a href="'.esc_url(get_edit_post_link($r->created_draft_post_id)).'">#'.esc_html($r->created_draft_post_id).'</a>' : '—'; ?></td>
        <td><?php echo esc_html(mysql2date('d.m.Y H:i',$r->created_at)); ?></td>
        <td>
          <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id=' . absint($r->id))); ?>">Открыть версию</a>
          <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-version-compare&rewrite_id=' . absint($r->id))); ?>">Сравнение</a>
          <?php if (!$r->created_draft_post_id && in_array($r->rewrite_status, array('done','re_audited'), true)): ?>
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline"><input type="hidden" name="action" value="aiseogeo_create_rewrite_draft"><input type="hidden" name="rewrite_id" value="<?php echo absint($r->id); ?>"><?php wp_nonce_field('aiseogeo_create_rewrite_draft_' . $r->id); ?><button class="button">Создать черновик</button></form>
          <?php endif; ?>
          <?php if (current_user_can('aiseogeo_delete_versions')): ?>
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline" onsubmit="return confirm('Удалить версию из истории?');"><input type="hidden" name="action" value="aiseogeo_delete_rewrite"><input type="hidden" name="rewrite_id" value="<?php echo absint($r->id); ?>"><?php wp_nonce_field('aiseogeo_delete_rewrite_' . $r->id); ?><button class="button">Удалить</button></form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap">
  <h1>Массовая обработка</h1>
  <?php if (!empty($_GET['aiseogeo_error'])): ?><div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div><?php endif; ?>
  <div class="aiseogeo-card">
    <h2>Создать массовую задачу <?php if (!empty($license_gate)) { echo $license_gate->feature_badge('bulk_process'); } ?></h2>
    <?php if (!empty($license_gate) && !$license_gate->can('bulk_process')): ?>
      <?php $license_gate->render_required_box('bulk_process', 'Массовая обработка доступна по лицензии'); ?>
    <?php else: ?>
    <p class="description">Массовые операции идут через Action Scheduler или WP-Cron. Плагин обрабатывает записи по одной, чтобы не валить сайт и не тратить API случайным залпом.</p>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action" value="aiseogeo_create_bulk_job">
      <?php wp_nonce_field('aiseogeo_create_bulk_job'); ?>
      <table class="form-table"><tbody>
        <tr><th>Тип задачи</th><td><select name="job_type"><option value="audit">Только анализ</option><option value="audit_rewrite">Анализ + переписывание</option><option value="re_rewrite">Повторное переписывание</option><option value="meta_only">Только мета-данные</option></select><p class="description">«Повторное переписывание» — для статей, которые уже были переписаны, но набрали низкий балл.</p></td></tr>
        <tr><th>Режим переписывания</th><td><select name="job_mode"><option value="soft_improve">Мягкое улучшение</option><option value="seo_boost">SEO-усиление</option><option value="geo_boost">GEO-усиление</option><option value="seo_geo_boost">SEO + GEO усиление</option><option value="full_refresh">Полное обновление</option><option value="problem_blocks_only">Только проблемные блоки</option></select></td></tr>
        <tr><th>Фильтр записей</th><td><select name="post_filter"><?php foreach($filters as $key=>$label): ?><option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option><?php endforeach; ?></select></td></tr>
        <tr><th>Рубрика</th><td><?php wp_dropdown_categories(array('name'=>'category','show_option_all'=>'Все рубрики','hide_empty'=>false)); ?></td></tr>
        <tr><th>Лимит записей</th><td><input type="number" name="limit" value="5" min="1" max="<?php echo esc_attr($settings->get('bulk_max_items','20')); ?>"> <p class="description">Текущий максимальный лимит за запуск: <?php echo esc_html($settings->get('bulk_max_items','20')); ?>.</p></td></tr>
      </tbody></table>
      <p><button class="button button-primary">Создать задачу</button></p>
    </form>
    <?php endif; ?>
  </div>
  <div class="aiseogeo-card">
    <h2>Последние задачи</h2>
    <table class="widefat striped"><thead><tr><th>ID</th><th>Тип</th><th>Режим</th><th>Статус</th><th>Готово</th><th>Ошибки</th><th>Дата</th><th></th></tr></thead><tbody>
    <?php foreach ((array)$jobs as $job): ?><tr><td><?php echo absint($job->id); ?></td><td><?php echo esc_html($job->job_type); ?></td><td><?php echo esc_html($job->job_mode); ?></td><td><?php echo esc_html($job->job_status); ?></td><td><?php echo absint($job->processed_items); ?>/<?php echo absint($job->total_items); ?></td><td><?php echo absint($job->failed_items); ?></td><td><?php echo esc_html($job->created_at); ?></td><td><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-bulk-job&job_id=' . absint($job->id))); ?>">Открыть</a></td></tr><?php endforeach; ?>
    <?php if(empty($jobs)): ?><tr><td colspan="8">Задач пока нет.</td></tr><?php endif; ?>
    </tbody></table>
  </div>
</div>

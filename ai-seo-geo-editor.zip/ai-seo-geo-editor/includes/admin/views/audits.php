<?php if (!defined('ABSPATH')) { exit; }
$status = isset($_GET['post_status']) ? sanitize_text_field($_GET['post_status']) : 'any';
$args = array('post_type'=>'post','posts_per_page'=>50,'post_status'=>$status === 'any' ? array('publish','draft','pending','future','private') : $status);
$q = new WP_Query($args);
?>
<div class="wrap aiseogeo-wrap">
  <h1>Анализ записей</h1>
  <p class="description">На этом экране анализ не запускается случайно. Сначала откройте карточку записи, затем нажмите «Запустить анализ».</p>
  <form method="get" class="aiseogeo-filter"><input type="hidden" name="page" value="aiseogeo-audits">
    <select name="post_status"><option value="any">Все статусы</option><option value="publish" <?php selected($status,'publish'); ?>>Опубликованные</option><option value="draft" <?php selected($status,'draft'); ?>>Черновики</option></select>
    <button class="button">Фильтр</button>
  </form>
  <table class="widefat striped"><thead><tr><th>Запись</th><th>Статус</th><th>Дата</th><th>Последний анализ</th><th>SEO</th><th>GEO</th><th>EEAT</th><th>Общая</th><th>Действия</th></tr></thead><tbody>
  <?php foreach ($q->posts as $post): $latest = $audit_service->get_latest_audit($post->ID); ?>
    <tr>
      <td><strong><?php echo esc_html(get_the_title($post)); ?></strong></td>
      <td><?php echo esc_html($post->post_status); ?></td>
      <td><?php echo esc_html(get_the_date('d.m.Y H:i', $post)); ?></td>
      <td><?php echo $latest ? esc_html(mysql2date('d.m.Y H:i', $latest->created_at)) : '—'; ?></td>
      <td><?php echo $latest ? esc_html($latest->seo_score) : '—'; ?></td>
      <td><?php echo $latest ? esc_html($latest->geo_score) : '—'; ?></td>
      <td><?php echo $latest ? esc_html($latest->eeat_score) : '—'; ?></td>
      <td><?php echo $latest ? esc_html($latest->overall_score . '/100') : '—'; ?></td>
      <td><a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post->ID))); ?>">AI анализ</a><?php if($latest): ?> <a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-report&audit_id=' . absint($latest->id))); ?>">Отчёт</a><?php endif; ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody></table>
</div>

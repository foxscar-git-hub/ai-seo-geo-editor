<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap">
  <h1>Подтверждение применения изменений</h1>
  <?php if (!$rewrite): ?><div class="notice notice-error"><p>AI-версия не найдена.</p></div><?php return; endif; ?>
  <?php if (!empty($_GET['aiseogeo_error'])): ?><div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div><?php endif; ?>
  <div class="notice notice-warning"><p><strong>Внимание:</strong> сейчас изменения будут применены к оригинальной записи. Перед применением плагин автоматически создаст резервную копию.</p></div>
  <div class="aiseogeo-card">
    <h2><?php echo esc_html($rewrite->original_title); ?></h2>
    <p><strong>AI-версия:</strong> #<?php echo absint($rewrite->id); ?> · <strong>Режим:</strong> <?php echo esc_html($rewrite->rewrite_mode); ?> · <strong>Статус:</strong> <?php echo esc_html($rewrite->rewrite_status); ?></p>
    <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id=' . absint($rewrite->id))); ?>">Открыть результат переписывания</a></p>
  </div>
  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="aiseogeo-card">
    <input type="hidden" name="action" value="aiseogeo_apply_rewrite">
    <input type="hidden" name="rewrite_id" value="<?php echo absint($rewrite->id); ?>">
    <?php wp_nonce_field('aiseogeo_apply_rewrite_' . $rewrite->id); ?>
    <h2>Что применить к оригинальной записи</h2>
    <p class="description">Можно применить только отдельные поля. Например, только SEO title и description, не трогая основной текст.</p>
    <div class="aiseogeo-grid two">
      <?php foreach ($fields as $key=>$label): ?>
        <label class="aiseogeo-check"><input type="checkbox" name="fields[]" value="<?php echo esc_attr($key); ?>" <?php checked(in_array($key, array('title','content','excerpt','meta_title','meta_description'), true)); ?>> <?php echo esc_html($label); ?></label>
      <?php endforeach; ?>
    </div>
    <p><button class="button button-primary">Создать backup и применить выбранные поля</button> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id=' . absint($rewrite->id))); ?>">Отмена</a></p>
  </form>
</div>

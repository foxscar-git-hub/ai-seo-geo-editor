<?php if (!defined('ABSPATH')) { exit; }

// ─── Группируем логи по сеансам ───────────────────────────────────────────────
$rewrite_contexts = array('rewrite_step', 'rewrite_plan', 'auto_rewrite');
$sessions   = array();
$other_logs = array();

foreach ($logs as $l) {
    $d   = json_decode((string)$l->data_json, true);
    $rid = !empty($d['rewrite_id']) ? (int)$d['rewrite_id'] : 0;
    if (in_array($l->context, $rewrite_contexts, true) && $rid) {
        if (!isset($sessions[$rid])) { $sessions[$rid] = array(); }
        $sessions[$rid][] = array('log' => $l, 'data' => is_array($d) ? $d : array());
    } else {
        $other_logs[] = array('log' => $l, 'data' => is_array($d) ? $d : array());
    }
}
$sessions = array_reverse($sessions, true);

// ─── Хелперы ──────────────────────────────────────────────────────────────────

function aig_find($slogs, $stage_substr = '', $msg_substr = '') {
    foreach ($slogs as $e) {
        $stage_match = $stage_substr && strpos((string)($e['data']['этап'] ?? ''), $stage_substr) !== false;
        $msg_match   = $msg_substr   && strpos((string)$e['log']->message, $msg_substr) !== false;
        if ($stage_match || $msg_match) { return $e; }
    }
    return null;
}

function aig_v($data, $key, $def = '—') {
    if (!isset($data[$key]) || $data[$key] === '' || $data[$key] === null) { return $def; }
    $v = $data[$key];
    return is_array($v) ? implode(', ', array_map('strval', $v)) : (string)$v;
}

/** Вернуть HTML строки этапа со статусом, коротким текстом и раскрывашкой */
function aig_stage_row($num, $label, $icon, $status, $short, $detail_html = '') {
    $st_icon  = array('ok'=>'✓','err'=>'✗','skip'=>'·','warn'=>'⚠')[$status] ?? '·';
    $st_color = array('ok'=>'#065f46','err'=>'#991b1b','skip'=>'#9ca3af','warn'=>'#b45309')[$status] ?? '#9ca3af';
    $st_bg    = array('ok'=>'#d1fae5','err'=>'#fee2e2','skip'=>'#f3f4f6','warn'=>'#fef3c7')[$status] ?? '#f3f4f6';
    $row_bg   = $status === 'err' ? 'background:#fff8f8' : ($status === 'ok' ? '' : 'background:#fafafa');

    $detail_btn = '';
    if ($detail_html !== '') {
        $uid = 'aig_d_' . $num . '_' . rand(10000, 99999);
        $detail_btn = '<details id="' . $uid . '" style="margin-top:4px">
            <summary style="cursor:pointer;font-size:11px;color:#2271b1;list-style:none;display:inline-flex;align-items:center;gap:3px">
                <span class="aig-arrow">▸</span> Подробнее
            </summary>
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:4px;padding:10px 12px;margin-top:6px;font-size:12px;line-height:1.6;white-space:pre-wrap;word-break:break-word;max-height:320px;overflow-y:auto">'
            . $detail_html .
            '</div></details>';
    }

    return '<tr style="' . $row_bg . '">
        <td style="width:36px;text-align:center;padding:8px 4px;vertical-align:top">
            <span style="display:inline-flex;width:22px;height:22px;border-radius:50%;background:' . $st_bg . ';color:' . $st_color . ';align-items:center;justify-content:center;font-size:12px;font-weight:700">' . $st_icon . '</span>
        </td>
        <td style="padding:8px 6px;vertical-align:top;width:28px;color:#6b7280;font-size:11px;font-weight:600;white-space:nowrap">' . esc_html($icon) . '</td>
        <td style="padding:8px 8px 8px 0;vertical-align:top">
            <div style="font-size:13px"><strong>' . esc_html('Этап ' . $num . ':') . '</strong> ' . esc_html($label) . '</div>
            ' . ($short !== '' ? '<div style="font-size:12px;color:#555;margin-top:2px">' . esc_html($short) . '</div>' : '') . '
            ' . $detail_btn . '
        </td>
    </tr>';
}

/** Фазовый заголовок */
function aig_phase($letter, $title) {
    return '<tr><td colspan="3" style="background:#1e293b;color:#e2e8f0;padding:7px 12px;font-size:11px;font-weight:700;letter-spacing:.8px;text-transform:uppercase">'
        . esc_html('Фаза ' . $letter . ' — ' . $title) . '</td></tr>';
}

$mode_labels = array(
    'full_refresh'=>'Полное обновление','soft_improve'=>'Мягкое улучшение','seo_boost'=>'SEO-усиление',
    'geo_boost'=>'GEO-усиление','seo_geo_boost'=>'SEO+GEO','meta_only'=>'Только мета','problem_blocks_only'=>'Проблемные блоки'
);

?>
<style>
.aig-wrap{background:#fff;border:1px solid #ddd;border-radius:6px;margin-bottom:20px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.aig-head{display:flex;align-items:center;gap:10px;padding:11px 16px;background:#f8f9fa;border-bottom:2px solid #e2e4e7;flex-wrap:wrap}
.aig-badge{display:inline-block;padding:2px 9px;border-radius:10px;font-size:11px;font-weight:600}
.aig-table{width:100%;border-collapse:collapse}
.aig-table td{border-bottom:1px solid #f0f0f1}
.aig-table tr:last-child td{border-bottom:none}
details[open] .aig-arrow{transform:rotate(90deg);display:inline-block}
.aig-arrow{display:inline-block;transition:transform .15s}
</style>

<div class="wrap aiseogeo-wrap">
<h1 style="margin-bottom:10px">Диагностика</h1>

<?php
$api_ok  = $settings->get('api_key','') !== '';
$tables_ok = !in_array(false, array_values($tables), true);
$tables_err = array_keys(array_filter($tables, function($v){ return !$v; }));
?>
<div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:9px 14px;margin-bottom:16px;display:flex;flex-wrap:wrap;gap:0;align-items:center;font-size:12px;color:#444;line-height:1.4">
  <span style="margin-right:16px"><strong style="color:#1e293b">Плагин</strong> <?php echo esc_html(AISEOGEO_VERSION); ?></span>
  <span style="margin-right:16px"><strong style="color:#1e293b">WP</strong> <?php echo esc_html(get_bloginfo('version')); ?></span>
  <span style="margin-right:16px"><strong style="color:#1e293b">PHP</strong> <?php echo esc_html(PHP_VERSION); ?></span>
  <span style="margin-right:16px"><strong style="color:#1e293b">API</strong> <?php echo $api_ok ? '<span style="color:#065f46;font-weight:600">✓ ключ указан</span>' : '<span style="color:#b91c1c;font-weight:600">✗ ключ не указан</span>'; ?></span>
  <span style="margin-right:16px"><strong style="color:#1e293b">Модель</strong> <?php echo esc_html($settings->get('model','—')); ?></span>
  <span><strong style="color:#1e293b">БД&nbsp;</strong>
  <?php if ($tables_ok): ?>
    <span style="color:#065f46;font-weight:600">✓ все таблицы OK</span>
  <?php else: ?>
    <span style="color:#b91c1c;font-weight:600">✗ нет: <?php echo esc_html(implode(', ', $tables_err)); ?></span>
  <?php endif; ?>
  </span>
</div>

<?php
if (!empty($_GET['deleted'])) {
    echo '<div class="notice notice-success is-dismissible"><p>Сеанс удалён из истории.</p></div>';
}
if (!empty($_GET['cleared'])) {
    echo '<div class="notice notice-success is-dismissible"><p>История логов очищена.</p></div>';
}
?>

<?php if (!empty($sessions)): ?>
<div class="aiseogeo-card" style="margin-top:20px">
<div style="padding:14px 16px;border-bottom:1px solid #e2e4e7;display:flex;align-items:center;justify-content:space-between;gap:12px">
  <h2 style="margin:0">Сеансы переписывания</h2>
  <div style="display:flex;align-items:center;gap:10px">
    <span style="font-size:12px;color:#666">последние <?php echo count($sessions); ?></span>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('Очистить всю историю логов? Это нельзя отменить.')">
      <input type="hidden" name="action" value="aiseogeo_clear_logs">
      <?php wp_nonce_field('aiseogeo_clear_logs'); ?>
      <button type="submit" class="button" style="color:#b91c1c;border-color:#fca5a5;font-size:12px;height:28px;line-height:26px;padding:0 10px">🗑 Очистить всё</button>
    </form>
  </div>
</div>

<?php foreach ($sessions as $rid => $slogs):
    $rw      = isset($rewrites_map[$rid]) ? $rewrites_map[$rid] : null;
    $title   = $rw ? (string)$rw->original_title : ('Сеанс #' . $rid);
    if (empty($title)) { $title = 'Сеанс #' . $rid; }
    $mode    = $rw ? (string)$rw->rewrite_mode : '';
    $rstatus = $rw ? (string)$rw->rewrite_status : '';
    $post_id = $rw ? (int)$rw->post_id : 0;

    $last_e  = $slogs[0];
    $first_e = end($slogs); reset($slogs);
    $started = substr((string)$first_e['log']->created_at, 0, 16);
    $tot_sec = isset($last_e['data']['сек_от_старта']) ? (float)$last_e['data']['сек_от_старта'] : 0;
    $t_str   = $tot_sec >= 60 ? round($tot_sec/60,1) . ' мин' : ($tot_sec > 0 ? $tot_sec . ' сек' : '');

    $has_err = false;
    foreach ($slogs as $e) { if ($e['log']->level === 'error') { $has_err = true; break; } }
    $is_done = ($rstatus === 'done');
    $st_txt  = $has_err ? '✗ Ошибка' : ($is_done ? '✓ Готово' : '⟳ В процессе');
    $st_css  = $has_err ? 'background:#fee2e2;color:#991b1b' : ($is_done ? 'background:#d1fae5;color:#065f46' : 'background:#fef3c7;color:#92400e');
    $ml      = $mode_labels[$mode] ?? $mode;

    // ── Находим нужные записи ──────────────────────────────────────────────────
    $e1  = aig_find($slogs, 'Этап 1');
    $e2  = aig_find($slogs, 'Этап 2');
    $e3  = aig_find($slogs, 'Этап 3');
    $e4  = aig_find($slogs, 'Этап 4');
    $e5p = aig_find($slogs, '', 'Структурный скелет с черновым контентом готов');
    $e5s = aig_find($slogs, '', 'Загружен черновой план');
    $e5  = $e5p ?? $e5s;
    $e6r = aig_find($slogs, '', 'Запрос к AI');
    $e6a = aig_find($slogs, '', 'Ответ AI получен');
    $e7  = aig_find($slogs, 'Этап 7');
    $e8  = aig_find($slogs, 'Этап 8');
    $e9  = aig_find($slogs, 'Этап 9');
    $e10 = aig_find($slogs, 'Этап 10');
    $e11 = aig_find($slogs, 'Этап 11');
    $e12 = aig_find($slogs, 'Этап 12');
    $e13v= aig_find($slogs, 'QA (объём)');
    $e13j= aig_find($slogs, 'QA (JSON)');
    $e14 = aig_find($slogs, 'Этап 14');
    $edone = aig_find($slogs, 'Готово');
?>
<div class="aig-wrap" style="border-radius:0;border-left:none;border-right:none;border-top:none;margin-bottom:8px">

  <div class="aig-head">
    <span style="font-size:18px">📄</span>
    <span style="font-weight:600;font-size:14px;flex:1;min-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?php echo esc_attr($title); ?>">
      <?php if ($post_id): ?><a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>" target="_blank" style="color:inherit;text-decoration:none"><?php echo esc_html($title); ?></a>
      <?php else: echo esc_html($title); endif; ?>
    </span>
    <?php if ($ml): ?><span class="aig-badge" style="background:#e0e7ff;color:#3730a3"><?php echo esc_html($ml); ?></span><?php endif; ?>
    <span class="aig-badge" style="<?php echo $st_css; ?>"><?php echo $st_txt; ?></span>
    <span style="font-size:11px;color:#777"><?php echo esc_html($started); ?><?php if ($t_str): ?> · ⏱ <?php echo esc_html($t_str); ?><?php endif; ?> · <?php echo count($slogs); ?> событий</span>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:0" onsubmit="return confirm('Удалить этот сеанс из истории?')">
      <input type="hidden" name="action" value="aiseogeo_delete_log_session">
      <input type="hidden" name="rewrite_id" value="<?php echo absint($rid); ?>">
      <?php wp_nonce_field('aiseogeo_delete_log_session_' . absint($rid)); ?>
      <button type="submit" class="button button-small" style="color:#b91c1c;border-color:#fca5a5;font-size:11px;height:24px;line-height:22px;padding:0 8px" title="Удалить сеанс">🗑</button>
    </form>
  </div>

  <table class="aig-table">

  <?php
  // ═══════════════════════════════════════════
  // ФАЗА А — ИССЛЕДОВАНИЕ И ПЛАНИРОВАНИЕ
  // ═══════════════════════════════════════════
  echo aig_phase('А', 'Исследование и планирование');

  // ── Этап 1: Анализ аудитории ──────────────
  $d1 = $e1 ? $e1['data'] : array();
  $short1 = aig_v($d1,'стратегия');
  if (mb_strlen($short1) > 150) { $short1 = mb_substr($short1,0,150) . '…'; }
  $keep_n = aig_v($d1,'сохраняем_блоков');
  $short1 .= ($keep_n !== '—' ? ' · сохраняем блоков: ' . $keep_n : '');
  $det1 = '';
  if ($e1) {
      $s = aig_v($d1,'_detail_strategy','');
      $k = aig_v($d1,'_detail_keep','');
      $det1 = ($s !== '' ? "СТРАТЕГИЯ:\n" . $s : '') . ($k !== '' ? "\n\nЧТО СОХРАНЯЕМ:\n• " . $k : '');
  }
  echo aig_stage_row(1, 'Анализ аудитории и болей читателя', '👥', $e1 ? 'ok' : 'skip', $e1 ? $short1 : 'выполняется внутри AI', $det1);

  // ── Этап 2: Анализ конкурентов ────────────
  $d2 = $e2 ? $e2['data'] : array();
  $s2 = aig_v($d2,'слабых_мест'); $a2 = aig_v($d2,'добавить_элементов');
  $short2 = ($s2!=='—'?'слабых мест: '.$s2:'') . ($a2!=='—'?' · добавить: '.$a2:'');
  $det2 = '';
  if ($e2) {
      $i = aig_v($d2,'_detail_improve',''); $a = aig_v($d2,'_detail_add','');
      $det2 = ($i!=='' ? "ЧТО УЛУЧШИТЬ:\n".$i : '') . ($a!=='' ? "\n\nЧТО ДОБАВИТЬ:\n".$a : '');
  }
  echo aig_stage_row(2, 'Анализ слабых мест и конкурентных пробелов', '🔬', $e2 ? 'ok' : 'skip', $e2 ? $short2 : 'выполняется внутри AI', $det2);

  // ── Этап 3: Семантика ─────────────────────
  $d3 = $e3 ? $e3['data'] : array();
  $h3 = aig_v($d3,'изменений_H2'); $t3 = aig_v($d3,'новый_H1'); $c3 = aig_v($d3,'клише_найдено');
  $short3 = ($h3!=='—'?'изменений H2: '.$h3:'') . ($c3!=='—'?' · клише найдено: '.$c3:'') . ($t3!=='—'?' · новый H1: '.mb_substr($t3,0,60):'');
  $det3 = '';
  if ($e3) {
      $hh = aig_v($d3,'_detail_headings',''); $mm = aig_v($d3,'_detail_meta',''); $cc = aig_v($d3,'_detail_cliches','');
      $det3 = ($hh!==''?"ИЗМЕНЕНИЯ H2:\n".$hh:'') . ($mm!==''?"\n\nМЕТА-ЧЕРНОВИКИ:\n".$mm:'') . ($cc!==''?"\n\nКЛИШЕ НАЙДЕНЫ:\n".$cc:'');
  }
  echo aig_stage_row(3, 'Семантика: заголовки, мета, Anti-AI правки', '🏷️', $e3 ? 'ok' : 'skip', $e3 ? $short3 : 'выполняется внутри AI', $det3);

  // ── Этап 4: Исследование ──────────────────
  $d4 = $e4 ? $e4['data'] : array();
  $s4n = aig_v($d4,'источников'); $s4e = aig_v($d4,'примеры');
  $short4 = ($s4n!=='—'?'источников: '.$s4n:'') . ($s4e!=='—'?' · '.$s4e:'');
  $det4 = $e4 ? aig_v($d4,'_detail_sources','') : '';
  echo aig_stage_row(4, 'Исследование источников и экспертных данных', '📚', $e4 ? 'ok' : 'skip', $e4 ? $short4 : 'выполняется внутри AI', $det4 !== '' ? "ИСТОЧНИКИ:\n" . $det4 : '');

  // ── Этап 5: Структурный план ──────────────
  $d5 = $e5 ? $e5['data'] : array();
  $h5 = aig_v($d5,'h2_с_tldr'); $f5 = aig_v($d5,'faq_черновик'); $src5 = aig_v($d5,'источники_черновик');
  $short5 = ($h5!=='—'?'H2 с TL;DR: '.$h5:'') . ($f5!=='—'?' · FAQ: '.$f5.' пар':'') . ($src5!=='—'?' · источники: '.$src5:'');
  $det5 = '';
  if ($e5) {
      $hp5 = aig_v($d5,'hero_promise'); $tbl5 = aig_v($d5, 'сравнит_таблица', aig_v($d5,'таблица'));
      $det5 = "Hero Promise: " . $hp5 . "\nH2 с TL;DR: " . $h5 . "\nFAQ черновик: " . $f5 . " пар Q&A\nИсточники: " . $src5 . "\nСравнительная таблица: " . $tbl5;
  }
  echo aig_stage_row(5, 'Структурный скелет с черновым контентом', '📋', $e5 ? 'ok' : 'skip', $e5 ? $short5 : 'план не создан', $det5);

  // ═══════════════════════════════════════════
  // ФАЗА Б — НАПИСАНИЕ
  // ═══════════════════════════════════════════
  echo aig_phase('Б', 'Написание');

  // ── Этап 6: Написание ────────────────────
  $d6r = $e6r ? $e6r['data'] : array();
  $d6a = $e6a ? $e6a['data'] : array();
  $model6 = aig_v($d6r,'модель'); $tok6 = aig_v($d6r,'лимит_токенов'); $len6 = aig_v($d6a,'длина_ответа_симв');
  $short6 = ($model6!=='—'?$model6:'') . ($tok6!=='—'?' · '.$tok6.' tok':'') . ($len6!=='—'?' · ответ: '.$len6.' симв':'');
  $e6_ok = $e6r && $e6a;
  echo aig_stage_row(6, 'Написание (AI-запрос → ответ)', '🤖', $e6_ok ? 'ok' : ($e6r ? 'warn' : 'skip'), $e6_ok ? $short6 : ($e6r ? 'ожидание ответа…' : 'не запущено'), '');

  // ═══════════════════════════════════════════
  // ФАЗА В — РЕДАКТУРА
  // ═══════════════════════════════════════════
  echo aig_phase('В', 'Редактура');

  // ── Этап 7: Редактура логики ──────────────
  $d7 = $e7 ? $e7['data'] : array();
  $w7 = aig_v($d7,'предупреждений'); $c7 = aig_v($d7,'уверенность_AI'); $p7 = aig_v($d7,'сохранено_блоков');
  $short7 = ($w7!=='—'?'предупреждений: '.$w7:'') . ($c7!=='—'?' · уверенность AI: '.$c7:'') . ($p7!=='—'?' · сохранено блоков: '.$p7:'');
  $det7 = '';
  if ($e7) {
      $dw = aig_v($d7,'_detail_warnings',''); $dp = aig_v($d7,'_detail_preserved','');
      $det7 = ($dw!==''?"ПРЕДУПРЕЖДЕНИЯ:\n".$dw:'') . ($dp!=='' && $dp!=='—' ? "\n\nСОХРАНЁННЫЕ БЛОКИ:\n".$dp:'');
  }
  $e7_st = $e7 ? ((int)$w7 === 0 ? 'ok' : 'warn') : 'skip';
  echo aig_stage_row(7, 'Редактура логики, фактов и важных блоков', '🧠', $e7_st, $e7 ? $short7 : 'выполняется внутри AI', $det7);

  // ── Этап 8: Редактура стиля ───────────────
  $d8 = $e8 ? $e8['data'] : array();
  $sym8 = aig_v($d8,'симметрий_переписано');
  $short8 = $sym8 !== '—' ? 'симметрий переписано: ' . $sym8 : '';
  $det8 = $e8 ? aig_v($d8,'_detail_symmetries','') : '';
  echo aig_stage_row(8, 'Редактура стиля: симметрии, ритм, кальки', '✏️', $e8 ? 'ok' : 'skip', $e8 ? $short8 : 'выполняется внутри AI', $det8 !== '' ? "СИММЕТРИИ ПЕРЕПИСАНЫ:\n" . $det8 : '');

  // ═══════════════════════════════════════════
  // ФАЗА Г — QA И ОПТИМИЗАЦИЯ
  // ═══════════════════════════════════════════
  echo aig_phase('Г', 'QA и оптимизация');

  // ── Этап 9: SEO/GEO QA ───────────────────
  $d9 = $e9 ? $e9['data'] : array();
  $h9 = aig_v($d9,'H2_разделов'); $cta9 = aig_v($d9,'CTA_точек'); $faq9 = aig_v($d9,'FAQ'); $src9 = aig_v($d9,'блок_источников'); $tbl9 = aig_v($d9,'таблиц');
  $h9_ok = $e9 && (int)$h9 >= 8 && (int)$h9 <= 14;
  $short9 = ($h9!=='—'?'H2: '.$h9.($h9_ok?'✓':'⚠'):'') . ($cta9!=='—'?' · CTA: '.$cta9:'') . ($faq9!=='—'?' · FAQ: '.$faq9:'') . ($src9!=='—'?' · источники: '.$src9:'') . ($tbl9!=='—'?' · таблиц: '.$tbl9:'');
  $det9_lines = array();
  if ($e9) {
      if ($h9!=='—') { $det9_lines[] = 'H2 разделов: ' . $h9 . ' (норма 8-14)' . ($h9_ok?' ✓':' ⚠ не в норме'); }
      if ($cta9!=='—') { $det9_lines[] = 'CTA-точки: ' . $cta9 . ' (норма 3)' . ((int)$cta9===3?' ✓':' ⚠'); }
      if ($faq9!=='—') { $det9_lines[] = 'FAQ-блок: ' . $faq9 . ($faq9==='да'?' ✓':' ⚠ не найден'); }
      if ($src9!=='—') { $det9_lines[] = 'Блок источники: ' . $src9 . ($src9==='да'?' ✓':' ⚠'); }
      if ($tbl9!=='—') { $det9_lines[] = 'Сравнительных таблиц: ' . $tbl9 . ((int)$tbl9>=1?' ✓':' ⚠ нет'); }
      $ol9 = aig_v($d9,'нумерованных_списков'); if($ol9!=='—'){$det9_lines[]='Нумерованных списков: '.$ol9;}
      $lnk9 = aig_v($d9,'внутренних_ссылок'); if($lnk9!=='—'){$det9_lines[]='Внутренних ссылок: '.$lnk9.((int)$lnk9>=3?' ✓':' ⚠ нужно ≥3');}
      $hp9 = aig_v($d9,'hero_promise'); if($hp9!=='—'){$det9_lines[]='Hero Promise: '.$hp9;}
  }
  $e9_bad = $e9 && ((int)$h9 < 8 || (int)$h9 > 14 || (int)$cta9 < 3 || $faq9==='нет' || $src9==='нет');
  echo aig_stage_row(9, 'SEO/GEO QA — структурная проверка (Блок Б)', '🔎', $e9 ? ($e9_bad?'warn':'ok') : 'skip', $e9 ? $short9 : '—', $e9 ? implode("\n", $det9_lines) : '');

  // ── Этап 10: Мета ────────────────────────
  $d10 = $e10 ? $e10['data'] : array();
  $h1_10 = aig_v($d10,'новый_H1'); $md10 = aig_v($d10,'meta_desc_длина');
  $short10 = ($h1_10!=='—'?mb_substr($h1_10,0,80):'') . ($md10!=='—'?' · description: '.$md10:'');
  $det10 = '';
  if ($e10) {
      $mt = aig_v($d10,'_detail_meta_title',''); $md = aig_v($d10,'_detail_meta_desc',''); $ex = aig_v($d10,'_detail_excerpt','');
      $det10 = "H1: " . $h1_10 . "\nMeta title: " . $mt . "\nMeta description: " . $md . "\nExcerpt: " . $ex;
  }
  echo aig_stage_row(10, 'Мета-оптимизация: title, description, excerpt', '📌', $e10 ? 'ok' : 'skip', $e10 ? $short10 : 'выполняется внутри AI', $det10);

  // ── Этап 11: Anti-AI ─────────────────────
  $d11 = $e11 ? $e11['data'] : array();
  $em11 = aig_v($d11,'длинных_тире_в_тексте'); $cl11 = aig_v($d11,'клише_убрано'); $af11 = aig_v($d11,'answer_first_добавлено'); $h2q11 = aig_v($d11,'H2_в_вопрос');
  $em_bad = $e11 && (int)$em11 > 0;
  $short11 = ($em11!=='—'?'тире осталось: '.$em11.($em_bad?' ⚠':' ✓'):'') . ($cl11!=='—'?' · клише убрано: '.$cl11:'') . ($af11!=='—'?' · Answer-First: '.$af11.' H2':'') . ($h2q11!=='—'?' · H2→вопрос: '.$h2q11:'');
  $det11 = array();
  if ($e11) {
      $det11[] = 'В.1 Длинных тире (—) осталось: ' . $em11 . ($em_bad?' ⚠ нужно 0!':' ✓');
      $er11 = aig_v($d11,'тире_заменено'); if($er11!=='—'){$det11[]='В.1 Тире заменено при написании: '.$er11;}
      if($cl11!=='—'){$det11[]='В.2 Клише убрано: '.$cl11;}
      if($af11!=='—'){$det11[]='В.3 Answer-First (TL;DR) добавлен в: '.$af11.' H2';}
      if($h2q11!=='—'){$det11[]='Б.2 H2 переведено в вопрос: '.$h2q11;}
  }
  $e11_st = $e11 ? ($em_bad ? 'warn' : 'ok') : 'skip';
  echo aig_stage_row(11, 'Anti-AI хуманизация (Блок В)', '✂️', $e11_st, $e11 ? $short11 : '—', implode("\n", $det11));

  // ── Этап 12: Внутренние ссылки ────────────
  $d12 = $e12 ? $e12['data'] : array();
  $lnk12 = aig_v($d12,'внутренних_ссылок'); $nrm12 = aig_v($d12,'норма');
  $short12 = ($lnk12!=='—'?'ссылок: '.$lnk12:'') . ($nrm12!=='—'?' · '.$nrm12:'');
  $e12_st = $e12 ? ((int)$lnk12 >= 3 ? 'ok' : 'warn') : 'skip';
  echo aig_stage_row(12, 'Внутренние ссылки (мин. 3, Б.13)', '🔗', $e12_st, $e12 ? $short12 : 'проверяется внутри AI', '');

  // ── Этап 13: Финальная QA ────────────────
  $d13j = $e13j ? $e13j['data'] : array();
  $d13v = $e13v ? $e13v['data'] : array();
  $orig13 = aig_v($d13v,'оригинал_симв'); $new13 = aig_v($d13v,'новая_версия_симв'); $growth13 = aig_v($d13v,'рост');
  $json_ok = $e13j ? (strpos(strtolower((string)$e13j['log']->message),'корректен')!==false || strpos((string)$e13j['log']->message,'восстановлен')!==false) : false;
  $vol_ok  = $e13v ? strpos(strtolower((string)$e13v['log']->message),'пройдена')!==false : false;
  $short13 = 'JSON: ' . ($json_ok ? 'OK' : ($e13j ? '⚠ ошибка' : '—')) . ($orig13!=='—'?' · '.$orig13.'→'.$new13.' симв':'') . ($growth13!=='—'?' ('.$growth13.')':'');
  $det13 = array();
  if ($e13j) { $det13[] = 'JSON разбор: ' . (string)$e13j['log']->message; }
  if ($e13v) { $det13[] = 'Объём: ' . $orig13 . ' → ' . $new13 . ' симв (рост: ' . $growth13 . ')'; }
  $e13_st = ($e13j || $e13v) ? (($json_ok || !$e13j) && ($vol_ok || !$e13v) ? 'ok' : 'warn') : 'skip';
  echo aig_stage_row(13, 'Финальная QA: JSON + объём статьи', '📏', $e13_st, ($e13j||$e13v) ? $short13 : '—', implode("\n", $det13));

  // ── Этап 14: Schema ───────────────────────
  $d14 = $e14 ? $e14['data'] : array();
  $sch14 = aig_v($d14,'тип_schema');
  $det14 = $e14 ? aig_v($d14,'_detail_schema','') : '';
  echo aig_stage_row(14, 'JSON-LD Schema разметка (Блок Г)', '🏷️', $e14 ? 'ok' : 'skip', $e14 ? 'тип: ' . $sch14 : 'выполняется внутри AI', $det14 !== '' && $det14 !== '—' ? "SCHEMA JSON:\n" . $det14 : '');

  // ═══════════════════════════════════════════
  // ФАЗА Д — ПУБЛИКАЦИЯ
  // ═══════════════════════════════════════════
  echo aig_phase('Д', 'Публикация и мониторинг');

  // ── Этап 15: Применение ───────────────────
  $applied = in_array($rstatus, array('applied','draft_created'), true);
  $done_d  = $edone ? $edone['data'] : array();
  $vol_fin = aig_v($done_d,'итоговый_объём_симв'); $steps_fin = aig_v($done_d,'всего_шагов');
  $short15 = $is_done ? 'версия создана' . ($vol_fin!=='—'?' · '.$vol_fin.' симв':'') . ($steps_fin!=='—'?' · '.$steps_fin.' шагов':'') . ($t_str?' · '.$t_str:'') : ($has_err ? 'завершено с ошибкой' : 'ожидает запуска');
  $e15_st  = $is_done ? ($applied?'ok':'warn') : ($has_err?'err':'skip');
  $e15_lbl = $is_done ? ($applied?'Применена к статье':'Версия готова, ожидает применения') : ($has_err?'Ошибка':'Ещё не завершено');
  echo aig_stage_row(15, 'Применение улучшенной версии к статье', '🚀', $e15_st, $short15, '');

  // ── Этап 16: Мониторинг ───────────────────
  echo aig_stage_row(16, 'Постпубликационный мониторинг (Автообучение)', '📊', 'skip', 'AI SEO/GEO Редактор → Автообучение', '');
  ?>

  </table>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (!empty($other_logs)): ?>
<div class="aiseogeo-card" style="margin-top:20px">
  <div style="padding:14px 16px;border-bottom:1px solid #e2e4e7"><h2 style="margin:0">Прочие события</h2></div>
  <table class="widefat striped" style="font-size:12px">
    <thead><tr><th style="width:130px">Дата</th><th style="width:55px">Уровень</th><th style="width:110px">Контекст</th><th>Сообщение</th></tr></thead>
    <tbody>
    <?php foreach ($other_logs as $entry):
        $l = $entry['log']; $data = $entry['data'];
        $bg = $l->level === 'error' ? 'background:#fcebea' : '';
        $parts = array();
        foreach ($data as $k=>$v) {
            if ($k === 'raw') { continue; }
            if (is_array($v)) { $v = implode(', ', array_map('strval', $v)); }
            if ($v===''||$v===null) { continue; }
            $parts[] = '<b>'.esc_html($k).':</b> '.esc_html((string)$v);
        }
    ?>
    <tr style="<?php echo $bg; ?>">
      <td><?php echo esc_html(substr($l->created_at,0,16)); ?></td>
      <td><?php echo esc_html($l->level); ?></td>
      <td><?php echo esc_html($l->context); ?></td>
      <td><?php echo esc_html($l->message); ?><?php if($parts): ?><br><span style="color:#666;font-size:11px"><?php echo implode(' &nbsp;·&nbsp; ',$parts); ?></span><?php endif; ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

</div>

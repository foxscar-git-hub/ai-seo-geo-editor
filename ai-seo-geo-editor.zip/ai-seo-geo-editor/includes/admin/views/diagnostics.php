<?php if (!defined('ABSPATH')) { exit; }

// ─── Группируем логи по сеансам ───────────────────────────────────────────────
$rewrite_contexts = array('rewrite_step', 'rewrite_plan', 'auto_rewrite');
$sessions   = array();
$other_logs = array();

foreach ($logs as $l) {
    $d   = json_decode((string)$l->data_json, true);
    $rid = !empty($d['rewrite_id']) ? (int)$d['rewrite_id'] : 0;
    if (in_array($l->context, $rewrite_contexts, true) && $rid) {
        if (!isset($sessions[$rid])) { $sessions[$rid] = array(); }
        $sessions[$rid][] = array('log' => $l, 'data' => is_array($d) ? $d : array());
    } else {
        $other_logs[] = array('log' => $l, 'data' => is_array($d) ? $d : array());
    }
}
$sessions = array_reverse($sessions, true);

// ─── Хелперы ──────────────────────────────────────────────────────────────────

function aig_find($slogs, $stage_substr = '', $msg_substr = '') {
    foreach ($slogs as $e) {
        $stage_match = $stage_substr && strpos((string)($e['data']['этап'] ?? ''), $stage_substr) !== false;
        $msg_match   = $msg_substr   && strpos((string)$e['log']->message, $msg_substr) !== false;
        if ($stage_match || $msg_match) { return $e; }
    }
    return null;
}

function aig_v($data, $key, $def = '—') {
    if (!isset($data[$key]) || $data[$key] === '' || $data[$key] === null) { return $def; }
    $v = $data[$key];
    return is_array($v) ? implode(', ', array_map('strval', $v)) : (string)$v;
}

/** Вернуть HTML строки этапа со статусом, коротким текстом и раскрывашкой */
function aig_stage_row($num, $label, $icon, $status, $short, $detail_html = '') {
    $st_icon  = array('ok'=>'✓','err'=>'✗','skip'=>'·','warn'=>'⚠')[$status] ?? '·';
    $st_color = array('ok'=>'#065f46','err'=>'#991b1b','skip'=>'#9ca3af','warn'=>'#b45309')[$status] ?? '#9ca3af';
    $st_bg    = array('ok'=>'#d1fae5','err'=>'#fee2e2','skip'=>'#f3f4f6','warn'=>'#fef3c7')[$status] ?? '#f3f4f6';
    $row_bg   = $status === 'err' ? 'background:#fff8f8' : ($status === 'ok' ? '' : 'background:#fafafa');

    $detail_btn = '';
    if ($detail_html !== '') {
        $uid = 'aig_d_' . $num . '_' . rand(10000, 99999);
        $detail_btn = '<details id="' . $uid . '" style="margin-top:4px">
            <summary style="cursor:pointer;font-size:11px;color:#2271b1;list-style:none;display:inline-flex;align-items:center;gap:3px">
                <span class="aig-arrow">▸</span> Подробнее
            </summary>
            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:4px;padding:10px 12px;margin-top:6px;font-size:12px;line-height:1.6;white-space:pre-wrap;word-break:break-word;max-height:320px;overflow-y:auto">'
            . $detail_html .
            '</div></details>';
    }

    return '<tr style="' . $row_bg . '">
        <td style="width:36px;text-align:center;padding:8px 4px;vertical-align:top">
            <span style="display:inline-flex;width:22px;height:22px;border-radius:50%;background:' . $st_bg . ';color:' . $st_color . ';align-items:center;justify-content:center;font-size:12px;font-weight:700">' . $st_icon . '</span>
        </td>
        <td style="padding:8px 6px;vertical-align:top;width:28px;color:#6b7280;font-size:11px;font-weight:600;white-space:nowrap">' . esc_html($icon) . '</td>
        <td style="padding:8px 8px 8px 0;vertical-align:top">
            <div style="font-size:13px"><strong>' . esc_html('Этап ' . $num . ':') . '</strong> ' . esc_html($label) . '</div>
            ' . ($short !== '' ? '<div style="font-size:12px;color:#555;margin-top:2px">' . esc_html($short) . '</div>' : '') . '
            ' . $detail_btn . '
        </td>
    </tr>';
}

/** Фазовый заголовок */
function aig_phase($letter, $title) {
    return '<tr><td colspan="3" style="background:#1e293b;color:#e2e8f0;padding:7px 12px;font-size:11px;font-weight:700;letter-spacing:.8px;text-transform:uppercase">'
        . esc_html('Фаза ' . $letter . ' — ' . $title) . '</td></tr>';
}

$mode_labels = array(
    'full_refresh'=>'Полное обновление','soft_improve'=>'Мягкое улучшение','seo_boost'=>'SEO-усиление',
    'geo_boost'=>'GEO-усиление','seo_geo_boost'=>'SEO+GEO','meta_only'=>'Только мета','problem_blocks_only'=>'Проблемные блоки'
);

?>
<style>
.aig-wrap{background:#fff;border:1px solid #ddd;border-radius:6px;margin-bottom:20px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.aig-head{display:flex;align-items:center;gap:10px;padding:11px 16px;background:#f8f9fa;border-bottom:2px solid #e2e4e7;flex-wrap:wrap}
.aig-badge{display:inline-block;padding:2px 9px;border-radius:10px;font-size:11px;font-weight:600}
.aig-table{width:100%;border-collapse:collapse}
.aig-table td{border-bottom:1px solid #f0f0f1}
.aig-table tr:last-child td{border-bottom:none}
details[open] .aig-arrow{transform:rotate(90deg);display:inline-block}
.aig-arrow{display:inline-block;transition:transform .15s}
</style>

<div class="wrap aiseogeo-wrap">
<h1 style="margin-bottom:10px">Диагностика</h1>

<?php
$api_ok  = $settings->get('api_key','') !== '';
$tables_ok = !in_array(false, array_values($tables), true);
$tables_err = array_keys(array_filter($tables, function($v){ return !$v; }));
?>
<div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:9px 14px;margin-bottom:16px;display:flex;flex-wrap:wrap;gap:0;align-items:center;font-size:12px;color:#444;line-height:1.4">
  <span style="margin-right:16px"><strong style="color:#1e293b">Плагин</strong> <?php echo esc_html(AISEOGEO_VERSION); ?></span>
  <span style="margin-right:16px"><strong style="color:#1e293b">WP</strong> <?php echo esc_html(get_bloginfo('version')); ?></span>
  <span style="margin-right:16px"><strong style="color:#1e293b">PHP</strong> <?php echo esc_html(PHP_VERSION); ?></span>
  <span style="margin-right:16px"><strong style="color:#1e293b">API</strong> <?php echo $api_ok ? '<span style="color:#065f46;font-weight:600">✓ ключ указан</span>' : '<span style="color:#b91c1c;font-weight:600">✗ ключ не указан</span>'; ?></span>
  <span style="margin-right:16px"><strong style="color:#1e293b">Модель</strong> <?php echo esc_html($settings->get('model','—')); ?></span>
  <span><strong style="color:#1e293b">БД&nbsp;</strong>
  <?php if ($tables_ok): ?>
    <span style="color:#065f46;font-weight:600">✓ все таблицы OK</span>
  <?php else: ?>
    <span style="color:#b91c1c;font-weight:600">✗ нет: <?php echo esc_html(implode(', ', $tables_err)); ?></span>
  <?php endif; ?>
  </span>
</div>

<?php
if (!empty($_GET['deleted'])) {
    echo '<div class="notice notice-success is-dismissible"><p>Сеанс удалён из истории.</p></div>';
}
if (!empty($_GET['cleared'])) {
    echo '<div class="notice notice-success is-dismissible"><p>История логов очищена.</p></div>';
}
if (!empty($_GET['auto_ran'])) {
    echo '<div class="notice notice-success is-dismissible"><p>Запуск автооптимизации выполнен. Смотрите логи ниже — если статья нашлась, появятся этапы переписывания.</p></div>';
}
?>

<?php
// ─── Блок активных сеансов (rewriting/plan_created) ──────────────────────────
if (!empty($active_rewrites)):
    $mode_map = array('full_refresh'=>'Полное обновление','soft_improve'=>'Мягкое улучшение','seo_boost'=>'SEO-усиление','geo_boost'=>'GEO-усиление','seo_geo_boost'=>'SEO+GEO','meta_only'=>'Только мета','problem_blocks_only'=>'Проблемные блоки');
?>
<div class="aiseogeo-card" style="margin-top:20px;border:2px solid #f59e0b">
<div style="padding:12px 16px;background:#fffbeb;border-bottom:1px solid #fde68a;display:flex;align-items:center;gap:10px">
  <span style="font-size:18px">⚙️</span>
  <strong style="font-size:14px;color:#92400e">Переписывание выполняется прямо сейчас</strong>
  <span id="aig-spinner" style="width:14px;height:14px;border:2px solid #f59e0b;border-top-color:#92400e;border-radius:50%;display:inline-block;animation:aig-spin .7s linear infinite;margin-left:4px"></span>
  <a href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-diagnostics')); ?>" style="margin-left:auto;font-size:12px;color:#92400e">↻ Обновить</a>
</div>
<style>@keyframes aig-spin{to{transform:rotate(360deg)}}</style>
<?php foreach ($active_rewrites as $ar):
    $ar_post  = get_post((int)$ar->post_id);
    $ar_title = !empty($ar->original_title) ? $ar->original_title : ($ar_post ? $ar_post->post_title : 'Запись #'.$ar->post_id);
    $ar_mode  = $mode_map[$ar->rewrite_mode] ?? $ar->rewrite_mode;
    $ar_since = human_time_diff(strtotime($ar->updated_at), current_time('timestamp')) . ' назад';
    $ar_step_label = $ar->rewrite_status === 'plan_created' ? 'Создание плана...' : 'Переписывание идёт...';
    // Найти текущий шаг из логов если есть
    $ar_rid = (int)$ar->id;
    $ar_last_step = '—';
    if (isset($sessions[$ar_rid])) {
        foreach ($sessions[$ar_rid] as $sl) {
            if (!empty($sl['data']['этап'])) { $ar_last_step = (string)$sl['data']['этап']; break; }
        }
    }
?>
<div style="padding:12px 16px;border-bottom:1px solid #fde68a;display:flex;flex-wrap:wrap;align-items:center;gap:10px">
  <span style="font-size:16px">📄</span>
  <span style="font-weight:600;font-size:13px;flex:1;min-width:160px">
    <?php if ($ar->post_id): ?>
      <a href="<?php echo esc_url(get_edit_post_link($ar->post_id)); ?>" target="_blank" style="color:inherit;text-decoration:none"><?php echo esc_html($ar_title); ?></a>
    <?php else: echo esc_html($ar_title); endif; ?>
  </span>
  <?php if ($ar_mode): ?><span class="aig-badge" style="background:#e0e7ff;color:#3730a3"><?php echo esc_html($ar_mode); ?></span><?php endif; ?>
  <span class="aig-badge" style="background:#fef3c7;color:#92400e">⟳ <?php echo esc_html($ar_step_label); ?></span>
  <span style="font-size:11px;color:#777">обновлено <?php echo esc_html($ar_since); ?></span>
  <?php if ($ar_last_step !== '—'): ?>
    <span style="font-size:11px;color:#555">последний шаг: <strong><?php echo esc_html(mb_substr($ar_last_step, 0, 60)); ?></strong></span>
  <?php endif; ?>
  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:0;margin-left:auto">
    <input type="hidden" name="action"     value="aiseogeo_stop_rewrite">
    <input type="hidden" name="rewrite_id" value="<?php echo absint($ar->id); ?>">
    <?php wp_nonce_field('aiseogeo_stop_rewrite_' . absint($ar->id)); ?>
    <button type="submit" onclick="return confirm('Остановить переписывание? Его можно будет продолжить с незавершённого этапа.')"
      style="background:#b91c1c;color:#fff;border:0;border-radius:6px;padding:5px 12px;font-size:12px;cursor:pointer;font-weight:600">
      ⏹ Остановить
    </button>
  </form>
</div>

<table class="aig-table" style="background:#fffef7">
<?php
  // Показываем 16 этапов — завершённые (из логов), текущий (spinning), ожидающие
  $ar_slogs = $sessions[$ar_rid] ?? array();
  $done_stages = array();
  foreach ($ar_slogs as $sl) {
      if (!empty($sl['data']['этап'])) { $done_stages[] = (string)$sl['data']['этап']; }
  }
  $all_stages = array(
      array(1, 'Анализ аудитории и болей читателя', '👥', 'Этап 1'),
      array(2, 'Анализ слабых мест и конкурентных пробелов', '🔬', 'Этап 2'),
      array(3, 'Семантика: заголовки, мета, Anti-AI правки', '🏷️', 'Этап 3'),
      array(4, 'Исследование источников и экспертных данных', '📚', 'Этап 4'),
      array(5, 'Структурный скелет с черновым контентом', '📋', 'Этап 5'),
      array(6, 'Написание (AI-запрос → ответ)', '🤖', 'Этап 6'),
      array(7, 'Редактура логики, фактов и важных блоков', '🧠', 'Этап 7'),
      array(8, 'Редактура стиля: симметрии, ритм, кальки', '✏️', 'Этап 8'),
      array(9, 'SEO/GEO QA — структурная проверка', '🔎', 'Этап 9'),
      array(10, 'Мета-оптимизация: title, description, excerpt', '📝', 'Этап 10'),
      array(11, 'Anti-AI хуманизация', '🧬', 'Этап 11'),
      array(12, 'Внутренние ссылки (мин. 3)', '🔗', 'Этап 12'),
      array(13, 'Финальная QA: JSON + объём статьи', '✅', 'Этап 13'),
      array(14, 'JSON-LD Schema разметка', '📐', 'Этап 14'),
      array(15, 'Применение улучшенной версии к статье', '🚀', 'Этап 15'),
      array(16, 'Постпубликационный мониторинг (Автообучение)', '🎓', 'Этап 16'),
  );
  // Определяем текущий активный этап
  $last_done_n = 0;
  foreach ($done_stages as $ds) { if (preg_match('/Этап (\d+)/u', $ds, $m)) { $last_done_n = max($last_done_n, (int)$m[1]); } }
  $current_active = ($ar->rewrite_status === 'rewriting') ? $last_done_n + 1 : 0;
  if ($ar->rewrite_status === 'plan_created') { $current_active = 1; }

  foreach ($all_stages as list($n, $lbl, $ico, $stage_key)) {
      $is_done = false;
      foreach ($done_stages as $ds) { if (strpos($ds, $stage_key) !== false) { $is_done = true; break; } }
      $is_active = (!$is_done && $n === $current_active);
      if ($is_done) {
          echo aig_stage_row($n, $lbl, $ico, 'ok', 'выполнено');
      } elseif ($is_active) {
          // Анимированный текущий шаг
          echo '<tr style="background:#fffbeb"><td style="width:36px;text-align:center;padding:8px 4px;vertical-align:top">
              <span style="display:inline-block;width:22px;height:22px;border-radius:50%;border:2px solid #f59e0b;border-top-color:#92400e;animation:aig-spin .7s linear infinite"></span>
          </td><td style="padding:8px 6px;vertical-align:top;width:28px;color:#6b7280;font-size:11px;font-weight:600">' . esc_html($ico) . '</td>
          <td style="padding:8px 8px 8px 0;vertical-align:top">
              <div style="font-size:13px"><strong>Этап ' . $n . ':</strong> ' . esc_html($lbl) . '</div>
              <div style="font-size:12px;color:#92400e;margin-top:2px">⚙️ выполняется сейчас…</div>
          </td></tr>';
      } else {
          echo aig_stage_row($n, $lbl, $ico, 'skip', 'ожидает');
      }
  }
?>
</table>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php
// Блок остановленных / зависших переписываний (старше 30 мин в rewriting или статус stopped)
global $wpdb;
$stalled = $wpdb->get_results(
    "SELECT r.id, r.post_id, r.original_title, r.rewrite_mode, r.rewrite_status, r.updated_at, r.meta_json
     FROM {$wpdb->prefix}aiseogeo_rewrites r
     WHERE (
       (r.rewrite_status = 'stopped')
       OR (r.rewrite_status = 'rewriting' AND r.updated_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE))
       OR (r.rewrite_status = 'failed')
     )
     ORDER BY r.id DESC LIMIT 5"
);
if (!empty($stalled)): ?>
<div class="aiseogeo-card" style="margin-top:20px;border:2px solid #e5e7eb">
<div style="padding:12px 16px;background:#f9fafb;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;gap:10px">
  <span style="font-size:18px">⏸</span>
  <strong style="font-size:14px;color:#374151">Остановленные / зависшие переписывания</strong>
  <span style="font-size:12px;color:#6b7280;margin-left:auto">Можно продолжить с незавершённого этапа</span>
</div>
<?php foreach ($stalled as $sr):
    $sr_title = !empty($sr->original_title) ? $sr->original_title : 'Запись #'.$sr->post_id;
    $sr_meta  = json_decode((string)$sr->meta_json, true) ?: [];
    $sr_step  = intval($sr_meta['stopped_at_step'] ?? 0);
    $sr_when  = !empty($sr_meta['stopped_at']) ? human_time_diff(strtotime($sr_meta['stopped_at']), current_time('timestamp')) . ' назад' : human_time_diff(strtotime($sr->updated_at), current_time('timestamp')) . ' назад';
    $status_labels = array('stopped'=>'Остановлено','failed'=>'Ошибка','rewriting'=>'Зависло');
    $status_colors = array('stopped'=>'#374151','failed'=>'#b91c1c','rewriting'=>'#b45309');
    $sl = $status_labels[$sr->rewrite_status] ?? $sr->rewrite_status;
    $sc = $status_colors[$sr->rewrite_status] ?? '#555';
?>
<div style="padding:12px 16px;border-bottom:1px solid #e5e7eb;display:flex;flex-wrap:wrap;align-items:center;gap:10px">
  <span style="font-weight:600;font-size:13px;flex:1;min-width:160px"><?php echo esc_html($sr_title); ?></span>
  <span style="font-size:11px;background:#f3f4f6;color:<?php echo esc_attr($sc); ?>;padding:2px 8px;border-radius:99px;font-weight:600"><?php echo esc_html($sl); ?></span>
  <?php if ($sr_step > 0): ?>
    <span style="font-size:12px;color:#6b7280">остановлено на этапе <strong><?php echo esc_html($sr_step); ?></strong></span>
  <?php endif; ?>
  <span style="font-size:11px;color:#9ca3af"><?php echo esc_html($sr_when); ?></span>
  <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:0">
    <input type="hidden" name="action"     value="aiseogeo_resume_rewrite">
    <input type="hidden" name="rewrite_id" value="<?php echo absint($sr->id); ?>">
    <?php wp_nonce_field('aiseogeo_resume_rewrite_' . absint($sr->id)); ?>
    <button type="submit" style="background:#065f46;color:#fff;border:0;border-radius:6px;padding:5px 14px;font-size:12px;cursor:pointer;font-weight:600">
      ▶ Продолжить с этапа <?php echo $sr_step > 0 ? esc_html($sr_step) : '1'; ?>
    </button>
  </form>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (!empty($sessions)): ?>
<div class="aiseogeo-card" style="margin-top:20px">
<div style="padding:14px 16px;border-bottom:1px solid #e2e4e7;display:flex;align-items:center;justify-content:space-between;gap:12px">
  <h2 style="margin:0">Сеансы переписывания</h2>
  <div style="display:flex;align-items:center;gap:10px">
    <span style="font-size:12px;color:#666">последние <?php echo count($sessions); ?></span>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('Очистить всю историю логов? Это нельзя отменить.')">
      <input type="hidden" name="action" value="aiseogeo_clear_logs">
      <?php wp_nonce_field('aiseogeo_clear_logs'); ?>
      <button type="submit" class="button" style="color:#b91c1c;border-color:#fca5a5;font-size:12px;height:28px;line-height:26px;padding:0 10px">🗑 Очистить всё</button>
    </form>
  </div>
</div>

<?php foreach ($sessions as $rid => $slogs):
    $rw      = isset($rewrites_map[$rid]) ? $rewrites_map[$rid] : null;
    $title   = $rw ? (string)$rw->original_title : ('Сеанс #' . $rid);
    if (empty($title)) { $title = 'Сеанс #' . $rid; }
    $mode    = $rw ? (string)$rw->rewrite_mode : '';
    $rstatus = $rw ? (string)$rw->rewrite_status : '';
    $post_id = $rw ? (int)$rw->post_id : 0;

    $last_e  = $slogs[0];
    $first_e = end($slogs); reset($slogs);
    $started = substr((string)$first_e['log']->created_at, 0, 16);
    $tot_sec = isset($last_e['data']['сек_от_старта']) ? (float)$last_e['data']['сек_от_старта'] : 0;
    $t_str   = $tot_sec >= 60 ? round($tot_sec/60,1) . ' мин' : ($tot_sec > 0 ? $tot_sec . ' сек' : '');

    $has_err = false;
    foreach ($slogs as $e) { if ($e['log']->level === 'error') { $has_err = true; break; } }
    // 'applied' сохранён здесь для обратной совместимости со старыми записями (баг до v1.7.13,
    // когда rewrite_status ошибочно перезаписывался вместо отдельного apply_status).
    $is_done = in_array($rstatus, array('done', 'applied', 're_audited'), true);
    $st_txt  = $has_err ? '✗ Ошибка' : ($is_done ? '✓ Готово' : '⟳ В процессе');
    $st_css  = $has_err ? 'background:#fee2e2;color:#991b1b' : ($is_done ? 'background:#d1fae5;color:#065f46' : 'background:#fef3c7;color:#92400e');
    $ml      = $mode_labels[$mode] ?? $mode;

    // ── Находим нужные записи ──────────────────────────────────────────────────
    // Поддерживаем оба формата: старый (одиночный AI-вызов) и новый (пошаговый)
    $e1  = aig_find($slogs, 'Этап 1:') ?: aig_find($slogs, 'Этап 1');
    // Этап 2: в новом формате — запись с данными об аудитории И слабых местах
    $e2  = aig_find($slogs, 'Этап 2:') ?: aig_find($slogs, 'Этап 2');
    // В новом формате этап 2 хранит все данные исследования (аудитория + слабые места)
    $e2_research = $e2; // алиас для удобства чтения
    $e3  = aig_find($slogs, 'Этап 3:') ?: aig_find($slogs, 'Этап 3');
    $e4  = aig_find($slogs, 'Этап 4:') ?: aig_find($slogs, 'Этап 4');
    // Этап 4 в новом формате хранит все данные семантики (запросы + источники)
    $e4_semantics = $e4;
    $e5p = aig_find($slogs, '', 'Структурный скелет создан')
        ?: aig_find($slogs, '', 'Структурный скелет с черновым контентом готов')
        ?: aig_find($slogs, '', 'Загружен черновой план');
    $e5  = $e5p ?: aig_find($slogs, 'Этап 5');
    $e6r = aig_find($slogs, '', 'Запрос к AI');
    $e6a = aig_find($slogs, '', 'Ответ AI получен') ?: aig_find($slogs, '', 'Статья написана');
    $e7  = aig_find($slogs, 'Этап 7:') ?: aig_find($slogs, 'Этап 7');
    $e8  = aig_find($slogs, 'Этап 8:') ?: aig_find($slogs, 'Этап 8');
    $e9  = aig_find($slogs, 'Этап 9:') ?: aig_find($slogs, 'Этап 9');
    $e10 = aig_find($slogs, 'Этап 10:') ?: aig_find($slogs, 'Этап 10');
    $e11 = aig_find($slogs, 'Этап 11:') ?: aig_find($slogs, 'Этап 11');
    $e12 = aig_find($slogs, 'Этап 12:') ?: aig_find($slogs, 'Этап 12');
    $e13v= aig_find($slogs, 'Этап 13:') ?: aig_find($slogs, 'QA (объём)');
    $e13j= aig_find($slogs, '', 'JSON') ?: aig_find($slogs, 'QA (JSON)');
    $e14 = aig_find($slogs, 'Этап 14:') ?: aig_find($slogs, 'Этап 14');
    $edone = aig_find($slogs, 'Готово');
?>
<div class="aig-wrap" style="border-radius:0;border-left:none;border-right:none;border-top:none;margin-bottom:8px">

  <div class="aig-head">
    <span style="font-size:18px">📄</span>
    <span style="font-weight:600;font-size:14px;flex:1;min-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?php echo esc_attr($title); ?>">
      <?php if ($post_id): ?><a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>" target="_blank" style="color:inherit;text-decoration:none"><?php echo esc_html($title); ?></a>
      <?php else: echo esc_html($title); endif; ?>
    </span>
    <?php if ($ml): ?><span class="aig-badge" style="background:#e0e7ff;color:#3730a3"><?php echo esc_html($ml); ?></span><?php endif; ?>
    <span class="aig-badge" style="<?php echo $st_css; ?>"><?php echo $st_txt; ?></span>
    <span style="font-size:11px;color:#777"><?php echo esc_html($started); ?><?php if ($t_str): ?> · ⏱ <?php echo esc_html($t_str); ?><?php endif; ?> · <?php echo count($slogs); ?> событий</span>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:0" onsubmit="return confirm('Удалить этот сеанс из истории?')">
      <input type="hidden" name="action" value="aiseogeo_delete_log_session">
      <input type="hidden" name="rewrite_id" value="<?php echo absint($rid); ?>">
      <?php wp_nonce_field('aiseogeo_delete_log_session_' . absint($rid)); ?>
      <button type="submit" class="button button-small" style="color:#b91c1c;border-color:#fca5a5;font-size:11px;height:24px;line-height:22px;padding:0 8px" title="Удалить сеанс">🗑</button>
    </form>
  </div>

  <table class="aig-table">

  <?php
  // ═══════════════════════════════════════════
  // ФАЗА А — ИССЛЕДОВАНИЕ И ПЛАНИРОВАНИЕ
  // ═══════════════════════════════════════════
  echo aig_phase('А', 'Исследование и планирование');

  // ── Этап 1: Анализ аудитории ──────────────
  // Новый формат: данные в записи этапа 2 (после завершения AI-вызова)
  // Старый формат: данные в записи этапа 1
  $d2r = $e2_research ? $e2_research['data'] : array();
  $d1  = $e1 ? $e1['data'] : array();
  // Определяем источник данных (новый или старый)
  $aud_primary = aig_v($d2r,'аудитория') !== '—' ? aig_v($d2r,'аудитория') : aig_v($d1,'стратегия');
  $aud_level   = aig_v($d2r,'уровень');
  $aud_pains   = aig_v($d2r,'болей');
  $e1_ok = $e1 || $e2_research;
  $short1 = '';
  if ($e1_ok) {
      if ($aud_primary !== '—') { $short1 = mb_substr($aud_primary, 0, 80); }
      if ($aud_level !== '—') { $short1 .= ($short1 ? ' · ' : '') . 'уровень: ' . $aud_level; }
      if ($aud_pains !== '—') { $short1 .= ($short1 ? ' · ' : '') . 'болей: ' . $aud_pains; }
  }
  $det1 = '';
  if ($e1_ok) {
      $pains_d = aig_v($d2r,'_detail_pains','');
      $det1 = "АУДИТОРИЯ: " . $aud_primary . "\nУровень: " . $aud_level .
              ($aud_pains !== '—' ? "\nКоличество болей: " . $aud_pains : '') .
              ($pains_d !== '' && $pains_d !== '—' ? "\n\nБОЛИ ЧИТАТЕЛЕЙ:\n" . $pains_d : '');
  }
  echo aig_stage_row(1, 'Анализ аудитории и болей читателя', '👥', $e1_ok ? 'ok' : 'skip', $e1_ok ? ($short1 ?: 'анализ выполнен') : 'ожидает запуска', $det1);

  // ── Этап 2: Анализ слабых мест ────────────
  $weak_n   = aig_v($d2r,'слабых_мест');
  $missing_n = aig_v($d2r,'недостающих_тем');
  // Старый формат fallback
  $weak_old = aig_v($d1,'слабых_мест') !== '—' ? aig_v($d1,'слабых_мест') : $weak_n;
  $short2 = '';
  if ($e2_research) {
      if ($weak_n !== '—')   { $short2 .= 'слабых мест: ' . $weak_n; }
      if ($missing_n !== '—'){ $short2 .= ($short2?' · ':'') . 'недостающих тем: ' . $missing_n; }
  }
  $det2 = '';
  if ($e2_research && ($weak_n !== '—' || $missing_n !== '—')) {
      $det2 = "СЛАБЫЕ МЕСТА: " . $weak_n . "\nНЕДОСТАЮЩИЕ ТЕМЫ: " . $missing_n;
  }
  echo aig_stage_row(2, 'Анализ слабых мест и конкурентных пробелов', '🔬', $e2_research ? 'ok' : 'skip', $e2_research ? ($short2 ?: 'анализ выполнен') : 'ожидает запуска', $det2);

  // ── Этап 3: Семантика ─────────────────────
  // Новый формат: данные в записи этапа 3 (запрос) и этапа 4 (результат)
  // Старый формат: данные в записи этапа 3
  $d4s = $e4_semantics ? $e4_semantics['data'] : array();
  $d3  = $e3 ? $e3['data'] : array();
  $main_kw  = aig_v($d4s,'главный_запрос') !== '—' ? aig_v($d4s,'главный_запрос') : aig_v($d3,'изменений_H2');
  $sec_kw_n = aig_v($d4s,'доп_запросов');
  $e3_ok = $e3 || $e4_semantics;
  $short3 = '';
  if ($e3_ok) {
      if ($main_kw !== '—')  { $short3 = mb_substr($main_kw, 0, 70); }
      if ($sec_kw_n !== '—') { $short3 .= ($short3?' · ':'') . 'доп. запросов: ' . $sec_kw_n; }
      $kws_d = aig_v($d4s,'_detail_kws','');
      if ($kws_d !== '—' && $kws_d !== '') { $short3 = $kws_d; }
  }
  $det3 = '';
  if ($e3_ok) {
      $kws_d = aig_v($d4s,'_detail_kws','');
      $det3 = "ГЛАВНЫЙ ЗАПРОС: " . $main_kw .
              ($sec_kw_n !== '—' ? "\nДОП. ЗАПРОСОВ: " . $sec_kw_n : '') .
              ($kws_d !== '—' && $kws_d !== '' ? "\n\nДОП. КЛЮЧЕВЫЕ СЛОВА:\n" . $kws_d : '');
  }
  echo aig_stage_row(3, 'Семантика: заголовки, мета, Anti-AI правки', '🏷️', $e3_ok ? 'ok' : 'skip', $e3_ok ? ($short3 ?: 'семантика получена') : 'ожидает запуска', $det3);

  // ── Этап 4: Исследование источников ───────
  $src_n    = aig_v($d4s,'источников');
  $facts_n  = aig_v($d4s,'фактов');
  $short4 = '';
  if ($e4_semantics) {
      if ($src_n !== '—')   { $short4 .= 'источников: ' . $src_n; }
      if ($facts_n !== '—') { $short4 .= ($short4?' · ':'') . 'фактов и цифр: ' . $facts_n; }
  }
  $det4 = $e4_semantics ? ("ИСТОЧНИКОВ: " . $src_n . "\nФАКТОВ: " . $facts_n) : '';
  echo aig_stage_row(4, 'Исследование источников и экспертных данных', '📚', $e4_semantics ? 'ok' : 'skip', $e4_semantics ? ($short4 ?: 'источники найдены') : 'ожидает запуска', $det4);

  // ── Этап 5: Структурный скелет ────────────
  $d5   = $e5 ? $e5['data'] : array();
  // Новый формат
  $h5n  = aig_v($d5,'H2_разделов');
  $f5n  = aig_v($d5,'FAQ_вопросов');
  $hp5n = aig_v($d5,'hero_promise');
  $h2s5 = aig_v($d5,'_detail_h2s');
  // Старый формат fallback
  $h5   = $h5n !== '—' ? $h5n : aig_v($d5,'h2_с_tldr');
  $f5   = $f5n !== '—' ? $f5n : aig_v($d5,'faq_черновик');
  $hp5  = $hp5n !== '—' ? $hp5n : aig_v($d5,'hero_promise');
  $short5 = '';
  if ($e5) {
      if ($h5 !== '—') { $short5 .= 'H2 разделов: ' . $h5; }
      if ($f5 !== '—') { $short5 .= ($short5?' · ':'') . 'FAQ вопросов: ' . $f5; }
      if ($hp5 !== '—') { $short5 .= ($short5?' · ':'') . 'Hero Promise: ' . $hp5; }
  }
  $det5 = '';
  if ($e5) {
      $det5 = "H2 РАЗДЕЛОВ В ПЛАНЕ: " . $h5 . "\nFAQ ВОПРОСОВ: " . $f5 . "\nHERO PROMISE: " . $hp5;
      if ($h2s5 !== '—' && $h2s5 !== '') { $det5 .= "\n\nЗАГОЛОВКИ H2:\n" . $h2s5; }
  }
  echo aig_stage_row(5, 'Структурный скелет с черновым контентом', '📋', $e5 ? 'ok' : 'skip', $e5 ? ($short5 ?: 'скелет создан') : 'ожидает запуска', $det5);

  // ═══════════════════════════════════════════
  // ФАЗА Б — НАПИСАНИЕ
  // ═══════════════════════════════════════════
  echo aig_phase('Б', 'Написание');

  // ── Этап 6: Написание ────────────────────
  $d6r = $e6r ? $e6r['data'] : array();
  $d6a = $e6a ? $e6a['data'] : array();
  $model6 = aig_v($d6r,'модель'); $tok6 = aig_v($d6r,'лимит_токенов');
  $len6   = aig_v($d6a,'длина_ответа') !== '—' ? aig_v($d6a,'длина_ответа') : aig_v($d6a,'длина_ответа_симв');
  $short6 = ($model6!=='—'?$model6:'') . ($tok6!=='—'?' · лимит '.$tok6.' tok':'') . ($len6!=='—'?' · ответ: '.$len6:'');
  $e6_ok = $e6r && $e6a;
  echo aig_stage_row(6, 'Написание (AI-запрос → ответ)', '🤖', $e6_ok ? 'ok' : ($e6r ? 'warn' : 'skip'), $e6_ok ? ($short6 ?: 'статья написана') : ($e6r ? 'ожидание ответа AI…' : 'ожидает запуска'), '');

  // ═══════════════════════════════════════════
  // ФАЗА В — РЕДАКТУРА
  // ═══════════════════════════════════════════
  echo aig_phase('В', 'Редактура');

  // ── Этап 7: Редактура логики ──────────────
  $d7 = $e7 ? $e7['data'] : array();
  $w7 = aig_v($d7,'предупреждений'); $c7 = aig_v($d7,'уверенность_AI'); $p7 = aig_v($d7,'сохранено_блоков');
  $short7 = ($w7!=='—'?'предупреждений: '.$w7:'') . ($c7!=='—'?' · уверенность AI: '.$c7:'') . ($p7!=='—'?' · сохранено блоков: '.$p7:'');
  $det7 = '';
  if ($e7) {
      $dw = aig_v($d7,'_detail_warnings',''); $dp = aig_v($d7,'_detail_preserved','');
      $det7 = ($dw!==''?"ПРЕДУПРЕЖДЕНИЯ:\n".$dw:'') . ($dp!=='' && $dp!=='—' ? "\n\nСОХРАНЁННЫЕ БЛОКИ:\n".$dp:'');
  }
  $e7_st = $e7 ? ((int)$w7 === 0 ? 'ok' : 'warn') : 'skip';
  echo aig_stage_row(7, 'Редактура логики, фактов и важных блоков', '🧠', $e7_st, $e7 ? $short7 : 'выполняется внутри AI', $det7);

  // ── Этап 8: Цикл хуманизации (детерминированные гейты) ────
  $d8 = $e8 ? $e8['data'] : array();
  // Новый формат: данные гейтов. Старый: симметрии
  $hard8 = aig_v($d8,'нарушений_hard'); $warn8 = aig_v($d8,'нарушений_warn');
  $dens8 = aig_v($d8,'плотность_AI_маркеров'); $cv8 = aig_v($d8,'ритм_CV'); $sc8 = aig_v($d8,'AI_score');
  $passes8 = aig_v($d8,'итераций_хуманизации'); $tire8 = aig_v($d8,'тире_заменено_php');
  $sym8_old = aig_v($d8,'симметрий_переписано');
  $short8 = '';
  if ($hard8 !== '—' || $dens8 !== '—') {
      if ($sc8 !== '—')   { $short8 = 'AI-score: ' . $sc8; }
      if ($hard8 !== '—') { $short8 .= ($short8?' · ':'') . 'блокеров: ' . $hard8 . ' · предупр.: ' . $warn8; }
      if ($cv8 !== '—')   { $short8 .= ' · ритм CV: ' . $cv8; }
  } elseif ($sym8_old !== '—') {
      $short8 = 'симметрий переписано: ' . $sym8_old;
  }
  $det8 = '';
  if ($e8) {
      $issues8 = aig_v($d8,'_detail_issues','');
      if ($dens8 !== '—') { $det8 .= "Плотность AI-маркеров: " . $dens8 . "\nРитм текста CV: " . $cv8 . "\nТире заменено (PHP): " . $tire8 . "\nИтераций хуманизации: " . $passes8 . "\n\n"; }
      if ($issues8 !== '—' && $issues8 !== '') { $det8 .= "НАЙДЕННЫЕ НАРУШЕНИЯ:\n" . $issues8; }
      if ($det8 === '') { $det8 = aig_v($d8,'_detail_symmetries',''); }
  }
  $e8_st = $e8 ? ((int)$hard8 > 0 ? 'warn' : 'ok') : 'skip';
  echo aig_stage_row(8, 'Редактура стиля: симметрии, ритм, кальки', '✏️', $e8_st, $e8 ? ($short8 ?: 'хуманизация выполнена') : 'ожидает запуска', $det8);

  // ═══════════════════════════════════════════
  // ФАЗА Г — QA И ОПТИМИЗАЦИЯ
  // ═══════════════════════════════════════════
  echo aig_phase('Г', 'QA и оптимизация');

  // ── Этап 9: SEO/GEO QA ───────────────────
  $d9 = $e9 ? $e9['data'] : array();
  $h9 = aig_v($d9,'H2_разделов'); $cta9 = aig_v($d9,'CTA_точек'); $faq9 = aig_v($d9,'FAQ'); $src9 = aig_v($d9,'блок_источников'); $tbl9 = aig_v($d9,'таблиц');
  $h9_ok = $e9 && (int)$h9 >= 8 && (int)$h9 <= 14;
  $short9 = ($h9!=='—'?'H2: '.$h9.($h9_ok?'✓':'⚠'):'') . ($cta9!=='—'?' · CTA: '.$cta9:'') . ($faq9!=='—'?' · FAQ: '.$faq9:'') . ($src9!=='—'?' · источники: '.$src9:'') . ($tbl9!=='—'?' · таблиц: '.$tbl9:'');
  $det9_lines = array();
  if ($e9) {
      if ($h9!=='—') { $det9_lines[] = 'H2 разделов: ' . $h9 . ' (норма 8-14)' . ($h9_ok?' ✓':' ⚠ не в норме'); }
      if ($cta9!=='—') { $det9_lines[] = 'CTA-точки: ' . $cta9 . ' (норма 3)' . ((int)$cta9===3?' ✓':' ⚠'); }
      if ($faq9!=='—') { $det9_lines[] = 'FAQ-блок: ' . $faq9 . ($faq9==='да'?' ✓':' ⚠ не найден'); }
      if ($src9!=='—') { $det9_lines[] = 'Блок источники: ' . $src9 . ($src9==='да'?' ✓':' ⚠'); }
      if ($tbl9!=='—') { $det9_lines[] = 'Сравнительных таблиц: ' . $tbl9 . ((int)$tbl9>=1?' ✓':' ⚠ нет'); }
      $ol9 = aig_v($d9,'нумерованных_списков'); if($ol9!=='—'){$det9_lines[]='Нумерованных списков: '.$ol9;}
      $lnk9 = aig_v($d9,'внутренних_ссылок'); if($lnk9!=='—'){$det9_lines[]='Внутренних ссылок: '.$lnk9.((int)$lnk9>=3?' ✓':' ⚠ нужно ≥3');}
      $hp9 = aig_v($d9,'hero_promise'); if($hp9!=='—'){$det9_lines[]='Hero Promise: '.$hp9;}
  }
  $e9_bad = $e9 && ((int)$h9 < 8 || (int)$h9 > 14 || (int)$cta9 < 3 || $faq9==='нет' || $src9==='нет');
  echo aig_stage_row(9, 'SEO/GEO QA — структурная проверка (Блок Б)', '🔎', $e9 ? ($e9_bad?'warn':'ok') : 'skip', $e9 ? $short9 : '—', $e9 ? implode("\n", $det9_lines) : '');

  // ── Этап 10: Мета ────────────────────────
  $d10 = $e10 ? $e10['data'] : array();
  $h1_10 = aig_v($d10,'новый_H1'); $md10 = aig_v($d10,'meta_desc_длина');
  $short10 = ($h1_10!=='—'?mb_substr($h1_10,0,80):'') . ($md10!=='—'?' · description: '.$md10:'');
  $det10 = '';
  if ($e10) {
      $mt = aig_v($d10,'_detail_meta_title',''); $md = aig_v($d10,'_detail_meta_desc',''); $ex = aig_v($d10,'_detail_excerpt','');
      $det10 = "H1: " . $h1_10 . "\nMeta title: " . $mt . "\nMeta description: " . $md . "\nExcerpt: " . $ex;
  }
  echo aig_stage_row(10, 'Мета-оптимизация: title, description, excerpt', '📌', $e10 ? 'ok' : 'skip', $e10 ? $short10 : 'выполняется внутри AI', $det10);

  // ── Этап 11: Anti-AI ─────────────────────
  $d11 = $e11 ? $e11['data'] : array();
  $em11 = aig_v($d11,'длинных_тире_в_тексте'); $cl11 = aig_v($d11,'клише_убрано'); $af11 = aig_v($d11,'answer_first_добавлено'); $h2q11 = aig_v($d11,'H2_в_вопрос');
  $em_bad = $e11 && (int)$em11 > 0;
  $short11 = ($em11!=='—'?'тире осталось: '.$em11.($em_bad?' ⚠':' ✓'):'') . ($cl11!=='—'?' · клише убрано: '.$cl11:'') . ($af11!=='—'?' · Answer-First: '.$af11.' H2':'') . ($h2q11!=='—'?' · H2→вопрос: '.$h2q11:'');
  $det11 = array();
  if ($e11) {
      $det11[] = 'В.1 Длинных тире (—) осталось: ' . $em11 . ($em_bad?' ⚠ нужно 0!':' ✓');
      $er11 = aig_v($d11,'тире_заменено'); if($er11!=='—'){$det11[]='В.1 Тире заменено при написании: '.$er11;}
      if($cl11!=='—'){$det11[]='В.2 Клише убрано: '.$cl11;}
      if($af11!=='—'){$det11[]='В.3 Answer-First (TL;DR) добавлен в: '.$af11.' H2';}
      if($h2q11!=='—'){$det11[]='Б.2 H2 переведено в вопрос: '.$h2q11;}
  }
  $e11_st = $e11 ? ($em_bad ? 'warn' : 'ok') : 'skip';
  echo aig_stage_row(11, 'Anti-AI хуманизация (Блок В)', '✂️', $e11_st, $e11 ? $short11 : '—', implode("\n", $det11));

  // ── Этап 12: Внутренние ссылки + живая HTTP-проверка ────────────
  $d12 = $e12 ? $e12['data'] : array();
  $lnk12 = aig_v($d12,'внутренних_ссылок'); $nrm12 = aig_v($d12,'норма');
  $chk12 = aig_v($d12,'ссылок_проверено'); $ok12 = aig_v($d12,'рабочих'); $bad12 = aig_v($d12,'битых');
  $short12 = ($lnk12!=='—'?'внутр. ссылок: '.$lnk12:'') . ($chk12!=='—'?' · HTTP-проверено: '.$chk12:'') . ($bad12!=='—'?' · битых: '.$bad12.((int)$bad12>0?' ⚠':' ✓'):'');
  $det12 = $e12 ? aig_v($d12,'_detail_broken','') : '';
  $e12_st = $e12 ? (((int)$lnk12 >= 3 && (int)$bad12 === 0) ? 'ok' : 'warn') : 'skip';
  echo aig_stage_row(12, 'Внутренние ссылки (мин. 3, Б.13)', '🔗', $e12_st, $e12 ? ($short12 ?: 'проверка ссылок') : 'ожидает запуска', $det12 !== '—' ? $det12 : '');

  // ── Этап 13: Финальная QA ────────────────
  $d13j = $e13j ? $e13j['data'] : array();
  $d13v = $e13v ? $e13v['data'] : array();
  // Новый формат: всё в одной записи этапа 13. Старый: две записи QA (объём) и QA (JSON)
  $e13  = $e13v ?: $e13j;
  $d13  = $e13 ? $e13['data'] : array();
  $d13v = $e13v ? $e13v['data'] : $d13;
  $d13j = $e13j ? $e13j['data'] : array();
  $orig13   = aig_v($d13,'оригинал_симв')     !== '—' ? aig_v($d13,'оригинал_симв')     : aig_v($d13v,'оригинал_симв');
  $new13    = aig_v($d13,'новая_версия_симв')  !== '—' ? aig_v($d13,'новая_версия_симв')  : aig_v($d13v,'новая_версия_симв');
  $growth13 = aig_v($d13,'рост')               !== '—' ? aig_v($d13,'рост')               : aig_v($d13v,'рост');
  $json_ok = $e13j ? (strpos(strtolower((string)$e13j['log']->message),'корректен')!==false || strpos((string)$e13j['log']->message,'восстановлен')!==false) : ($e13 ? true : false);
  $short13 = ($orig13!=='—' ? $orig13.'→'.$new13.' симв' : '') . ($growth13!=='—' ? ' (рост: '.$growth13.')' : '');
  $det13 = array();
  if ($orig13!=='—') { $det13[] = 'Оригинал: ' . $orig13 . ' симв'; }
  if ($new13!=='—')  { $det13[] = 'Новая версия: ' . $new13 . ' симв'; }
  if ($growth13!=='—'){ $det13[] = 'Рост: ' . $growth13; }
  $e13_st = $e13 ? 'ok' : 'skip';
  echo aig_stage_row(13, 'Финальная QA: JSON + объём статьи', '📏', $e13_st, $e13 ? ($short13 ?: 'QA пройдена') : 'ожидает запуска', implode("\n", $det13));

  // ── Этап 14: Schema ───────────────────────
  $d14 = $e14 ? $e14['data'] : array();
  $sch14 = aig_v($d14,'тип_schema');
  $det14 = $e14 ? aig_v($d14,'_detail_schema','') : '';
  echo aig_stage_row(14, 'JSON-LD Schema разметка (Блок Г)', '🏷️', $e14 ? 'ok' : 'skip', $e14 ? 'тип: ' . $sch14 : 'выполняется внутри AI', $det14 !== '' && $det14 !== '—' ? "SCHEMA JSON:\n" . $det14 : '');

  // ═══════════════════════════════════════════
  // ФАЗА Д — ПУБЛИКАЦИЯ
  // ═══════════════════════════════════════════
  echo aig_phase('Д', 'Публикация и мониторинг');

  // ── Этап 15: Применение ───────────────────
  $apply_status = $rw ? (string)($rw->apply_status ?? '') : '';
  $applied = ($apply_status === 'applied') || in_array($rstatus, array('applied', 'draft_created'), true);
  $done_d  = $edone ? $edone['data'] : array();
  $vol_fin = aig_v($done_d,'итоговый_объём_симв'); $steps_fin = aig_v($done_d,'всего_шагов');
  $ai_calls = aig_v($done_d,'всего_AI_запросов');
  $short15 = $is_done ? 'версия создана' . ($vol_fin!=='—'?' · '.$vol_fin.' симв':'') . ($steps_fin!=='—'?' · '.$steps_fin.' шагов':'') . ($ai_calls!=='—'?' · '.$ai_calls.' AI-запросов':'') . ($t_str?' · '.$t_str:'') : ($has_err ? 'завершено с ошибкой' : 'ожидает запуска');
  $e15_st  = $is_done ? ($applied?'ok':'warn') : ($has_err?'err':'skip');
  $e15_lbl = $is_done ? ($applied?'Применена к статье':'Версия готова, ожидает применения') : ($has_err?'Ошибка':'Ещё не завершено');
  echo aig_stage_row(15, 'Применение улучшенной версии к статье', '🚀', $e15_st, $short15, '');

  // ── Этап 16: Мониторинг (реальный статус из learning_evaluated) ──────────
  $l_evaluated = $rw ? (int)($rw->learning_evaluated ?? 0) : 0;
  $l_success   = $rw ? $rw->learning_success ?? null : null;
  $l_growth    = $rw ? $rw->learning_views_growth ?? null : null;
  if (!$applied) {
      $e16_st  = 'skip';
      $e16_lbl = 'Ожидает применения версии';
      $e16_msg = 'Мониторинг начнётся после применения версии к статье';
  } elseif ($l_evaluated) {
      $e16_st  = $l_success ? 'ok' : 'warn';
      $e16_lbl = $l_success ? 'Успех подтверждён' : 'Оценено — рост не подтверждён';
      $e16_msg = 'Рост просмотров: ' . ($l_growth !== null ? round((float)$l_growth, 1) . '%' : '—');
  } else {
      $e16_st  = 'skip';
      $e16_lbl = 'Ожидает оценки (ежедневный cron)';
      $e16_msg = 'AI SEO/GEO Редактор → Автообучение · оценка через несколько дней после применения';
  }
  echo aig_stage_row(16, 'Постпубликационный мониторинг (Автообучение)', '📊', $e16_st, $e16_msg, '');
  ?>

  </table>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (!empty($other_logs)): ?>
<div class="aiseogeo-card" style="margin-top:20px">
  <div style="padding:14px 16px;border-bottom:1px solid #e2e4e7"><h2 style="margin:0">Прочие события</h2></div>
  <table class="widefat striped" style="font-size:12px">
    <thead><tr><th style="width:130px">Дата</th><th style="width:55px">Уровень</th><th style="width:110px">Контекст</th><th>Сообщение</th></tr></thead>
    <tbody>
    <?php foreach ($other_logs as $entry):
        $l = $entry['log']; $data = $entry['data'];
        $bg = $l->level === 'error' ? 'background:#fcebea' : '';
        $parts = array();
        foreach ($data as $k=>$v) {
            if ($k === 'raw') { continue; }
            if (is_array($v)) { $v = implode(', ', array_map('strval', $v)); }
            if ($v===''||$v===null) { continue; }
            $parts[] = '<b>'.esc_html($k).':</b> '.esc_html((string)$v);
        }
    ?>
    <tr style="<?php echo $bg; ?>">
      <td><?php echo esc_html(substr($l->created_at,0,16)); ?></td>
      <td><?php echo esc_html($l->level); ?></td>
      <td><?php echo esc_html($l->context); ?></td>
      <td><?php echo esc_html($l->message); ?><?php if($parts): ?><br><span style="color:#666;font-size:11px"><?php echo implode(' &nbsp;·&nbsp; ',$parts); ?></span><?php endif; ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

</div>

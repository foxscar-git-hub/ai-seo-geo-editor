<?php if (!defined('ABSPATH')) { exit; }

// ─── Разделяем логи на сеансы переписывания и прочие ─────────────────────────
$rewrite_contexts = array('rewrite_step', 'rewrite_plan', 'auto_rewrite');
$sessions   = array(); // rewrite_id => ['logs'=>[], 'first_ts'=>'', 'last_ts'=>'', 'total_sec'=>0]
$other_logs = array();

foreach ($logs as $l) {
    $d   = json_decode((string)$l->data_json, true);
    $rid = !empty($d['rewrite_id']) ? (int)$d['rewrite_id'] : 0;
    if (in_array($l->context, $rewrite_contexts, true) && $rid) {
        if (!isset($sessions[$rid])) { $sessions[$rid] = array('logs' => array()); }
        $sessions[$rid]['logs'][] = array('log' => $l, 'data' => is_array($d) ? $d : array());
    } else {
        $other_logs[] = array('log' => $l, 'data' => is_array($d) ? $d : array());
    }
}

// Самые новые сессии сверху — в logs идут DESC, поэтому обращаем
$sessions = array_reverse($sessions, true);

// ─── Хелперы ─────────────────────────────────────────────────────────────────

/** Найти первый лог сессии, у которого этап содержит $stage_substr */
function aig_by_stage($slogs, $stage_substr) {
    foreach ($slogs as $e) {
        if (strpos((string)($e['data']['этап'] ?? ''), $stage_substr) !== false) { return $e; }
    }
    return null;
}

/** Найти первый лог сессии, у которого message содержит $needle */
function aig_by_msg($slogs, $needle) {
    foreach ($slogs as $e) {
        if (strpos((string)$e['log']->message, $needle) !== false) { return $e; }
    }
    return null;
}

/** Найти лог по context */
function aig_by_ctx($slogs, $ctx) {
    foreach ($slogs as $e) {
        if ($e['log']->context === $ctx) { return $e; }
    }
    return null;
}

/** Значение из data или '-' */
function aig_val($data, $key, $default = '—') {
    if (!isset($data[$key]) || $data[$key] === '' || $data[$key] === null) { return $default; }
    $v = $data[$key];
    return is_array($v) ? implode(', ', array_map('strval', $v)) : (string)$v;
}

/** Вернуть HTML строки чеклиста: статус (ok/err/skip/warn), label, value */
function aig_row($status, $label, $value = '', $detail = '') {
    $icons = array('ok'=>'✓','err'=>'✗','skip'=>'·','warn'=>'⚠');
    $colors = array('ok'=>'#065f46','err'=>'#991b1b','skip'=>'#9ca3af','warn'=>'#92400e');
    $bgs    = array('ok'=>'#d1fae5','err'=>'#fee2e2','skip'=>'#f3f4f6','warn'=>'#fef3c7');
    $ic = isset($icons[$status])  ? $icons[$status]  : '·';
    $cl = isset($colors[$status]) ? $colors[$status] : '#9ca3af';
    $bg = isset($bgs[$status])    ? $bgs[$status]    : '#f3f4f6';
    $val_html = $value !== '' ? '<span style="color:#374151;margin-left:6px">' . esc_html($value) . '</span>' : '';
    $det_html = $detail !== '' ? '<span style="color:#6b7280;font-size:11px;margin-left:6px">(' . esc_html($detail) . ')</span>' : '';
    return '<li style="display:flex;align-items:flex-start;gap:8px;padding:5px 16px;border-bottom:1px solid #f0f0f1;font-size:13px">'
         . '<span style="width:20px;height:20px;border-radius:50%;background:' . $bg . ';color:' . $cl . ';display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0;margin-top:1px">' . $ic . '</span>'
         . '<span style="flex:1">' . esc_html($label) . $val_html . $det_html . '</span>'
         . '</li>';
}

/** Секция с заголовком */
function aig_section($title, $icon = '') {
    return '<li style="background:#f1f5f9;padding:6px 16px;font-size:11px;font-weight:700;color:#475569;letter-spacing:.5px;text-transform:uppercase;border-bottom:1px solid #e2e8f0">'
         . esc_html(($icon ? $icon . ' ' : '') . $title) . '</li>';
}

/** Числовое значение с оценкой */
function aig_num($val, $ok_min = null, $ok_max = null) {
    if ($val === '—' || $val === '') { return array('skip', $val); }
    $n = intval($val);
    if ($ok_min !== null && $ok_max !== null) {
        return array($n >= $ok_min && $n <= $ok_max ? 'ok' : 'warn', $val);
    }
    if ($ok_min !== null) { return array($n >= $ok_min ? 'ok' : 'warn', $val); }
    return array($n === 0 ? 'ok' : 'warn', $val);
}

$mode_labels = array(
    'full_refresh'=>'Полное обновление','soft_improve'=>'Мягкое улучшение','seo_boost'=>'SEO-усиление',
    'geo_boost'=>'GEO-усиление','seo_geo_boost'=>'SEO+GEO','meta_only'=>'Только мета','problem_blocks_only'=>'Проблемные блоки'
);

?>
<style>
.aig-card{background:#fff;border:1px solid #ddd;border-radius:6px;margin-bottom:20px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.aig-head{display:flex;align-items:center;gap:10px;padding:10px 16px;background:#f8f9fa;border-bottom:2px solid #e2e4e7;flex-wrap:wrap}
.aig-title{font-weight:600;font-size:14px;color:#1d2327;flex:1;min-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aig-badge{display:inline-block;padding:2px 9px;border-radius:10px;font-size:11px;font-weight:600}
.aig-meta{font-size:11px;color:#666;margin-left:auto}
.aig-list{padding:0;margin:0;list-style:none}
.aig-list li:last-child{border-bottom:none!important}
</style>

<div class="wrap aiseogeo-wrap">
<h1>Диагностика</h1>

<div class="aiseogeo-grid two">
  <div class="aiseogeo-card"><h2>Система</h2>
    <p>Плагин: <?php echo esc_html(AISEOGEO_VERSION); ?></p>
    <p>WordPress: <?php echo esc_html(get_bloginfo('version')); ?></p>
    <p>PHP: <?php echo esc_html(PHP_VERSION); ?></p>
    <p>OpenRouter API: <?php echo $settings->get('api_key','') ? '<span style="color:#065f46">ключ указан</span>' : '<span style="color:#991b1b">ключ не указан</span>'; ?></p>
    <p>Модель: <?php echo esc_html($settings->get('model','')); ?></p>
  </div>
  <div class="aiseogeo-card"><h2>Таблицы БД</h2>
    <?php foreach($tables as $t=>$ok): ?>
    <p><?php echo esc_html($t); ?> — <?php echo $ok ? '<span style="color:#065f46">OK</span>' : '<span style="color:#991b1b">нет</span>'; ?></p>
    <?php endforeach; ?>
  </div>
</div>

<?php if (!empty($sessions)): ?>
<div class="aiseogeo-card" style="margin-top:20px">
<h2 style="padding:16px;margin:0;border-bottom:1px solid #e2e4e7">
  Сеансы переписывания
  <span style="font-weight:400;font-size:13px;color:#666"> — последние <?php echo count($sessions); ?></span>
</h2>

<?php foreach ($sessions as $rid => $session):
    $slogs  = $session['logs'];
    $rw     = isset($rewrites_map[$rid]) ? $rewrites_map[$rid] : null;
    $title  = $rw ? (string)$rw->original_title : '';
    if (empty($title)) { $title = 'Сеанс #' . $rid; }
    $mode   = $rw ? (string)$rw->rewrite_mode : '';
    $rstatus = $rw ? (string)$rw->rewrite_status : '';
    $post_id = $rw ? (int)$rw->post_id : 0;

    // Время первого и последнего события
    $last_entry  = $slogs[0];
    $first_entry = end($slogs); reset($slogs);
    $started_at  = substr((string)$first_entry['log']->created_at, 0, 16);
    $total_sec   = isset($last_entry['data']['сек_от_старта']) ? (float)$last_entry['data']['сек_от_старта'] : 0;
    $time_str    = $total_sec >= 60 ? round($total_sec/60, 1) . ' мин' : ($total_sec > 0 ? $total_sec . ' сек' : '');

    $has_err = false;
    foreach ($slogs as $e) { if ($e['log']->level === 'error') { $has_err = true; break; } }
    $is_done = ($rstatus === 'done');

    $st_text  = $has_err ? '✗ Ошибка' : ($is_done ? '✓ Готово' : '⟳ В процессе');
    $st_style = $has_err ? 'background:#fee2e2;color:#991b1b' : ($is_done ? 'background:#d1fae5;color:#065f46' : 'background:#fef3c7;color:#92400e');
    $ml = isset($mode_labels[$mode]) ? $mode_labels[$mode] : $mode;

    // ─── Извлекаем нужные записи логов ───────────────────────────────────────
    // ПЛАН
    $l_plan_done  = aig_by_msg($slogs, 'Структурный скелет с черновым контентом готов');
    $l_plan_start = aig_by_msg($slogs, 'Этап 5: Старт построения');
    // Данные плана — предпочитаем из rewrite_step (шаг 2), иначе из rewrite_plan
    $l_plan_step  = aig_by_msg($slogs, 'Загружен черновой план');
    $plan_d       = $l_plan_step ? $l_plan_step['data'] : ($l_plan_done ? $l_plan_done['data'] : array());

    // ЗАЩИТА (контекст)
    $l_protect    = aig_by_msg($slogs, 'Собран контекст');
    $prot_d       = $l_protect ? $l_protect['data'] : array();

    // НАПИСАНИЕ
    $l_req        = aig_by_msg($slogs, 'Запрос к AI');
    $l_resp       = aig_by_msg($slogs, 'Ответ AI получен');
    $req_d        = $l_req ? $l_req['data'] : array();

    // QA JSON
    $l_json_ok    = aig_by_msg($slogs, 'JSON-ответ корректен');
    $l_json_fix   = aig_by_msg($slogs, 'JSON успешно восстановлен');
    $l_json_err   = aig_by_msg($slogs, 'JSON не удалось разобрать');
    $l_json_rep   = aig_by_msg($slogs, 'JSON некорректен');

    // QA Объём
    $l_vol        = aig_by_stage($slogs, 'QA (объём)');
    $vol_d        = $l_vol ? $l_vol['data'] : array();

    // QA Структура (Этап 9)
    $l_seo        = aig_by_stage($slogs, 'Этап 9');
    $seo_d        = $l_seo ? $l_seo['data'] : array();

    // QA Anti-AI (Этап 11)
    $l_ai         = aig_by_stage($slogs, 'Этап 11');
    $ai_d         = $l_ai ? $l_ai['data'] : array();

    // Защита итог
    $l_prot_ok    = aig_by_msg($slogs, 'сохранены без потерь');
    $l_prot_warn  = aig_by_msg($slogs, 'предупреждений');
    // берём последний лог про защиту итог
    $l_prot_end   = $l_prot_ok ?: $l_prot_warn;

    // Готово
    $l_done       = aig_by_stage($slogs, 'Готово');
    $done_d       = $l_done ? $l_done['data'] : array();
?>
<div class="aig-card" style="margin:0 0 12px;border-radius:0;border-left:none;border-right:none;border-top:none">
  <div class="aig-head">
    <span style="font-size:18px">📄</span>
    <span class="aig-title">
      <?php if ($post_id): ?>
        <a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>" target="_blank" style="color:inherit;text-decoration:none"><?php echo esc_html($title); ?></a>
      <?php else: echo esc_html($title); endif; ?>
    </span>
    <?php if ($ml): ?><span class="aig-badge" style="background:#e0e7ff;color:#3730a3"><?php echo esc_html($ml); ?></span><?php endif; ?>
    <span class="aig-badge" style="<?php echo $st_style; ?>"><?php echo $st_text; ?></span>
    <span class="aig-meta">
      <?php echo esc_html($started_at); ?>
      <?php if ($time_str): ?>&nbsp;·&nbsp; ⏱ <?php echo esc_html($time_str); ?><?php endif; ?>
      &nbsp;·&nbsp; <?php echo count($slogs); ?> событий
    </span>
  </div>

  <ul class="aig-list">

  <?php
  // ══════════════════════════════════════════════════════
  // БЛОК 1: ЭТАП 5 — СТРУКТУРНЫЙ ПЛАН
  // ══════════════════════════════════════════════════════
  echo aig_section('Этап 5: Структурный план (черновой контент)', '📋');

  // Hero Promise черновик
  $hp = aig_val($plan_d, 'hero_promise');
  echo aig_row($l_plan_step || $l_plan_done ? ($hp !== '—' && $hp !== 'нет' ? 'ok' : 'warn') : 'skip',
      'Б.1 — Hero Promise черновик',
      $hp !== '—' ? $hp : '',
      'конкретные буллеты + выгода + время применения');

  // H2 с TL;DR (Answer-First)
  $h2t = aig_val($plan_d, 'h2_с_tldr');
  $h2t_n = is_numeric($h2t) ? (int)$h2t : 0;
  echo aig_row($l_plan_step || $l_plan_done ? ($h2t_n >= 1 ? 'ok' : 'warn') : 'skip',
      'Б.2/Б.3 — H2 структура с TL;DR',
      $h2t !== '—' ? $h2t . ' разделов' : '',
      'каждый H2 — вопрос + готовый TL;DR 40-75 слов');

  // FAQ черновик
  $faqd = aig_val($plan_d, 'faq_черновик');
  $faqd_n = is_numeric($faqd) ? (int)$faqd : 0;
  echo aig_row($l_plan_step || $l_plan_done ? ($faqd_n >= 3 ? 'ok' : 'warn') : 'skip',
      'Б.11 — FAQ черновик (вопросы + ответы)',
      $faqd !== '—' ? $faqd . ' пар Q&A' : '',
      'мин. 3 реальных вопроса читателей с полными ответами');

  // Источники черновик
  $srcd = aig_val($plan_d, 'источники_черновик');
  echo aig_row($l_plan_step || $l_plan_done ? ($srcd !== '—' && $srcd !== 'нет' && $srcd !== '0' ? 'ok' : 'warn') : 'skip',
      'Б.8/Б.12 — Источники черновик',
      $srcd !== '—' ? $srcd : '',
      'мин. 5 именованных источников с URL');

  // Сравнительная таблица
  $tabd = aig_val($plan_d, 'сравнит_таблица', aig_val($plan_d, 'таблица'));
  echo aig_row($l_plan_step || $l_plan_done ? ($tabd !== '—' && $tabd !== 'нет' ? 'ok' : 'skip') : 'skip',
      'Б.6 — Сравнительная таблица черновик',
      $tabd !== '—' ? $tabd : '',
      'любое сравнение А vs Б = таблица');

  // Anti-AI правки из плана
  $antid_src = $l_plan_start ? $l_plan_start['data'] : array();
  // plan_start не содержит anti_ai — информация будет в Этапе 11, показываем факт наличия плана
  echo aig_row($l_plan_done ? 'ok' : 'skip',
      'В.2/В.3 — Anti-AI правки (клише + симметрии)',
      $l_plan_done ? 'найдены в тексте оригинала' : '',
      'конкретные клише/симметрии/запрещённый зачин');

  // CTA черновики
  echo aig_row($l_plan_done ? 'ok' : 'skip',
      'Б.10 — CTA черновики (3 точки)',
      $l_plan_done ? 'из плана' : '',
      'до 1-го H2 · после 2-3 раздела · после источников');

  // Мета черновики
  echo aig_row($l_plan_done ? 'ok' : 'skip',
      'Мета-черновики (title · meta_title · description · excerpt)',
      $l_plan_done ? 'из плана' : '',
      '');

  // Токены на план
  $plan_tokens = aig_val($l_plan_start ? $l_plan_start['data'] : array(), 'лимит_токенов');
  echo aig_row($plan_tokens !== '—' ? 'ok' : 'skip',
      'Лимит токенов плана',
      $plan_tokens !== '—' ? $plan_tokens . ' tok' : '',
      'мин. 10-16k — черновики занимают много места');

  // ══════════════════════════════════════════════════════
  // БЛОК 2: ЭТАП 0 — ЗАЩИТА БЛОКОВ
  // ══════════════════════════════════════════════════════
  echo aig_section('Этап 0: Защита блоков', '🔒');

  $pb = aig_val($prot_d, 'защищённых_блоков');
  echo aig_row($l_protect ? 'ok' : 'skip',
      'Шорткоды / формы / iframe сохранены',
      $pb !== '—' ? $pb . ' блоков' : '',
      '');

  $geo_s = aig_val($prot_d, 'аудит_GEO');
  $seo_s = aig_val($prot_d, 'аудит_SEO');
  echo aig_row($l_protect ? 'ok' : 'skip',
      'Результаты аудита загружены',
      ($geo_s !== '—' ? 'GEO: ' . $geo_s : '') . ($seo_s !== '—' ? '  SEO: ' . $seo_s : ''),
      '');

  // ══════════════════════════════════════════════════════
  // БЛОК 3: ЭТАП 6 — НАПИСАНИЕ
  // ══════════════════════════════════════════════════════
  echo aig_section('Этап 6: Написание (AI-запрос)', '🤖');

  $model_used = aig_val($req_d, 'модель');
  $tok_used   = aig_val($req_d, 'лимит_токенов');
  echo aig_row($l_req ? 'ok' : 'skip',
      'Запрос к AI отправлен',
      $model_used !== '—' ? $model_used : '',
      $tok_used !== '—' ? $tok_used . ' tok' : '');

  echo aig_row($l_resp ? 'ok' : ($l_req ? 'warn' : 'skip'),
      'Ответ AI получен',
      $l_resp ? aig_val($l_resp['data'], 'длина_симв', '') : '',
      '');

  // ══════════════════════════════════════════════════════
  // БЛОК 4: QA — РАЗБОР JSON
  // ══════════════════════════════════════════════════════
  echo aig_section('QA: Разбор JSON-ответа', '🔍');

  if ($l_json_err) {
      echo aig_row('err', 'JSON разобрать не удалось', '', '');
  } elseif ($l_json_fix) {
      echo aig_row('warn', 'JSON восстановлен автоматически', 'OK после ремонта', '');
  } elseif ($l_json_ok) {
      echo aig_row('ok', 'JSON корректен', 'OK', '');
  } else {
      echo aig_row('skip', 'JSON разбор', '', '');
  }

  // ══════════════════════════════════════════════════════
  // БЛОК 5: QA — ОБЪЁМ
  // ══════════════════════════════════════════════════════
  echo aig_section('QA: Объём статьи (Этап 13)', '📏');

  $orig_c = aig_val($vol_d, 'оригинал_симв');
  $new_c  = aig_val($vol_d, 'новая_версия_симв');
  $growth = aig_val($vol_d, 'рост');

  $vol_st = 'skip';
  if ($l_vol) {
      $msg_lc = strtolower((string)$l_vol['log']->message);
      $vol_st = (strpos($msg_lc, 'ошибка') !== false || strpos($msg_lc, 'не пройдена') !== false) ? 'err' : 'ok';
  }

  $vol_label = 'Объём ≥ 90% оригинала (методология +40-80%)';
  $vol_val   = '';
  if ($orig_c !== '—' && $new_c !== '—') {
      $vol_val = $orig_c . ' → ' . $new_c . ' симв';
      if ($growth !== '—') { $vol_val .= ' (' . $growth . ')'; }
  }
  echo aig_row($vol_st, $vol_label, $vol_val, '');

  if (aig_by_msg($slogs, 'Текст короткий')) {
      echo aig_row('warn', 'Повторный запрос к AI (текст был короткий)', '', '');
      $retry_ok = aig_by_msg($slogs, 'Повторная генерация дала полный текст');
      $retry_fail = aig_by_msg($slogs, 'Повтор не помог');
      if ($retry_ok)   { echo aig_row('ok',  'Повтор успешен — полный текст получен', '', ''); }
      if ($retry_fail) { echo aig_row('warn','Повтор не помог — применён fallback',   '', ''); }
  }

  // ══════════════════════════════════════════════════════
  // БЛОК 6: QA — СТРУКТУРА (Этап 9 / Блок Б)
  // ══════════════════════════════════════════════════════
  echo aig_section('Этап 9: SEO/GEO структура (Блок Б)', '🔎');

  // Б.1 Hero Promise
  $hp_qa = aig_val($seo_d, 'hero_promise');
  echo aig_row($l_seo ? ($hp_qa === 'да' ? 'ok' : 'warn') : 'skip',
      'Б.1 — Hero Promise блок в статье',
      $hp_qa !== '—' ? $hp_qa : '',
      '<div class="hero-promise"> перед первым H2');

  // Б.2 H2 структура (8-14)
  $h2qa = aig_val($seo_d, 'H2_разделов');
  list($h2_st, ) = aig_num($h2qa, 8, 14);
  echo aig_row($l_seo ? $h2_st : 'skip',
      'Б.2 — Разделов H2 (норма 8-14)',
      $h2qa !== '—' ? $h2qa . ' H2' : '',
      $h2qa !== '—' && (int)$h2qa < 8 ? 'мало разделов' : ($h2qa !== '—' && (int)$h2qa > 14 ? 'слишком много' : ''));

  // Б.3 Answer-First (из Этап 11)
  $af = aig_val($ai_d, 'answer_first_добавлено');
  $af_n = is_numeric($af) ? (int)$af : -1;
  echo aig_row($l_ai ? ($af_n > 0 ? 'ok' : 'warn') : 'skip',
      'Б.3 — Answer-First TL;DR в H2 (40-75 слов)',
      $af !== '—' ? 'добавлен в ' . $af . ' H2' : '',
      'первый параграф каждого H2 — прямой ответ');

  // Б.4 Параграфы 2-4 предл. (не логируется напрямую)
  echo aig_row($l_seo ? 'ok' : 'skip',
      'Б.4 — Параграфы 2-4 предложения (одна идея)',
      '',
      'встроено в системный промпт');

  // Б.5 Standalone-секции (не логируется)
  echo aig_row($l_seo ? 'ok' : 'skip',
      'Б.5 — Standalone-секции (без ссылок "как выше")',
      '',
      'встроено в системный промпт');

  // Б.6 Таблицы
  $tbl = aig_val($seo_d, 'таблиц');
  list($tbl_st, ) = aig_num($tbl, 1);
  echo aig_row($l_seo ? $tbl_st : 'skip',
      'Б.6 — Сравнительные таблицы (мин. 1)',
      $tbl !== '—' ? $tbl . ' таблиц' : '',
      'А vs Б = <table> без JS');

  // Б.7 Нумерованные списки
  $ol = aig_val($seo_d, 'нумерованных_списков');
  echo aig_row($l_seo ? ((int)$ol >= 1 ? 'ok' : 'warn') : 'skip',
      'Б.7 — Нумерованные списки пошаговых процессов',
      $ol !== '—' ? $ol . ' списков <ol>' : '',
      'процессы = <ol>, характеристики = <ul>');

  // Б.8 Факты с источниками (не логируются отдельно)
  echo aig_row($l_seo ? 'ok' : 'skip',
      'Б.8 — Факты с именованными источниками',
      '',
      'каждая цифра/цитата = «По данным [Источник]...»');

  // Б.9 Явное именование (не логируется)
  echo aig_row($l_seo ? 'ok' : 'skip',
      'Б.9 — Явное именование сущностей (без "оно/это")',
      '',
      'встроено в промпт');

  // Б.10 CTA
  $cta = aig_val($seo_d, 'CTA_точек');
  list($cta_st, ) = aig_num($cta, 3, 3);
  echo aig_row($l_seo ? $cta_st : 'skip',
      'Б.10 — CTA-точки (должно быть ровно 3)',
      $cta !== '—' ? $cta . ' CTA' : '',
      'до H2 · 25-35% · после источников');

  // Б.11 FAQ
  $faq_qa = aig_val($seo_d, 'FAQ');
  echo aig_row($l_seo ? ($faq_qa === 'да' ? 'ok' : 'warn') : 'skip',
      'Б.11 — FAQ-блок <div class="faq-block">',
      $faq_qa !== '—' ? $faq_qa : '',
      'мин. 3 вопроса перед источниками');

  // Б.12 Источники
  $src_qa = aig_val($seo_d, 'блок_источников');
  echo aig_row($l_seo ? ($src_qa === 'да' ? 'ok' : 'warn') : 'skip',
      'Б.12 — Блок «Источники» (мин. 5 именованных)',
      $src_qa !== '—' ? $src_qa : '',
      '<h2>Источники</h2><ul>...');

  // Б.13 Внутренние ссылки
  $links = aig_val($seo_d, 'внутренних_ссылок');
  list($links_st, ) = aig_num($links, 3);
  echo aig_row($l_seo ? $links_st : 'skip',
      'Б.13 — Внутренние ссылки (мин. 3)',
      $links !== '—' ? $links . ' ссылок' : '',
      'описательные анкоры');

  // ══════════════════════════════════════════════════════
  // БЛОК 7: QA — ANTI-AI ХУМАНИЗАЦИЯ (Этап 11 / Блок В)
  // ══════════════════════════════════════════════════════
  echo aig_section('Этап 11: Anti-AI хуманизация (Блок В)', '✂️');

  // В.1 Длинные тире
  $em = aig_val($ai_d, 'длинных_тире_в_тексте');
  $em_rep = aig_val($ai_d, 'тире_заменено');
  $em_st = 'skip';
  if ($l_ai) { $em_st = ((int)$em === 0) ? 'ok' : 'warn'; }
  echo aig_row($em_st,
      'В.1 — Длинные тире (—) убраны → дефис',
      $em !== '—' ? 'осталось: ' . $em . ($em_rep !== '—' ? ' · заменено при написании: ' . $em_rep : '') : '',
      'главный маркер ИИ-текста — ни одного в финале');

  // В.2 Клише
  $cl = aig_val($ai_d, 'клише_убрано');
  echo aig_row($l_ai ? ((int)$cl >= 0 ? 'ok' : 'skip') : 'skip',
      'В.2 — Запрещённые клише убраны',
      $cl !== '—' ? $cl . ' клише' : '',
      'таким образом / следует отметить / данный / ...');

  // В.3 Симметрии (H2 в вопрос — косвенный показатель)
  $h2q = aig_val($ai_d, 'H2_в_вопрос');
  echo aig_row($l_ai ? 'ok' : 'skip',
      'В.3 — Симметрии переписаны в живую речь',
      $h2q !== '—' ? 'H2 в вопрос: ' . $h2q : '',
      'Во-первых/во-вторых → конкретные шаги');

  // В.4 Запрещённый зачин
  echo aig_row($l_ai ? 'ok' : 'skip',
      'В.4 — Запрещённый зачин убран',
      '',
      'Привет друзья / Сегодня поговорим / В этой статье...');

  // В.5 Запрещённая концовка
  echo aig_row($l_ai ? 'ok' : 'skip',
      'В.5 — Запрещённая концовка убрана',
      '',
      'Спасибо за внимание / Подписывайтесь / До новых встреч');

  // В.6 Ритм предложений
  echo aig_row($l_ai ? 'ok' : 'skip',
      'В.6 — Монотонный ритм разбит',
      '',
      'длинное - короткое - длинное (не удар-удар-удар)');

  // В.7 Кальки с английского
  echo aig_row($l_ai ? 'ok' : 'skip',
      'В.7 — Машинные кальки убраны',
      '',
      'погружаемся в / бесшовно / всеобъемлющий / ...');

  // В.8 Местоимения
  echo aig_row($l_ai ? 'ok' : 'skip',
      'В.8 — Местоимения заменены на имена',
      '',
      'оно/это/он/она → повторить имя через 2 предл.');

  // ══════════════════════════════════════════════════════
  // БЛОК 8: QA — SCHEMA (Блок Г)
  // ══════════════════════════════════════════════════════
  echo aig_section('Блок Г: JSON-LD Schema рекомендации', '🏷️');
  echo aig_row($l_done ? 'ok' : 'skip',
      'Schema type выбран (Article / FAQPage / HowTo)',
      '',
      'FAQPage если есть FAQ · HowTo для пошаговых инструкций');

  // ══════════════════════════════════════════════════════
  // БЛОК 9: ЭТАП 0 — ЗАЩИТА ИТОГ
  // ══════════════════════════════════════════════════════
  echo aig_section('Этап 0: Защита блоков — итог', '🔐');

  if ($l_prot_ok) {
      echo aig_row('ok', 'Шорткоды / формы / iframe сохранены без потерь', '', '');
  } elseif ($l_prot_warn) {
      $warn_d = $l_prot_warn['data'];
      $warns  = aig_val($warn_d, 'предупреждения');
      echo aig_row('warn', 'Есть предупреждения при проверке защиты', $warns !== '—' ? $warns : '', '');
  } else {
      echo aig_row('skip', 'Проверка защиты', '', '');
  }

  // ══════════════════════════════════════════════════════
  // БЛОК 10: ГОТОВО
  // ══════════════════════════════════════════════════════
  echo aig_section('Готово — версия сохранена', '✅');

  $fin_vol   = aig_val($done_d, 'итоговый_объём_симв');
  $fin_steps = aig_val($done_d, 'всего_шагов');
  $fin_time  = $total_sec > 0 ? ($total_sec >= 60 ? round($total_sec/60,1) . ' мин' : $total_sec . ' сек') : '—';

  echo aig_row($l_done ? 'ok' : ($has_err ? 'err' : 'skip'),
      $l_done ? 'Улучшенная версия создана и сохранена' : ($has_err ? 'Завершено с ошибкой' : 'Ещё не завершено'),
      $fin_vol !== '—' ? $fin_vol . ' симв' : '',
      ($fin_steps !== '—' ? $fin_steps . ' шагов' : '') . ($fin_time !== '—' ? ' · ' . $fin_time : ''));
  ?>

  </ul>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (!empty($other_logs)): ?>
<div class="aiseogeo-card" style="margin-top:20px">
  <h2 style="padding:16px;margin:0;border-bottom:1px solid #e2e4e7">Прочие события</h2>
  <table class="widefat striped" style="font-size:12px">
    <thead><tr><th style="width:130px">Дата</th><th style="width:55px">Уровень</th><th style="width:110px">Контекст</th><th>Сообщение</th></tr></thead>
    <tbody>
    <?php foreach ($other_logs as $entry):
        $l    = $entry['log'];
        $data = $entry['data'];
        $bg   = $l->level === 'error' ? 'background:#fcebea' : '';
        $parts = array();
        foreach ($data as $k => $v) {
            if ($k === 'raw') { continue; }
            if (is_array($v)) { $v = implode(', ', array_map('strval', $v)); }
            if ($v === '' || $v === null) { continue; }
            $parts[] = '<b>' . esc_html($k) . ':</b> ' . esc_html((string)$v);
        }
        $detail = implode(' &nbsp;·&nbsp; ', $parts);
    ?>
    <tr style="<?php echo $bg; ?>">
      <td><?php echo esc_html(substr($l->created_at, 0, 16)); ?></td>
      <td><?php echo esc_html($l->level); ?></td>
      <td><?php echo esc_html($l->context); ?></td>
      <td><?php echo esc_html($l->message); ?>
        <?php if ($detail): ?><br><span style="color:#666;font-size:11px"><?php echo $detail; ?></span><?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

</div>

<?php if (!defined('ABSPATH')) { exit; }

// ─── Разделяем логи: сеансы переписывания и прочие события ──────────────────
$rewrite_contexts = array('rewrite_step', 'rewrite_plan', 'auto_rewrite');
$sessions  = array(); // rewrite_id => array of logs
$other_logs = array();

foreach ($logs as $l) {
    $d = json_decode((string)$l->data_json, true);
    $rid = !empty($d['rewrite_id']) ? (int)$d['rewrite_id'] : 0;
    if (in_array($l->context, $rewrite_contexts, true) && $rid) {
        $sessions[$rid][] = array('log' => $l, 'data' => $d);
    } else {
        $other_logs[] = array('log' => $l, 'data' => is_array($d) ? $d : array());
    }
}

// Порядок: самые новые сессии сверху (ключи уже desc из recent())
$sessions = array_reverse($sessions, true);

// ─── Этапы «Скилл статей» (порядок отображения в чеклисте) ──────────────────
$checklist_stages = array(
    'plan'      => array('icon' => '📋', 'label' => 'Этап 5 — Структурный план',   'match' => array('Этап 5')),
    'protect'   => array('icon' => '🔒', 'label' => 'Этап 0 — Защита блоков',      'match' => array('Этап 0')),
    'write_req' => array('icon' => '🤖', 'label' => 'Этап 6 — Запрос к AI',        'match' => array('Этап 6: Написание', 'Этап 6: Написание (авто)')),
    'write_res' => array('icon' => '📝', 'label' => 'Этап 6 — Ответ AI получен',   'match' => array('Этап 6')),
    'qa_json'   => array('icon' => '🔍', 'label' => 'QA — Разбор JSON',            'match' => array('Этап 13: QA (JSON)', 'QA (JSON)')),
    'qa_vol'    => array('icon' => '📏', 'label' => 'QA — Объём статьи',           'match' => array('Этап 13: QA (объём)', 'QA (объём)')),
    'qa_seo'    => array('icon' => '🔎', 'label' => 'Этап 9 — SEO/GEO структура',  'match' => array('Этап 9')),
    'qa_ai'     => array('icon' => '✂️', 'label' => 'Этап 11 — Anti-AI хуманизация','match' => array('Этап 11')),
    'done'      => array('icon' => '✅', 'label' => 'Готово — версия сохранена',    'match' => array('Готово')),
);

// ─── Хелпер: найти первый лог сессии, чей этап совпадает с матчером ─────────
function aiseogeo_diag_match_stage($session_logs, $match_keys) {
    foreach ($session_logs as $entry) {
        $stage = isset($entry['data']['этап']) ? (string)$entry['data']['этап'] : '';
        $msg   = (string)$entry['log']->message;
        foreach ($match_keys as $mk) {
            if (strpos($stage, $mk) !== false || strpos($msg, $mk) !== false) {
                return $entry;
            }
        }
    }
    return null;
}

// ─── Хелпер: форматировать детали из data без служебных ключей ───────────────
function aiseogeo_diag_details($data, $skip = array()) {
    $skip_always = array('rewrite_id', 'шаг', 'этап', 'сек_от_старта', 'raw');
    $parts = array();
    foreach ($data as $k => $v) {
        if (in_array($k, $skip_always, true) || in_array($k, $skip, true)) { continue; }
        if (is_array($v)) { $v = implode(', ', array_map(function($x){ return is_scalar($x) ? (string)$x : '…'; }, $v)); }
        if ($v === '' || $v === null) { continue; }
        $parts[] = '<b>' . esc_html($k) . ':</b> ' . esc_html((string)$v);
    }
    return implode(' &nbsp;·&nbsp; ', $parts);
}

// ─── Хелпер: статус строки чеклиста ─────────────────────────────────────────
function aiseogeo_diag_stage_status($entry) {
    if (!$entry) { return 'pending'; }
    $msg = strtolower((string)$entry['log']->message);
    if ($entry['log']->level === 'error' || strpos($msg, 'ошибка') !== false || strpos($msg, 'error') !== false) {
        return 'error';
    }
    return 'done';
}

?>
<style>
.aiseogeo-diag-session { background:#fff; border:1px solid #ddd; border-radius:6px; margin-bottom:20px; overflow:hidden; box-shadow:0 1px 3px rgba(0,0,0,.06); }
.aiseogeo-diag-session-header { display:flex; align-items:center; gap:12px; padding:12px 16px; background:#f8f9fa; border-bottom:1px solid #e2e4e7; }
.aiseogeo-diag-session-title { font-weight:600; font-size:14px; color:#1d2327; flex:1; min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.aiseogeo-diag-session-meta { font-size:11px; color:#666; white-space:nowrap; }
.aiseogeo-diag-badge { display:inline-block; padding:2px 8px; border-radius:10px; font-size:11px; font-weight:600; }
.aiseogeo-diag-badge-done { background:#d1fae5; color:#065f46; }
.aiseogeo-diag-badge-error { background:#fee2e2; color:#991b1b; }
.aiseogeo-diag-badge-running { background:#fef3c7; color:#92400e; }
.aiseogeo-diag-badge-mode { background:#e0e7ff; color:#3730a3; }
.aiseogeo-diag-checklist { padding:0; margin:0; list-style:none; }
.aiseogeo-diag-checklist li { display:flex; align-items:flex-start; gap:10px; padding:8px 16px; border-bottom:1px solid #f0f0f1; font-size:13px; }
.aiseogeo-diag-checklist li:last-child { border-bottom:none; }
.aiseogeo-diag-step-icon { width:22px; height:22px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:13px; flex-shrink:0; margin-top:1px; }
.aiseogeo-diag-step-done   { background:#d1fae5; }
.aiseogeo-diag-step-error  { background:#fee2e2; }
.aiseogeo-diag-step-pending { background:#f3f4f6; opacity:.5; }
.aiseogeo-diag-step-label { font-weight:500; color:#1d2327; }
.aiseogeo-diag-step-details { color:#666; font-size:11px; margin-top:2px; }
.aiseogeo-diag-step-msg { color:#555; font-size:12px; margin-top:1px; font-style:italic; }
.aiseogeo-diag-step-time { margin-left:auto; font-size:10px; color:#999; white-space:nowrap; padding-left:8px; }
.aiseogeo-diag-other { margin-top:24px; }
.aiseogeo-diag-other table td, .aiseogeo-diag-other table th { padding:6px 10px; font-size:12px; vertical-align:top; }
</style>

<div class="wrap aiseogeo-wrap">
<h1>Диагностика</h1>

<div class="aiseogeo-grid two">
  <div class="aiseogeo-card"><h2>Система</h2>
    <p>Плагин: <?php echo esc_html(AISEOGEO_VERSION); ?></p>
    <p>WordPress: <?php echo esc_html(get_bloginfo('version')); ?></p>
    <p>PHP: <?php echo esc_html(PHP_VERSION); ?></p>
    <p>OpenRouter API: <?php echo $settings->get('api_key','') ? 'ключ указан' : 'ключ не указан'; ?></p>
    <p>Модель: <?php echo esc_html($settings->get('model','')); ?></p>
  </div>
  <div class="aiseogeo-card"><h2>Таблицы БД</h2>
    <?php foreach($tables as $t=>$ok): ?><p><?php echo esc_html($t); ?> — <?php echo $ok ? '<span style="color:#065f46">OK</span>' : '<span style="color:#991b1b">нет</span>'; ?></p><?php endforeach; ?>
  </div>
</div>

<?php if (!empty($sessions)): ?>
<div class="aiseogeo-card" style="margin-top:20px">
  <h2>Сеансы переписывания <span style="font-weight:400;font-size:13px;color:#666">(последние <?php echo count($sessions); ?>)</span></h2>

<?php foreach ($sessions as $rid => $session_logs):
    $rewrite = isset($rewrites_map[$rid]) ? $rewrites_map[$rid] : null;
    $title   = $rewrite ? (string)$rewrite->original_title : ('Сеанс #' . $rid);
    if (empty($title)) { $title = 'Сеанс #' . $rid; }
    $mode    = $rewrite ? (string)$rewrite->rewrite_mode : '';
    $status  = $rewrite ? (string)$rewrite->rewrite_status : '';
    $post_id = $rewrite ? (int)$rewrite->post_id : 0;

    // Время начала и конца
    $first_log = end($session_logs); reset($session_logs);
    $last_log  = $session_logs[0];
    $started   = $first_log['log']->created_at ?? '';
    $ended     = $last_log['log']->created_at ?? '';

    // Общее время в секундах
    $last_data = $last_log['data'];
    $total_sec = isset($last_data['сек_от_старта']) ? (float)$last_data['сек_от_старта'] : 0;
    $time_str  = $total_sec > 60 ? round($total_sec/60, 1) . ' мин' : $total_sec . ' сек';

    // Статус-бейдж
    $has_error = false;
    foreach ($session_logs as $e) { if ($e['log']->level === 'error') { $has_error = true; break; } }
    $is_done   = ($status === 'done');

    $badge_class = $has_error ? 'error' : ($is_done ? 'done' : 'running');
    $badge_text  = $has_error ? '✗ Ошибка' : ($is_done ? '✓ Готово' : '⟳ В процессе');

    $mode_labels = array(
        'full_refresh'=>'Полное обновление','soft_improve'=>'Мягкое улучшение','seo_boost'=>'SEO',
        'geo_boost'=>'GEO','seo_geo_boost'=>'SEO+GEO','meta_only'=>'Только мета','problem_blocks_only'=>'Проблемные блоки'
    );
    $mode_label = isset($mode_labels[$mode]) ? $mode_labels[$mode] : $mode;
?>
<div class="aiseogeo-diag-session">
  <div class="aiseogeo-diag-session-header">
    <span style="font-size:18px">📄</span>
    <span class="aiseogeo-diag-session-title" title="<?php echo esc_attr($title); ?>">
      <?php if ($post_id): ?><a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>" target="_blank" style="color:inherit;text-decoration:none"><?php echo esc_html($title); ?></a><?php else: echo esc_html($title); endif; ?>
    </span>
    <?php if ($mode_label): ?><span class="aiseogeo-diag-badge aiseogeo-diag-badge-mode"><?php echo esc_html($mode_label); ?></span><?php endif; ?>
    <span class="aiseogeo-diag-badge aiseogeo-diag-badge-<?php echo $badge_class; ?>"><?php echo $badge_text; ?></span>
    <span class="aiseogeo-diag-session-meta">
      <?php echo esc_html(substr($started, 0, 16)); ?>
      <?php if ($total_sec > 0): ?> &nbsp;·&nbsp; ⏱ <?php echo esc_html($time_str); ?><?php endif; ?>
      &nbsp;·&nbsp; <?php echo count($session_logs); ?> событий
    </span>
  </div>

  <ul class="aiseogeo-diag-checklist">
  <?php foreach ($checklist_stages as $stage_key => $stage_def):
      // Специальная логика: write_req = первый "Запрос к AI", write_res = "Ответ AI получен"
      if ($stage_key === 'write_req') {
          $entry = null;
          foreach ($session_logs as $e) {
              $msg = (string)$e['log']->message;
              if (strpos($msg, 'Запрос к AI') !== false || strpos($msg, 'запрос к AI') !== false) { $entry = $e; break; }
          }
      } elseif ($stage_key === 'write_res') {
          $entry = null;
          foreach ($session_logs as $e) {
              $msg = (string)$e['log']->message;
              if (strpos($msg, 'Ответ AI получен') !== false || strpos($msg, 'ответ AI получен') !== false) { $entry = $e; break; }
          }
      } else {
          $entry = aiseogeo_diag_match_stage($session_logs, $stage_def['match']);
      }

      $st = aiseogeo_diag_stage_status($entry);

      $icon_map = array('done' => '✓', 'error' => '✗', 'pending' => '·');
      $icon_ch  = $icon_map[$st];
      $class_ch = 'aiseogeo-diag-step-' . $st;

      $details_html = '';
      $msg_html     = '';
      $time_html    = '';

      if ($entry) {
          $details_html = aiseogeo_diag_details($entry['data']);
          // Сообщение (без префикса [Шаг N])
          $clean_msg = preg_replace('/^\[Шаг \d+\]\s*/', '', (string)$entry['log']->message);
          $clean_msg = trim($clean_msg);
          // Не дублируем label в сообщении
          if (!empty($clean_msg) && $clean_msg !== $stage_def['label']) {
              $msg_html = esc_html($clean_msg);
          }
          if (isset($entry['data']['сек_от_старта']) && $entry['data']['сек_от_старта'] > 0) {
              $time_html = esc_html('+' . $entry['data']['сек_от_старта'] . 'с');
          }
      }
  ?>
  <li>
    <div class="aiseogeo-diag-step-icon <?php echo $class_ch; ?>"><?php echo $icon_ch; ?></div>
    <div style="flex:1;min-width:0">
      <div class="aiseogeo-diag-step-label"><?php echo $stage_def['icon']; ?> <?php echo esc_html($stage_def['label']); ?></div>
      <?php if ($msg_html): ?><div class="aiseogeo-diag-step-msg"><?php echo $msg_html; ?></div><?php endif; ?>
      <?php if ($details_html): ?><div class="aiseogeo-diag-step-details"><?php echo $details_html; ?></div><?php endif; ?>
    </div>
    <?php if ($time_html): ?><div class="aiseogeo-diag-step-time"><?php echo $time_html; ?></div><?php endif; ?>
  </li>
  <?php endforeach; ?>
  </ul>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (!empty($other_logs)): ?>
<div class="aiseogeo-card aiseogeo-diag-other">
  <h2>Прочие события</h2>
  <table class="widefat striped">
    <thead><tr><th style="width:130px">Дата</th><th style="width:55px">Уровень</th><th style="width:110px">Контекст</th><th>Сообщение</th></tr></thead>
    <tbody>
    <?php foreach ($other_logs as $entry):
        $l    = $entry['log'];
        $data = $entry['data'];
        $row_bg = $l->level === 'error' ? 'background:#fcebea' : '';
        $parts  = array();
        foreach ($data as $k => $v) {
            if (in_array($k, array('raw'), true)) { continue; }
            if (is_array($v)) { $v = implode(', ', array_map(function($x){ return is_scalar($x)?(string)$x:'…'; }, $v)); }
            if ($v === '' || $v === null) { continue; }
            $parts[] = '<b>' . esc_html($k) . ':</b> ' . esc_html((string)$v);
        }
        $detail = implode(' &nbsp;·&nbsp; ', $parts);
    ?>
    <tr style="<?php echo $row_bg; ?>">
      <td><?php echo esc_html(substr($l->created_at, 0, 16)); ?></td>
      <td><?php echo esc_html($l->level); ?></td>
      <td><?php echo esc_html($l->context); ?></td>
      <td><?php echo esc_html($l->message); ?>
        <?php if ($detail): ?><br><span style="color:#666;font-size:11px"><?php echo $detail; ?></span><?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

</div>

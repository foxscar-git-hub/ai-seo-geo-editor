<?php if (!defined('ABSPATH')) { exit; }
$api_ok    = $settings->get('api_key','') !== '';
$model     = $settings->get('model','не указана');
$auto_on   = $settings->get('auto_optimize_enabled','0') === '1';
?>
<div class="wrap aiseogeo-wrap">
  <h1>AI SEO/GEO Редактор статей</h1>

  <?php if (!$api_ok): ?>
  <div class="notice notice-error"><p>API-ключ OpenRouter не указан. <a href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-openrouter')); ?>"><strong>Указать ключ →</strong></a></p></div>
  <?php endif; ?>

  <div class="aiseogeo-grid" style="grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px">
    <div class="aiseogeo-card" style="text-align:center">
      <div style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Проверок всего</div>
      <div class="aiseogeo-big"><?php echo esc_html($stats['total']); ?></div>
    </div>
    <div class="aiseogeo-card" style="text-align:center">
      <div style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Успешно</div>
      <div class="aiseogeo-big" style="color:#065f46"><?php echo esc_html($stats['done']); ?></div>
    </div>
    <div class="aiseogeo-card" style="text-align:center">
      <div style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Слабых статей</div>
      <div class="aiseogeo-big" style="color:#b45309"><?php echo esc_html($stats['weak']); ?></div>
    </div>
    <div class="aiseogeo-card" style="text-align:center">
      <div style="font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px">Ошибок API</div>
      <div class="aiseogeo-big" style="color:<?php echo $stats['errors'] > 0 ? '#b91c1c' : '#6b7280'; ?>"><?php echo esc_html($stats['errors']); ?></div>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">

    <div class="aiseogeo-card">
      <h2 style="margin-top:0">Быстрые действия</h2>
      <p style="margin:0 0 8px">
        <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audits')); ?>">📋 Анализ записей</a>
        <span class="description" style="margin-left:8px">Выбрать и проанализировать статью</span>
      </p>
      <p style="margin:0 0 8px">
        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rewrite')); ?>">✏️ Переписывание</a>
        <span class="description" style="margin-left:8px">Запустить переписывание по статейнику</span>
      </p>
      <p style="margin:0 0 8px">
        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-bulk')); ?>">⚡ Массовая обработка</a>
        <span class="description" style="margin-left:8px">Обработать несколько статей сразу</span>
      </p>
      <p style="margin:0">
        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-versions')); ?>">📁 История версий</a>
        <span class="description" style="margin-left:8px">Сравнить и применить результат</span>
      </p>
    </div>

    <div class="aiseogeo-card">
      <h2 style="margin-top:0">Статус системы</h2>
      <table style="width:100%;font-size:13px;border-collapse:collapse">
        <tr>
          <td style="padding:5px 0;color:#555;width:140px">API OpenRouter</td>
          <td><?php echo $api_ok ? '<span style="color:#065f46;font-weight:600">✓ ключ указан</span>' : '<span style="color:#b91c1c;font-weight:600">✗ не указан</span>'; ?>
          &nbsp;<a href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-openrouter')); ?>" style="font-size:11px">настроить</a></td>
        </tr>
        <tr>
          <td style="padding:5px 0;color:#555">Модель</td>
          <td style="font-family:monospace;font-size:12px"><?php echo esc_html($model); ?></td>
        </tr>
        <tr>
          <td style="padding:5px 0;color:#555">Автопереписывание</td>
          <td><?php echo $auto_on
            ? '<span style="color:#065f46;font-weight:600">✓ включено</span>'
            : '<span style="color:#6b7280">выключено</span>'; ?>
          &nbsp;<a href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-learning')); ?>" style="font-size:11px">настроить</a></td>
        </tr>
        <tr>
          <td style="padding:5px 0;color:#555">Версия плагина</td>
          <td><?php echo esc_html(AISEOGEO_VERSION); ?></td>
        </tr>
        <tr>
          <td style="padding:5px 0;color:#555">Диагностика</td>
          <td><a href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-diagnostics')); ?>">открыть логи этапов →</a></td>
        </tr>
      </table>
    </div>

  </div>
</div>

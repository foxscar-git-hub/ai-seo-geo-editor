<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap">
  <h1>Отчёт по сайту</h1>
  <div class="aiseogeo-kpis">
    <div><span>Записей всего</span><strong><?php echo absint($report['posts_total']); ?></strong></div>
    <div><span>Проанализировано</span><strong><?php echo absint($report['checked']); ?></strong></div>
    <div><span>Требуют улучшения</span><strong><?php echo absint($report['needs_attention'] ?? 0); ?></strong></div>
    <div><span>Критических<br><small>оценка ниже 40/100</small></span><strong><?php echo absint($report['critical']); ?></strong></div>
  </div>
  <?php $insights = isset($report['optimization_insights']) && is_array($report['optimization_insights']) ? $report['optimization_insights'] : array(); ?>
  <div class="aiseogeo-card">
    <div class="aiseogeo-section-head">
      <div>
        <h2>Эффективность оптимизации обработанных материалов</h2>
        <p>Сводная аналитика “до/после” считается только по записям, которые уже были обработаны плагином: проанализированы, переписаны или применены к оригиналу.</p>
      </div>
      <span class="aiseogeo-badge">ДО / ПОСЛЕ</span>
    </div>
    <div class="aiseogeo-note" style="margin:10px 0 16px;">
      В расчёт блока входят AI-версии: <strong><?php echo absint($insights['total_rewrites'] ?? 0); ?></strong>; применено к оригиналам: <strong><?php echo absint($insights['applied_rewrites'] ?? 0); ?></strong>. Общие записи сайта без анализа/AI-версии здесь не учитываются.
    </div>
    <?php if (!empty($insights['has_data'])): $changes = (array)($insights['change_summary'] ?? array()); ?>
      <h3>Конверсия в выдаче по обработанным материалам: до и после</h3>
      <div class="aiseogeo-forecast-grid">
        <?php foreach ((array)($insights['forecast_rows'] ?? array()) as $row): ?>
          <div class="aiseogeo-forecast-item">
            <h3><?php echo esc_html($row['label'] ?? 'Показатель'); ?></h3>
            <div class="aiseogeo-before-after">
              <div><span>До</span><strong><?php echo absint($row['before'] ?? 0); ?></strong></div>
              <div><span>После</span><strong><?php echo absint($row['after'] ?? 0); ?></strong></div>
              <div class="aiseogeo-delta"><span>Рост</span><strong><?php echo ((int)($row['delta'] ?? 0) >= 0 ? '+' : '') . intval($row['delta'] ?? 0); ?></strong></div>
            </div>
            <div class="aiseogeo-meter"><i style="width:<?php echo esc_attr(max(0,min(100,(int)($row['after'] ?? 0)))); ?>%"></i></div>
            <p class="aiseogeo-note"><?php echo esc_html($row['note'] ?? ''); ?></p>
          </div>
        <?php endforeach; ?>
      </div>
      <h3>Понятное сравнение изменений по обработанным материалам</h3>
      <div class="aiseogeo-diff-card">
        <div class="aiseogeo-diff-kpi">
          <div><span>AI-версий создано</span><strong><?php echo absint($insights['total_rewrites'] ?? 0); ?></strong><em>переписанные версии</em></div>
          <div><span>Применено к оригиналам</span><strong><?php echo absint($insights['applied_rewrites'] ?? 0); ?></strong><em>боевые применения</em></div>
          <div><span>Новые title</span><strong><?php echo absint($changes['changed_title'] ?? 0); ?></strong><em>заголовки изменены</em></div>
          <div><span>Новые description</span><strong><?php echo absint($changes['new_meta_description'] ?? 0); ?></strong><em>meta description</em></div>
          <div><span>FAQ сохранён/добавлен</span><strong><?php echo absint($changes['faq_saved_or_added'] ?? 0); ?></strong><em>GEO-блоки</em></div>
          <div><span>CTA сохранён</span><strong><?php echo absint($changes['cta_saved'] ?? 0); ?></strong><em>важные призывы</em></div>
          <div><span>Ссылки сохранены</span><strong><?php echo absint($changes['links_preserved'] ?? 0); ?></strong><em>перелинковка</em></div>
          <div><span>Средний рост текста</span><strong><?php echo intval($changes['avg_text_growth_percent'] ?? 0); ?>%</strong><em>по AI-версиям</em></div>
        </div>
      </div>
      <p class="aiseogeo-note"><strong>Важно:</strong> <?php echo esc_html($insights['note'] ?? 'Показатели являются прогнозными и не заменяют аналитику поисковых систем.'); ?></p>
    <?php else: ?>
      <p>Сводная аналитика “до/после” появится после создания первых AI-версий. Необработанные записи сайта в этот блок не входят.</p>
    <?php endif; ?>
  </div>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card"><h2>Средние оценки</h2><p>Общая: <strong><?php echo esc_html($report['avg']['overall']); ?>/100</strong></p><p>SEO: <strong><?php echo esc_html($report['avg']['seo']); ?>/100</strong></p><p>GEO: <strong><?php echo esc_html($report['avg']['geo']); ?>/100</strong></p><p>EEAT: <strong><?php echo esc_html($report['avg']['eeat']); ?>/100</strong></p></div>
    <div class="aiseogeo-card"><h2>Быстрые риски</h2><p>Без meta description: <strong><?php echo absint($report['no_meta']); ?></strong></p><p>Без FAQ-блока: <strong><?php echo absint($report['no_faq']); ?></strong><br><small>Считаются записи без отдельного H2/H3 “Частые вопросы / FAQ”.</small></p><p>Давно не обновлялись: <strong><?php echo absint($report['old']); ?></strong><br><small>Не изменялись более <?php echo absint($report['old_days'] ?? 180); ?> дней.</small></p><p>Без анализа: <strong><?php echo absint($report['unchecked']); ?></strong></p></div>
  </div>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card"><h2>Топ статей для улучшения</h2><ol><?php foreach((array)$report['weak_posts'] as $r): ?><li><a href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-report&audit_id=' . absint($r->id))); ?>"><?php echo esc_html($r->post_title); ?></a> — <?php echo absint($r->overall_score); ?>/100</li><?php endforeach; ?></ol></div>
    <div class="aiseogeo-card"><h2>Топ сильных статей</h2><ol><?php foreach((array)$report['strong_posts'] as $r): ?><li><a href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-report&audit_id=' . absint($r->id))); ?>"><?php echo esc_html($r->post_title); ?></a> — <?php echo absint($r->overall_score); ?>/100</li><?php endforeach; ?></ol></div>
  </div>
  <div class="aiseogeo-card"><h2>Частые проблемы</h2><ol><?php foreach((array)$report['top_problems'] as $problem=>$count): ?><li><?php echo esc_html($problem); ?> <strong>×<?php echo absint($count); ?></strong></li><?php endforeach; ?></ol></div>
</div>

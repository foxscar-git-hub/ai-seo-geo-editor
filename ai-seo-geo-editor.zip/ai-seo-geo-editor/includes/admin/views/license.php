<?php if (!defined('ABSPATH')) { exit; } $status = $license->status(); $plan = !empty($license_gate) ? $license_gate->plan() : 'free'; $remaining = !empty($license_gate) ? $license_gate->remaining_free_audits() : null; ?>
<div class="wrap aiseogeo-wrap">
  <h1>Лицензия и коммерческий доступ</h1>
  <?php if (isset($_GET['saved'])): ?><div class="notice notice-success"><p>Настройки лицензии сохранены.</p></div><?php endif; ?>
  <?php if (isset($_GET['checked'])): ?><div class="notice notice-success"><p>Лицензия проверена.</p></div><?php endif; ?>
  <?php if (!empty($_GET['aiseogeo_error'])): ?><div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div><?php endif; ?>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card">
      <h2>Статус лицензии</h2>
      <p><strong>Статус:</strong> <?php echo esc_html($status['status']); ?></p>
      <p><strong>Тариф / режим:</strong> <?php echo esc_html($plan); ?></p>
      <p><strong>Сообщение:</strong> <?php echo esc_html($status['message']); ?></p>
      <p><strong>Ключ:</strong> <?php echo esc_html($status['license_key'] ?: 'не указан'); ?></p>
      <p><strong>Последняя проверка:</strong> <?php echo esc_html($status['last_checked_at'] ?: 'ещё не было'); ?></p>
      <?php if (!empty($status['expires_at'])): ?><p><strong>Действует до:</strong> <?php echo esc_html($status['expires_at']); ?></p><?php endif; ?>
      <?php if ($remaining !== null): ?><p><strong>Бесплатных анализов осталось:</strong> <?php echo esc_html($remaining); ?> из <?php echo esc_html($license_gate->free_audit_limit()); ?></p><?php endif; ?>
    </div>
    <div class="aiseogeo-card">
      <h2>Активация лицензии</h2>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <?php wp_nonce_field('aiseogeo_save_license'); ?>
        <input type="hidden" name="action" value="aiseogeo_save_license">
        <table class="form-table" role="presentation">
          <tr><th scope="row">Лицензионный ключ</th><td><input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr($settings->get('license_key','')); ?>" autocomplete="off"><p class="description">Введите лицензионный ключ для активации всех функций.</p></td></tr>
        </table>
        <?php submit_button('Сохранить лицензию'); ?>
      </form>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top:10px">
        <?php wp_nonce_field('aiseogeo_check_license'); ?>
        <input type="hidden" name="action" value="aiseogeo_check_license">
        <?php submit_button('Проверить лицензию', 'secondary', 'submit', false); ?>
      </form>
    </div>
  </div>
  <div class="aiseogeo-card">
    <h2>Доступность функций</h2>
    <table class="widefat striped">
      <thead><tr><th>Функция</th><th>Статус</th></tr></thead>
      <tbody>
        <?php $rows = array(
          'audit' => 'AI-анализ',
          'rewrite_plan' => 'План улучшения',
          'rewrite' => 'AI-переписывание',
          'draft_create' => 'Создание черновика',
          're_audit' => 'Повторный анализ',
          'apply' => 'Применение к оригиналу',
          'rollback' => 'Откат',
          'bulk_process' => 'Массовая обработка',
          'site_report_shortcode' => 'Фронтенд-отчёт',
        ); foreach ($rows as $feature=>$label): ?>
          <tr><td><?php echo esc_html($label); ?></td><td><?php echo !empty($license_gate) ? $license_gate->feature_badge($feature) : '—'; ?></td></tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

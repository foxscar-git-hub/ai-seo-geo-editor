<?php if (!defined('ABSPATH')) { exit; }
$q = new WP_Query(array('post_type'=>'post','post_status'=>'any','posts_per_page'=>50,'orderby'=>'date','order'=>'DESC'));
?>
<div class="wrap aiseogeo-wrap">
  <h1>Переписывание</h1>
  <div class="aiseogeo-card"><p>Здесь создаются улучшенные версии статей на основе уже выполненного AI SEO/GEO-анализа. Оригинальные записи на Этапе 2 не изменяются.</p></div>
  <table class="widefat striped">
    <thead><tr><th>Запись</th><th>Статус</th><th>Последний анализ</th><th>Оценки</th><th>Версий</th><th>Действия</th></tr></thead>
    <tbody>
      <?php foreach ($q->posts as $p): $audit=$audit_service->get_latest_audit($p->ID); $rewrites=$rewrite_service->get_post_rewrites($p->ID); ?>
      <tr>
        <td><strong><?php echo esc_html(get_the_title($p)); ?></strong><br><a href="<?php echo esc_url(get_edit_post_link($p->ID)); ?>">Редактировать запись</a></td>
        <td><?php echo esc_html($p->post_status); ?></td>
        <td><?php echo $audit ? esc_html(mysql2date('d.m.Y H:i',$audit->created_at)) : 'Нет анализа'; ?></td>
        <td><?php echo $audit ? ('Общая '.$audit->overall_score.'/100 · SEO '.$audit->seo_score.' · GEO '.$audit->geo_score.' · EEAT '.$audit->eeat_score) : '—'; ?></td>
        <td><?php echo esc_html(count($rewrites)); ?></td>
        <td>
          <?php if ($audit): ?>
            <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rewrite-create&post_id=' . absint($p->ID) . '&audit_id=' . absint($audit->id))); ?>">Создать улучшенную версию</a>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-report&audit_id=' . absint($audit->id))); ?>">Открыть отчёт</a>
          <?php else: ?>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($p->ID))); ?>">Сначала выполнить анализ</a>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

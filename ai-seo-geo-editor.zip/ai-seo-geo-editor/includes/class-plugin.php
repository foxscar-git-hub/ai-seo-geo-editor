<?php
if (!defined('ABSPATH')) { exit; }

require_once AISEOGEO_DIR . 'includes/class-installer.php';
require_once AISEOGEO_DIR . 'includes/class-capabilities.php';
require_once AISEOGEO_DIR . 'includes/class-settings.php';
require_once AISEOGEO_DIR . 'includes/class-logger.php';
require_once AISEOGEO_DIR . 'includes/class-openrouter-client.php';
require_once AISEOGEO_DIR . 'includes/class-post-content-reader.php';
require_once AISEOGEO_DIR . 'includes/class-audit-result-parser.php';
require_once AISEOGEO_DIR . 'includes/class-json-helper.php';
require_once AISEOGEO_DIR . 'includes/class-audit-service.php';
require_once AISEOGEO_DIR . 'includes/class-content-protector.php';
require_once AISEOGEO_DIR . 'includes/class-version-service.php';
require_once AISEOGEO_DIR . 'includes/class-rewrite-plan-service.php';
require_once AISEOGEO_DIR . 'includes/class-quality-gates.php';
require_once AISEOGEO_DIR . 'includes/class-rewrite-steps.php';
require_once AISEOGEO_DIR . 'includes/class-rewrite-service.php';
require_once AISEOGEO_DIR . 'includes/class-draft-service.php';
require_once AISEOGEO_DIR . 'includes/class-comparison-service.php';
require_once AISEOGEO_DIR . 'includes/class-search-forecast-service.php';
require_once AISEOGEO_DIR . 'includes/class-backup-service.php';
require_once AISEOGEO_DIR . 'includes/class-apply-log-service.php';
require_once AISEOGEO_DIR . 'includes/class-apply-service.php';
require_once AISEOGEO_DIR . 'includes/class-rollback-service.php';
require_once AISEOGEO_DIR . 'includes/class-post-filter-service.php';
require_once AISEOGEO_DIR . 'includes/class-action-scheduler.php';
require_once AISEOGEO_DIR . 'includes/class-site-report-service.php';
require_once AISEOGEO_DIR . 'includes/class-site-optimization-insights-service.php';
require_once AISEOGEO_DIR . 'includes/class-auto-optimize-service.php';
require_once AISEOGEO_DIR . 'includes/class-updater.php';
require_once AISEOGEO_DIR . 'includes/class-meta-output-service.php';
require_once AISEOGEO_DIR . 'includes/class-shortcodes.php';
require_once AISEOGEO_DIR . 'includes/class-admin-assets.php';
require_once AISEOGEO_DIR . 'includes/class-admin-menu.php';
require_once AISEOGEO_DIR . 'includes/class-post-metabox.php';
require_once AISEOGEO_DIR . 'includes/class-rest-controller.php';
require_once AISEOGEO_DIR . 'includes/class-learning-service.php';
require_once AISEOGEO_DIR . 'includes/class-learning-tracker.php';
require_once AISEOGEO_DIR . 'includes/prompts/class-prompt-loader.php';

final class AISEOGEO_Plugin {
    private static $instance = null;
    public $settings;
    public $logger;
    public $audit_service;
    public $rewrite_service;
    public $learning_service;

    public static function instance() { if (self::$instance === null) { self::$instance = new self(); } return self::$instance; }
    public static function activate() { AISEOGEO_Installer::install(); AISEOGEO_Capabilities::add_caps(); }
    public static function deactivate() { AISEOGEO_Capabilities::remove_caps(); }

    public function init() {
        if (get_option('aiseogeo_version') !== AISEOGEO_VERSION) { AISEOGEO_Installer::install(); AISEOGEO_Capabilities::add_caps(); }
        $this->settings = new AISEOGEO_Settings();
        $this->logger = new AISEOGEO_Logger();
        $this->audit_service = new AISEOGEO_Audit_Service($this->settings, $this->logger);
        $this->rewrite_service = new AISEOGEO_Rewrite_Service($this->settings, $this->logger, $this->audit_service);

        (new AISEOGEO_Admin_Assets())->init();
        (new AISEOGEO_Admin_Menu($this->audit_service, $this->settings, $this->logger, $this->rewrite_service))->init();
        (new AISEOGEO_Post_Metabox($this->audit_service))->init();
        (new AISEOGEO_REST_Controller($this->audit_service, $this->settings, $this->logger, $this->rewrite_service))->init();
        (new AISEOGEO_Action_Scheduler($this->audit_service, $this->rewrite_service, $this->logger, $this->settings))->init();
        $auto_optimize = new AISEOGEO_Auto_Optimize_Service($this->settings, $this->logger, $this->audit_service, $this->rewrite_service);
        $auto_optimize->init();
        $auto_optimize->register_cron();
        (new AISEOGEO_Updater())->init();
        (new AISEOGEO_Meta_Output_Service($this->settings))->init();
        (new AISEOGEO_Shortcodes($this->audit_service))->init();

        $this->learning_service = new AISEOGEO_Learning_Service($this->settings, $this->logger);
        $this->learning_service->init();
        (new AISEOGEO_Learning_Tracker($this->settings))->init();

        add_filter('post_row_actions', array($this, 'add_row_action'), 10, 2);
        add_filter('manage_post_posts_columns', array($this, 'add_posts_column'));
        add_action('manage_post_posts_custom_column', array($this, 'render_posts_column'), 10, 2);
    }

    public function add_row_action($actions, $post) {
        if (!$post || $post->post_type !== 'post') { return $actions; }
        if (current_user_can('aiseogeo_run_audit')) {
            $url = admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post->ID));
            $actions['aiseogeo_audit'] = '<a href="' . esc_url($url) . '">AI анализ</a>';
        }
        if (current_user_can('aiseogeo_run_rewrite') && $this->audit_service->get_latest_audit($post->ID)) {
            $latest = $this->audit_service->get_latest_audit($post->ID);
            $rewrite_url = admin_url('admin.php?page=aiseogeo-rewrite-create&post_id=' . absint($post->ID) . '&audit_id=' . absint($latest->id));
            $actions['aiseogeo_rewrite'] = '<a href="' . esc_url($rewrite_url) . '">AI переписать</a>';
        }
        return $actions;
    }

    public function add_posts_column($columns) {
        $new = array();
        foreach ($columns as $key => $label) { $new[$key] = $label; if ($key === 'title') { $new['aiseogeo_score'] = 'AI SEO/GEO'; } }
        if (!isset($new['aiseogeo_score'])) { $new['aiseogeo_score'] = 'AI SEO/GEO'; }
        return $new;
    }

    public function render_posts_column($column, $post_id) {
        if ($column !== 'aiseogeo_score') { return; }
        if (!current_user_can('aiseogeo_view_reports')) { echo '—'; return; }

        $audit       = $this->audit_service->get_latest_audit($post_id);
        $has_rewrite = $this->has_done_rewrite($post_id);
        $is_optimized= get_post_meta($post_id, '_aiseogeo_is_optimized_copy', true);
        $is_auto     = get_post_meta($post_id, '_aiseogeo_auto_optimized', true);
        $auto_ver    = get_post_meta($post_id, '_aiseogeo_auto_version', true); // '2' для новых, '' для старых
        $rewritten   = $has_rewrite || $is_optimized;

        // ── Бейдж версии ──────────────────────────────────────────────────────
        $badge = '';
        if ($is_auto || $has_rewrite) {
            if ($auto_ver === '2') {
                $badge = ' <span class="aiseogeo-badge-auto" style="background:#065f46">авто v2</span>';
            } else {
                $badge = ' <span class="aiseogeo-badge-auto">авто v1</span>';
            }
        }

        $in_progress = $this->has_active_rewrite($post_id);
        if ($in_progress) { $badge .= ' <span class="aiseogeo-badge-auto" style="background:#b45309">в работе</span>'; }

        // ── Нет аудита: только кнопка Переписать ──────────────────────────────
        if (!$audit) {
            echo '<span style="color:#aaa;font-size:11px">нет анализа</span>' . $badge . '<br>';
            if (current_user_can('aiseogeo_run_rewrite')) {
                $audit_url = admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post_id));
                echo '<span class="aiseogeo-dot gray"></span> <a href="' . esc_url($audit_url) . '">Переписать</a>';
            }
            return;
        }

        // ── Есть аудит: счёт + кнопка Переписать ─────────────────────────────
        $score = intval($audit->overall_score);
        $class = 'bad';
        if ($score >= 80) { $class = 'good'; } elseif ($score >= 60) { $class = 'ok'; } elseif ($score >= 40) { $class = 'weak'; }
        $rewrite_url = admin_url('admin.php?page=aiseogeo-rewrite-create&post_id=' . absint($post_id) . '&audit_id=' . absint($audit->id));

        echo '<span class="aiseogeo-score ' . esc_attr($class) . '">' . esc_html($score) . '/100</span>' . $badge . '<br>';
        if (current_user_can('aiseogeo_run_rewrite')) {
            $rw_dot = $rewritten ? 'green' : 'gray';
            echo '<span class="aiseogeo-dot ' . $rw_dot . '"></span> <a href="' . esc_url($rewrite_url) . '">Переписать</a>';
        }
    }

    private function has_done_rewrite($post_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'aiseogeo_rewrites';
        return (bool) $wpdb->get_var($wpdb->prepare("SELECT 1 FROM {$table} WHERE post_id=%d AND rewrite_status='done' LIMIT 1", absint($post_id)));
    }

    private function has_active_rewrite($post_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'aiseogeo_rewrites';
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT 1 FROM {$table} WHERE post_id=%d AND rewrite_status IN ('pending','running','plan_done') LIMIT 1",
            absint($post_id)
        ));
    }
}

<?php
if (!defined('ABSPATH')) { exit; }

require_once AISEOGEO_DIR . 'includes/class-installer.php';
require_once AISEOGEO_DIR . 'includes/class-capabilities.php';
require_once AISEOGEO_DIR . 'includes/class-settings.php';
require_once AISEOGEO_DIR . 'includes/class-logger.php';
require_once AISEOGEO_DIR . 'includes/class-openrouter-client.php';
require_once AISEOGEO_DIR . 'includes/class-model-router.php';
require_once AISEOGEO_DIR . 'includes/class-post-content-reader.php';
require_once AISEOGEO_DIR . 'includes/class-audit-result-parser.php';
require_once AISEOGEO_DIR . 'includes/class-json-helper.php';
require_once AISEOGEO_DIR . 'includes/class-audit-service.php';
require_once AISEOGEO_DIR . 'includes/class-content-protector.php';
require_once AISEOGEO_DIR . 'includes/class-version-service.php';
require_once AISEOGEO_DIR . 'includes/class-rewrite-plan-service.php';
require_once AISEOGEO_DIR . 'includes/class-quality-gates.php';
require_once AISEOGEO_DIR . 'includes/class-rewrite-steps.php';
require_once AISEOGEO_DIR . 'includes/class-rewrite-service.php';
require_once AISEOGEO_DIR . 'includes/class-draft-service.php';
require_once AISEOGEO_DIR . 'includes/class-comparison-service.php';
require_once AISEOGEO_DIR . 'includes/class-search-forecast-service.php';
require_once AISEOGEO_DIR . 'includes/class-backup-service.php';
require_once AISEOGEO_DIR . 'includes/class-apply-log-service.php';
require_once AISEOGEO_DIR . 'includes/class-apply-service.php';
require_once AISEOGEO_DIR . 'includes/class-rollback-service.php';
require_once AISEOGEO_DIR . 'includes/class-post-filter-service.php';
require_once AISEOGEO_DIR . 'includes/class-action-scheduler.php';
require_once AISEOGEO_DIR . 'includes/class-site-report-service.php';
require_once AISEOGEO_DIR . 'includes/class-site-optimization-insights-service.php';
require_once AISEOGEO_DIR . 'includes/class-auto-optimize-service.php';
require_once AISEOGEO_DIR . 'includes/class-updater.php';
require_once AISEOGEO_DIR . 'includes/class-meta-output-service.php';
require_once AISEOGEO_DIR . 'includes/class-shortcodes.php';
require_once AISEOGEO_DIR . 'includes/class-admin-assets.php';
require_once AISEOGEO_DIR . 'includes/class-admin-menu.php';
require_once AISEOGEO_DIR . 'includes/class-post-metabox.php';
require_once AISEOGEO_DIR . 'includes/class-rest-controller.php';
require_once AISEOGEO_DIR . 'includes/class-learning-service.php';
require_once AISEOGEO_DIR . 'includes/class-learning-tracker.php';
require_once AISEOGEO_DIR . 'includes/prompts/class-prompt-loader.php';

final class AISEOGEO_Plugin {
    private static $instance = null;
    public $settings;
    public $logger;
    public $audit_service;
    public $rewrite_service;
    public $learning_service;

    public static function instance() { if (self::$instance === null) { self::$instance = new self(); } return self::$instance; }
    public static function activate() { AISEOGEO_Installer::install(); AISEOGEO_Capabilities::add_caps(); }
    public static function deactivate() { AISEOGEO_Capabilities::remove_caps(); }

    public function init() {
        if (get_option('aiseogeo_version') !== AISEOGEO_VERSION) { AISEOGEO_Installer::install(); AISEOGEO_Capabilities::add_caps(); }
        $this->settings = new AISEOGEO_Settings();
        $this->logger = new AISEOGEO_Logger();
        $this->audit_service = new AISEOGEO_Audit_Service($this->settings, $this->logger);
        $this->rewrite_service = new AISEOGEO_Rewrite_Service($this->settings, $this->logger, $this->audit_service);

        (new AISEOGEO_Admin_Assets())->init();
        (new AISEOGEO_Admin_Menu($this->audit_service, $this->settings, $this->logger, $this->rewrite_service))->init();
        (new AISEOGEO_Post_Metabox($this->audit_service))->init();
        (new AISEOGEO_REST_Controller($this->audit_service, $this->settings, $this->logger, $this->rewrite_service))->init();
        (new AISEOGEO_Action_Scheduler($this->audit_service, $this->rewrite_service, $this->logger, $this->settings))->init();
        $auto_optimize = new AISEOGEO_Auto_Optimize_Service($this->settings, $this->logger, $this->audit_service, $this->rewrite_service);
        $auto_optimize->init();
        $auto_optimize->register_cron();
        (new AISEOGEO_Updater())->init();
        (new AISEOGEO_Meta_Output_Service($this->settings))->init();
        (new AISEOGEO_Shortcodes($this->audit_service))->init();

        $this->learning_service = new AISEOGEO_Learning_Service($this->settings, $this->logger);
        $this->learning_service->init();
        (new AISEOGEO_Learning_Tracker($this->settings))->init();

        add_filter('post_row_actions', array($this, 'add_row_action'), 10, 2);
        add_filter('manage_post_posts_columns', array($this, 'add_posts_column'));
        add_action('manage_post_posts_custom_column', array($this, 'render_posts_column'), 10, 2);
    }

    public function add_row_action($actions, $post) {
        if (!$post || $post->post_type !== 'post') { return $actions; }
        if (current_user_can('aiseogeo_run_audit')) {
            $url = admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post->ID));
            $actions['aiseogeo_audit'] = '<a href="' . esc_url($url) . '">AI анализ</a>';
        }
        if (current_user_can('aiseogeo_run_rewrite') && $this->audit_service->get_latest_audit($post->ID)) {
            $latest = $this->audit_service->get_latest_audit($post->ID);
            $rewrite_url = admin_url('admin.php?page=aiseogeo-rewrite-create&post_id=' . absint($post->ID) . '&audit_id=' . absint($latest->id));
            $actions['aiseogeo_rewrite'] = '<a href="' . esc_url($rewrite_url) . '">AI переписать</a>';
        }
        return $actions;
    }

    public function add_posts_column($columns) {
        $new = array();
        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            if ($key === 'title') { $new['aiseogeo_score'] = 'AI SEO/GEO'; }
        }
        if (!isset($new['aiseogeo_score'])) { $new['aiseogeo_score'] = 'AI SEO/GEO'; }
        return $new;
    }

    public function render_posts_column($column, $post_id) {
        if ($column !== 'aiseogeo_score') { return; }
        if (!current_user_can('aiseogeo_view_reports')) { echo '—'; return; }

        $audit      = $this->audit_service->get_latest_audit($post_id);
        $auto_ver   = get_post_meta($post_id, '_aiseogeo_auto_version', true);
        $in_progress= $this->has_active_rewrite($post_id);

        // ── В процессе переписывания ──────────────────────────────────────────
        if ($in_progress) {
            $score = $audit ? intval($audit->overall_score) : 0;
            if ($audit) {
                echo '<span class="aiseogeo-score ' . esc_attr($this->score_class($score)) . '">' . esc_html($score) . '/100</span> ';
            }
            echo '<span class="aiseogeo-badge-auto" style="background:#b45309;animation:aig-pulse 1.2s infinite">⚙ в работе</span>';
            return;
        }

        // ── Нет аудита ────────────────────────────────────────────────────────
        if (!$audit) {
            echo '<span style="color:#aaa;font-size:11px">нет анализа</span><br>';
            if (current_user_can('aiseogeo_run_audit')) {
                $url = admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post_id));
                echo '<a href="' . esc_url($url) . '" style="font-size:11px">📋 Анализ</a>';
            }
            return;
        }

        // ── Получаем данные до/после ──────────────────────────────────────────
        $before_score = intval($audit->overall_score);
        $rewrite_row  = $this->get_done_rewrite($post_id);
        $after_score  = null;
        $after_gates  = null;

        if ($rewrite_row) {
            // Берём оценку после из audit переписанной версии или из quality_gates
            $after_audit = $this->get_rewrite_audit($rewrite_row->id);
            if ($after_audit) {
                $after_score = intval($after_audit->overall_score);
            } else {
                // Fallback: считаем из quality_gates в result_json
                $rj = json_decode((string)$rewrite_row->result_json, true);
                $qg = $rj['quality_gates'] ?? null;
                if ($qg) { $after_score = $this->gates_to_score($qg, $before_score); $after_gates = $qg; }
            }
        }

        // ── Строим HTML колонки ───────────────────────────────────────────────
        $rewrite_url = admin_url('admin.php?page=aiseogeo-rewrite-create&post_id=' . absint($post_id) . '&audit_id=' . absint($audit->id));
        $can_rewrite = current_user_can('aiseogeo_run_rewrite');

        // Основной блок оценки
        echo '<div style="line-height:1.5">';

        if ($after_score !== null) {
            // Показываем ДО → ПОСЛЕ
            $delta = $after_score - $before_score;
            $delta_html = '';
            if ($delta > 0) {
                $delta_html = ' <span style="color:#065f46;font-size:10px;font-weight:700">▲+' . $delta . '</span>';
            } elseif ($delta < 0) {
                $delta_html = ' <span style="color:#b91c1c;font-size:10px;font-weight:700">▼' . $delta . '</span>';
            }

            $tip = $this->build_score_tooltip($audit, $after_audit ?? null, $after_gates);
            echo '<span class="aiseogeo-score ' . esc_attr($this->score_class($before_score)) . '" title="' . esc_attr($tip) . '">'
               . esc_html($before_score) . '</span>'
               . ' <span style="color:#9ca3af;font-size:10px">→</span> '
               . '<span class="aiseogeo-score ' . esc_attr($this->score_class($after_score)) . '" title="' . esc_attr($tip) . '">'
               . esc_html($after_score) . '</span>'
               . $delta_html;

            // Бейдж версии
            $badge_txt = ($auto_ver === '2') ? 'авто' : 'v1';
            $badge_bg  = ($auto_ver === '2') ? '#065f46' : '#374151';
            echo ' <span class="aiseogeo-badge-auto" style="background:' . $badge_bg . '">' . $badge_txt . '</span>';

        } else {
            // Только оценка до, без переписывания
            $tip = $this->build_score_tooltip($audit, null, null);
            echo '<span class="aiseogeo-score ' . esc_attr($this->score_class($before_score)) . '" title="' . esc_attr($tip) . '">'
               . esc_html($before_score) . '/100</span>';
        }

        echo '</div>';

        // Мини-полоски суб-оценок (только если есть аудит)
        echo '<div style="margin:3px 0 2px;display:flex;gap:2px" title="SEO · GEO · E-E-A-T · Структура">';
        foreach (array(
            intval($audit->seo_score)           => '#3b82f6',
            intval($audit->geo_score)           => '#8b5cf6',
            intval($audit->eeat_score)          => '#f59e0b',
            intval($audit->structure_score ?: 0)=> '#10b981',
        ) as $s => $c) {
            $w = max(4, min(40, (int)($s * 0.4)));
            echo '<span style="display:inline-block;width:' . $w . 'px;height:4px;border-radius:2px;background:' . $c . '" title="' . $s . '"></span>';
        }
        echo '</div>';

        // Кнопка Переписать
        if ($can_rewrite) {
            $label = $rewrite_row ? '↻ Переписать' : '✎ Переписать';
            echo '<a href="' . esc_url($rewrite_url) . '" style="font-size:11px;color:#2271b1">' . $label . '</a>';
        }

        // Качество гейтов если есть (AI-score после переписывания)
        if ($after_gates) {
            $ai_sc = intval($after_gates['ai_score'] ?? 0);
            $verdict = (string)($after_gates['verdict'] ?? '');
            $v_icon  = array('clean' => '✓', 'soft_warn' => '~', 'blocked' => '✗')[$verdict] ?? '';
            $v_color = array('clean' => '#065f46', 'soft_warn' => '#b45309', 'blocked' => '#b91c1c')[$verdict] ?? '#555';
            echo ' <span style="font-size:10px;color:' . $v_color . '" title="AI-humanization score">' . $v_icon . ' AI:' . $ai_sc . '</span>';
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function score_class($score) {
        if ($score >= 80) { return 'good'; }
        if ($score >= 60) { return 'ok'; }
        if ($score >= 40) { return 'weak'; }
        return 'bad';
    }

    // Вычисляет оценку после переписывания из quality_gates (если нет audit переписанной версии).
    // Логика: берём оценку до, корректируем на детерминированные метрики.
    private function gates_to_score($qg, $before_score) {
        $ai_sc   = intval($qg['ai_score'] ?? 50);
        $hard    = intval($qg['hard'] ?? 0);
        $warn    = intval($qg['warn'] ?? 0);
        $verdict = (string)($qg['verdict'] ?? 'soft_warn');

        // Штрафы за нарушения
        $penalty = min(30, $hard * 8 + $warn * 2);

        // Компонент «качество текста» из AI-score гейтов
        $text_quality = max(0, min(40, (int)(($ai_sc / 100) * 40)));

        // Берём исходный score и корректируем
        $adjusted = $before_score + 10 + $text_quality - $penalty;
        if ($verdict === 'clean')     { $adjusted += 5; }
        if ($verdict === 'blocked')   { $adjusted -= 10; }

        return max(0, min(100, $adjusted));
    }

    // Строит текст подсказки с детализацией оценок
    private function build_score_tooltip($audit, $after_audit, $after_gates) {
        $lines = array();
        $lines[] = '── ДО ПЕРЕПИСЫВАНИЯ ──';
        $lines[] = 'Общая: '    . $audit->overall_score;
        $lines[] = 'SEO: '      . $audit->seo_score;
        $lines[] = 'GEO: '      . $audit->geo_score;
        $lines[] = 'E-E-A-T: '  . $audit->eeat_score;
        $lines[] = 'Структура: '. ($audit->structure_score ?? '—');
        $lines[] = 'Anti-AI: '  . ($audit->anti_ai_score ?? '—');
        if ($audit->summary) { $lines[] = ''; $lines[] = mb_substr($audit->summary, 0, 120); }

        if ($after_audit) {
            $lines[] = '';
            $lines[] = '── ПОСЛЕ ПЕРЕПИСЫВАНИЯ ──';
            $lines[] = 'Общая: '    . $after_audit->overall_score;
            $lines[] = 'SEO: '      . $after_audit->seo_score;
            $lines[] = 'GEO: '      . $after_audit->geo_score;
            $lines[] = 'E-E-A-T: '  . $after_audit->eeat_score;
        } elseif ($after_gates) {
            $lines[] = '';
            $lines[] = '── ГЕЙТЫ ПОСЛЕ ПЕРЕПИСЫВАНИЯ ──';
            $lines[] = 'AI-humanization score: ' . ($after_gates['ai_score'] ?? '—') . '/100';
            $lines[] = 'Блокеров: '  . ($after_gates['hard'] ?? 0);
            $lines[] = 'Предупреждений: ' . ($after_gates['warn'] ?? 0);
            $lines[] = 'Плотность AI-маркеров: ' . ($after_gates['density'] ?? '—') . '/1000';
            $lines[] = 'Ритм CV: '   . ($after_gates['cv'] ?? '—');
            $lines[] = 'Вердикт: '   . ($after_gates['verdict'] ?? '—');
        }
        return implode("\n", $lines);
    }

    private function get_done_rewrite($post_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'aiseogeo_rewrites';
        return $wpdb->get_row($wpdb->prepare(
            "SELECT id, result_json FROM {$table} WHERE post_id=%d AND rewrite_status='done' ORDER BY id DESC LIMIT 1",
            absint($post_id)
        ));
    }

    private function get_rewrite_audit($rewrite_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'aiseogeo_audits';
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE rewrite_id=%d AND status='done' ORDER BY id DESC LIMIT 1",
            absint($rewrite_id)
        ));
    }

    private function has_done_rewrite($post_id) {
        return (bool)$this->get_done_rewrite($post_id);
    }

    private function has_active_rewrite($post_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'aiseogeo_rewrites';
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT 1 FROM {$table} WHERE post_id=%d AND rewrite_status IN ('rewriting','plan_created') AND updated_at >= DATE_SUB(NOW(), INTERVAL 3 HOUR) LIMIT 1",
            absint($post_id)
        ));
    }
}

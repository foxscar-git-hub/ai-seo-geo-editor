<?php
if (!defined('ABSPATH')) { exit; }

require_once AISEOGEO_DIR . 'includes/class-installer.php';
require_once AISEOGEO_DIR . 'includes/class-capabilities.php';
require_once AISEOGEO_DIR . 'includes/class-settings.php';
require_once AISEOGEO_DIR . 'includes/class-logger.php';
require_once AISEOGEO_DIR . 'includes/class-openrouter-client.php';
require_once AISEOGEO_DIR . 'includes/class-model-router.php';
require_once AISEOGEO_DIR . 'includes/class-post-content-reader.php';
require_once AISEOGEO_DIR . 'includes/class-audit-result-parser.php';
require_once AISEOGEO_DIR . 'includes/class-json-helper.php';
require_once AISEOGEO_DIR . 'includes/class-audit-service.php';
require_once AISEOGEO_DIR . 'includes/class-content-protector.php';
require_once AISEOGEO_DIR . 'includes/class-version-service.php';
require_once AISEOGEO_DIR . 'includes/class-rewrite-plan-service.php';
require_once AISEOGEO_DIR . 'includes/class-quality-gates.php';
require_once AISEOGEO_DIR . 'includes/class-rewrite-steps.php';
require_once AISEOGEO_DIR . 'includes/class-rewrite-service.php';
require_once AISEOGEO_DIR . 'includes/class-draft-service.php';
require_once AISEOGEO_DIR . 'includes/class-comparison-service.php';
require_once AISEOGEO_DIR . 'includes/class-search-forecast-service.php';
require_once AISEOGEO_DIR . 'includes/class-backup-service.php';
require_once AISEOGEO_DIR . 'includes/class-apply-log-service.php';
require_once AISEOGEO_DIR . 'includes/class-apply-service.php';
require_once AISEOGEO_DIR . 'includes/class-rollback-service.php';
require_once AISEOGEO_DIR . 'includes/class-post-filter-service.php';
require_once AISEOGEO_DIR . 'includes/class-action-scheduler.php';
require_once AISEOGEO_DIR . 'includes/class-site-report-service.php';
require_once AISEOGEO_DIR . 'includes/class-site-optimization-insights-service.php';
require_once AISEOGEO_DIR . 'includes/class-auto-optimize-service.php';
require_once AISEOGEO_DIR . 'includes/class-updater.php';
require_once AISEOGEO_DIR . 'includes/class-meta-output-service.php';
require_once AISEOGEO_DIR . 'includes/class-shortcodes.php';
require_once AISEOGEO_DIR . 'includes/class-admin-assets.php';
require_once AISEOGEO_DIR . 'includes/class-admin-menu.php';
require_once AISEOGEO_DIR . 'includes/class-post-metabox.php';
require_once AISEOGEO_DIR . 'includes/class-rest-controller.php';
require_once AISEOGEO_DIR . 'includes/class-learning-service.php';
require_once AISEOGEO_DIR . 'includes/class-learning-tracker.php';
require_once AISEOGEO_DIR . 'includes/prompts/class-prompt-loader.php';

final class AISEOGEO_Plugin {
    private static $instance = null;
    public $settings;
    public $logger;
    public $audit_service;
    public $rewrite_service;
    public $learning_service;

    public static function instance() { if (self::$instance === null) { self::$instance = new self(); } return self::$instance; }
    public static function activate() { AISEOGEO_Installer::install(); AISEOGEO_Capabilities::add_caps(); }
    public static function deactivate() {
        AISEOGEO_Capabilities::remove_caps();
        wp_clear_scheduled_hook('aiseogeo_rewrite_watchdog');
    }

    public function init() {
        if (get_option('aiseogeo_version') !== AISEOGEO_VERSION) { AISEOGEO_Installer::install(); AISEOGEO_Capabilities::add_caps(); }
        $this->settings = new AISEOGEO_Settings();
        $this->logger = new AISEOGEO_Logger();
        $this->audit_service = new AISEOGEO_Audit_Service($this->settings, $this->logger);
        $this->rewrite_service = new AISEOGEO_Rewrite_Service($this->settings, $this->logger, $this->audit_service);

        (new AISEOGEO_Admin_Assets())->init();
        (new AISEOGEO_Admin_Menu($this->audit_service, $this->settings, $this->logger, $this->rewrite_service))->init();
        (new AISEOGEO_Post_Metabox($this->audit_service))->init();
        (new AISEOGEO_REST_Controller($this->audit_service, $this->settings, $this->logger, $this->rewrite_service))->init();
        (new AISEOGEO_Action_Scheduler($this->audit_service, $this->rewrite_service, $this->logger, $this->settings))->init();
        $auto_optimize = new AISEOGEO_Auto_Optimize_Service($this->settings, $this->logger, $this->audit_service, $this->rewrite_service);
        $auto_optimize->init();
        $auto_optimize->register_cron();
        (new AISEOGEO_Updater())->init();
        (new AISEOGEO_Meta_Output_Service($this->settings))->init();
        (new AISEOGEO_Shortcodes($this->audit_service))->init();

        $this->learning_service = new AISEOGEO_Learning_Service($this->settings, $this->logger);
        $this->learning_service->init();
        (new AISEOGEO_Learning_Tracker($this->settings))->init();

        add_filter('post_row_actions', array($this, 'add_row_action'), 10, 2);
        add_filter('manage_post_posts_columns', array($this, 'add_posts_column'));
        add_action('manage_post_posts_custom_column', array($this, 'render_posts_column'), 10, 2);

        // Watchdog — сам находит и перезапускает зависшие переписывания (без участия человека).
        add_filter('cron_schedules', array($this, 'add_watchdog_interval'));
        add_action('aiseogeo_rewrite_watchdog', array($this->rewrite_service, 'watchdog_scan'));
        if (!wp_next_scheduled('aiseogeo_rewrite_watchdog')) {
            wp_schedule_event(time() + 300, 'aiseogeo_10min', 'aiseogeo_rewrite_watchdog');
        }
    }

    public function add_watchdog_interval($schedules) {
        $schedules['aiseogeo_10min'] = array('interval' => 600, 'display' => 'Каждые 10 минут (AI SEO/GEO watchdog)');
        return $schedules;
    }

    public function add_row_action($actions, $post) {
        if (!$post || $post->post_type !== 'post') { return $actions; }
        if (current_user_can('aiseogeo_run_audit')) {
            $url = admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post->ID));
            $actions['aiseogeo_audit'] = '<a href="' . esc_url($url) . '">AI анализ</a>';
        }
        if (current_user_can('aiseogeo_run_rewrite') && $this->audit_service->get_latest_audit($post->ID)) {
            $latest = $this->audit_service->get_latest_audit($post->ID);
            $rewrite_url = admin_url('admin.php?page=aiseogeo-rewrite-create&post_id=' . absint($post->ID) . '&audit_id=' . absint($latest->id));
            $actions['aiseogeo_rewrite'] = '<a href="' . esc_url($rewrite_url) . '">AI переписать</a>';
        }
        return $actions;
    }

    public function add_posts_column($columns) {
        $new = array();
        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            if ($key === 'title') { $new['aiseogeo_score'] = 'AI SEO/GEO'; }
        }
        if (!isset($new['aiseogeo_score'])) { $new['aiseogeo_score'] = 'AI SEO/GEO'; }
        return $new;
    }

    public function render_posts_column($column, $post_id) {
        if ($column !== 'aiseogeo_score') { return; }
        if (!current_user_can('aiseogeo_view_reports')) { echo '—'; return; }

        $audit       = $this->audit_service->get_latest_audit($post_id);
        $in_progress = $this->has_active_rewrite($post_id);
        $can_rewrite = current_user_can('aiseogeo_run_rewrite');

        // ── В процессе переписывания ──────────────────────────────────────────
        if ($in_progress) {
            if ($audit) {
                $s = intval($audit->overall_score);
                echo '<span class="aiseogeo-score ' . esc_attr($this->score_class($s)) . '">' . esc_html($s) . '/100</span> ';
            }
            echo '<span class="aiseogeo-badge-auto" style="background:#b45309;animation:aig-pulse 1.2s infinite">⚙ в работе</span>';
            return;
        }

        // ── Нет аудита ────────────────────────────────────────────────────────
        if (!$audit) {
            echo '<span style="color:#aaa;font-size:12px">нет анализа</span>';
            if (current_user_can('aiseogeo_run_audit')) {
                $url = admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post_id));
                echo '<br><a href="' . esc_url($url) . '" style="font-size:12px">Анализ</a>';
            }
            return;
        }

        // ── Оценки до / после ─────────────────────────────────────────────────
        $before      = intval($audit->overall_score);
        $rewrite_row = $this->get_done_rewrite($post_id);
        $after       = null;

        if ($rewrite_row) {
            $after_audit = $this->get_rewrite_audit($rewrite_row->id);
            if ($after_audit) {
                $after = intval($after_audit->overall_score);
            } else {
                $rj = json_decode((string)$rewrite_row->result_json, true);
                $qg = $rj['quality_gates'] ?? null;
                if ($qg) { $after = $this->gates_to_score($qg, $before); }
            }
        }

        $rewrite_url = admin_url('admin.php?page=aiseogeo-rewrite-create&post_id=' . absint($post_id) . '&audit_id=' . absint($audit->id));

        // ── HTML — одна строка: до/после/100 ─────────────────────────────────
        if ($after !== null) {
            echo '<span class="aiseogeo-score ' . esc_attr($this->score_class($before)) . '">' . esc_html($before) . '</span>'
               . '<span style="color:#bbb;font-size:11px;margin:0 1px">/</span>'
               . '<span class="aiseogeo-score ' . esc_attr($this->score_class($after)) . '">' . esc_html($after) . '</span>'
               . '<span style="color:#bbb;font-size:11px;margin:0 1px">/100</span>';
        } else {
            echo '<span class="aiseogeo-score ' . esc_attr($this->score_class($before)) . '">' . esc_html($before) . '/100</span>';
        }

        if ($can_rewrite) {
            $label = ($after !== null) ? 'Переписать ещё' : 'Переписать';
            echo '<br><a href="' . esc_url($rewrite_url) . '" style="font-size:12px">' . $label . '</a>';
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function score_class($score) {
        if ($score >= 80) { return 'good'; }
        if ($score >= 60) { return 'ok'; }
        if ($score >= 40) { return 'weak'; }
        return 'bad';
    }

    // Вычисляет оценку после переписывания из quality_gates (если нет audit переписанной версии).
    // Логика: берём оценку до, корректируем на детерминированные метрики.
    private function gates_to_score($qg, $before_score) {
        $ai_sc   = intval($qg['ai_score'] ?? 50);
        $hard    = intval($qg['hard'] ?? 0);
        $warn    = intval($qg['warn'] ?? 0);
        $verdict = (string)($qg['verdict'] ?? 'soft_warn');

        // Штрафы за нарушения
        $penalty = min(30, $hard * 8 + $warn * 2);

        // Компонент «качество текста» из AI-score гейтов
        $text_quality = max(0, min(40, (int)(($ai_sc / 100) * 40)));

        // Берём исходный score и корректируем
        $adjusted = $before_score + 10 + $text_quality - $penalty;
        if ($verdict === 'clean')     { $adjusted += 5; }
        if ($verdict === 'blocked')   { $adjusted -= 10; }

        return max(0, min(100, $adjusted));
    }

    // Строит текст подсказки с детализацией оценок
    private function build_score_tooltip($audit, $after_audit, $after_gates) {
        $lines = array();
        $lines[] = '── ДО ПЕРЕПИСЫВАНИЯ ──';
        $lines[] = 'Общая: '    . $audit->overall_score;
        $lines[] = 'SEO: '      . $audit->seo_score;
        $lines[] = 'GEO: '      . $audit->geo_score;
        $lines[] = 'E-E-A-T: '  . $audit->eeat_score;
        $lines[] = 'Структура: '. ($audit->structure_score ?? '—');
        $lines[] = 'Anti-AI: '  . ($audit->anti_ai_score ?? '—');
        if ($audit->summary) { $lines[] = ''; $lines[] = mb_substr($audit->summary, 0, 120); }

        if ($after_audit) {
            $lines[] = '';
            $lines[] = '── ПОСЛЕ ПЕРЕПИСЫВАНИЯ ──';
            $lines[] = 'Общая: '    . $after_audit->overall_score;
            $lines[] = 'SEO: '      . $after_audit->seo_score;
            $lines[] = 'GEO: '      . $after_audit->geo_score;
            $lines[] = 'E-E-A-T: '  . $after_audit->eeat_score;
        } elseif ($after_gates) {
            $lines[] = '';
            $lines[] = '── ГЕЙТЫ ПОСЛЕ ПЕРЕПИСЫВАНИЯ ──';
            $lines[] = 'AI-humanization score: ' . ($after_gates['ai_score'] ?? '—') . '/100';
            $lines[] = 'Блокеров: '  . ($after_gates['hard'] ?? 0);
            $lines[] = 'Предупреждений: ' . ($after_gates['warn'] ?? 0);
            $lines[] = 'Плотность AI-маркеров: ' . ($after_gates['density'] ?? '—') . '/1000';
            $lines[] = 'Ритм CV: '   . ($after_gates['cv'] ?? '—');
            $lines[] = 'Вердикт: '   . ($after_gates['verdict'] ?? '—');
        }
        return implode("\n", $lines);
    }

    private function get_done_rewrite($post_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'aiseogeo_rewrites';
        // 'applied' оставлен для совместимости со старыми записями (баг до v1.7.13, когда
        // rewrite_status ошибочно перезаписывался вместо отдельного apply_status).
        return $wpdb->get_row($wpdb->prepare(
            "SELECT id, result_json FROM {$table} WHERE post_id=%d AND rewrite_status IN ('done','applied','re_audited') ORDER BY id DESC LIMIT 1",
            absint($post_id)
        ));
    }

    private function get_rewrite_audit($rewrite_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'aiseogeo_audits';
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE rewrite_id=%d AND status='done' ORDER BY id DESC LIMIT 1",
            absint($rewrite_id)
        ));
    }

    private function has_done_rewrite($post_id) {
        return (bool)$this->get_done_rewrite($post_id);
    }

    private function has_active_rewrite($post_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'aiseogeo_rewrites';
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT 1 FROM {$table} WHERE post_id=%d AND rewrite_status IN ('rewriting','plan_created') AND updated_at >= DATE_SUB(NOW(), INTERVAL 3 HOUR) LIMIT 1",
            absint($post_id)
        ));
    }
}

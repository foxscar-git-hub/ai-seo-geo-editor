<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Audit_Service {
    private $settings; private $logger; private $reader; private $client; private $parser;
    public function __construct($settings, $logger) {
        $this->settings = $settings; $this->logger = $logger;
        $this->reader = new AISEOGEO_Post_Content_Reader();
        $this->client = new AISEOGEO_OpenRouter_Client($settings, $logger);
        $this->parser = new AISEOGEO_Audit_Result_Parser();
    }
    public function table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_audits'; }
    public function run_audit($post_id) {
        if (!current_user_can('aiseogeo_run_audit') && !doing_action('aiseogeo_process_bulk_job_item')) { return new WP_Error('forbidden', 'Недостаточно прав.'); }
        $post_data = $this->reader->read($post_id);
        if (is_wp_error($post_data)) { return $post_data; }
        return $this->run_audit_for_data($post_data, array('audit_type'=>'full','content_source'=>'post'));
    }
    public function run_audit_bypass($post_id) {
        $post_data = $this->reader->read($post_id);
        if (is_wp_error($post_data)) { return $post_data; }
        return $this->run_audit_for_data($post_data, array('audit_type'=> 'full', 'content_source'=> 'post'));
    }
    public function run_rewrite_audit($rewrite) {
        if (!current_user_can('aiseogeo_run_rewrite') && !doing_action('aiseogeo_process_bulk_job_item')) { return new WP_Error('forbidden', 'Недостаточно прав.'); }
        if (!$rewrite) { return new WP_Error('rewrite_not_found', 'Версия переписывания не найдена.'); }
        $post = get_post((int)$rewrite->post_id);
        $post_data = array(
            'id' => (int)$rewrite->post_id,
            'title' => $rewrite->new_title ?: ($post ? get_the_title($post) : ''),
            'slug' => $post ? $post->post_name : '',
            'status' => $post ? $post->post_status : '',
            'excerpt' => $rewrite->new_excerpt,
            'content' => $rewrite->new_content_longtext,
            'categories' => $post ? wp_get_post_terms($post->ID, 'category', array('fields'=>'names')) : array(),
            'tags' => $post ? wp_get_post_terms($post->ID, 'post_tag', array('fields'=>'names')) : array(),
            'meta_title' => $rewrite->new_meta_title,
            'meta_description' => $rewrite->new_meta_description,
            'source' => 'rewrite',
        );
        return $this->run_audit_for_data($post_data, array(
            'audit_type'=>'rewrite_audit',
            'content_source'=>'rewrite',
            'rewrite_id'=>(int)$rewrite->id,
            'source_audit_id'=>(int)$rewrite->audit_id,
        ));
    }
    public function run_audit_for_data($post_data, $extra = array()) {
        $messages = array(
            array('role'=>'system','content'=>AISEOGEO_Prompt_Loader::audit_system()),
            array('role'=>'user','content'=>AISEOGEO_Prompt_Loader::audit_user($post_data)),
        );
        $result = $this->client->chat($messages);
        if (is_wp_error($result)) {
            $this->save_error_audit($post_data, $result->get_error_message(), '', '', $extra);
            return $result;
        }
        $parsed = $this->parser->parse($result['content']);
        if (is_wp_error($parsed)) {
            $repaired = $this->repair_audit_json_response($result['content']);
            if (!is_wp_error($repaired)) {
                $parsed = $repaired;
                $result['content'] .= "\n\n--- AISEOGEO_AUDIT_JSON_REPAIR_APPLIED ---";
            }
        }
        if (is_wp_error($parsed)) {
            $this->save_error_audit($post_data, $parsed->get_error_message(), $result['content'], $result['model'], $extra);
            return $parsed;
        }
        return $this->save_audit($post_data, $parsed, $result, $extra);
    }

    private function repair_audit_json_response($raw_content) {
        $messages = array(
            array('role'=>'system','content'=>'Ты исправляешь технически некорректный JSON-ответ SEO/GEO аудита. Верни только валидный JSON без markdown и пояснений. Не добавляй новых выводов, а восстанови структуру из исходного ответа. Все многострочные значения должны быть корректными JSON-строками.'),
            array('role'=>'user','content'=>'Верни валидный JSON со строгими ключами: overall_score, seo_score, geo_score, eeat_score, readability_score, structure_score, meta_score, internal_links_score, anti_ai_score, summary, main_problems, quick_wins, critical_issues, recommended_actions, suggested_title, suggested_meta_description, suggested_h2, suggested_faq, schema_recommendation, rewrite_needed, rewrite_priority, rewrite_strategy. Некорректный ответ:
' . mb_substr((string)$raw_content, 0, 100000)),
        );
        $repair = $this->client->chat($messages, max(6000, intval($this->settings->get('max_tokens', '6000'))));
        if (is_wp_error($repair)) { return $repair; }
        return $this->parser->parse($repair['content']);
    }

    private function score($arr, $key) { return max(0, min(100, intval($arr[$key] ?? 0))); }
    public function save_audit($post_data, $parsed, $result, $extra = array()) {
        global $wpdb;
        $now = current_time('mysql');
        $suggested = array(
            'suggested_title'=>$parsed['suggested_title'] ?? '',
            'suggested_meta_description'=>$parsed['suggested_meta_description'] ?? '',
            'suggested_h2'=>$parsed['suggested_h2'] ?? array(),
            'suggested_faq'=>$parsed['suggested_faq'] ?? array(),
            'schema_recommendation'=>$parsed['schema_recommendation'] ?? '',
            'rewrite_needed'=>$parsed['rewrite_needed'] ?? false,
            'rewrite_priority'=>$parsed['rewrite_priority'] ?? '',
            'rewrite_strategy'=>$parsed['rewrite_strategy'] ?? '',
        );
        $wpdb->insert($this->table(), array(
            'post_id'=>absint($post_data['id']), 'post_title'=>$post_data['title'], 'post_status'=>$post_data['status'] ?? '',
            'audit_type'=>$extra['audit_type'] ?? 'full', 'rewrite_id'=>$extra['rewrite_id'] ?? null, 'source_audit_id'=>$extra['source_audit_id'] ?? null, 'content_source'=>$extra['content_source'] ?? 'post',
            'overall_score'=>$this->score($parsed,'overall_score'), 'seo_score'=>$this->score($parsed,'seo_score'), 'geo_score'=>$this->score($parsed,'geo_score'), 'eeat_score'=>$this->score($parsed,'eeat_score'),
            'readability_score'=>$this->score($parsed,'readability_score'), 'structure_score'=>$this->score($parsed,'structure_score'), 'meta_score'=>$this->score($parsed,'meta_score'), 'internal_links_score'=>$this->score($parsed,'internal_links_score'),
            'anti_ai_score'=>$this->score($parsed,'anti_ai_score'),
            'summary'=>sanitize_textarea_field($parsed['summary'] ?? ''),
            'problems_json'=>wp_json_encode(array('main_problems'=>$parsed['main_problems'] ?? array(), 'critical_issues'=>$parsed['critical_issues'] ?? array(), 'geo_violations'=>$parsed['geo_violations'] ?? array(), 'anti_ai_violations'=>$parsed['anti_ai_violations'] ?? array(), 'structure_violations'=>$parsed['structure_violations'] ?? array()), JSON_UNESCAPED_UNICODE),
            'recommendations_json'=>wp_json_encode(array('quick_wins'=>$parsed['quick_wins'] ?? array(), 'recommended_actions'=>$parsed['recommended_actions'] ?? array()), JSON_UNESCAPED_UNICODE),
            'suggested_json'=>wp_json_encode($suggested, JSON_UNESCAPED_UNICODE),
            'raw_ai_response'=>$this->settings->get('save_raw_response','1') === '1' ? $result['content'] : '',
            'model'=>$result['model'], 'status'=>'done', 'error_message'=>'', 'created_at'=>$now, 'updated_at'=>$now,
        ));
        $id = $wpdb->insert_id;
        $this->logger->log('info','audit','Анализ записи выполнен.', array('audit_id'=>$id, 'content_source'=>$extra['content_source'] ?? 'post'), $post_data['id']);
        return $this->get_audit($id);
    }
    private function save_error_audit($post_data, $message, $raw = '', $model = '', $extra = array()) {
        global $wpdb;
        $now = current_time('mysql');
        $wpdb->insert($this->table(), array(
            'post_id'=>absint($post_data['id']), 'post_title'=>$post_data['title'] ?? '', 'post_status'=>$post_data['status'] ?? '',
            'audit_type'=>$extra['audit_type'] ?? 'full', 'rewrite_id'=>$extra['rewrite_id'] ?? null, 'source_audit_id'=>$extra['source_audit_id'] ?? null, 'content_source'=>$extra['content_source'] ?? 'post',
            'status'=>'error', 'error_message'=>$message, 'raw_ai_response'=>$raw, 'model'=>$model, 'created_at'=>$now, 'updated_at'=>$now,
        ));
        $this->logger->log('error','audit',$message, array('content_source'=>$extra['content_source'] ?? 'post'), $post_data['id'] ?? 0);
    }
    public function get_audit($audit_id) { global $wpdb; return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table()} WHERE id=%d", absint($audit_id))); }
    public function get_latest_audit($post_id) { global $wpdb; return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table()} WHERE post_id=%d AND status='done' AND content_source='post' ORDER BY id DESC LIMIT 1", absint($post_id))); }
    public function get_post_audits($post_id, $limit = 20) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} WHERE post_id=%d ORDER BY id DESC LIMIT %d", absint($post_id), absint($limit))); }
    public function history($limit = 50) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} ORDER BY id DESC LIMIT %d", absint($limit))); }
    public function stats() { global $wpdb; $t=$this->table(); return array('total'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t}"),'done'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE status='done'"),'errors'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE status='error'"),'weak'=>(int)$wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE status='done' AND overall_score < 60"),'today'=>(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE DATE(created_at)=%s", current_time('Y-m-d')))); }
}

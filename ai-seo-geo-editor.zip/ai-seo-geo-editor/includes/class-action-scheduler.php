<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Action_Scheduler {
    private $audit_service; private $rewrite_service; private $logger; private $settings;
    public function __construct($audit_service, $rewrite_service, $logger, $settings) { $this->audit_service=$audit_service; $this->rewrite_service=$rewrite_service; $this->logger=$logger; $this->settings=$settings; }
    public function init() {}
}

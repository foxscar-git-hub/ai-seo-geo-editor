<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Клиент OpenRouter. Выполняет один запрос к конкретной модели.
 * Перебор моделей — в AISEOGEO_Model_Router.
 */
class AISEOGEO_OpenRouter_Client {
    private $settings;
    private $logger;

    public function __construct($settings, $logger) {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    public function test() {
        return $this->chat(array(
            array('role' => 'system', 'content' => 'Ответь только JSON.'),
            array('role' => 'user',   'content' => 'Верни {"ok":true,"service":"openrouter"}'),
        ), 500);
    }

    /**
     * Один запрос к одной модели. Возвращает WP_Error при любой ошибке.
     * Перебор моделей — за пределами этого класса (Model_Router).
     *
     * @param array       $messages
     * @param int|null    $max_tokens
     * @param string|null $model      Конкретная модель; null = из настроек.
     * @param bool        $web_search Добавить плагин web-grounding (если разрешён).
     */
    public function chat($messages, $max_tokens = null, $model = null, $web_search = false) {
        $api_key = trim((string)$this->settings->get('api_key', ''));
        if ($api_key === '') {
            return new WP_Error('api_key_missing', 'API-ключ OpenRouter не указан.');
        }

        $base_url        = rtrim((string)$this->settings->get('base_url', 'https://openrouter.ai/api/v1'), '/');
        $resolved_model  = $model ?: trim((string)$this->settings->get('model', 'google/gemini-flash-1.5'));
        $resolved_tokens = $max_tokens ?: intval($this->settings->get('max_tokens', '6000'));

        $payload = array(
            'model'       => $resolved_model,
            'messages'    => $messages,
            'temperature' => floatval($this->settings->get('temperature', '0.2')),
            'max_tokens'  => $resolved_tokens,
        );

        if ($web_search && $this->settings->get('web_search_enabled', '0') === '1') {
            $payload['plugins'] = array(array('id' => 'web', 'max_results' => 5));
        }

        // Таймаут масштабируется: ~1 сек на 100 токенов, мин = настройка пользователя, макс 600.
        $base_timeout    = max(30, intval($this->settings->get('timeout', '90')));
        $token_timeout   = (int)($resolved_tokens / 100) + 30;
        $dynamic_timeout = max($base_timeout, min(600, $token_timeout));

        $args = array(
            'timeout' => $dynamic_timeout,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
                'HTTP-Referer'  => home_url('/'),
                'X-Title'       => get_bloginfo('name') . ' AI SEO/GEO Editor',
            ),
            'body' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE),
        );

        $url      = $base_url . '/chat/completions';
        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            $this->logger->log('error', 'openrouter',
                'Ошибка запроса OpenRouter: ' . $response->get_error_message(),
                array('model' => $resolved_model, 'timeout' => $dynamic_timeout)
            );
            return $response;
        }

        $code = intval(wp_remote_retrieve_response_code($response));
        $body = wp_remote_retrieve_body($response);

        if ($code >= 200 && $code < 300) {
            $json    = json_decode($body, true);
            $content = $json['choices'][0]['message']['content'] ?? '';
            if (is_array($content) || is_object($content)) {
                $content = wp_json_encode($content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }
            if (trim((string)$content) === '') {
                return new WP_Error('empty_response', 'OpenRouter вернул пустой ответ (модель: ' . $resolved_model . ').');
            }
            return array('content' => $content, 'model' => $resolved_model, 'raw' => $body);
        }

        $err = new WP_Error(
            'openrouter_http_' . $code,
            'OpenRouter HTTP ' . $code . ' (модель: ' . $resolved_model . ')',
            array('body' => mb_substr($body, 0, 500))
        );
        $this->logger->log('error', 'openrouter', 'OpenRouter HTTP ' . $code,
            array('model' => $resolved_model, 'body' => mb_substr($body, 0, 500))
        );
        return $err;
    }
}

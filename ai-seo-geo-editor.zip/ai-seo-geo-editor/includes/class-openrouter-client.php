<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Клиент OpenRouter. Выполняет один запрос к конкретной модели.
 * Перебор моделей — в AISEOGEO_Model_Router.
 */
class AISEOGEO_OpenRouter_Client {
    private $settings;
    private $logger;
    private $kie_client;

    public function __construct($settings, $logger) {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    public function test() {
        return $this->chat(array(
            array('role' => 'system', 'content' => 'Ответь только JSON.'),
            array('role' => 'user',   'content' => 'Верни {"ok":true,"service":"openrouter"}'),
        ), 500);
    }

    /**
     * Один запрос к одной модели. Возвращает WP_Error при любой ошибке.
     * Перебор моделей — за пределами этого класса (Model_Router).
     *
     * @param array       $messages
     * @param int|null    $max_tokens
     * @param string|null $model      Конкретная модель; null = из настроек.
     * @param bool        $web_search Добавить плагин web-grounding (если разрешён).
     */
    public function chat($messages, $max_tokens = null, $model = null, $web_search = false) {
        // Диспетчер: модели с префиксом "kie:" (добавляются в цепочку роутером как
        // резервный провайдер) уходят в отдельный клиент KIE.ai вместо OpenRouter.
        if ($model && strpos($model, 'kie:') === 0) {
            if (!$this->kie_client) { $this->kie_client = new AISEOGEO_Kie_Client($this->settings, $this->logger); }
            return $this->kie_client->chat($messages, $max_tokens, substr($model, 4), $web_search);
        }

        $api_key = trim((string)$this->settings->get('api_key', ''));
        if ($api_key === '') {
            return new WP_Error('api_key_missing', 'API-ключ OpenRouter не указан.');
        }

        $base_url        = rtrim((string)$this->settings->get('base_url', 'https://openrouter.ai/api/v1'), '/');
        $resolved_model  = $model ?: trim((string)$this->settings->get('model', 'google/gemini-flash-1.5'));
        $resolved_tokens = $max_tokens ?: intval($this->settings->get('max_tokens', '6000'));

        $payload = array(
            'model'       => $resolved_model,
            'messages'    => $messages,
            'temperature' => floatval($this->settings->get('temperature', '0.2')),
            'max_tokens'  => $resolved_tokens,
        );

        if ($web_search && $this->settings->get('web_search_enabled', '0') === '1') {
            $payload['plugins'] = array(array('id' => 'web', 'max_results' => 5));
        }

        // Таймаут: ~1 сек на 100 токенов + 30 сек, макс 90 сек (быстрый failover).
        // Для задач с большим объёмом токенов (write/finalize) масштабируется выше.
        // Потолок для крупных запросов поднят с 240 до 420 сек: "думающие" модели
        // (напр. Claude Sonnet 5, приоритетная для write/finalize) легитимно могут
        // работать 4-6 минут на полном переписывании статьи — раньше более низкий
        // потолок обрывал их РЯДОМ с завершением, откатываясь на модель послабее и
        // сводя на нет смысл приоритизации качественной модели. Безопасно поднимать
        // это выше, т.к. есть страховки уровнем ниже: принудительный cURL-таймаут
        // (см. ниже) и watchdog, который сам перезапускает по-настоящему зависшие
        // процессы (без активности 8+ минут).
        $base_timeout    = max(30, intval($this->settings->get('timeout', '90')));
        $token_timeout   = (int)($resolved_tokens / 100) + 30;
        $cap = $resolved_tokens > 8000 ? 420 : 90;
        $dynamic_timeout = max($base_timeout, min($cap, $token_timeout));

        $args = array(
            'timeout' => $dynamic_timeout,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
                'HTTP-Referer'  => home_url('/'),
                'X-Title'       => get_bloginfo('name') . ' AI SEO/GEO Editor',
            ),
            'body' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE),
        );

        $url = $base_url . '/chat/completions';

        // Жёсткая защита от зависания на уровне cURL. На некоторых хостингах другие
        // плагины (файрволы/security) вешают свой фильтр http_request_args и могут
        // переопределять/игнорировать наш 'timeout' — были случаи, когда запрос висел
        // 20+ минут при настроенном таймауте 90-240 сек. Принудительно выставляем
        // CURLOPT_TIMEOUT/CONNECTTIMEOUT напрямую на хендле — это последний рубеж,
        // который не может переопределить ни один фильтр уровня 'timeout' в args.
        $hard_timeout = $dynamic_timeout;
        $force_curl_timeout = function ($handle) use ($hard_timeout) {
            if (function_exists('curl_setopt')) {
                curl_setopt($handle, CURLOPT_TIMEOUT, $hard_timeout);
                curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 20);
            }
        };
        add_action('http_api_curl', $force_curl_timeout, 10, 1);
        $response = wp_remote_post($url, $args);
        remove_action('http_api_curl', $force_curl_timeout, 10);

        if (is_wp_error($response)) {
            $this->logger->log('error', 'openrouter',
                'Ошибка запроса OpenRouter: ' . $response->get_error_message(),
                array('model' => $resolved_model, 'timeout' => $dynamic_timeout)
            );
            return $response;
        }

        $code = intval(wp_remote_retrieve_response_code($response));
        $body = wp_remote_retrieve_body($response);

        if ($code >= 200 && $code < 300) {
            $json    = json_decode($body, true);
            $content = $json['choices'][0]['message']['content'] ?? '';
            if (is_array($content) || is_object($content)) {
                $content = wp_json_encode($content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }
            if (trim((string)$content) === '') {
                return new WP_Error('empty_response', 'OpenRouter вернул пустой ответ (модель: ' . $resolved_model . ').');
            }
            return array('content' => $content, 'model' => $resolved_model, 'raw' => $body);
        }

        $err = new WP_Error(
            'openrouter_http_' . $code,
            'OpenRouter HTTP ' . $code . ' (модель: ' . $resolved_model . ')',
            array('body' => mb_substr($body, 0, 500))
        );
        $this->logger->log('error', 'openrouter', 'OpenRouter HTTP ' . $code,
            array('model' => $resolved_model, 'body' => mb_substr($body, 0, 500))
        );
        return $err;
    }
}

<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_OpenRouter_Client {
    private $settings;
    private $logger;
    public function __construct($settings, $logger) { $this->settings = $settings; $this->logger = $logger; }
    public function test() {
        return $this->chat(array(
            array('role'=>'system','content'=>'Ответь только JSON.'),
            array('role'=>'user','content'=>'Верни {"ok":true,"service":"openrouter"}')
        ), 500);
    }
    public function chat($messages, $max_tokens = null, $model = null, $web_search = false) {
        $api_key = trim((string)$this->settings->get('api_key', ''));
        if ($api_key === '') { return new WP_Error('api_key_missing', 'API-ключ OpenRouter не указан.'); }
        $base_url = rtrim((string)$this->settings->get('base_url', 'https://openrouter.ai/api/v1'), '/');
        $model = $model ?: (string)$this->settings->get('model', 'google/gemini-2.5-flash');
        $payload = array(
            'model' => $model,
            'messages' => $messages,
            'temperature' => floatval($this->settings->get('temperature', '0.2')),
            'max_tokens' => $max_tokens ?: intval($this->settings->get('max_tokens', '6000')),
        );
        // Веб-поиск (grounding) для этапов ресёрча — только если включён в настройках.
        // Неизвестные поля шлюзы обычно игнорируют, поэтому риск минимальный.
        if ($web_search && $this->settings->get('web_search_enabled', '0') === '1') {
            $payload['plugins'] = array(array('id' => 'web', 'max_results' => 5));
        }
        $args = array(
            'timeout' => max(15, intval($this->settings->get('timeout', '60'))),
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json',
                'HTTP-Referer' => home_url('/'),
                'X-Title' => get_bloginfo('name') . ' AI SEO/GEO Editor',
            ),
            'body' => wp_json_encode($payload, JSON_UNESCAPED_UNICODE),
        );
        $url = $base_url . '/chat/completions';
        $max_retry = max(0, intval($this->settings->get('max_retry', '1')));
        $last_error = null;
        $models_to_try = array($model);
        $fallback = trim((string)$this->settings->get('fallback_model', ''));
        if ($fallback && $fallback !== $model) { $models_to_try[] = $fallback; }
        foreach ($models_to_try as $try_model) {
            $payload['model'] = $try_model;
            $args['body'] = wp_json_encode($payload, JSON_UNESCAPED_UNICODE);
            for ($i = 0; $i <= $max_retry; $i++) {
                $response = wp_remote_post($url, $args);
                if (is_wp_error($response)) {
                    $last_error = $response;
                    $this->logger->log('error', 'openrouter', 'Ошибка запроса OpenRouter: ' . $response->get_error_message(), array('model'=>$try_model));
                } else {
                    $code = intval(wp_remote_retrieve_response_code($response));
                    $body = wp_remote_retrieve_body($response);
                    if ($code >= 200 && $code < 300) {
                        $json = json_decode($body, true);
                        $content = $json['choices'][0]['message']['content'] ?? '';
                        if (is_array($content) || is_object($content)) { $content = wp_json_encode($content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }
                        if ($content === '') { return new WP_Error('empty_response', 'OpenRouter вернул пустой ответ.'); }
                        return array('content'=>$content, 'model'=>$try_model, 'raw'=>$body);
                    }
                    $last_error = new WP_Error('openrouter_http_' . $code, 'OpenRouter вернул HTTP ' . $code . ' (модель: ' . $try_model . ')', array('body'=>$body));
                    $this->logger->log('error', 'openrouter', 'OpenRouter HTTP ' . $code, array('model'=>$try_model,'body'=>mb_substr($body,0,1000)));
                    if ($code === 400 || $code === 401 || $code === 403 || $code === 404) { break; }
                }
                if ($i < $max_retry) { sleep(max(0, intval($this->settings->get('retry_delay', '2')))); }
            }
        }
        return $last_error ?: new WP_Error('openrouter_failed', 'Не удалось получить ответ OpenRouter.');
    }
}

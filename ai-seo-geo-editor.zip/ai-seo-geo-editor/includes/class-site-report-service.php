<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Site_Report_Service {
    private $audit_service;
    private $old_days = 180;

    public function __construct($audit_service) { $this->audit_service = $audit_service; }

    public function report() {
        global $wpdb;
        $posts_total = (int)wp_count_posts('post')->publish;
        $t = $this->audit_service->table();
        $latest_sql = "SELECT a.* FROM {$t} a INNER JOIN (SELECT post_id, MAX(id) mid FROM {$t} WHERE status='done' AND content_source='post' GROUP BY post_id) x ON x.mid=a.id";
        $rows = $wpdb->get_results($latest_sql);
        $checked = count($rows);
        $avg = array('overall'=>0,'seo'=>0,'geo'=>0,'eeat'=>0);
        $needs_attention = 0; $weak = 0; $critical = 0; $problems = array();
        foreach ($rows as $r) {
            $overall = (int)$r->overall_score;
            $avg['overall'] += $overall;
            $avg['seo'] += (int)$r->seo_score;
            $avg['geo'] += (int)$r->geo_score;
            $avg['eeat'] += (int)$r->eeat_score;
            // Единая логика шкалы: до 80 — стоит улучшить, до 60 — слабая, до 40 — критическая.
            if ($overall < 80) { $needs_attention++; }
            if ($overall < 60) { $weak++; }
            if ($overall < 40) { $critical++; }
            $p = json_decode((string)$r->problems_json, true);
            foreach ((array)($p['main_problems'] ?? array()) as $item) {
                $text = trim(wp_strip_all_tags(is_array($item) ? wp_json_encode($item, JSON_UNESCAPED_UNICODE) : (string)$item));
                if ($text) { $key = mb_substr($text, 0, 90); $problems[$key] = ($problems[$key] ?? 0) + 1; }
            }
        }
        if ($checked) { foreach ($avg as $k=>$v) { $avg[$k] = round($v / $checked); } }
        arsort($problems);

        // В топ выводим именно материалы, требующие улучшения (<80), чтобы счётчик и список не расходились.
        $weak_posts = $wpdb->get_results("{$latest_sql} WHERE overall_score < 80 ORDER BY overall_score ASC LIMIT 10");
        $strong_posts = $wpdb->get_results("{$latest_sql} ORDER BY overall_score DESC LIMIT 10");

        $no_meta = 0; $old = 0; $no_faq = 0;
        $posts = get_posts(array('post_type'=>'post','post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids','no_found_rows'=>true));
        foreach ($posts as $id) {
            $desc = get_post_meta($id, '_aiseogeo_meta_description', true)
                ?: get_post_meta($id, '_yoast_wpseo_metadesc', true)
                ?: get_post_meta($id, 'rank_math_description', true)
                ?: get_post_meta($id, '_aioseo_description', true)
                ?: get_post_meta($id, '_aioseop_description', true);
            if (trim((string)$desc) === '') { $no_meta++; }
            if (strtotime(get_post_modified_time('Y-m-d H:i:s', true, $id)) < strtotime('-' . $this->old_days . ' days')) { $old++; }
            $content = (string)get_post_field('post_content', $id);
            if (!$this->has_real_faq_block($content)) { $no_faq++; }
        }
        $optimization_insights = class_exists('AISEOGEO_Site_Optimization_Insights_Service') ? (new AISEOGEO_Site_Optimization_Insights_Service())->insights() : array();

        return array(
            'posts_total'=>$posts_total,
            'checked'=>$checked,
            'unchecked'=>max(0,$posts_total-$checked),
            'avg'=>$avg,
            'needs_attention'=>$needs_attention,
            'weak'=>$weak,
            'critical'=>$critical,
            'no_meta'=>$no_meta,
            'no_faq'=>$no_faq,
            'old'=>$old,
            'old_days'=>$this->old_days,
            'top_problems'=>array_slice($problems,0,10,true),
            'weak_posts'=>$weak_posts,
            'strong_posts'=>$strong_posts,
            'optimization_insights'=>$optimization_insights
        );
    }

    private function has_real_faq_block($content) {
        $content = (string)$content;
        if ($content === '') { return false; }

        // Проверяем только заголовки, а не любое вхождение слов. Иначе ссылка вида
        // «Частые вопросы перед подключением» в блоке перелинковки ошибочно считается FAQ.
        if (preg_match_all('/<h[2-4][^>]*>(.*?)<\/h[2-4]>/isu', $content, $m)) {
            foreach ($m[1] as $heading_html) {
                $heading = mb_strtolower(trim(wp_strip_all_tags($heading_html)));
                if ($this->is_faq_heading($heading)) { return true; }
            }
        }

        // Gutenberg heading block fallback.
        if (preg_match_all('/<!--\s*wp:heading[^>]*-->\s*(.*?)\s*<!--\s*\/wp:heading\s*-->/isu', $content, $m2)) {
            foreach ($m2[1] as $heading_html) {
                $heading = mb_strtolower(trim(wp_strip_all_tags($heading_html)));
                if ($this->is_faq_heading($heading)) { return true; }
            }
        }
        return false;
    }

    private function is_faq_heading($heading) {
        $heading = preg_replace('/\s+/u', ' ', (string)$heading);
        if ($heading === '') { return false; }
        $needles = array(
            'частые вопросы',
            'часто задаваемые вопросы',
            'вопросы и ответы',
            'faq'
        );
        foreach ($needles as $needle) {
            if (mb_strpos($heading, $needle) !== false) { return true; }
        }
        return false;
    }
}

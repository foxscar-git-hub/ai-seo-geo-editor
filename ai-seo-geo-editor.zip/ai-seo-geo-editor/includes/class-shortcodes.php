<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Shortcodes {
    private $audit_service;

    public function __construct($audit_service) { $this->audit_service = $audit_service; }

    public function init() {
        add_shortcode('aiseogeo_site_report', array($this, 'site_report'));
        add_shortcode('aiseogeo_dashboard', array($this, 'site_report'));
    }

    public function site_report($atts = array()) {
        if (!is_user_logged_in() || !current_user_can('aiseogeo_view_reports')) {
            return '<div class="aiseogeo-front-report"><p>Отчёт по сайту доступен только администратору или пользователю с правом просмотра отчётов.</p></div>';
        }
        $report = (new AISEOGEO_Site_Report_Service($this->audit_service))->report();
        ob_start();
        $this->render_front_report($report);
        return ob_get_clean();
    }

    private function render_front_report($report) {
        $avg = isset($report['avg']) && is_array($report['avg']) ? $report['avg'] : array();
        ?>
        <style>
            .aiseogeo-front-report{font-family:inherit;background:#f6f7fb;border:1px solid #e5e7eb;border-radius:24px;padding:24px;margin:24px 0;color:#172033}.aiseogeo-front-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:18px}.aiseogeo-front-head h2{margin:0 0 6px;font-size:30px;line-height:1.15}.aiseogeo-front-head p{margin:0;color:#667085}.aiseogeo-front-badge{display:inline-flex;align-items:center;border-radius:999px;background:#ede9fe;color:#5b21b6;padding:8px 12px;font-weight:700;font-size:13px}.aiseogeo-front-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:18px 0}.aiseogeo-front-kpi{background:#fff;border:1px solid #edf0f5;border-radius:18px;padding:18px;box-shadow:0 8px 24px rgba(16,24,40,.05)}.aiseogeo-front-kpi span{display:block;color:#667085;font-size:13px;margin-bottom:8px}.aiseogeo-front-kpi strong{display:block;font-size:32px;line-height:1.05}.aiseogeo-front-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:16px}.aiseogeo-front-card{background:#fff;border:1px solid #edf0f5;border-radius:18px;padding:20px;box-shadow:0 8px 24px rgba(16,24,40,.05)}.aiseogeo-front-card h3{margin:0 0 14px;font-size:20px}.aiseogeo-front-score{display:flex;align-items:center;justify-content:space-between;margin:10px 0}.aiseogeo-front-bar{height:10px;background:#eef2f7;border-radius:999px;overflow:hidden;flex:1;margin-left:14px}.aiseogeo-front-bar i{display:block;height:100%;background:#7c3aed;border-radius:999px}.aiseogeo-front-list{margin:0;padding-left:22px}.aiseogeo-front-list li{margin:8px 0}.aiseogeo-front-muted{color:#667085}.aiseogeo-front-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}.aiseogeo-front-btn{display:inline-flex;align-items:center;justify-content:center;border-radius:12px;padding:10px 14px;background:#7c3aed;color:#fff!important;text-decoration:none;font-weight:700}@media(max-width:900px){.aiseogeo-front-kpis,.aiseogeo-front-grid{grid-template-columns:1fr 1fr}}@media(max-width:640px){.aiseogeo-front-kpis,.aiseogeo-front-grid{grid-template-columns:1fr}}
        </style>
        <div class="aiseogeo-front-report">
            <div class="aiseogeo-front-head">
                <div>
                    <h2>Отчёт по сайту</h2>
                    <p>Сводка по SEO/GEO-качеству статей, рискам и материалам, которые стоит улучшить первыми.</p>
                </div>
                <span class="aiseogeo-front-badge">AI SEO/GEO</span>
            </div>
            <div class="aiseogeo-front-kpis">
                <div class="aiseogeo-front-kpi"><span>Записей всего</span><strong><?php echo absint($report['posts_total'] ?? 0); ?></strong></div>
                <div class="aiseogeo-front-kpi"><span>Проанализировано</span><strong><?php echo absint($report['checked'] ?? 0); ?></strong></div>
                <div class="aiseogeo-front-kpi"><span>Требуют улучшения</span><strong><?php echo absint($report['needs_attention'] ?? 0); ?></strong></div>
                <div class="aiseogeo-front-kpi"><span>Критических</span><strong><?php echo absint($report['critical'] ?? 0); ?></strong></div>
            </div>
            <div class="aiseogeo-front-grid">
                <div class="aiseogeo-front-card">
                    <h3>Средние оценки</h3>
                    <?php foreach (array('overall'=>'Общая','seo'=>'SEO','geo'=>'GEO','eeat'=>'EEAT') as $key=>$label): $val = max(0, min(100, (int)($avg[$key] ?? 0))); ?>
                        <div class="aiseogeo-front-score"><strong><?php echo esc_html($label); ?>: <?php echo $val; ?>/100</strong><div class="aiseogeo-front-bar"><i style="width:<?php echo esc_attr($val); ?>%"></i></div></div>
                    <?php endforeach; ?>
                </div>
                <div class="aiseogeo-front-card">
                    <h3>Быстрые риски</h3>
                    <ul class="aiseogeo-front-list">
                        <li>Без анализа: <strong><?php echo absint($report['unchecked'] ?? 0); ?></strong></li>
                        <li>Без meta description: <strong><?php echo absint($report['no_meta'] ?? 0); ?></strong></li>
                        <li>Без FAQ-блока: <strong><?php echo absint($report['no_faq'] ?? 0); ?></strong></li>
                        <li>Давно не обновлялись: <strong><?php echo absint($report['old'] ?? 0); ?></strong></li>
                    </ul>
                </div>
            </div>
            <div class="aiseogeo-front-grid">
                <div class="aiseogeo-front-card">
                    <h3>Топ статей для улучшения</h3>
                    <ol class="aiseogeo-front-list">
                        <?php foreach ((array)($report['weak_posts'] ?? array()) as $r): ?>
                            <li><a href="<?php echo esc_url(get_permalink((int)$r->post_id)); ?>"><?php echo esc_html($r->post_title); ?></a> — <strong><?php echo absint($r->overall_score); ?>/100</strong></li>
                        <?php endforeach; ?>
                    </ol>
                </div>
                <div class="aiseogeo-front-card">
                    <h3>Частые проблемы</h3>
                    <ol class="aiseogeo-front-list">
                        <?php foreach ((array)($report['top_problems'] ?? array()) as $problem=>$count): ?>
                            <li><?php echo esc_html($problem); ?> <strong>×<?php echo absint($count); ?></strong></li>
                        <?php endforeach; ?>
                    </ol>
                </div>
            </div>
            <div class="aiseogeo-front-actions">
                <a class="aiseogeo-front-btn" target="_blank" rel="noopener" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-site-report')); ?>">Открыть полный отчёт</a>
            </div>
        </div>
        <?php
    }
}

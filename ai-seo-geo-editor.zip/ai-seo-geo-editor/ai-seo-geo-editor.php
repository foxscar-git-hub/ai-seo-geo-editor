<?php
/**
 * Plugin Name: AI SEO/GEO Редактор статей
 * Description: AI SEO/GEO оптимизация статей. Анализ, переписывание, автооптимизация новых публикаций.
 * Version: 1.6.4
 * Author: @foxscar
 * Text Domain: ai-seo-geo-editor
 */

if (!defined('ABSPATH')) {
    exit;
}

define('AISEOGEO_VERSION', '1.6.4');
define('AISEOGEO_FILE', __FILE__);
define('AISEOGEO_DIR', plugin_dir_path(__FILE__));
define('AISEOGEO_URL', plugin_dir_url(__FILE__));
define('AISEOGEO_BASENAME', plugin_basename(__FILE__));

require_once AISEOGEO_DIR . 'includes/class-plugin.php';

register_activation_hook(__FILE__, array('AISEOGEO_Plugin', 'activate'));
register_deactivation_hook(__FILE__, array('AISEOGEO_Plugin', 'deactivate'));

add_action('plugins_loaded', function () {
    AISEOGEO_Plugin::instance()->init();
});

<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
$delete_data = get_option('aiseogeo_delete_data_on_uninstall', '0');
if ($delete_data === '1') {
    global $wpdb;
    $tables = array(
        $wpdb->prefix . 'aiseogeo_audits',
        $wpdb->prefix . 'aiseogeo_logs',
        $wpdb->prefix . 'aiseogeo_settings',
        $wpdb->prefix . 'aiseogeo_rewrites',
        $wpdb->prefix . 'aiseogeo_versions',
        $wpdb->prefix . 'aiseogeo_backups',
        $wpdb->prefix . 'aiseogeo_jobs',
        $wpdb->prefix . 'aiseogeo_job_items',
        $wpdb->prefix . 'aiseogeo_apply_logs',
    );
    foreach ($tables as $table) { $wpdb->query("DROP TABLE IF EXISTS {$table}"); }
    delete_option('aiseogeo_version');
    delete_option('aiseogeo_delete_data_on_uninstall');
}

<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Прямой клиент OpenAI (api.openai.com), в обход OpenRouter.
 *
 * Используется автоматически диспетчером в class-openrouter-client.php,
 * когда выбрана модель "openai/*" и в настройках указан отдельный
 * OpenAI API-ключ — это позволяет обойти блокировки/security policy
 * конкретно у OpenRouter (напр. HTTP 403 "Access denied by security policy"),
 * не трогая остальную цепочку моделей.
 */
class AISEOGEO_OpenAI_Client {
    private $settings;
    private $logger;

    const BASE = 'https://api.openai.com/v1';

    public function __construct($settings, $logger) {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    public function has_key() {
        return trim((string)$this->settings->get('openai_api_key', '')) !== '';
    }

    public function test() {
        return $this->chat(array(
            array('role' => 'system', 'content' => 'Ответь только JSON.'),
            array('role' => 'user',   'content' => 'Верни {"ok":true,"service":"openai"}'),
        ), 500, 'gpt-4o-mini');
    }

    /**
     * @param array    $messages
     * @param int|null $max_tokens
     * @param string   $model  Без префикса "openai/" — просто ID модели (gpt-4o-mini, gpt-4o, ...).
     */
    public function chat($messages, $max_tokens = null, $model = '') {
        $api_key = trim((string)$this->settings->get('openai_api_key', ''));
        if ($api_key === '') {
            return new WP_Error('openai_api_key_missing', 'API-ключ OpenAI не указан.');
        }

        $model      = $model ?: 'gpt-4o-mini';
        $max_tokens = $max_tokens ?: intval($this->settings->get('max_tokens', '6000'));

        $body = array(
            'model'       => $model,
            'messages'    => $messages,
            'temperature' => floatval($this->settings->get('temperature', '0.2')),
            'max_tokens'  => $max_tokens,
        );

        $base_timeout    = max(30, intval($this->settings->get('timeout', '90')));
        $token_timeout   = (int)($max_tokens / 100) + 30;
        $cap             = $max_tokens > 8000 ? 420 : 90;
        $dynamic_timeout = max($base_timeout, min($cap, $token_timeout));

        $args = array(
            'timeout' => $dynamic_timeout,
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode($body, JSON_UNESCAPED_UNICODE),
        );

        $hard_timeout = $dynamic_timeout;
        $force_curl_timeout = function ($handle) use ($hard_timeout) {
            if (function_exists('curl_setopt')) {
                curl_setopt($handle, CURLOPT_TIMEOUT, $hard_timeout);
                curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 20);
            }
        };
        add_action('http_api_curl', $force_curl_timeout, 10, 1);
        $response = wp_remote_post(self::BASE . '/chat/completions', $args);
        remove_action('http_api_curl', $force_curl_timeout, 10);

        if (is_wp_error($response)) {
            $this->logger->log('error', 'openai', 'Ошибка запроса OpenAI: ' . $response->get_error_message(), array('model' => $model));
            return $response;
        }

        $code = intval(wp_remote_retrieve_response_code($response));
        $resp_body = wp_remote_retrieve_body($response);

        if ($code >= 200 && $code < 300) {
            $json    = json_decode($resp_body, true);
            $content = $json['choices'][0]['message']['content'] ?? '';
            if (trim((string)$content) === '') {
                return new WP_Error('openai_empty_response', 'OpenAI вернул пустой ответ (модель: ' . $model . ').');
            }
            return array('content' => $content, 'model' => 'openai/' . $model, 'raw' => $resp_body);
        }

        $this->logger->log('error', 'openai', 'OpenAI HTTP ' . $code, array('model' => $model, 'body' => mb_substr($resp_body, 0, 500)));
        return new WP_Error(
            'openai_http_' . $code,
            'OpenAI HTTP ' . $code . ' (модель: ' . $model . ')',
            array('body' => mb_substr($resp_body, 0, 500))
        );
    }
}

<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Settings {
    public function table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_settings'; }
    public function get($key, $default = '') {
        global $wpdb;
        $val = $wpdb->get_var($wpdb->prepare("SELECT setting_value FROM {$this->table()} WHERE setting_key=%s", $key));
        return $val === null ? $default : maybe_unserialize($val);
    }
    public function set($key, $value) {
        global $wpdb;
        $now = current_time('mysql');
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table()} WHERE setting_key=%s", $key));
        $data = array('setting_key'=>$key,'setting_value'=>maybe_serialize($value),'updated_at'=>$now);
        if ($exists) {
            $wpdb->update($this->table(), $data, array('setting_key'=>$key));
        } else {
            $data['created_at'] = $now;
            $wpdb->insert($this->table(), $data);
        }
    }
    public function all() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT setting_key, setting_value FROM {$this->table()} ORDER BY setting_key ASC");
        $out = array();
        foreach ($rows as $r) { $out[$r->setting_key] = maybe_unserialize($r->setting_value); }
        return $out;
    }
    public function save_from_request($data) {
        $allowed = array('api_key','base_url','model','fallback_model','kie_api_key','openai_api_key','timeout','max_retry','retry_delay','temperature','max_tokens','log_requests','enable_metabox','save_raw_response','web_search_enabled','auto_optimize_enabled','auto_optimize_mode','auto_optimize_model','frontend_meta_description_enabled','learning_enabled','learning_min_days','learning_views_threshold','learning_min_samples','learning_inject_audit','learning_inject_rewrite');
        foreach ($allowed as $key) {
            if (isset($data[$key])) {
                $this->set($key, is_array($data[$key]) ? array_map('sanitize_text_field', $data[$key]) : sanitize_text_field(wp_unslash($data[$key])));
            }
        }
    }
}

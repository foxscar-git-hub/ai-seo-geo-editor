<?php
if (!defined('ABSPATH')) { exit; }

class AISEOGEO_Shortcodes {
    private $audit_service;

    public function __construct($audit_service) { $this->audit_service = $audit_service; }

    public function init() {
        add_shortcode('aiseogeo_site_report', array($this, 'site_report'));
        add_shortcode('aiseogeo_dashboard', array($this, 'site_report'));
    }

    public function site_report($atts = array()) {
        if (!is_user_logged_in() || !current_user_can('aiseogeo_view_reports')) {
            return '<div class="aiseogeo-front-report"><p>Отчёт по сайту доступен только администратору или пользователю с правом просмотра отчётов.</p></div>';
        }
        $settings = new AISEOGEO_Settings();
        $gate = new AISEOGEO_License_Gate($settings, AISEOGEO_Plugin::instance()->logger);
        if (!$gate->can('site_report_shortcode')) {
            return '<div class="aiseogeo-front-report"><h2>Отчёт по сайту</h2><p>Фронтенд-отчёт доступен в платной версии AI SEO/GEO Редактора. В бесплатном режиме можно смотреть отчёты в админке и выполнить базовые анализы.</p><p><a class="aiseogeo-front-btn" href="' . esc_url(admin_url('admin.php?page=aiseogeo-license')) . '">Ввести лицензионный ключ</a></p></div>';
        }
        $gate->track('frontend_report');
        $report = (new AISEOGEO_Site_Report_Service($this->audit_service))->report();
        ob_start();
        $this->render_front_report($report);
        return ob_get_clean();
    }

    private function render_front_report($report) {
        $avg = isset($report['avg']) && is_array($report['avg']) ? $report['avg'] : array();
        ?>
        <style>
            .aiseogeo-front-report{font-family:inherit;background:#f6f7fb;border:1px solid #e5e7eb;border-radius:24px;padding:24px;margin:24px 0;color:#172033}.aiseogeo-front-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:18px}.aiseogeo-front-head h2{margin:0 0 6px;font-size:30px;line-height:1.15}.aiseogeo-front-head p{margin:0;color:#667085}.aiseogeo-front-badge{display:inline-flex;align-items:center;border-radius:999px;background:#ede9fe;color:#5b21b6;padding:8px 12px;font-weight:700;font-size:13px}.aiseogeo-front-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:18px 0}.aiseogeo-front-kpi{background:#fff;border:1px solid #edf0f5;border-radius:18px;padding:18px;box-shadow:0 8px 24px rgba(16,24,40,.05)}.aiseogeo-front-kpi span{display:block;color:#667085;font-size:13px;margin-bottom:8px}.aiseogeo-front-kpi strong{display:block;font-size:32px;line-height:1.05}.aiseogeo-front-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:16px}.aiseogeo-front-insights{background:#fff;border:1px solid #edf0f5;border-radius:18px;padding:20px;margin:16px 0;box-shadow:0 8px 24px rgba(16,24,40,.05)}.aiseogeo-front-insights-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:14px}.aiseogeo-front-insights-head h3{margin:0 0 6px;font-size:22px}.aiseogeo-front-insights-head p{margin:0;color:#667085}.aiseogeo-front-mini-badge{border-radius:999px;background:#eef2ff;color:#3730a3;padding:7px 10px;font-weight:800;font-size:12px}.aiseogeo-front-forecast{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.aiseogeo-front-forecast-card{border:1px solid #e5e7eb;border-radius:16px;padding:14px;background:#fbfcff}.aiseogeo-front-forecast-card h4{margin:0 0 10px;font-size:15px}.aiseogeo-front-triplet{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.aiseogeo-front-triplet span{display:block;background:#f6f7fb;border-radius:12px;padding:9px;font-size:12px;color:#667085}.aiseogeo-front-triplet strong{display:block;color:#172033;font-size:22px;margin-top:2px}.aiseogeo-front-triplet .growth{background:#dcfce7;color:#166534}.aiseogeo-front-triplet .growth strong{color:#047857}.aiseogeo-front-insights-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:14px}.aiseogeo-front-change{background:#f8fafc;border:1px solid #edf0f5;border-radius:14px;padding:12px}.aiseogeo-front-change span{display:block;color:#667085;font-size:12px;margin-bottom:5px}.aiseogeo-front-change strong{font-size:24px}.aiseogeo-front-note{margin-top:12px;color:#667085;font-size:13px}.aiseogeo-front-card{background:#fff;border:1px solid #edf0f5;border-radius:18px;padding:20px;box-shadow:0 8px 24px rgba(16,24,40,.05)}.aiseogeo-front-card h3{margin:0 0 14px;font-size:20px}.aiseogeo-front-score{display:flex;align-items:center;justify-content:space-between;margin:10px 0}.aiseogeo-front-bar{height:10px;background:#eef2f7;border-radius:999px;overflow:hidden;flex:1;margin-left:14px}.aiseogeo-front-bar i{display:block;height:100%;background:#7c3aed;border-radius:999px}.aiseogeo-front-list{margin:0;padding-left:22px}.aiseogeo-front-list li{margin:8px 0}.aiseogeo-front-muted{color:#667085}.aiseogeo-front-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}.aiseogeo-front-btn{display:inline-flex;align-items:center;justify-content:center;border-radius:12px;padding:10px 14px;background:#7c3aed;color:#fff!important;text-decoration:none;font-weight:700}.aiseogeo-front-btn.secondary{background:#fff;color:#7c3aed!important;border:1px solid #ddd6fe}@media(max-width:900px){.aiseogeo-front-kpis,.aiseogeo-front-grid,.aiseogeo-front-forecast,.aiseogeo-front-insights-grid{grid-template-columns:1fr 1fr}.aiseogeo-front-head{display:block}.aiseogeo-front-badge{margin-top:12px}}@media(max-width:640px){.aiseogeo-front-kpis,.aiseogeo-front-grid,.aiseogeo-front-forecast,.aiseogeo-front-insights-grid{grid-template-columns:1fr}.aiseogeo-front-report{padding:16px;border-radius:18px}.aiseogeo-front-head h2{font-size:24px}}
        </style>
        <div class="aiseogeo-front-report">
            <div class="aiseogeo-front-head">
                <div>
                    <h2>Отчёт по сайту</h2>
                    <p>Сводка по SEO/GEO-качеству статей, рискам и материалам, которые стоит улучшить первыми.</p>
                </div>
                <span class="aiseogeo-front-badge">AI SEO/GEO</span>
            </div>
            <div class="aiseogeo-front-kpis">
                <div class="aiseogeo-front-kpi"><span>Записей всего</span><strong><?php echo absint($report['posts_total'] ?? 0); ?></strong></div>
                <div class="aiseogeo-front-kpi"><span>Проанализировано</span><strong><?php echo absint($report['checked'] ?? 0); ?></strong></div>
                <div class="aiseogeo-front-kpi"><span>Требуют улучшения</span><strong><?php echo absint($report['needs_attention'] ?? 0); ?></strong></div>
                <div class="aiseogeo-front-kpi"><span>Критических <small title="Проанализированные статьи с общей оценкой ниже 40/100">?</small></span><strong><?php echo absint($report['critical'] ?? 0); ?></strong></div>
            </div>
            <?php $insights = isset($report['optimization_insights']) && is_array($report['optimization_insights']) ? $report['optimization_insights'] : array(); ?>
            <?php if (!empty($insights['has_data'])): $changes = (array)($insights['change_summary'] ?? array()); ?>
            <div class="aiseogeo-front-insights">
                <div class="aiseogeo-front-insights-head">
                    <div>
                        <h3>Эффективность оптимизации обработанных материалов</h3>
                        <p>Сводная картина только по материалам, которые уже обработаны плагином: анализ, AI-версии, применения к оригиналу.</p>
                    </div>
                    <span class="aiseogeo-front-mini-badge">ДО / ПОСЛЕ</span>
                </div>
                <div class="aiseogeo-front-coverage" style="margin:10px 0 14px;color:#667085;font-size:14px">В расчёт входят AI-версии: <strong><?php echo absint($insights['total_rewrites'] ?? 0); ?></strong>; применено к оригиналам: <strong><?php echo absint($insights['applied_rewrites'] ?? 0); ?></strong>. Остальные записи сайта без обработки не учитываются в “до/после”.</div>
                <div class="aiseogeo-front-forecast">
                    <?php foreach ((array)($insights['forecast_rows'] ?? array()) as $row): ?>
                        <div class="aiseogeo-front-forecast-card">
                            <h4><?php echo esc_html($row['label'] ?? 'Показатель'); ?></h4>
                            <div class="aiseogeo-front-triplet">
                                <span>До<strong><?php echo absint($row['before'] ?? 0); ?></strong></span>
                                <span>После<strong><?php echo absint($row['after'] ?? 0); ?></strong></span>
                                <span class="growth">Рост<strong><?php echo ((int)($row['delta'] ?? 0) >= 0 ? '+' : '') . intval($row['delta'] ?? 0); ?></strong></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <h3 style="margin:18px 0 8px">Понятное сравнение изменений по обработанным материалам</h3>
                <div class="aiseogeo-front-insights-grid">
                    <div class="aiseogeo-front-change"><span>AI-версий создано</span><strong><?php echo absint($insights['total_rewrites'] ?? 0); ?></strong></div>
                    <div class="aiseogeo-front-change"><span>Применено к оригиналам</span><strong><?php echo absint($insights['applied_rewrites'] ?? 0); ?></strong></div>
                    <div class="aiseogeo-front-change"><span>Новые title</span><strong><?php echo absint($changes['changed_title'] ?? 0); ?></strong></div>
                    <div class="aiseogeo-front-change"><span>Новые description</span><strong><?php echo absint($changes['new_meta_description'] ?? 0); ?></strong></div>
                    <div class="aiseogeo-front-change"><span>FAQ сохранён/добавлен</span><strong><?php echo absint($changes['faq_saved_or_added'] ?? 0); ?></strong></div>
                    <div class="aiseogeo-front-change"><span>CTA сохранён</span><strong><?php echo absint($changes['cta_saved'] ?? 0); ?></strong></div>
                    <div class="aiseogeo-front-change"><span>Ссылки сохранены</span><strong><?php echo absint($changes['links_preserved'] ?? 0); ?></strong></div>
                    <div class="aiseogeo-front-change"><span>Средний рост текста</span><strong><?php echo intval($changes['avg_text_growth_percent'] ?? 0); ?>%</strong></div>
                </div>
                <p class="aiseogeo-front-note"><strong>Важно:</strong> <?php echo esc_html($insights['note'] ?? 'Показатели являются прогнозными и не заменяют аналитику поисковых систем.'); ?></p>
            </div>
            <?php else: ?>
            <div class="aiseogeo-front-insights">
                <div class="aiseogeo-front-insights-head"><div><h3>Эффективность оптимизации обработанных материалов</h3><p>Здесь появится сводная аналитика “до/после”, когда будут созданы первые AI-версии. Необработанные записи сайта в этот блок не входят.</p></div><span class="aiseogeo-front-mini-badge">ОЖИДАЕТ ДАННЫЕ</span></div>
            </div>
            <?php endif; ?>
            <div class="aiseogeo-front-grid">
                <div class="aiseogeo-front-card">
                    <h3>Средние оценки</h3>
                    <?php foreach (array('overall'=>'Общая','seo'=>'SEO','geo'=>'GEO','eeat'=>'EEAT') as $key=>$label): $val = max(0, min(100, (int)($avg[$key] ?? 0))); ?>
                        <div class="aiseogeo-front-score"><strong><?php echo esc_html($label); ?>: <?php echo $val; ?>/100</strong><div class="aiseogeo-front-bar"><i style="width:<?php echo esc_attr($val); ?>%"></i></div></div>
                    <?php endforeach; ?>
                </div>
                <div class="aiseogeo-front-card">
                    <h3>Быстрые риски</h3>
                    <ul class="aiseogeo-front-list">
                        <li>Без анализа: <strong><?php echo absint($report['unchecked'] ?? 0); ?></strong></li>
                        <li>Без meta description: <strong><?php echo absint($report['no_meta'] ?? 0); ?></strong></li>
                        <li>Без FAQ-блока: <strong><?php echo absint($report['no_faq'] ?? 0); ?></strong><br><span class="aiseogeo-front-muted">Считаются статьи без отдельного H2/H3 “Частые вопросы / FAQ”. Ссылки в перелинковке больше не считаются FAQ.</span></li>
                        <li>Давно не обновлялись: <strong><?php echo absint($report['old'] ?? 0); ?></strong><br><span class="aiseogeo-front-muted">Записи, которые не изменялись более <?php echo absint($report['old_days'] ?? 180); ?> дней.</span></li>
                    </ul>
                </div>
            </div>
            <div class="aiseogeo-front-grid">
                <div class="aiseogeo-front-card">
                    <h3>Топ статей для улучшения</h3>
                    <ol class="aiseogeo-front-list">
                        <?php foreach ((array)($report['weak_posts'] ?? array()) as $r): ?>
                            <li><a href="<?php echo esc_url(get_permalink((int)$r->post_id)); ?>"><?php echo esc_html($r->post_title); ?></a> — <strong><?php echo absint($r->overall_score); ?>/100</strong></li>
                        <?php endforeach; ?>
                    </ol>
                </div>
                <div class="aiseogeo-front-card">
                    <h3>Частые проблемы</h3>
                    <ol class="aiseogeo-front-list">
                        <?php foreach ((array)($report['top_problems'] ?? array()) as $problem=>$count): ?>
                            <li><?php echo esc_html($problem); ?> <strong>×<?php echo absint($count); ?></strong></li>
                        <?php endforeach; ?>
                    </ol>
                </div>
            </div>
            <div class="aiseogeo-front-actions">
                <a class="aiseogeo-front-btn" target="_blank" rel="noopener" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-site-report')); ?>">Открыть полный отчёт</a>
                <a class="aiseogeo-front-btn secondary" target="_blank" rel="noopener" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-bulk')); ?>">Массовая обработка</a>
            </div>
        </div>
        <?php
    }
}

<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap"><h1>Диагностика</h1>
<div class="aiseogeo-grid two"><div class="aiseogeo-card"><h2>Система</h2><p>Плагин: <?php echo esc_html(AISEOGEO_VERSION); ?></p><p>WordPress: <?php echo esc_html(get_bloginfo('version')); ?></p><p>PHP: <?php echo esc_html(PHP_VERSION); ?></p><p>OpenRouter API: <?php echo $settings->get('api_key','') ? 'ключ указан' : 'ключ не указан'; ?></p><p>Модель: <?php echo esc_html($settings->get('model','')); ?></p></div><div class="aiseogeo-card"><h2>Таблицы БД</h2><?php foreach($tables as $t=>$ok): ?><p><?php echo esc_html($t); ?> — <?php echo $ok ? 'OK' : 'нет'; ?></p><?php endforeach; ?></div></div>
<div class="aiseogeo-card"><h2>Последние логи</h2>
<p style="color:#666;font-size:12px">Шаги переписывания (контекст <code>rewrite_step</code> / <code>rewrite_plan</code>) показывают каждый этап методологии «Скилл статей» в реальном времени.</p>
<table class="widefat striped"><thead><tr><th style="width:140px">Дата</th><th style="width:60px">Уровень</th><th style="width:120px">Контекст</th><th>Сообщение / детали</th></tr></thead><tbody>
<?php foreach($logs as $l):
    $is_step = in_array($l->context, array('rewrite_step','rewrite_plan','auto_rewrite'), true);
    $row_bg = $l->level === 'error' ? 'background:#fcebea' : ($is_step ? 'background:#f0f6fc' : '');
    $data = json_decode((string)$l->data_json, true);
    $detail = '';
    if (is_array($data)) {
        $parts = array();
        foreach ($data as $k=>$v) {
            if (in_array($k, array('rewrite_id','raw'), true)) { continue; }
            if (is_array($v)) { $v = implode('; ', array_map(function($x){ return is_scalar($x)?(string)$x:wp_json_encode($x, JSON_UNESCAPED_UNICODE); }, $v)); }
            if ($v === '' || $v === null) { continue; }
            $parts[] = '<strong>'.esc_html($k).':</strong> '.esc_html((string)$v);
        }
        $detail = implode(' &nbsp;·&nbsp; ', $parts);
    }
?>
<tr style="<?php echo $row_bg; ?>">
  <td><?php echo esc_html($l->created_at); ?></td>
  <td><?php echo esc_html($l->level); ?></td>
  <td><?php echo esc_html($l->context); ?></td>
  <td><?php echo esc_html($l->message); ?><?php if($detail): ?><br><span style="color:#555;font-size:11px"><?php echo $detail; ?></span><?php endif; ?></td>
</tr>
<?php endforeach; ?>
</tbody></table></div>
</div>

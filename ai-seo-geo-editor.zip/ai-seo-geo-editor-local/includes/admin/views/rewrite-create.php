<?php if (!defined('ABSPATH')) { exit; }
if (!function_exists('aiseogeo_rewrite_mode_description')) { function aiseogeo_rewrite_mode_description($key){ $d=array('soft_improve'=>'Сохраняет структуру и мягко улучшает слабые места.','seo_boost'=>'Усиливает SEO, заголовки, интент и мета-данные.','geo_boost'=>'Готовит статью к AI-поиску: краткие ответы, FAQ, цитируемость.','full_refresh'=>'Глубоко обновляет слабую или устаревшую статью.','meta_only'=>'Меняет только title, description, excerpt, FAQ и schema-рекомендации.','problem_blocks_only'=>'Переписывает только проблемные блоки из отчёта.'); return $d[$key] ?? ''; }} $problems=$audit ? (json_decode($audit->problems_json,true) ?: array()) : array(); $suggested=$audit ? (json_decode($audit->suggested_json,true) ?: array()) : array(); ?>
<div class="wrap aiseogeo-wrap">
  <h1>Создание улучшенной версии</h1>
  <?php if (!empty($_GET['aiseogeo_error'])): ?><div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div><?php endif; ?>
  <?php if (!$post || !$audit || $audit->status !== 'done'): ?>
    <div class="notice notice-error"><p>Для переписывания сначала нужен успешный AI-анализ статьи.</p></div>
    <?php if ($post): ?><p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audit-post&post_id=' . absint($post->ID))); ?>">Перейти к анализу</a></p><?php endif; ?>
    <?php return; ?>
  <?php endif; ?>
  <div class="aiseogeo-card">
    <h2><?php echo esc_html(get_the_title($post)); ?></h2>
    <p><strong>Статус:</strong> <?php echo esc_html($post->post_status); ?> · <strong>Последний анализ:</strong> <?php echo esc_html(mysql2date('d.m.Y H:i',$audit->created_at)); ?></p>
    <p><strong>Оценки:</strong> Общая <?php echo esc_html($audit->overall_score); ?>/100 · SEO <?php echo esc_html($audit->seo_score); ?> · GEO <?php echo esc_html($audit->geo_score); ?> · EEAT <?php echo esc_html($audit->eeat_score); ?></p>
    <p><?php echo esc_html($audit->summary); ?></p>
  </div>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card"><h2>Основные проблемы</h2><?php if(function_exists('aiseogeo_list')){aiseogeo_list($problems['main_problems'] ?? array());} else { echo '<pre>'.esc_html(wp_json_encode($problems,JSON_UNESCAPED_UNICODE)).'</pre>'; } ?></div>
    <div class="aiseogeo-card"><h2>Рекомендуемая стратегия</h2><p><?php echo esc_html($suggested['rewrite_strategy'] ?? 'Выберите режим вручную.'); ?></p></div>
  </div>
  <div class="aiseogeo-card">
    <h2>Выберите режим переписывания <?php if (!empty($license_gate)) { echo $license_gate->feature_badge('rewrite_plan'); } ?></h2>
    <?php if (!empty($license_gate) && !$license_gate->can('rewrite_plan')): ?>
      <?php $license_gate->render_required_box('rewrite_plan', 'Переписывание доступно по лицензии'); ?>
    <?php else: ?>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
      <input type="hidden" name="action" value="aiseogeo_create_rewrite_plan">
      <input type="hidden" name="post_id" value="<?php echo absint($post->ID); ?>">
      <input type="hidden" name="audit_id" value="<?php echo absint($audit->id); ?>">
      <?php wp_nonce_field('aiseogeo_create_rewrite_plan_' . $post->ID . '_' . $audit->id); ?>
      <?php foreach ($modes as $key=>$label): ?>
        <p><label><input type="radio" name="rewrite_mode" value="<?php echo esc_attr($key); ?>" <?php checked($key, 'soft_improve'); ?>> <strong><?php echo esc_html($label); ?></strong><br><span class="description"><?php echo esc_html(aiseogeo_rewrite_mode_description($key)); ?></span></label></p>
      <?php endforeach; ?>
      <div class="notice notice-warning inline"><p>Создание плана использует OpenRouter API. Оригинальная статья не будет изменена.</p></div>
      <button class="button button-primary button-hero">Сформировать план улучшения</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<?php if (!defined('ABSPATH')) { exit; }
if (!function_exists('aiseogeo_stage2_list')) { function aiseogeo_stage2_list($items){ if(empty($items)){echo '—'; return;} if(!is_array($items)){$items=array($items);} echo '<ul class="aiseogeo-list">'; foreach($items as $item){ $txt=is_array($item)?wp_json_encode($item,JSON_UNESCAPED_UNICODE):(string)$item; echo '<li>'.esc_html($txt).'</li>'; } echo '</ul>'; } }


if (!function_exists('aiseogeo_render_change_intelligence')) {
    function aiseogeo_render_change_intelligence($change) {
        if (empty($change) || !is_array($change)) { return; }
        $word_delta = (int)($change['new_words'] ?? 0) - (int)($change['old_words'] ?? 0);
        echo '<div class="aiseogeo-card aiseogeo-diff-card"><div class="aiseogeo-section-head"><div><h2>Понятное сравнение изменений</h2><p>Что реально изменилось между исходной статьёй и AI-версией.</p></div><span class="aiseogeo-badge">до / после</span></div>';
        echo '<div class="aiseogeo-diff-kpi">';
        echo '<div><span>Объём текста</span><strong>'.esc_html((int)$change['old_words']).' → '.esc_html((int)$change['new_words']).'</strong><em>'.esc_html(($word_delta>0?'+':'').$word_delta).' слов</em></div>';
        echo '<div><span>Подзаголовки</span><strong>'.esc_html((int)$change['old_headings_count']).' → '.esc_html((int)$change['new_headings_count']).'</strong><em>структура</em></div>';
        echo '<div><span>Ссылки</span><strong>'.esc_html((int)$change['old_links_count']).' → '.esc_html((int)$change['new_links_count']).'</strong><em>перелинковка</em></div>';
        echo '<div><span>Похожесть текста</span><strong>'.esc_html((int)$change['content_similarity']).'%</strong><em>'.esc_html(((int)$change['content_similarity'] > 85) ? 'мягкая правка' : 'существенная правка').'</em></div>';
        echo '</div>';

        echo '<div class="aiseogeo-grid two">';
        echo '<div class="aiseogeo-mini-panel"><h3>Заголовок</h3><p><b>Было:</b> '.esc_html($change['old_title'] ?? '').'</p><p><b>Стало:</b> '.esc_html($change['new_title'] ?? '').'</p></div>';
        echo '<div class="aiseogeo-mini-panel"><h3>Excerpt / краткое описание</h3><p><b>Было:</b> '.esc_html(mb_substr((string)($change['old_excerpt'] ?? ''),0,260)).'</p><p><b>Стало:</b> '.esc_html(mb_substr((string)($change['new_excerpt'] ?? ''),0,260)).'</p></div>';
        echo '</div>';

        echo '<div class="aiseogeo-grid two">';
        echo '<div class="aiseogeo-mini-panel"><h3>Добавленные подзаголовки</h3>'; aiseogeo_stage2_list($change['added_headings'] ?? array()); echo '</div>';
        echo '<div class="aiseogeo-mini-panel"><h3>Удалённые подзаголовки</h3>'; aiseogeo_stage2_list($change['removed_headings'] ?? array()); echo '</div>';
        echo '</div>';

        echo '<div class="aiseogeo-mini-panel"><h3>Контроль важных блоков</h3><div class="aiseogeo-protection-grid">';
        foreach (($change['blocks'] ?? array()) as $block) {
            $status = $block['status'] ?? 'missing';
            $class = $status === 'removed' ? 'bad' : (($block['before'] || $block['after']) ? 'ok' : 'muted');
            $text = $status === 'removed' ? 'Был, но не найден после' : (($block['before'] && $block['after']) ? 'Сохранён' : ((!empty($block['after'])) ? 'Добавлен' : 'Не найден'));
            echo '<div class="aiseogeo-protection-item '.esc_attr($class).'"><strong>'.esc_html($block['label'] ?? '').'</strong><span>'.esc_html($text).'</span></div>';
        }
        echo '</div></div>';

        if (!empty($change['removed_links']) || !empty($change['removed_shortcodes'])) {
            echo '<div class="notice notice-warning inline"><p><strong>Проверь перед публикацией:</strong> в новой версии могли исчезнуть ссылки или шорткоды.</p></div>';
            echo '<div class="aiseogeo-grid two"><div class="aiseogeo-mini-panel"><h3>Удалённые ссылки</h3>'; aiseogeo_stage2_list($change['removed_links'] ?? array()); echo '</div><div class="aiseogeo-mini-panel"><h3>Удалённые шорткоды</h3>'; aiseogeo_stage2_list($change['removed_shortcodes'] ?? array()); echo '</div></div>';
        }
        echo '</div>';
    }
}

if (!function_exists('aiseogeo_compare_forecast_cards')) {
    function aiseogeo_compare_forecast_cards($rows) {
        if (empty($rows) || !is_array($rows)) { return; }
        $is_forecast = !empty($rows[0]['is_forecast']);
        echo '<div class="aiseogeo-card aiseogeo-forecast-card"><div class="aiseogeo-section-head"><div><h2>Конверсия в выдаче: до и после</h2><p>' . esc_html($is_forecast ? 'Показатели «После» пока прогнозные. После повторного анализа новой версии они будут пересчитаны по фактическому AI-аудиту.' : 'Показатели рассчитаны по повторному анализу улучшенной версии.') . '</p></div><span class="aiseogeo-badge">' . esc_html($is_forecast ? 'прогноз' : 'после анализа') . '</span></div><div class="aiseogeo-forecast-grid">';
        foreach ($rows as $row) {
            $before = isset($row['before']) ? (int)$row['before'] : 0;
            $after = isset($row['after']) ? (int)$row['after'] : 0;
            $delta = isset($row['delta']) ? (int)$row['delta'] : ($after - $before);
            echo '<div class="aiseogeo-forecast-item"><h3>' . esc_html($row['label'] ?? '') . '</h3><div class="aiseogeo-before-after"><div><span>До</span><strong>' . esc_html($before) . '</strong></div><div><span>После</span><strong>' . esc_html($after) . '</strong></div><div class="aiseogeo-delta"><span>Рост</span><strong>' . esc_html(($delta > 0 ? '+' : '') . $delta) . '</strong></div></div><div class="aiseogeo-meter"><i style="width:' . esc_attr(max(0, min(100, $after))) . '%"></i></div>';
            if (!empty($row['note'])) { echo '<p class="aiseogeo-note">' . esc_html($row['note']) . '</p>'; }
            echo '</div>';
        }
        echo '</div></div>';
    }
}

?>
<div class="wrap aiseogeo-wrap">
  <h1>Результат переписывания</h1>
  <?php if (!$rewrite): ?><div class="notice notice-error"><p>Версия не найдена.</p></div><?php return; endif; ?>
  <?php if (!empty($_GET['aiseogeo_error'])): ?><div class="notice notice-error"><p><?php echo esc_html(wp_unslash($_GET['aiseogeo_error'])); ?></p></div><?php endif; ?>
  <?php if (!empty($_GET['draft_created'])): ?><div class="notice notice-success"><p>Черновик улучшенной версии создан. <a href="<?php echo esc_url(get_edit_post_link(absint($_GET['draft_created']))); ?>">Редактировать черновик</a></p></div><?php endif; ?>
  <?php if (!empty($_GET['reaudited'])): ?><div class="notice notice-success"><p>Повторный анализ новой версии выполнен.</p></div><?php endif; ?>
  <?php if (!empty($_GET['applied'])): ?><div class="notice notice-success"><p>Выбранные изменения применены к оригинальной записи. Backup #<?php echo absint($_GET['backup_id'] ?? 0); ?> создан.</p></div><?php endif; ?>
  <div class="aiseogeo-card">
    <h2><?php echo esc_html($rewrite->new_title ?: $rewrite->original_title); ?></h2>
    <p><strong>Режим:</strong> <?php echo esc_html($rewrite->rewrite_mode); ?> · <strong>Статус:</strong> <?php echo esc_html($rewrite->rewrite_status); ?> · <strong>Модель:</strong> <?php echo esc_html($rewrite->model); ?></p>
    <?php if ($rewrite->error_message): ?><div class="notice notice-error inline"><p><?php echo esc_html($rewrite->error_message); ?></p></div><?php endif; ?>
  </div>
  <div class="aiseogeo-grid two">
    <div class="aiseogeo-card"><h2>Новые SEO-поля</h2><p><strong>Title:</strong> <?php echo esc_html($rewrite->new_meta_title); ?></p><p><strong>Description:</strong> <?php echo esc_html($rewrite->new_meta_description); ?></p><p><strong>Excerpt:</strong> <?php echo esc_html($rewrite->new_excerpt); ?></p></div>
    <div class="aiseogeo-card"><h2>Предупреждения</h2><?php aiseogeo_stage2_list(json_decode($rewrite->warnings_json,true) ?: array()); ?></div>
  </div>
  <?php if (method_exists($comparison, 'get_content_change_summary')) { aiseogeo_render_change_intelligence($comparison->get_content_change_summary($rewrite->id)); } ?>
  <div class="aiseogeo-card"><h2>Список изменений от AI</h2><?php aiseogeo_stage2_list(json_decode($rewrite->change_summary_json,true) ?: array()); ?></div>
  <div class="aiseogeo-card"><h2>FAQ</h2><pre><?php echo esc_html(wp_json_encode(json_decode($rewrite->new_faq_json,true) ?: array(), JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)); ?></pre></div>
  <div class="aiseogeo-card"><h2>Новый контент</h2><div style="max-height:520px;overflow:auto;border:1px solid #dcdcde;padding:16px;background:#fff"><?php echo wp_kses_post($rewrite->new_content_longtext); ?></div></div>
  <?php $scores=$comparison->get_score_comparison($rewrite->id); $is_forecast=!empty($scores) && !empty($scores[0]['is_forecast']); if($scores): ?>
  <div class="aiseogeo-card"><h2>Сравнение оценок</h2><table class="widefat striped"><thead><tr><th>Показатель</th><th>Было</th><th>Стало<?php echo $is_forecast ? ' (прогноз)' : ''; ?></th><th>Изменение</th></tr></thead><tbody><?php foreach($scores as $s): ?><tr><td><?php echo esc_html($s['label']); ?></td><td><?php echo $s['before']===null?'—':esc_html($s['before']); ?></td><td><?php echo $s['after']===null?'—':esc_html($s['after']); ?></td><td><?php echo $s['delta']===null?'—':esc_html(($s['delta']>0?'+':'').$s['delta']); ?></td></tr><?php endforeach; ?></tbody></table><?php if($is_forecast): ?><p class="description">Показатели «Стало» рассчитаны как прогноз. Для фактических оценок нажмите «Повторно проанализировать новую версию».</p><?php endif; ?></div>
  <?php endif; ?>
  <?php if (method_exists($comparison, 'get_search_forecast') && function_exists('aiseogeo_compare_forecast_cards')) { aiseogeo_compare_forecast_cards($comparison->get_search_forecast($rewrite->id)); } ?>
  <div class="aiseogeo-card">
    <h2>Действия с AI-версией</h2>
    <?php if (!empty($license_gate) && (!$license_gate->can('draft_create') || !$license_gate->can('re_audit') || !$license_gate->can('apply'))): ?>
      <p class="description">Часть действий ниже относится к платной версии. Бесплатно можно просматривать отчёт, сравнение и уже созданные результаты.</p>
    <?php endif; ?>
    <p>
      <?php if ($rewrite->rewrite_status === 'done' || $rewrite->rewrite_status === 're_audited'): ?>
        <?php if (empty($license_gate) || $license_gate->can('draft_create')): ?>
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;margin-right:8px"><input type="hidden" name="action" value="aiseogeo_create_rewrite_draft"><input type="hidden" name="rewrite_id" value="<?php echo absint($rewrite->id); ?>"><?php wp_nonce_field('aiseogeo_create_rewrite_draft_' . $rewrite->id); ?><button class="button button-primary">Создать черновик улучшенной версии</button></form>
        <?php else: ?><a class="button button-primary disabled" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-license')); ?>">Черновик — нужна лицензия</a><?php endif; ?>
        <?php if (empty($license_gate) || $license_gate->can('re_audit')): ?>
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;margin-right:8px"><input type="hidden" name="action" value="aiseogeo_reaudit_rewrite"><input type="hidden" name="rewrite_id" value="<?php echo absint($rewrite->id); ?>"><?php wp_nonce_field('aiseogeo_reaudit_rewrite_' . $rewrite->id); ?><button class="button">Повторно проанализировать новую версию</button></form>
        <?php else: ?><a class="button disabled" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-license')); ?>">Повторный анализ — нужна лицензия</a><?php endif; ?>
      <?php endif; ?>
      <?php if (empty($license_gate) || $license_gate->can('apply')): ?>
        <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-apply-confirm&rewrite_id=' . absint($rewrite->id))); ?>">Применить к оригинальной записи</a>
      <?php else: ?><a class="button button-primary disabled" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-license')); ?>">Применение — нужна лицензия</a><?php endif; ?>
      <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-version-compare&rewrite_id=' . absint($rewrite->id))); ?>">Открыть сравнение</a>
      <a class="button" href="<?php echo esc_url(get_edit_post_link($rewrite->post_id)); ?>">Вернуться к записи</a>
      <?php if ($rewrite->created_draft_post_id): ?><a class="button" href="<?php echo esc_url(get_edit_post_link($rewrite->created_draft_post_id)); ?>">Редактировать созданный черновик</a><?php endif; ?>
    </p>
  </div>
</div>

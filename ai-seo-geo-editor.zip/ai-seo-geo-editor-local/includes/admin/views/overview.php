<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap aiseogeo-wrap">
  <h1>AI SEO/GEO Редактор статей</h1>
  <p class="description">Этап 1: анализ записей WordPress под SEO, GEO/AI-поиск и EEAT через OpenRouter.</p>
  <div class="aiseogeo-grid">
    <div class="aiseogeo-card"><h2>Проверок всего</h2><div class="aiseogeo-big"><?php echo esc_html($stats['total']); ?></div></div>
    <div class="aiseogeo-card"><h2>Успешно</h2><div class="aiseogeo-big"><?php echo esc_html($stats['done']); ?></div></div>
    <div class="aiseogeo-card"><h2>Слабых статей</h2><div class="aiseogeo-big"><?php echo esc_html($stats['weak']); ?></div></div>
    <div class="aiseogeo-card"><h2>Ошибок API</h2><div class="aiseogeo-big"><?php echo esc_html($stats['errors']); ?></div></div>
  </div>
  <div class="aiseogeo-card">
    <h2>Быстрые действия</h2>
    <p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-audits')); ?>">Перейти к анализу записей</a> <span class="description">Выберите запись и откройте экран осознанного запуска анализа.</span></p>
    <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-history')); ?>">Открыть историю</a> <span class="description">Посмотреть все сохранённые проверки.</span></p>
    <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-openrouter')); ?>">Проверить OpenRouter</a> <span class="description">Настроить API-ключ, модель и тест подключения.</span></p>
    <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=aiseogeo-rules')); ?>">Открыть правила анализа</a> <span class="description">Понять, по каким критериям проверяются статьи.</span></p>
  </div>
</div>

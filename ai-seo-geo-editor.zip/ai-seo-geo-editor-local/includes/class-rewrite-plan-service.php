<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Rewrite_Plan_Service {
    private $settings; private $logger; private $audit_service; private $reader; private $client; private $protector;
    public function __construct($settings, $logger, $audit_service) {
        $this->settings=$settings; $this->logger=$logger; $this->audit_service=$audit_service;
        $this->reader = new AISEOGEO_Post_Content_Reader();
        $this->client = new AISEOGEO_OpenRouter_Client($settings, $logger);
        $this->protector = new AISEOGEO_Content_Protector();
    }
    public function rewrites_table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_rewrites'; }
    public static function modes() {
        return array(
            'soft_improve'=>'Мягкое улучшение', 'seo_boost'=>'SEO-усиление', 'geo_boost'=>'GEO-усиление',
            'full_refresh'=>'Полное обновление', 'seo_geo_boost'=>'SEO + GEO усиление', 'meta_only'=>'Только мета-данные', 'problem_blocks_only'=>'Только проблемные блоки'
        );
    }
    public function create_plan($post_id, $audit_id, $rewrite_mode) {
        if (!current_user_can('aiseogeo_run_rewrite') && !doing_action('aiseogeo_process_bulk_job_item')) { return new WP_Error('forbidden', 'Недостаточно прав.'); }
        $modes = self::modes();
        if (!isset($modes[$rewrite_mode])) { return new WP_Error('bad_mode', 'Неизвестный режим переписывания.'); }
        $post_data = $this->reader->read($post_id);
        if (is_wp_error($post_data)) { return $post_data; }
        $audit = $this->audit_service->get_audit($audit_id);
        if (!$audit || (int)$audit->post_id !== (int)$post_id || $audit->status !== 'done') { return new WP_Error('audit_not_found', 'Успешный анализ для этой записи не найден.'); }
        $protected = $this->protector->extract_protected_items($post_data['content']);
        $payload = array('post'=>$post_data,'audit'=>$this->audit_to_array($audit),'rewrite_mode'=>$rewrite_mode,'rewrite_mode_label'=>$modes[$rewrite_mode],'protected_items'=>$protected);
        $messages = array(
            array('role'=>'system','content'=>AISEOGEO_Prompt_Loader::rewrite_plan_system()),
            array('role'=>'user','content'=>AISEOGEO_Prompt_Loader::rewrite_plan_user($payload)),
        );
        $plan_tokens = $this->plan_max_tokens($post_data['content']);
        $this->logger->log('info','rewrite_plan','[План] Этап 5: Старт построения структурного скелета.',array('режим'=>$rewrite_mode,'модель'=>$this->settings->get('model','—'),'лимит_токенов'=>$plan_tokens,'защищённых_блоков'=>count($protected)),$post_id);
        $result = $this->client->chat($messages, $plan_tokens);
        $now = current_time('mysql');
        $base = array(
            'post_id'=>absint($post_id),'audit_id'=>absint($audit_id),'rewrite_mode'=>$rewrite_mode,'rewrite_status'=>'draft',
            'protected_items_json'=>wp_json_encode($protected, JSON_UNESCAPED_UNICODE),
            'original_title'=>$post_data['title'],'original_excerpt'=>$post_data['excerpt'],'original_content_longtext'=>$post_data['content'],
            'created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now,
        );
        global $wpdb;
        if (is_wp_error($result)) {
            $base['rewrite_status']='plan_failed'; $base['error_message']=$result->get_error_message();
            $wpdb->insert($this->rewrites_table(), $base);
            $this->logger->log('error','rewrite_plan','[План] ОШИБКА запроса к AI: '.$result->get_error_message(),array(),$post_id);
            return $result;
        }
        $plan = $this->parse_json($result['content']);
        if (is_wp_error($plan)) {
            $this->logger->log('info','rewrite_plan','[План] JSON некорректен, восстанавливаю структуру.',array('причина'=>$plan->get_error_message()),$post_id);
            $repaired = $this->repair_json_response($result['content'], 'plan');
            if (!is_wp_error($repaired)) {
                $plan = $repaired;
                $result['content'] .= "\n\n--- AISEOGEO_JSON_REPAIR_APPLIED ---";
            }
        }
        if (is_wp_error($plan)) {
            $base['rewrite_status']='plan_failed'; $base['raw_plan_response']=$result['content']; $base['model']=$result['model']; $base['error_message']=$plan->get_error_message();
            $wpdb->insert($this->rewrites_table(), $base);
            $this->logger->log('error','rewrite_plan','[План] ОШИБКА разбора JSON: '.$plan->get_error_message(),array('raw'=>mb_substr((string)$result['content'],0,1000)),$post_id);
            return $plan;
        }
        $plan = $this->normalize_plan($plan, $rewrite_mode);
        $base['rewrite_status']='plan_created';
        $base['improvement_plan_json']=wp_json_encode($plan, JSON_UNESCAPED_UNICODE);
        $base['raw_plan_response']=$this->settings->get('save_raw_response','1') === '1' ? $result['content'] : '';
        $base['model']=$result['model'];
        $wpdb->insert($this->rewrites_table(), $base);
        $id = $wpdb->insert_id;
        $this->logger->log('info','rewrite_plan','[План] Этап 5: Структурный скелет с черновым контентом готов.',array(
            'rewrite_id'=>$id,
            'hero_promise'=>!empty($plan['hero_promise_draft']) ? 'есть' : 'нет',
            'h2_с_tldr'=>is_array($plan['h2_structure_draft'] ?? null) ? count($plan['h2_structure_draft']) : 0,
            'faq_черновик'=>is_array($plan['faq_draft'] ?? null) ? count($plan['faq_draft']) : 0,
            'источники_черновик'=>is_array($plan['sources_draft'] ?? null) ? count($plan['sources_draft']) : 0,
            'сравнит_таблица'=>!empty($plan['comparison_table_draft']) ? 'есть' : 'нет',
        ),$post_id);
        return $this->get_plan($id);
    }

    /** Лимит токенов для плана — план теперь несёт черновой контент (TL;DR, FAQ, источники), нужно много места. */
    private function plan_max_tokens($content) {
        $len = mb_strlen(wp_strip_all_tags((string)$content));
        $base = intval($this->settings->get('max_tokens', '6000'));
        if ($len > 12000) { return max(16000, $base); }
        if ($len > 6000)  { return max(13000, $base); }
        return max(10000, $base);
    }
    public function get_plan($rewrite_id) { global $wpdb; return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->rewrites_table()} WHERE id=%d", absint($rewrite_id))); }
    public function parse_json($content) {
        return AISEOGEO_JSON_Helper::parse($content);
    }
    private function repair_json_response($raw_content, $type = 'plan') {
        $schema = 'Верни JSON плана улучшения с ключами: strategy_summary, rewrite_mode, what_to_keep, what_to_improve, what_to_add, what_not_to_touch, hero_promise_draft, h2_structure_draft, faq_draft, comparison_table_draft, sources_draft, heading_changes, anti_ai_fixes, meta_changes, cta_plan, internal_links_plan, schema_plan, protected_items_policy, expected_improvement. Сохрани весь черновой контент (готовые TL;DR, FAQ-ответы, источники) из исходного ответа.';
        $messages = array(
            array('role'=>'system','content'=>'Ты исправляешь технически некорректный ответ AI. Верни только валидный JSON без markdown, комментариев и пояснений. Не добавляй новые факты. Сохрани весь смысл и черновой контент исходного ответа.'),
            array('role'=>'user','content'=>$schema . "

Некорректный ответ:
" . mb_substr((string)$raw_content, 0, 90000)),
        );
        $repair = $this->client->chat($messages, $this->plan_max_tokens($raw_content));
        if (is_wp_error($repair)) { return $repair; }
        return $this->parse_json($repair['content']);
    }
    private function normalize_plan($plan, $rewrite_mode) {
        if (isset($plan['plan']) && is_array($plan['plan'])) { $plan = array_merge($plan, $plan['plan']); }
        $defaults = array(
            'strategy_summary'=>'', 'rewrite_mode'=>$rewrite_mode,
            'what_to_keep'=>array(), 'what_to_improve'=>array(), 'what_to_add'=>array(), 'what_not_to_touch'=>array(),
            // Черновой контент (Этап 5 методологии)
            'hero_promise_draft'=>array(), 'h2_structure_draft'=>array(), 'faq_draft'=>array(),
            'comparison_table_draft'=>array(), 'sources_draft'=>array(),
            'heading_changes'=>array(), 'anti_ai_fixes'=>array(), 'meta_changes'=>array(),
            'cta_plan'=>array(), 'internal_links_plan'=>array(), 'schema_plan'=>array(),
            'protected_items_policy'=>array(), 'expected_improvement'=>array(),
            // Совместимость со старой схемой
            'geo_blocks_to_add'=>array(), 'faq_needed'=>false, 'schema_needed'=>false, 'risks'=>array(),
        );
        $plan = wp_parse_args($plan, $defaults);
        foreach (array('what_to_keep','what_to_improve','what_to_add','what_not_to_touch','heading_changes','h2_structure_draft','faq_draft','sources_draft','internal_links_plan','geo_blocks_to_add','protected_items_policy','risks') as $key) {
            if (!is_array($plan[$key])) { $plan[$key] = array((string)$plan[$key]); }
        }
        foreach (array('hero_promise_draft','comparison_table_draft','anti_ai_fixes','meta_changes','cta_plan','schema_plan','expected_improvement') as $key) {
            if (!is_array($plan[$key])) { $plan[$key] = array('note'=>(string)$plan[$key]); }
        }
        $plan['rewrite_mode'] = $plan['rewrite_mode'] ?: $rewrite_mode;
        return $plan;
    }
    private function audit_to_array($audit) {
        return array(
            'id'=>(int)$audit->id,'overall_score'=>(int)$audit->overall_score,'seo_score'=>(int)$audit->seo_score,'geo_score'=>(int)$audit->geo_score,'eeat_score'=>(int)$audit->eeat_score,
            'summary'=>$audit->summary,'problems'=>json_decode($audit->problems_json,true),'recommendations'=>json_decode($audit->recommendations_json,true),'suggested'=>json_decode($audit->suggested_json,true)
        );
    }

    public function create_plan_bypass($post_id, $audit_id, $rewrite_mode) {
        $modes = self::modes();
        if (!isset($modes[$rewrite_mode])) { return new WP_Error('bad_mode', 'Неизвестный режим переписывания.'); }
        $post_data = $this->reader->read($post_id);
        if (is_wp_error($post_data)) { return $post_data; }
        $audit = $this->audit_service->get_audit($audit_id);
        if (!$audit || (int)$audit->post_id !== (int)$post_id || $audit->status !== 'done') { return new WP_Error('audit_not_found', 'Успешный анализ для этой записи не найден.'); }
        $protected = $this->protector->extract_protected_items($post_data['content']);
        $payload = array('post'=>$post_data,'audit'=>$this->audit_to_array($audit),'rewrite_mode'=>$rewrite_mode,'rewrite_mode_label'=>$modes[$rewrite_mode],'protected_items'=>$protected);
        $messages = array(
            array('role'=>'system','content'=>AISEOGEO_Prompt_Loader::rewrite_plan_system()),
            array('role'=>'user','content'=>AISEOGEO_Prompt_Loader::rewrite_plan_user($payload)),
        );
        $result = $this->client->chat($messages, $this->plan_max_tokens($post_data['content']));
        $now = current_time('mysql');
        $base = array(
            'post_id'=>absint($post_id),'audit_id'=>absint($audit_id),'rewrite_mode'=>$rewrite_mode,'rewrite_status'=>'draft',
            'protected_items_json'=>wp_json_encode($protected, JSON_UNESCAPED_UNICODE),
            'original_title'=>$post_data['title'],'original_excerpt'=>$post_data['excerpt'],'original_content_longtext'=>$post_data['content'],
            'created_by'=>0,'created_at'=>$now,'updated_at'=>$now,
        );
        global $wpdb;
        if (is_wp_error($result)) {
            $base['rewrite_status']='plan_failed'; $base['error_message']=$result->get_error_message();
            $wpdb->insert($this->rewrites_table(), $base);
            return $result;
        }
        $plan = $this->parse_json($result['content']);
        if (is_wp_error($plan)) {
            $repaired = $this->repair_json_response($result['content'], 'plan');
            if (!is_wp_error($repaired)) { $plan = $repaired; }
        }
        if (is_wp_error($plan)) {
            $base['rewrite_status']='plan_failed'; $base['raw_plan_response']=$result['content']; $base['model']=$result['model']; $base['error_message']=$plan->get_error_message();
            $wpdb->insert($this->rewrites_table(), $base);
            return $plan;
        }
        $plan = $this->normalize_plan($plan, $rewrite_mode);
        $base['rewrite_status']='plan_created';
        $base['improvement_plan_json']=wp_json_encode($plan, JSON_UNESCAPED_UNICODE);
        $base['raw_plan_response']=$this->settings->get('save_raw_response','1') === '1' ? $result['content'] : '';
        $base['model']=$result['model'];
        $wpdb->insert($this->rewrites_table(), $base);
        $id = $wpdb->insert_id;
        return $this->get_rewrite($id);
    }
    private function get_rewrite($id) { global $wpdb; return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->rewrites_table()} WHERE id=%d", absint($id))); }
}

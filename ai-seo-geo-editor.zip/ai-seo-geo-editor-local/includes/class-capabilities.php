<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Capabilities {
    public static function caps() {
        return array('aiseogeo_manage_settings','aiseogeo_run_audit','aiseogeo_run_rewrite','aiseogeo_apply_rewrite','aiseogeo_rollback','aiseogeo_bulk_process','aiseogeo_view_reports','aiseogeo_view_versions','aiseogeo_manage_license','aiseogeo_delete_versions');
    }
    public static function add_caps() {
        $role = get_role('administrator');
        if ($role) { foreach (self::caps() as $cap) { $role->add_cap($cap); } }
        $editor = get_role('editor');
        if ($editor) {
            $editor->add_cap('aiseogeo_run_audit');
            $editor->add_cap('aiseogeo_run_rewrite');
            $editor->add_cap('aiseogeo_view_reports');
            $editor->add_cap('aiseogeo_view_versions');
            $editor->add_cap('aiseogeo_apply_rewrite');
        }
    }
    public static function remove_caps() { /* keep caps to avoid permission loss on temporary deactivation */ }
}

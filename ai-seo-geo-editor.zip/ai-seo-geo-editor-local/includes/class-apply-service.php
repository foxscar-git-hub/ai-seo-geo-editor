<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Apply_Service {
    private $rewrite_service; private $backup_service; private $log_service; private $logger;
    public function __construct($rewrite_service, $logger = null) {
        $this->rewrite_service = $rewrite_service;
        $this->backup_service = new AISEOGEO_Backup_Service();
        $this->log_service = new AISEOGEO_Apply_Log_Service();
        $this->logger = $logger;
    }
    public static function allowed_fields() {
        return array('title'=>'Заголовок','content'=>'Основной текст','excerpt'=>'Краткое описание','meta_title'=>'SEO title','meta_description'=>'Meta description','faq'=>'FAQ','schema'=>'Schema');
    }
    public function apply($rewrite_id, $fields) {
        if (!current_user_can('aiseogeo_apply_rewrite')) { return new WP_Error('forbidden', 'Недостаточно прав для применения изменений.'); }
        $rewrite = $this->rewrite_service->get_rewrite(absint($rewrite_id));
        if (!$rewrite) { return new WP_Error('rewrite_not_found', 'AI-версия не найдена.'); }
        if (!in_array($rewrite->rewrite_status, array('done','re_audited','draft_created'), true)) { return new WP_Error('bad_status', 'Эту AI-версию пока нельзя применить к оригиналу.'); }
        $post = get_post((int)$rewrite->post_id);
        if (!$post || $post->post_type !== 'post') { return new WP_Error('post_not_found', 'Исходная запись не найдена.'); }
        $allowed = array_keys(self::allowed_fields());
        $fields = array_values(array_intersect($allowed, array_map('sanitize_key', (array)$fields)));
        if (!$fields) { return new WP_Error('no_fields', 'Не выбраны поля для применения.'); }
        $backup_id = $this->backup_service->create_backup($post->ID, $rewrite->id, 'before_apply');
        if (is_wp_error($backup_id)) { return $backup_id; }
        $update = array('ID' => $post->ID);
        if (in_array('title', $fields, true) && trim((string)$rewrite->new_title) !== '') { $update['post_title'] = wp_strip_all_tags($rewrite->new_title); }
        if (in_array('content', $fields, true) && trim((string)$rewrite->new_content_longtext) !== '') { $update['post_content'] = wp_kses_post($rewrite->new_content_longtext); }
        if (in_array('excerpt', $fields, true)) { $update['post_excerpt'] = wp_kses_post($rewrite->new_excerpt); }
        $result = count($update) > 1 ? wp_update_post($update, true) : $post->ID;
        if (is_wp_error($result)) { $this->log_service->add($post->ID, $rewrite->id, $backup_id, $fields, 'failed', $result->get_error_message()); return $result; }
        if (in_array('meta_title', $fields, true) && trim((string)$rewrite->new_meta_title) !== '') {
            update_post_meta($post->ID, '_aiseogeo_meta_title', sanitize_text_field($rewrite->new_meta_title));
            $this->write_common_seo_meta($post->ID, 'title', $rewrite->new_meta_title);
        }
        if (in_array('meta_description', $fields, true)) {
            $meta_description = trim((string)$rewrite->new_meta_description);
            if ($meta_description === '') { $meta_description = trim((string)$rewrite->new_excerpt); }
            if ($meta_description !== '') {
                update_post_meta($post->ID, '_aiseogeo_meta_description', sanitize_textarea_field($meta_description));
                $this->write_common_seo_meta($post->ID, 'description', $meta_description);
            }
        }
        if (in_array('faq', $fields, true)) { update_post_meta($post->ID, '_aiseogeo_faq_json', (string)$rewrite->new_faq_json); }
        if (in_array('schema', $fields, true)) { update_post_meta($post->ID, '_aiseogeo_schema_json', (string)$rewrite->new_schema_json); }
        update_post_meta($post->ID, '_aiseogeo_last_applied_rewrite_id', (int)$rewrite->id);
        update_post_meta($post->ID, '_aiseogeo_last_backup_id', (int)$backup_id);

        // Mark rewrite as applied for learning tracker
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'aiseogeo_rewrites',
            array('apply_status' => 'applied', 'updated_at' => current_time('mysql')),
            array('id' => $rewrite->id)
        );
        // Fire hook so Learning Tracker saves baseline metrics
        do_action('aiseogeo_rewrite_applied', $post->ID);

        $log_id = $this->log_service->add($post->ID, $rewrite->id, $backup_id, $fields, 'done', '');
        if ($this->logger) { $this->logger->log('info', 'apply', 'AI-версия применена к оригинальной записи.', array('rewrite_id'=>$rewrite->id,'backup_id'=>$backup_id,'fields'=>$fields), $post->ID); }
        return array('post_id'=>$post->ID, 'backup_id'=>$backup_id, 'apply_log_id'=>$log_id, 'fields'=>$fields);
    }
    private function write_common_seo_meta($post_id, $type, $value) {
        $value = $type === 'title' ? sanitize_text_field($value) : sanitize_textarea_field($value);
        if ($type === 'title') {
            update_post_meta($post_id, '_yoast_wpseo_title', $value);
            update_post_meta($post_id, 'rank_math_title', $value);
            update_post_meta($post_id, '_aioseo_title', $value);
        } else {
            update_post_meta($post_id, '_yoast_wpseo_metadesc', $value);
            update_post_meta($post_id, 'rank_math_description', $value);
            update_post_meta($post_id, '_aioseo_description', $value);
        }
    }
}

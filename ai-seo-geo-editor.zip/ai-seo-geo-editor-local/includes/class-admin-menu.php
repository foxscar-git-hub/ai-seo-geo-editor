<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Admin_Menu {
    private $audit_service; private $settings; private $logger; private $rewrite_service;
    public function __construct($audit_service, $settings, $logger, $rewrite_service = null) { $this->audit_service=$audit_service; $this->settings=$settings; $this->logger=$logger; $this->rewrite_service=$rewrite_service; }
    public function init() {
        add_action('admin_menu', array($this,'menu'));
        add_action('admin_post_aiseogeo_save_settings', array($this,'save_settings'));
        add_action('admin_post_aiseogeo_save_learning_settings', array($this,'save_learning_settings'));
        add_action('admin_post_aiseogeo_run_audit', array($this,'run_audit'));
        add_action('admin_post_aiseogeo_create_rewrite_plan', array($this,'create_rewrite_plan'));
        add_action('admin_post_aiseogeo_run_rewrite', array($this,'run_rewrite'));
        add_action('admin_post_aiseogeo_create_rewrite_draft', array($this,'create_rewrite_draft'));
        add_action('admin_post_aiseogeo_reaudit_rewrite', array($this,'reaudit_rewrite'));
        add_action('admin_post_aiseogeo_delete_rewrite', array($this,'delete_rewrite'));
        add_action('admin_post_aiseogeo_delete_version', array($this,'delete_version'));
        add_action('admin_post_aiseogeo_apply_rewrite', array($this,'apply_rewrite'));
        add_action('admin_post_aiseogeo_rollback_backup', array($this,'rollback_backup'));
        add_action('admin_post_aiseogeo_create_bulk_job', array($this,'create_bulk_job'));
        add_action('admin_post_aiseogeo_pause_bulk_job', array($this,'pause_bulk_job'));
        add_action('admin_post_aiseogeo_resume_bulk_job', array($this,'resume_bulk_job'));
        add_action('admin_post_aiseogeo_cancel_bulk_job', array($this,'cancel_bulk_job'));
        add_action('admin_post_aiseogeo_save_license', array($this,'save_license'));
        add_action('admin_post_aiseogeo_check_license', array($this,'check_license'));
    }
    public function menu() {
        add_menu_page('AI SEO/GEO Редактор','AI SEO/GEO Редактор','aiseogeo_view_reports','aiseogeo-overview',array($this,'overview'),'dashicons-chart-area',58);
        add_submenu_page('aiseogeo-overview','Обзор','Обзор','aiseogeo_view_reports','aiseogeo-overview',array($this,'overview'));
        add_submenu_page('aiseogeo-overview','Анализ записей','Анализ записей','aiseogeo_run_audit','aiseogeo-audits',array($this,'audits'));
        add_submenu_page('aiseogeo-overview','Переписывание','Переписывание','aiseogeo_run_rewrite','aiseogeo-rewrite',array($this,'rewrite'));
        add_submenu_page('aiseogeo-overview','История версий','История версий','aiseogeo_view_versions','aiseogeo-versions',array($this,'versions'));
        add_submenu_page('aiseogeo-overview','Массовая обработка','Массовая обработка','aiseogeo_bulk_process','aiseogeo-bulk',array($this,'bulk'));
        add_submenu_page('aiseogeo-overview','Отчёт по сайту','Отчёт по сайту','aiseogeo_view_reports','aiseogeo-site-report',array($this,'site_report'));
        add_submenu_page('aiseogeo-overview','История применений','История применений','aiseogeo_view_versions','aiseogeo-apply-logs',array($this,'apply_logs'));
        add_submenu_page('aiseogeo-overview','Лицензия','Лицензия','aiseogeo_manage_license','aiseogeo-license',array($this,'license'));
        add_submenu_page(null,'Анализ записи','Анализ записи','aiseogeo_run_audit','aiseogeo-audit-post',array($this,'audit_post'));
        add_submenu_page(null,'Отчёт анализа','Отчёт анализа','aiseogeo_view_reports','aiseogeo-audit-report',array($this,'audit_report'));
        add_submenu_page(null,'Создание улучшенной версии','Создание улучшенной версии','aiseogeo_run_rewrite','aiseogeo-rewrite-create',array($this,'rewrite_create'));
        add_submenu_page(null,'План улучшения','План улучшения','aiseogeo_run_rewrite','aiseogeo-rewrite-plan',array($this,'rewrite_plan'));
        add_submenu_page(null,'Результат переписывания','Результат переписывания','aiseogeo_run_rewrite','aiseogeo-rewrite-result',array($this,'rewrite_result'));
        add_submenu_page(null,'Сравнение версии','Сравнение версии','aiseogeo_view_versions','aiseogeo-version-compare',array($this,'version_compare'));
        add_submenu_page(null,'Подтверждение применения','Подтверждение применения','aiseogeo_apply_rewrite','aiseogeo-apply-confirm',array($this,'apply_confirm'));
        add_submenu_page(null,'Откат изменений','Откат изменений','aiseogeo_rollback','aiseogeo-rollback',array($this,'rollback'));
        add_submenu_page(null,'Массовая задача','Массовая задача','aiseogeo_bulk_process','aiseogeo-bulk-job',array($this,'bulk_job'));
        add_submenu_page('aiseogeo-overview','История анализов','История анализов','aiseogeo_view_reports','aiseogeo-history',array($this,'history'));
        add_submenu_page('aiseogeo-overview','Правила анализа','Правила анализа','aiseogeo_view_reports','aiseogeo-rules',array($this,'rules'));
        add_submenu_page('aiseogeo-overview','OpenRouter','OpenRouter','aiseogeo_manage_settings','aiseogeo-openrouter',array($this,'openrouter'));
        add_submenu_page('aiseogeo-overview','Автообучение','Автообучение','aiseogeo_manage_settings','aiseogeo-learning',array($this,'learning'));
        add_submenu_page('aiseogeo-overview','Диагностика','Диагностика','aiseogeo_manage_settings','aiseogeo-diagnostics',array($this,'diagnostics'));
    }

    private function license_gate() { return new AISEOGEO_License_Gate($this->settings, $this->logger); }
    private function redirect_license_error($feature, $fallback_url) {
        $gate = $this->license_gate();
        $check = $gate->require_feature($feature);
        if (is_wp_error($check)) {
            wp_safe_redirect(add_query_arg('aiseogeo_error', rawurlencode($check->get_error_message()), $fallback_url));
            exit;
        }
        return $gate;
    }

    private function view($file, $vars=array()) { extract($vars); include AISEOGEO_DIR . 'includes/admin/views/' . $file . '.php'; }
    public function overview() { $this->view('overview', array('stats'=>$this->audit_service->stats(), 'settings'=>$this->settings, 'license_gate'=>$this->license_gate())); }
    public function audits() { $this->view('audits', array('audit_service'=>$this->audit_service)); }
    public function audit_post() { $post_id = isset($_GET['post_id']) ? absint($_GET['post_id']) : 0; $post = get_post($post_id); $latest = $post ? $this->audit_service->get_latest_audit($post_id) : null; $audits = $post ? $this->audit_service->get_post_audits($post_id,10) : array(); $this->view('audit-post', compact('post','latest','audits')); }
    public function audit_report() { $audit_id = isset($_GET['audit_id']) ? absint($_GET['audit_id']) : 0; $audit = $this->audit_service->get_audit($audit_id); $this->view('audit-report', compact('audit')); }
    public function history() { $this->view('history', array('items'=>$this->audit_service->history(100))); }
    public function rules() { $this->view('rules'); }
    public function openrouter() { $this->view('openrouter', array('settings'=>$this->settings)); }
    public function diagnostics() { global $wpdb; $tables=array($wpdb->prefix.'aiseogeo_audits',$wpdb->prefix.'aiseogeo_logs',$wpdb->prefix.'aiseogeo_settings',$wpdb->prefix.'aiseogeo_rewrites',$wpdb->prefix.'aiseogeo_versions',$wpdb->prefix.'aiseogeo_backups',$wpdb->prefix.'aiseogeo_jobs',$wpdb->prefix.'aiseogeo_job_items',$wpdb->prefix.'aiseogeo_apply_logs'); $exists=array(); foreach($tables as $t){$exists[$t]=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$t))===$t;} $this->view('diagnostics', array('settings'=>$this->settings,'logs'=>$this->logger->recent(80),'tables'=>$exists,'stats'=>$this->audit_service->stats())); }
    public function rewrite() { $this->view('rewrite', array('audit_service'=>$this->audit_service,'rewrite_service'=>$this->rewrite_service)); }
    public function versions() { $vs = new AISEOGEO_Version_Service(); $this->view('versions', array('items'=>$this->rewrite_service->history(100),'version_service'=>$vs)); }
    public function rewrite_create() { $post_id=isset($_GET['post_id'])?absint($_GET['post_id']):0; $audit_id=isset($_GET['audit_id'])?absint($_GET['audit_id']):0; $post=get_post($post_id); $audit=$this->audit_service->get_audit($audit_id); $this->view('rewrite-create', array('post'=>$post,'audit'=>$audit,'modes'=>AISEOGEO_Rewrite_Plan_Service::modes(),'license_gate'=>$this->license_gate())); }
    public function rewrite_plan() { $rewrite_id=isset($_GET['rewrite_id'])?absint($_GET['rewrite_id']):0; $rewrite=$this->rewrite_service->get_rewrite($rewrite_id); $license_gate=$this->license_gate(); $this->view('rewrite-plan', compact('rewrite','license_gate')); }
    public function rewrite_result() { $rewrite_id=isset($_GET['rewrite_id'])?absint($_GET['rewrite_id']):0; $rewrite=$this->rewrite_service->get_rewrite($rewrite_id); $comparison = new AISEOGEO_Comparison_Service($this->rewrite_service, $this->audit_service); $this->view('rewrite-result', array('rewrite'=>$rewrite,'comparison'=>$comparison,'license_gate'=>$this->license_gate())); }
    public function version_compare() { $rewrite_id=isset($_GET['rewrite_id'])?absint($_GET['rewrite_id']):0; $rewrite=$this->rewrite_service->get_rewrite($rewrite_id); $comparison = new AISEOGEO_Comparison_Service($this->rewrite_service, $this->audit_service); $this->view('version-compare', array('rewrite'=>$rewrite,'comparison'=>$comparison)); }

    public function apply_confirm() { $rewrite_id=isset($_GET['rewrite_id'])?absint($_GET['rewrite_id']):0; $rewrite=$this->rewrite_service->get_rewrite($rewrite_id); $this->view('apply-confirm', array('rewrite'=>$rewrite,'fields'=>AISEOGEO_Apply_Service::allowed_fields(),'license_gate'=>$this->license_gate())); }
    public function rollback() { $backup_service=new AISEOGEO_Backup_Service(); $backup_id=isset($_GET['backup_id'])?absint($_GET['backup_id']):0; $post_id=isset($_GET['post_id'])?absint($_GET['post_id']):0; $backup=$backup_id?$backup_service->get_backup($backup_id):null; $backups=$post_id?$backup_service->get_post_backups($post_id,50):array(); $this->view('rollback', compact('backup','backups','post_id')); }
    public function bulk() { $bulk=new AISEOGEO_Bulk_Job_Service($this->audit_service,$this->rewrite_service,$this->logger,$this->settings); $this->view('bulk', array('jobs'=>$bulk->get_jobs(30),'filters'=>AISEOGEO_Post_Filter_Service::filters(),'settings'=>$this->settings,'license_gate'=>$this->license_gate())); }
    public function bulk_job() { $bulk=new AISEOGEO_Bulk_Job_Service($this->audit_service,$this->rewrite_service,$this->logger,$this->settings); $job_id=isset($_GET['job_id'])?absint($_GET['job_id']):0; $job=$bulk->get_job($job_id); $items=$job?$bulk->get_job_items($job_id,300):array(); $this->view('bulk-job', compact('job','items')); }
    public function site_report() { $report_service=new AISEOGEO_Site_Report_Service($this->audit_service); $this->view('site-report', array('report'=>$report_service->report())); }
    public function apply_logs() { $logs=(new AISEOGEO_Apply_Log_Service())->history(100); $this->view('apply-logs', compact('logs')); }
    public function license() { $license = new AISEOGEO_License_Client($this->settings, $this->logger); $this->view('license', array('settings'=>$this->settings, 'license'=>$license, 'license_gate'=>$this->license_gate())); }

    public function learning() {
        if (!current_user_can('aiseogeo_manage_settings')) { wp_die('Недостаточно прав.'); }
        $plugin = AISEOGEO_Plugin::instance();
        $learning_service = $plugin->learning_service ?? null;
        $saved_notice = ''; $error_notice = '';

        if (!empty($_POST['aiseogeo_learning_action']) && check_admin_referer('aiseogeo_learning_settings')) {
            $action = sanitize_key($_POST['aiseogeo_learning_action']);
            if ($action === 'save_settings') {
                $this->settings->set('learning_enabled',          isset($_POST['learning_enabled']) ? '1' : '0');
                $this->settings->set('learning_min_days',         absint($_POST['learning_min_days'] ?? 14));
                $this->settings->set('learning_views_threshold',  absint($_POST['learning_views_threshold'] ?? 20));
                $this->settings->set('learning_min_samples',      absint($_POST['learning_min_samples'] ?? 3));
                $this->settings->set('learning_inject_audit',     isset($_POST['learning_inject_audit']) ? '1' : '0');
                $this->settings->set('learning_inject_rewrite',   isset($_POST['learning_inject_rewrite']) ? '1' : '0');
                $saved_notice = 'Настройки автообучения сохранены.';
                // Re-init cron if enabled
                if ($this->settings->get('learning_enabled', '0') === '1' && !wp_next_scheduled('aiseogeo_daily_evaluate')) {
                    wp_schedule_event(time() + 3600, 'daily', 'aiseogeo_daily_evaluate');
                }
            } elseif ($action === 'force_evaluate' && $learning_service) {
                $learning_service->force_evaluate_all();
                $saved_notice = 'Оценка запущена. Результаты появятся в таблице паттернов.';
            } elseif ($action === 'reset_patterns') {
                global $wpdb;
                $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}aiseogeo_learning");
                $wpdb->query("UPDATE {$wpdb->prefix}aiseogeo_rewrites SET learning_evaluated=0, learning_views_growth=NULL, learning_success=NULL, learning_note=NULL");
                $saved_notice = 'Паттерны сброшены. Обучение начнётся заново.';
            }
        }

        $stats = $learning_service ? $learning_service->stats() : array();
        $patterns = $learning_service ? $learning_service->get_all_patterns() : array();
        $insights_preview = ($learning_service && !empty($stats['patterns'])) ? $learning_service->get_insights_block() : '';
        $settings = $this->settings;

        $this->view('learning', compact('settings', 'saved_notice', 'error_notice', 'stats', 'patterns', 'insights_preview', 'learning_service'));
    }

    public function save_learning_settings() {
        if (!current_user_can('aiseogeo_manage_settings')) { wp_die('Недостаточно прав.'); }
        check_admin_referer('aiseogeo_save_learning_settings');
        $this->settings->set('learning_enabled', isset($_POST['learning_enabled']) ? '1' : '0');
        $this->settings->set('learning_min_days', absint($_POST['learning_min_days'] ?? 14));
        $this->settings->set('learning_views_threshold', absint($_POST['learning_views_threshold'] ?? 20));
        $this->settings->set('learning_min_samples', absint($_POST['learning_min_samples'] ?? 3));
        $this->settings->set('learning_inject_audit', isset($_POST['learning_inject_audit']) ? '1' : '0');
        $this->settings->set('learning_inject_rewrite', isset($_POST['learning_inject_rewrite']) ? '1' : '0');
        wp_safe_redirect(admin_url('admin.php?page=aiseogeo-learning&saved=1'));
        exit;
    }

    public function save_settings() { if (!current_user_can('aiseogeo_manage_settings')) { wp_die('Недостаточно прав.'); } check_admin_referer('aiseogeo_save_settings'); $this->settings->save_from_request($_POST); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-openrouter&saved=1')); exit; }
    public function run_audit() { if (!current_user_can('aiseogeo_run_audit')) { wp_die('Недостаточно прав.'); } $post_id=isset($_POST['post_id'])?absint($_POST['post_id']):0; check_admin_referer('aiseogeo_run_audit_' . $post_id); $gate=$this->redirect_license_error('audit', admin_url('admin.php?page=aiseogeo-audit-post&post_id='.$post_id)); $result=$this->audit_service->run_audit($post_id); if (is_wp_error($result)) { wp_safe_redirect(admin_url('admin.php?page=aiseogeo-audit-post&post_id='.$post_id.'&aiseogeo_error='.rawurlencode($result->get_error_message()))); exit; } $gate->track('audit'); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-audit-report&audit_id='.absint($result->id).'&created=1')); exit; }
    public function create_rewrite_plan() { if (!current_user_can('aiseogeo_run_rewrite')) { wp_die('Недостаточно прав.'); } $post_id=absint($_POST['post_id'] ?? 0); $audit_id=absint($_POST['audit_id'] ?? 0); $mode=sanitize_key($_POST['rewrite_mode'] ?? 'soft_improve'); check_admin_referer('aiseogeo_create_rewrite_plan_' . $post_id . '_' . $audit_id); $gate=$this->redirect_license_error('rewrite_plan', admin_url('admin.php?page=aiseogeo-rewrite-create&post_id='.$post_id.'&audit_id='.$audit_id)); $result=$this->rewrite_service->create_rewrite($post_id,$audit_id,$mode); if(is_wp_error($result)){wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rewrite-create&post_id='.$post_id.'&audit_id='.$audit_id.'&aiseogeo_error='.rawurlencode($result->get_error_message()))); exit;} $gate->track('rewrite_plan'); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rewrite-plan&rewrite_id='.absint($result->id))); exit; }
    public function run_rewrite() { if (!current_user_can('aiseogeo_run_rewrite')) { wp_die('Недостаточно прав.'); } $rewrite_id=absint($_POST['rewrite_id'] ?? 0); check_admin_referer('aiseogeo_run_rewrite_' . $rewrite_id); $gate=$this->redirect_license_error('rewrite', admin_url('admin.php?page=aiseogeo-rewrite-plan&rewrite_id='.$rewrite_id)); $result=$this->rewrite_service->run_rewrite($rewrite_id); if(is_wp_error($result)){wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rewrite-plan&rewrite_id='.$rewrite_id.'&aiseogeo_error='.rawurlencode($result->get_error_message()))); exit;} $gate->track('rewrite'); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id='.absint($rewrite_id).'&created=1')); exit; }
    public function create_rewrite_draft() { if (!current_user_can('aiseogeo_run_rewrite')) { wp_die('Недостаточно прав.'); } $rewrite_id=absint($_POST['rewrite_id'] ?? 0); check_admin_referer('aiseogeo_create_rewrite_draft_' . $rewrite_id); $gate=$this->redirect_license_error('draft_create', admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id='.$rewrite_id)); $draft_service=new AISEOGEO_Draft_Service($this->rewrite_service); $draft_id=$draft_service->create_draft_from_rewrite($rewrite_id); if(is_wp_error($draft_id)){wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id='.$rewrite_id.'&aiseogeo_error='.rawurlencode($draft_id->get_error_message()))); exit;} $gate->track('draft_create'); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id='.$rewrite_id.'&draft_created='.absint($draft_id))); exit; }
    public function reaudit_rewrite() { if (!current_user_can('aiseogeo_run_rewrite')) { wp_die('Недостаточно прав.'); } $rewrite_id=absint($_POST['rewrite_id'] ?? 0); check_admin_referer('aiseogeo_reaudit_rewrite_' . $rewrite_id); $gate=$this->redirect_license_error('re_audit', admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id='.$rewrite_id)); $rewrite=$this->rewrite_service->get_rewrite($rewrite_id); $result=$this->audit_service->run_rewrite_audit($rewrite); if(is_wp_error($result)){wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id='.$rewrite_id.'&aiseogeo_error='.rawurlencode($result->get_error_message()))); exit;} $this->rewrite_service->mark_reaudited($rewrite_id, $result->id); $gate->track('re_audit'); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id='.$rewrite_id.'&reaudited=1')); exit; }
    public function delete_rewrite() { if (!current_user_can('aiseogeo_delete_versions')) { wp_die('Недостаточно прав.'); } $rewrite_id=absint($_POST['rewrite_id'] ?? 0); check_admin_referer('aiseogeo_delete_rewrite_' . $rewrite_id); $this->rewrite_service->delete_rewrite($rewrite_id); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-versions&deleted=1')); exit; }
    public function delete_version() { if (!current_user_can('aiseogeo_delete_versions')) { wp_die('Недостаточно прав.'); } $version_id=absint($_POST['version_id'] ?? 0); check_admin_referer('aiseogeo_delete_version_' . $version_id); $vs=new AISEOGEO_Version_Service(); $vs->delete_version($version_id); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-versions&deleted=1')); exit; }
    public function apply_rewrite() { if (!current_user_can('aiseogeo_apply_rewrite')) { wp_die('Недостаточно прав.'); } $rewrite_id=absint($_POST['rewrite_id'] ?? 0); check_admin_referer('aiseogeo_apply_rewrite_' . $rewrite_id); $gate=$this->redirect_license_error('apply', admin_url('admin.php?page=aiseogeo-apply-confirm&rewrite_id='.$rewrite_id)); $fields=isset($_POST['fields'])?(array)$_POST['fields']:array(); $service=new AISEOGEO_Apply_Service($this->rewrite_service,$this->logger); $result=$service->apply($rewrite_id,$fields); if(is_wp_error($result)){wp_safe_redirect(admin_url('admin.php?page=aiseogeo-apply-confirm&rewrite_id='.$rewrite_id.'&aiseogeo_error='.rawurlencode($result->get_error_message()))); exit;} $gate->track('apply'); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rewrite-result&rewrite_id='.$rewrite_id.'&applied=1&backup_id='.absint($result['backup_id']))); exit; }
    public function rollback_backup() { if (!current_user_can('aiseogeo_rollback')) { wp_die('Недостаточно прав.'); } $backup_id=absint($_POST['backup_id'] ?? 0); check_admin_referer('aiseogeo_rollback_backup_' . $backup_id); $gate=$this->redirect_license_error('rollback', admin_url('admin.php?page=aiseogeo-rollback&backup_id='.$backup_id)); $fields=isset($_POST['fields'])?(array)$_POST['fields']:array('title','content','excerpt','meta'); $service=new AISEOGEO_Rollback_Service($this->logger); $result=$service->rollback($backup_id,$fields); if(is_wp_error($result)){wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rollback&backup_id='.$backup_id.'&aiseogeo_error='.rawurlencode($result->get_error_message()))); exit;} $gate->track('rollback'); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-rollback&post_id='.absint($result['post_id']).'&rolled_back=1')); exit; }
    public function save_license() { if (!current_user_can('aiseogeo_manage_license')) { wp_die('Недостаточно прав.'); } check_admin_referer('aiseogeo_save_license'); $license = new AISEOGEO_License_Client($this->settings, $this->logger); $license->save_settings($_POST); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-license&saved=1')); exit; }
    public function check_license() { if (!current_user_can('aiseogeo_manage_license')) { wp_die('Недостаточно прав.'); } check_admin_referer('aiseogeo_check_license'); $license = new AISEOGEO_License_Client($this->settings, $this->logger); $result = $license->validate(); if (is_wp_error($result)) { wp_safe_redirect(admin_url('admin.php?page=aiseogeo-license&aiseogeo_error=' . rawurlencode($result->get_error_message()))); exit; } wp_safe_redirect(admin_url('admin.php?page=aiseogeo-license&checked=1')); exit; }
    public function create_bulk_job() { if (!current_user_can('aiseogeo_bulk_process')) { wp_die('Недостаточно прав.'); } check_admin_referer('aiseogeo_create_bulk_job'); $gate=$this->redirect_license_error('bulk_process', admin_url('admin.php?page=aiseogeo-bulk')); $bulk=new AISEOGEO_Bulk_Job_Service($this->audit_service,$this->rewrite_service,$this->logger,$this->settings); $job_type=sanitize_key($_POST['job_type'] ?? 'audit'); $mode=sanitize_key($_POST['job_mode'] ?? 'soft_improve'); $filter=sanitize_key($_POST['post_filter'] ?? 'all_published'); $limit=absint($_POST['limit'] ?? 10); $category=absint($_POST['category'] ?? 0); $job=$bulk->create_job($job_type,$mode,$filter,$limit,$category); if(is_wp_error($job)){wp_safe_redirect(admin_url('admin.php?page=aiseogeo-bulk&aiseogeo_error='.rawurlencode($job->get_error_message()))); exit;} $gate->track('bulk_job'); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-bulk-job&job_id='.absint($job->id).'&created=1')); exit; }
    public function pause_bulk_job() { if (!current_user_can('aiseogeo_bulk_process')) { wp_die('Недостаточно прав.'); } $job_id=absint($_POST['job_id'] ?? 0); check_admin_referer('aiseogeo_pause_bulk_job_' . $job_id); (new AISEOGEO_Bulk_Job_Service($this->audit_service,$this->rewrite_service,$this->logger,$this->settings))->pause_job($job_id); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-bulk-job&job_id='.$job_id.'&paused=1')); exit; }
    public function resume_bulk_job() { if (!current_user_can('aiseogeo_bulk_process')) { wp_die('Недостаточно прав.'); } $job_id=absint($_POST['job_id'] ?? 0); check_admin_referer('aiseogeo_resume_bulk_job_' . $job_id); (new AISEOGEO_Bulk_Job_Service($this->audit_service,$this->rewrite_service,$this->logger,$this->settings))->resume_job($job_id); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-bulk-job&job_id='.$job_id.'&resumed=1')); exit; }
    public function cancel_bulk_job() { if (!current_user_can('aiseogeo_bulk_process')) { wp_die('Недостаточно прав.'); } $job_id=absint($_POST['job_id'] ?? 0); check_admin_referer('aiseogeo_cancel_bulk_job_' . $job_id); (new AISEOGEO_Bulk_Job_Service($this->audit_service,$this->rewrite_service,$this->logger,$this->settings))->cancel_job($job_id); wp_safe_redirect(admin_url('admin.php?page=aiseogeo-bulk-job&job_id='.$job_id.'&cancelled=1')); exit; }

}
<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Logger {
    public function table() { global $wpdb; return $wpdb->prefix . 'aiseogeo_logs'; }
    public function log($level, $context, $message, $data = array(), $post_id = null) {
        global $wpdb;
        $wpdb->insert($this->table(), array(
            'level' => sanitize_text_field($level),
            'context' => sanitize_text_field($context),
            'post_id' => $post_id ? absint($post_id) : null,
            'message' => wp_kses_post($message),
            'data_json' => wp_json_encode($data, JSON_UNESCAPED_UNICODE),
            'created_at' => current_time('mysql'),
        ));
    }
    public function recent($limit = 20) {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->table()} ORDER BY id DESC LIMIT %d", absint($limit)));
    }
}

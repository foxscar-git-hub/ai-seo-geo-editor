<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_REST_Controller {
    private $audit_service; private $settings; private $logger; private $rewrite_service;
    public function __construct($audit_service, $settings, $logger, $rewrite_service = null) { $this->audit_service=$audit_service; $this->settings=$settings; $this->logger=$logger; $this->rewrite_service=$rewrite_service; }
    public function init() { add_action('rest_api_init', array($this,'routes')); }
    public function routes() {
        register_rest_route('aiseogeo/v1','/status',array('methods'=>'GET','callback'=>array($this,'status'),'permission_callback'=>array($this,'can_view')));
        register_rest_route('aiseogeo/v1','/settings',array(array('methods'=>'GET','callback'=>array($this,'settings'),'permission_callback'=>array($this,'can_manage')),array('methods'=>'POST','callback'=>array($this,'save_settings'),'permission_callback'=>array($this,'can_manage'))));
        register_rest_route('aiseogeo/v1','/openrouter/test',array('methods'=>'POST','callback'=>array($this,'openrouter_test'),'permission_callback'=>array($this,'can_manage')));
        register_rest_route('aiseogeo/v1','/posts',array('methods'=>'GET','callback'=>array($this,'posts'),'permission_callback'=>array($this,'can_view')));
        register_rest_route('aiseogeo/v1','/posts/(?P<post_id>\d+)/audit',array('methods'=>'POST','callback'=>array($this,'run_audit'),'permission_callback'=>array($this,'can_run')));
        register_rest_route('aiseogeo/v1','/posts/(?P<post_id>\d+)/audits',array('methods'=>'GET','callback'=>array($this,'post_audits'),'permission_callback'=>array($this,'can_view')));
        register_rest_route('aiseogeo/v1','/audits/(?P<audit_id>\d+)',array('methods'=>'GET','callback'=>array($this,'audit'),'permission_callback'=>array($this,'can_view')));
        register_rest_route('aiseogeo/v1','/history',array('methods'=>'GET','callback'=>array($this,'history'),'permission_callback'=>array($this,'can_view')));
        register_rest_route('aiseogeo/v1','/logs',array('methods'=>'GET','callback'=>array($this,'logs'),'permission_callback'=>array($this,'can_manage')));
        register_rest_route('aiseogeo/v1','/diagnostics',array('methods'=>'GET','callback'=>array($this,'diagnostics'),'permission_callback'=>array($this,'can_manage')));
        register_rest_route('aiseogeo/v1','/posts/(?P<post_id>\d+)/rewrite-plan',array('methods'=>'POST','callback'=>array($this,'rewrite_plan'),'permission_callback'=>array($this,'can_rewrite')));
        register_rest_route('aiseogeo/v1','/rewrites/(?P<rewrite_id>\d+)/run',array('methods'=>'POST','callback'=>array($this,'rewrite_run'),'permission_callback'=>array($this,'can_rewrite')));
        register_rest_route('aiseogeo/v1','/rewrites/(?P<rewrite_id>\d+)',array(array('methods'=>'GET','callback'=>array($this,'rewrite_get'),'permission_callback'=>array($this,'can_view')),array('methods'=>'DELETE','callback'=>array($this,'rewrite_delete'),'permission_callback'=>array($this,'can_delete_versions'))));
        register_rest_route('aiseogeo/v1','/posts/(?P<post_id>\d+)/rewrites',array('methods'=>'GET','callback'=>array($this,'post_rewrites'),'permission_callback'=>array($this,'can_view')));
        register_rest_route('aiseogeo/v1','/rewrites/(?P<rewrite_id>\d+)/create-draft',array('methods'=>'POST','callback'=>array($this,'rewrite_draft'),'permission_callback'=>array($this,'can_rewrite')));
        register_rest_route('aiseogeo/v1','/rewrites/(?P<rewrite_id>\d+)/re-audit',array('methods'=>'POST','callback'=>array($this,'rewrite_reaudit'),'permission_callback'=>array($this,'can_rewrite')));
        register_rest_route('aiseogeo/v1','/rewrites/(?P<rewrite_id>\d+)/compare',array('methods'=>'GET','callback'=>array($this,'rewrite_compare'),'permission_callback'=>array($this,'can_view')));
        register_rest_route('aiseogeo/v1','/rewrites/(?P<rewrite_id>\d+)/apply',array('methods'=>'POST','callback'=>array($this,'rewrite_apply'),'permission_callback'=>array($this,'can_apply')));
        register_rest_route('aiseogeo/v1','/posts/(?P<post_id>\d+)/backups',array('methods'=>'GET','callback'=>array($this,'post_backups'),'permission_callback'=>array($this,'can_view_versions')));
        register_rest_route('aiseogeo/v1','/backups/(?P<backup_id>\d+)/rollback',array('methods'=>'POST','callback'=>array($this,'rollback_backup'),'permission_callback'=>array($this,'can_rollback')));
        register_rest_route('aiseogeo/v1','/jobs',array(array('methods'=>'GET','callback'=>array($this,'jobs'),'permission_callback'=>array($this,'can_bulk')),array('methods'=>'POST','callback'=>array($this,'job_create'),'permission_callback'=>array($this,'can_bulk'))));
        register_rest_route('aiseogeo/v1','/jobs/(?P<job_id>\d+)',array('methods'=>'GET','callback'=>array($this,'job_get'),'permission_callback'=>array($this,'can_bulk')));
        register_rest_route('aiseogeo/v1','/jobs/(?P<job_id>\d+)/pause',array('methods'=>'POST','callback'=>array($this,'job_pause'),'permission_callback'=>array($this,'can_bulk')));
        register_rest_route('aiseogeo/v1','/jobs/(?P<job_id>\d+)/resume',array('methods'=>'POST','callback'=>array($this,'job_resume'),'permission_callback'=>array($this,'can_bulk')));
        register_rest_route('aiseogeo/v1','/jobs/(?P<job_id>\d+)/cancel',array('methods'=>'POST','callback'=>array($this,'job_cancel'),'permission_callback'=>array($this,'can_bulk')));
        register_rest_route('aiseogeo/v1','/site-report',array('methods'=>'GET','callback'=>array($this,'site_report'),'permission_callback'=>array($this,'can_view')));
        register_rest_route('aiseogeo/v1','/apply-logs',array('methods'=>'GET','callback'=>array($this,'apply_logs'),'permission_callback'=>array($this,'can_view_versions')));
        register_rest_route('aiseogeo/v1','/versions',array('methods'=>'GET','callback'=>array($this,'versions'),'permission_callback'=>array($this,'can_view_versions')));
        register_rest_route('aiseogeo/v1','/versions/(?P<version_id>\d+)',array(array('methods'=>'GET','callback'=>array($this,'version_get'),'permission_callback'=>array($this,'can_view_versions')),array('methods'=>'DELETE','callback'=>array($this,'version_delete'),'permission_callback'=>array($this,'can_delete_versions'))));
    }
    public function can_view(){return current_user_can('aiseogeo_view_reports');}
    public function can_run(){return current_user_can('aiseogeo_run_audit');}
    public function can_manage(){return current_user_can('aiseogeo_manage_settings');}
    public function can_rewrite(){return current_user_can('aiseogeo_run_rewrite');}
    public function can_view_versions(){return current_user_can('aiseogeo_view_versions');}
    public function can_delete_versions(){return current_user_can('aiseogeo_delete_versions');}
    public function can_apply(){return current_user_can('aiseogeo_apply_rewrite');}
    public function can_rollback(){return current_user_can('aiseogeo_rollback');}
    public function can_bulk(){return current_user_can('aiseogeo_bulk_process');}
    public function status(){return rest_ensure_response(array('version'=>AISEOGEO_VERSION,'stats'=>$this->audit_service->stats()));}
    public function settings(){ $all=$this->settings->all(); if(isset($all['api_key']) && $all['api_key']){$all['api_key']='***'.substr($all['api_key'],-4);} return rest_ensure_response($all); }
    public function save_settings($request){ $this->settings->save_from_request($request->get_params()); return rest_ensure_response(array('ok'=>true)); }
    public function openrouter_test(){ $client=new AISEOGEO_OpenRouter_Client($this->settings,$this->logger); $r=$client->test(); if(is_wp_error($r)){return $r;} return rest_ensure_response(array('ok'=>true,'model'=>$r['model'],'content'=>$r['content'])); }
    public function posts($request){ $q=new WP_Query(array('post_type'=>'post','posts_per_page'=>20,'post_status'=>'any','s'=>sanitize_text_field($request->get_param('search')))); $items=array(); foreach($q->posts as $p){$items[]=array('id'=>$p->ID,'title'=>get_the_title($p),'status'=>$p->post_status);} return rest_ensure_response($items); }
    private function license_gate(){ return new AISEOGEO_License_Gate($this->settings, $this->logger); }
    private function rest_require($feature){ $gate=$this->license_gate(); $check=$gate->require_feature($feature); return is_wp_error($check) ? $check : $gate; }
    public function run_audit($request){ $gate=$this->rest_require('audit'); if(is_wp_error($gate)){return $gate;} $r=$this->audit_service->run_audit(absint($request['post_id'])); if(is_wp_error($r)){return $r;} $gate->track('audit'); return rest_ensure_response($r); }
    public function post_audits($request){return rest_ensure_response($this->audit_service->get_post_audits(absint($request['post_id'])));}
    public function audit($request){return rest_ensure_response($this->audit_service->get_audit(absint($request['audit_id'])));}
    public function history(){return rest_ensure_response($this->audit_service->history(100));}
    public function logs(){return rest_ensure_response($this->logger->recent(100));}
    public function diagnostics(){return rest_ensure_response(array('version'=>AISEOGEO_VERSION,'stats'=>$this->audit_service->stats(),'settings'=>$this->settings->all()));}
    public function rewrite_plan($request){ $gate=$this->rest_require('rewrite_plan'); if(is_wp_error($gate)){return $gate;} $r=$this->rewrite_service->create_rewrite(absint($request['post_id']), absint($request->get_param('audit_id')), sanitize_key($request->get_param('rewrite_mode') ?: 'soft_improve')); if(is_wp_error($r)){return $r;} $gate->track('rewrite_plan'); return rest_ensure_response($r); }
    public function rewrite_run($request){ $gate=$this->rest_require('rewrite'); if(is_wp_error($gate)){return $gate;} $r=$this->rewrite_service->run_rewrite(absint($request['rewrite_id'])); if(is_wp_error($r)){return $r;} $gate->track('rewrite'); return rest_ensure_response($r); }
    public function rewrite_get($request){ return rest_ensure_response($this->rewrite_service->get_rewrite(absint($request['rewrite_id']))); }
    public function post_rewrites($request){ return rest_ensure_response($this->rewrite_service->get_post_rewrites(absint($request['post_id']))); }
    public function rewrite_draft($request){ $gate=$this->rest_require('draft_create'); if(is_wp_error($gate)){return $gate;} $draft_service=new AISEOGEO_Draft_Service($this->rewrite_service); $r=$draft_service->create_draft_from_rewrite(absint($request['rewrite_id'])); if(is_wp_error($r)){return $r;} $gate->track('draft_create'); return rest_ensure_response(array('draft_id'=>$r)); }
    public function rewrite_reaudit($request){ $gate=$this->rest_require('re_audit'); if(is_wp_error($gate)){return $gate;} $rewrite=$this->rewrite_service->get_rewrite(absint($request['rewrite_id'])); $r=$this->audit_service->run_rewrite_audit($rewrite); if(is_wp_error($r)){return $r;} $this->rewrite_service->mark_reaudited(absint($request['rewrite_id']), $r->id); $gate->track('re_audit'); return rest_ensure_response($r); }
    public function rewrite_compare($request){ $c=new AISEOGEO_Comparison_Service($this->rewrite_service,$this->audit_service); return rest_ensure_response($c->get_score_comparison(absint($request['rewrite_id']))); }
    public function rewrite_delete($request){ $this->rewrite_service->delete_rewrite(absint($request['rewrite_id'])); return rest_ensure_response(array('ok'=>true)); }
    public function versions(){ $vs=new AISEOGEO_Version_Service(); return rest_ensure_response($vs->get_versions(100)); }
    public function version_get($request){ $vs=new AISEOGEO_Version_Service(); return rest_ensure_response($vs->get_version(absint($request['version_id']))); }
    public function version_delete($request){ $vs=new AISEOGEO_Version_Service(); $vs->delete_version(absint($request['version_id'])); return rest_ensure_response(array('ok'=>true)); }
    public function rewrite_apply($request){ $gate=$this->rest_require('apply'); if(is_wp_error($gate)){return $gate;} $fields=$request->get_param('fields'); if(!$fields){$fields=array('title','content','excerpt','meta_title','meta_description');} $service=new AISEOGEO_Apply_Service($this->rewrite_service,$this->logger); $r=$service->apply(absint($request['rewrite_id']),(array)$fields); if(is_wp_error($r)){return $r;} $gate->track('apply'); return rest_ensure_response($r); }
    public function post_backups($request){ $service=new AISEOGEO_Backup_Service(); return rest_ensure_response($service->get_post_backups(absint($request['post_id']),50)); }
    public function rollback_backup($request){ $gate=$this->rest_require('rollback'); if(is_wp_error($gate)){return $gate;} $fields=$request->get_param('fields') ?: array('title','content','excerpt','meta'); $service=new AISEOGEO_Rollback_Service($this->logger); $r=$service->rollback(absint($request['backup_id']),(array)$fields); if(is_wp_error($r)){return $r;} $gate->track('rollback'); return rest_ensure_response($r); }
    private function bulk_service(){ return new AISEOGEO_Bulk_Job_Service($this->audit_service,$this->rewrite_service,$this->logger,$this->settings); }
    public function jobs(){ return rest_ensure_response($this->bulk_service()->get_jobs(50)); }
    public function job_create($request){ $gate=$this->rest_require('bulk_process'); if(is_wp_error($gate)){return $gate;} $r=$this->bulk_service()->create_job(sanitize_key($request->get_param('job_type') ?: 'audit'), sanitize_key($request->get_param('job_mode') ?: 'soft_improve'), sanitize_key($request->get_param('post_filter') ?: 'all_published'), absint($request->get_param('limit') ?: 5), absint($request->get_param('category') ?: 0)); if(is_wp_error($r)){return $r;} $gate->track('bulk_job'); return rest_ensure_response($r); }
    public function job_get($request){ $svc=$this->bulk_service(); return rest_ensure_response(array('job'=>$svc->get_job(absint($request['job_id'])),'items'=>$svc->get_job_items(absint($request['job_id']),300))); }
    public function job_pause($request){ $this->bulk_service()->pause_job(absint($request['job_id'])); return rest_ensure_response(array('ok'=>true)); }
    public function job_resume($request){ $this->bulk_service()->resume_job(absint($request['job_id'])); return rest_ensure_response(array('ok'=>true)); }
    public function job_cancel($request){ $this->bulk_service()->cancel_job(absint($request['job_id'])); return rest_ensure_response(array('ok'=>true)); }
    public function site_report(){ $service=new AISEOGEO_Site_Report_Service($this->audit_service); return rest_ensure_response($service->report()); }
    public function apply_logs(){ return rest_ensure_response((new AISEOGEO_Apply_Log_Service())->history(100)); }

}
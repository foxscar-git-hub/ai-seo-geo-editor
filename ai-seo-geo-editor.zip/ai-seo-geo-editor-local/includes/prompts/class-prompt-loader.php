<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Prompt_Loader {

    /** Returns audit system prompt, optionally with learning insights appended. */
    public static function audit_system() {
        $base = include AISEOGEO_DIR . 'includes/prompts/audit-system-prompt.php';
        return $base . self::learning_block('audit');
    }

    public static function audit_user($post_data) {
        $template = include AISEOGEO_DIR . 'includes/prompts/audit-user-prompt.php';
        return str_replace('{{POST_JSON}}', wp_json_encode($post_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $template);
    }

    /** Returns rewrite-plan system prompt, optionally with learning insights appended. */
    public static function rewrite_plan_system() {
        $base = include AISEOGEO_DIR . 'includes/prompts/rewrite-plan-system-prompt.php';
        return $base . self::learning_block('rewrite');
    }

    public static function rewrite_plan_user($payload) {
        $template = include AISEOGEO_DIR . 'includes/prompts/rewrite-plan-user-prompt.php';
        return str_replace('{{PAYLOAD_JSON}}', wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $template);
    }

    /** Returns rewrite system prompt, optionally with learning insights appended. */
    public static function rewrite_system() {
        $base = include AISEOGEO_DIR . 'includes/prompts/rewrite-system-prompt.php';
        return $base . self::learning_block('rewrite');
    }

    public static function rewrite_user($payload) {
        $template = include AISEOGEO_DIR . 'includes/prompts/rewrite-user-prompt.php';
        return str_replace('{{PAYLOAD_JSON}}', wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $template);
    }

    public static function re_audit_system() { return include AISEOGEO_DIR . 'includes/prompts/re-audit-system-prompt.php'; }
    public static function re_audit_user($payload) { $t = include AISEOGEO_DIR . 'includes/prompts/re-audit-user-prompt.php'; return str_replace('{{PAYLOAD_JSON}}', wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $t); }

    /**
     * Returns the learning insights block if learning is enabled and configured.
     * $context = 'audit' | 'rewrite'
     */
    private static function learning_block($context) {
        if (!class_exists('AISEOGEO_Learning_Service')) { return ''; }

        $plugin = AISEOGEO_Plugin::instance();
        if (!$plugin || !isset($plugin->settings)) { return ''; }

        $inject_key = 'learning_inject_' . $context;
        if ($plugin->settings->get($inject_key, '1') !== '1') { return ''; }
        if ($plugin->settings->get('learning_enabled', '0') !== '1') { return ''; }

        if (!isset($plugin->learning_service)) { return ''; }

        return $plugin->learning_service->get_insights_block();
    }
}

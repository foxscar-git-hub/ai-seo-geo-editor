<?php
if (!defined('ABSPATH')) { exit; }
class AISEOGEO_Action_Scheduler {
    private $audit_service; private $rewrite_service; private $logger; private $settings;
    public function __construct($audit_service, $rewrite_service, $logger, $settings) { $this->audit_service=$audit_service; $this->rewrite_service=$rewrite_service; $this->logger=$logger; $this->settings=$settings; }
    public function init() { add_action('aiseogeo_process_bulk_job_item', array($this, 'process_job_item'), 10, 1); }
    public static function schedule_next($job_id, $delay = 30) {
        $timestamp = time() + max(1, absint($delay));
        if (function_exists('as_schedule_single_action')) {
            as_schedule_single_action($timestamp, 'aiseogeo_process_bulk_job_item', array(absint($job_id)), 'aiseogeo');
        } else {
            wp_schedule_single_event($timestamp, 'aiseogeo_process_bulk_job_item', array(absint($job_id)));
        }
    }
    public function process_job_item($job_id) {
        $service = new AISEOGEO_Bulk_Job_Service($this->audit_service, $this->rewrite_service, $this->logger, $this->settings);
        $service->process_next_item(absint($job_id));
    }
}
